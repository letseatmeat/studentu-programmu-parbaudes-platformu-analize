
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>
#include <string>

using namespace std;

string rmWhiteSpace(const string &givStr);
bool validFloatCheck(const string &givStr);
void saveFileFromPth(const string &fullPthFile, vector<string> strBusVect);
void consOut(const string &busRoutesStr);
vector<string> loadFromFilePth(const string &fullPthFile);

struct busRouteStruct {
    string firstStop;
    string lastStop;
    string arrivingDay;
    string arrivingTime;
    double routePrice{};
};
void busRouteConsOut(const busRouteStruct &busRoutesStr);
bool loadBusCheck(const string &currGivRoute, vector<busRouteStruct> &routVect);

vector<string> vectCommaSplit(const string &givenTxt) { 
    vector<string> busRoutesStr;
    istringstream istreamString(givenTxt);
    string splTXT;

    while (getline(istreamString, splTXT, ',')) {
        busRoutesStr.push_back(splTXT);
    }
    return busRoutesStr;

}

bool validFloatCheck(const string &givStr) {
    istringstream istreamString(givStr);
    float f;
    istreamString >> noskipws >> f;
    return istreamString.eof() && !istreamString.fail();
}

vector<busRouteStruct>searchByRouteVect(const string &usrFirstRoute, const string &usrSecRoute,
                                         const vector<busRouteStruct> &vctBusRout) {
    vector<busRouteStruct> selectedBusRts;
      for (const busRouteStruct &busRouteStruct: vctBusRout) {
        if (busRouteStruct.firstStop == usrFirstRoute &&
            busRouteStruct.lastStop == usrSecRoute)
            selectedBusRts.push_back(busRouteStruct);
    }
    return selectedBusRts;
}


string rmWhiteSpace(const string &givStr) {
    string selectedBusRts;
    string::const_iterator rmWhitespaceSTR = find_if(givStr.begin(), givStr.end(),
                                                   [](char busRoutesStr) { return busRoutesStr != ' '; });
    unique_copy(rmWhitespaceSTR, givStr.end(), back_insert_iterator<string>(selectedBusRts),
                [](char a, char b) { return isspace(a) && isspace(b); });
    return selectedBusRts;
}

void saveFileFromPth(const string &fullPthFile, vector<string> strBusVect) {
    ofstream selectedBusRts(fullPthFile);
    streambuf *sbStr = cout.rdbuf();
    cout.rdbuf(selectedBusRts.rdbuf());
    for_each(strBusVect.begin(), strBusVect.end(), consOut);
    cout.rdbuf(sbStr);
}

vector<string> loadFromFilePth(const string &fullPthFile) {
    vector<string> selectedBusRts;

    ifstream iStreamF(fullPthFile);
    streambuf *stB = cin.rdbuf();
    cin.rdbuf(iStreamF.rdbuf());
    string currGivRoute;
    while (getline(cin, currGivRoute)) {
        if (currGivRoute.length() != 0)
            selectedBusRts.push_back(currGivRoute);
    }

    cin.rdbuf(stB);
    return selectedBusRts;
}

vector<busRouteStruct> searchByDayVect(const string &givenUsrDay,
                                          const vector<busRouteStruct> &vctBusRout) {
    vector<busRouteStruct> selectedBusRts;
    for (const busRouteStruct &busRouteStruct: vctBusRout) {
        string arrivingDay = busRouteStruct.arrivingDay;
        transform(arrivingDay.begin(), arrivingDay.end(), arrivingDay.begin(), ::tolower);
        if (arrivingDay == givenUsrDay) selectedBusRts.push_back(busRouteStruct);
    }
    return selectedBusRts;
}

vector<busRouteStruct> searchByPriceVect(float usrGivenPrice,
                                          const vector<busRouteStruct> &vctBusRout) {
    vector<busRouteStruct> selectedBusRts;
    for (const busRouteStruct &busRouteStruct: vctBusRout) {
        if (busRouteStruct.routePrice <= usrGivenPrice) selectedBusRts.push_back(busRouteStruct);
    }
    return selectedBusRts;
}

bool loadBusCheck(const string &currGivRoute, vector<busRouteStruct> &routVect) {
    int currPos = 0;
    bool routeLoaded = true;
    busRouteStruct currBusVect;
    string removedWS = rmWhiteSpace(currGivRoute);
    vector<string> splittedVect = vectCommaSplit(removedWS);
    if (splittedVect.size() != 5) return false;
    for (auto currSelectedRoute: splittedVect) {
        currSelectedRoute = rmWhiteSpace(currSelectedRoute);
        currSelectedRoute.erase(remove(currSelectedRoute.begin(),
                                   currSelectedRoute.end(), ' '), currSelectedRoute.end());
        currSelectedRoute.erase(remove(currSelectedRoute.begin(),
                                   currSelectedRoute.end(), '\r'), currSelectedRoute.end());
        if (currSelectedRoute.length() == 0) return false;
        switch (currPos) {
            case 0:
                currSelectedRoute.erase(remove_if(currSelectedRoute.begin(),
                                              currSelectedRoute.end(), ::isspace),
                                    currSelectedRoute.end());
                currBusVect.firstStop = currSelectedRoute;
                break;
            case 1:
                currSelectedRoute.erase(remove_if(currSelectedRoute.begin(),
                                              currSelectedRoute.end(), ::isspace),
                                    currSelectedRoute.end());
                currBusVect.lastStop = currSelectedRoute;
                break;
            case 2: {
                string routeWorkingDays[] = {"pr", "ot", "tr", "ce", "pt", "st", "sv"};

                currSelectedRoute.erase(
                        remove_if(currSelectedRoute.begin(), currSelectedRoute.end(), ::isspace),
                        currSelectedRoute.end());
                transform(currSelectedRoute.begin(), currSelectedRoute.end(),
                          currSelectedRoute.begin(), ::tolower);

                for (auto &arrivingDay: routeWorkingDays) {
                    if (currSelectedRoute == arrivingDay) {
                        currBusVect.arrivingDay = currSelectedRoute;
                    }
                }

                break;
            }

            case 3: {
                if (currSelectedRoute.length() < 5) return false;
                currSelectedRoute.erase(remove_if(currSelectedRoute.begin(),
                                              currSelectedRoute.end(), ::isspace),
                                    currSelectedRoute.end());
                int optRouteHours = stoi(currSelectedRoute.substr(0, 2));
                int optRouteMinutes = stoi(currSelectedRoute.substr(3, 4));

                if (optRouteHours >= 0 && optRouteHours < 24 && optRouteMinutes >= 0 && optRouteMinutes < 60) {
                    currBusVect.arrivingTime = currSelectedRoute;
                } else return false;
                break;
            }
            case 4: {
                currSelectedRoute.erase(remove_if(currSelectedRoute.begin(),
                                              currSelectedRoute.end(), ::isspace),
                                    currSelectedRoute.end());
                if (validFloatCheck(currSelectedRoute)) {
                    currBusVect.routePrice = stod(currSelectedRoute);
                } else {
                    return false;
                }
                break;
            }
            default:
                return false;
        }
        currPos++;

    }
    if (currPos != 5) return false;
    routVect.push_back(currBusVect);
    return routeLoaded;
}

void consOut(const string &busRoutesStr) {
    cout << busRoutesStr << endl;
}

void busRouteConsOut(const busRouteStruct &busRoutesStr) {
    cout << fixed;
    cout << setprecision(2);
    string arrivingDay = busRoutesStr.arrivingDay;
    arrivingDay[0] = toupper(arrivingDay[0]);
    string selectedBusRts =
            busRoutesStr.firstStop + " " + busRoutesStr.lastStop + " " + arrivingDay + " " +
            busRoutesStr.arrivingTime + " " + to_string(busRoutesStr.routePrice);
    selectedBusRts.erase(remove(selectedBusRts.begin(), selectedBusRts.end(), '\r'),
                                 selectedBusRts.end());
    cout << selectedBusRts.substr(0, selectedBusRts.length() - 4) << endl;
}

int main() {
    vector<string> vectCSV = loadFromFilePth("db.csv");
    vector<string> failedToLoad;
    vector<busRouteStruct> vctBusRout;

    for (string &currGivRoute: vectCSV) {
        if (!loadBusCheck(currGivRoute, vctBusRout)) {
            if (isalpha(currGivRoute[0])) {
                currGivRoute.erase(remove(currGivRoute.begin(), currGivRoute.end(), ' '), currGivRoute.end());
                currGivRoute.erase(remove(currGivRoute.begin(), currGivRoute.end(), '\r'), currGivRoute.end());
                failedToLoad.push_back(currGivRoute);
            } else {
                continue;
            }
        }
    }

    saveFileFromPth("err.txt", failedToLoad);

    bool continueToRun = true;
    string usrIn;

    while (continueToRun) {
        cin >> usrIn;

        if (usrIn == "a" || usrIn == "A") {
            string usrFirstStop;
            cin >> usrFirstStop;
            string usrSecStop;
            cin >> usrSecStop;
            transform(usrFirstStop.begin(), usrFirstStop.end(), usrFirstStop.begin(), ::tolower);
            usrFirstStop[0] = toupper(usrFirstStop[0]);
            transform(usrSecStop.begin(), usrSecStop.end(), usrSecStop.begin(), ::tolower);
            usrSecStop[0] = toupper(usrSecStop[0]);

            vector<busRouteStruct> selRoutes = searchByRouteVect(usrFirstStop,
                                                                                          usrSecStop,
                                                                                          vctBusRout);
            cout << "result:" << endl;
            for (auto &selBusr: selRoutes) {
                busRouteConsOut(selBusr);
            }
            continue;
        } else if (usrIn == "b" || usrIn == "B") {
            string givenUsrDay;
            cin >> givenUsrDay;

            transform(givenUsrDay.begin(), givenUsrDay.end(), givenUsrDay.begin(),
                      ::tolower);

            vector<busRouteStruct> selRoutes = searchByDayVect(givenUsrDay,
                                                                                        vctBusRout);
            cout << "result:" << endl;
            for (auto &selBusr: selRoutes) {
                busRouteConsOut(selBusr);
            }
            continue;
        } else if (usrIn == "c" || usrIn == "C") {
            string usrInPrice;
            cin >> usrInPrice;

            if (!validFloatCheck(usrInPrice)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                continue;
            }
            vector<busRouteStruct> selRoutes = searchByPriceVect(stof(usrInPrice),
                                                                                       vctBusRout);
            cout << "result:" << endl;
            for (auto &selBusr: selRoutes) {
                busRouteConsOut(selBusr);
            }

            continue;
        } else if (usrIn == "d" || usrIn == "D") {
            vector<string> loadFailedBus = loadFromFilePth("err.txt");
            cout << "result:" << endl;

            for (int selBusr = 0; selBusr < loadFailedBus.size(); ++selBusr) {
                cout << loadFailedBus[selBusr];
                if (selBusr == loadFailedBus.size() - 1) cout << "";
                cout << endl;
            }
        } else if (usrIn == "e") {
            continueToRun = false;
            continue;
        } else {
            continue;
        }
    }
}