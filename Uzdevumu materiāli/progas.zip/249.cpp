
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

// maršruta struktūras inicializācija
struct Route { 
  string beginCity;
  string endCity;
  string routeDay;
  string routTime;
  string routePrice;
};

// katra struktūras Route lauka pārbaude
bool checkRouteItem(string str, int count) {
   switch(count) {
    case 1 : {
      for (char ch: str) {
        if (ch == ':' || str.length() == 2 || ch == '.' || isdigit(ch)) {
          return false;
        }
      }
    } break;
    case 2 : {
      for (char ch: str) {
        if (ch == ':' || str.length() == 2 || ch == '.' || isdigit(ch)) 
          return false;
      }
    } break;
    case 3 : {
      if(str.length()!=2) return false;
      for (char ch: str) {
        if (isdigit(ch)) {
          return false;
        }
      }
    } break;
    case 4 : {
      if(str.length() !=5 || str.at(2) != ':') return false;
      for (int i = 0; i < str.length(); i++) {
        if (!isdigit(str.at(i)) && i != 2) {
          return false;
        }
      }
    } break;
    case 5 : {
      try {
        stod(str);
      } catch (...) {
        return false;
      }
    } break;
  }
  return true;
}

// funkcija izvada visus maršrutus no ievadītā sākumpunkta līdz ievadītajam galapunktam
void routeName(vector<Route> allRoutes, string fromCity, string toCity) {
  cout << "result:" << endl;
  for (int i = 0; i < allRoutes.size(); i++) {
    if (allRoutes[i].beginCity == fromCity && allRoutes[i].endCity == toCity) {
      cout << allRoutes[i].beginCity << " " << allRoutes[i].endCity << " " << allRoutes[i].routeDay << " " << allRoutes[i].routTime << " " << allRoutes[i].routePrice << endl;
    }
  }
};

// funkcija izvada visus maršrutus, kuri kursē ievadītajā dienā
void routeNameByDate(vector<Route> allRoutes, string routeDay) {
  cout << "result:" << endl;
  for (int i = 0; i < allRoutes.size(); i++) {
    if (allRoutes[i].routeDay == routeDay) {
      cout << allRoutes[i].beginCity << " " << allRoutes[i].endCity << " " << allRoutes[i].routeDay << " " << allRoutes[i].routTime << " " << allRoutes[i].routePrice << endl;
    }
  }
};

// funkcija izvada visus maršrutus, kuru cena nepārsniedz ievadīto
void routeNameByPrice(vector<Route> allRoutes, double routePrice) {
  cout << "result:" << endl;
  for (int i = 0; i < allRoutes.size(); i++) {
    if (stod(allRoutes[i].routePrice) <= routePrice) {
      cout << allRoutes[i].beginCity << " " << allRoutes[i].endCity << " " << allRoutes[i].routeDay << " " << allRoutes[i].routTime << " " << allRoutes[i].routePrice << endl;
    }
  }
};

int main() {
  ifstream inFile;
  ofstream writeFile;
  inFile.open("db.csv");
  writeFile.open("err.txt");
  vector<Route> allRoutes;
  int count;
	if (!inFile) return 0;
  
  string lineFromFile;
  string helpStr;
  string newlineFromFile;

  // rindu pēc rindas csv faila nolasīšana līdz pēdējai rindai failā
  while (getline(inFile,lineFromFile)) {
    newlineFromFile = "";
    // izlaiž rindu, ja tā ir tukša
    if (lineFromFile.empty() || lineFromFile.find_first_not_of(" \t\n\r") == string::npos) {
      continue;
    }
    // ar pirmā string stream palīdzību novāc liekās atstarpes
    stringstream removeSpaces(lineFromFile);
    while(removeSpaces >> helpStr) {
      newlineFromFile = newlineFromFile + helpStr;
    }
    helpStr = "";
    count = 0; // Route struktūras komponenšu skaits
    Route newRoute;
    // ar otrā string stream palīdzību sadala teksta līniju pēc simbola "," un sadalītās komponentes pārbauda uz pareizību
    stringstream splitByComma(newlineFromFile);
    while (getline(splitByComma, helpStr, ',')) {
      count++;
      if (count == 1) {
        if (checkRouteItem(helpStr, count)){
          newRoute.beginCity = helpStr;  
        } else {
          newRoute.beginCity = "";  
        }         
      } else if (count == 2) {
        if (checkRouteItem(helpStr, count)){
          newRoute.endCity = helpStr;
        } else {
          newRoute.endCity = "";
        }
      } else if (count == 3) {
        if (checkRouteItem(helpStr, count)){
          newRoute.routeDay = helpStr;
        } else {
          newRoute.routeDay = "";
        }       
      } else if (count == 4) {
        if (checkRouteItem(helpStr, count)){
          newRoute.routTime = helpStr;
        } else {
          newRoute.routTime = "";
        }
      } else if (count == 5) {
        if (checkRouteItem(helpStr, count)){
          newRoute.routePrice = helpStr;
        } else {
          newRoute.routePrice = "";  
        }
      } else if (count > 5) {
        newRoute.beginCity = ""; // var jebkuram laukam piešķir tukšumu un tad tas nepievienosies beigu vektoram
      }
    }
    // pārbaude vai ir kāds tukšs lauks Route struktūrā
    if (!newRoute.beginCity.empty() && !newRoute.endCity.empty() && !newRoute.routeDay.empty() && !newRoute.routTime.empty() &&  !newRoute.routePrice.empty()) {
      allRoutes.push_back(newRoute);
    } else {
      writeFile << lineFromFile << endl;
    }  
  }
  inFile.close();
  writeFile.close();

  // galvenais izvēles cikls
  char option;
  while(true) {
    cin >> option;
    switch (option) {
      case 'a' : {
        string fromCity, toCity;
        cin >> fromCity >> toCity;
        routeName(allRoutes, fromCity, toCity);
      } break;
      case 'b' : {
        string routeDay;
        cin >> routeDay;
        routeNameByDate(allRoutes, routeDay);
      } break;
      case 'c' : {
        double routePrice;
        cin >> routePrice;
        routeNameByPrice(allRoutes, routePrice);
      } break;
      case 'd' : {
        cout << "result:" << endl;
        inFile.open("err.txt");
        string errStr; 
        while (inFile >> errStr)
        {
          cout << errStr << endl;
        }
        inFile.close();
      } break;
      case 'e' : {
      return 0;
      } break;
    }
  } 
}  