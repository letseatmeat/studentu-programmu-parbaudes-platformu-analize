


#include <fstream>
#include <iomanip>
#include <string> 
#include <iostream> 
#include <sstream>
#include <vector>
#include <limits>
#include <algorithm> 
 
struct Route { 
  std::string pirma_piet;
  std::string pedeja_piet;
  std::string diena; 
  std::string laiks;
  double cena;
}; 

bool derigs_marsruts(const std::vector<std::string>& mezacuka) { 

  if (mezacuka.size() != 5 || mezacuka[3].find(':') == std::string::npos) { 
    return false;
  }

  char* beigas; 
  strtod(mezacuka[4].c_str(), &beigas);

  return *beigas == '\0'; 
  
} 


std::string apgr(const std::string &str) {
  size_t pirmais = str.find_first_not_of(' '); 
  if (std::string::npos == pirmais) { 
    return str;
  } 
  size_t pedejais = str.find_last_not_of(' ');
  return str.substr(pirmais, (pedejais - pirmais + 1));
}

bool tuksums(const std::string &str) {
  return std::all_of(str.begin(), str.end(), ::isspace);
}


std::vector<Route> lade_marsr(const std::string &faila_cels,
                              std::ofstream &errtxt) {
  std::vector<Route> marsruti;
  std::ifstream fails(faila_cels);

   
  std::string line;
  while (std::getline(fails, line)) {
    if (line.empty() || tuksums(line))
      continue;
 
    std::istringstream vk(line);
    std::string item;
    std::vector<std::string> mezacuka; 

    while (std::getline(vk, item, ',')) {
      mezacuka.push_back(apgr(item));
    }
 
    if (!derigs_marsruts(mezacuka)) {
      errtxt << line << '\n';
      continue;
    }

    Route jauns_marsr;
    try {
      jauns_marsr.pirma_piet = mezacuka[0];
      jauns_marsr.pedeja_piet = mezacuka[1];
      jauns_marsr.diena = mezacuka[2]; 
      jauns_marsr.laiks = mezacuka[3]; 
      jauns_marsr.cena = std::stod(mezacuka[4]);

      marsruti.push_back(jauns_marsr);
    } catch (const std::exception &e) {}
  }

  fails.close(); 
  return marsruti;
}
  
void radit_marsr(const std::vector<Route> &marsruti) {
  for (const auto &route : marsruti) {
    printf("%s %s %s %s %.2f\n", route.pirma_piet.c_str(), route.pedeja_piet.c_str(),
           route.diena.c_str(), route.laiks.c_str(), route.cena);
  }
}
 
int main() {
  std::ofstream errtxt("err.txt");
  std::vector<Route> marsruti = lade_marsr("db.csv", errtxt);

  errtxt.close();
  char komanda;
  do {

    std::cin >> komanda;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    switch (komanda) {
    case 'a': {

       
          std::string sakums, beigas;

          std::getline(std::cin, sakums);
          std::getline(std::cin, beigas);

          printf("result:\n");
          for (const auto &route : marsruti) {
              if (route.pirma_piet == sakums && route.pedeja_piet == beigas) {
                  radit_marsr({route});
              }
          }
          break;
      }

      
    case 'b': {
          std::string day;

          std::getline(std::cin, day);

          printf("result:\n");
          for (const auto &route : marsruti) {
              if (route.diena == day) {
                  radit_marsr({route});
              }
          }
          break;
      }  

      
    case 'c': {
          double max_cena;

          std::cin >> max_cena;
          std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

          printf("result:\n");
          for (const auto &route : marsruti) {
              if (route.cena <= max_cena) {
                  radit_marsr({route});
              }
             
          }
          break;
      } 

        
    case 'd': {
      
      std::ifstream infile("err.txt");
      if (!infile.is_open()) {
        std::cout << "nevar atvert failu" << std::endl;
      } 
      else {
        std::cout << "result:" << '\n';
        infile.seekg(0, std::ios::beg);

        std::string saturs;
        while (std::getline(infile, saturs)) {
          if (!saturs.empty() && saturs.find(",,") == std::string::npos) {
            std::cout << saturs << '\n';
          }
        }
        infile.close();
      }
      break;
    }
    case 'e': {

      break;
    }
    default: {
      std::cout << "nepareiza ievade" << '\n';
      break; 
    } 
    }
  } while (komanda != 'e'); 
  
  return 0;
   
}

 