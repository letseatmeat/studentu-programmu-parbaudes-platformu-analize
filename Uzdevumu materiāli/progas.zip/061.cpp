
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>

struct Route {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

std::string trim(const std::string& str) {
  size_t start = str.find_first_not_of(" \t");
  size_t end = str.find_last_not_of(" \t");
  if (start == std::string::npos || end == std::string::npos)
    return "";
  return str.substr(start, end - start + 1);
}

std::vector<Route> readRoutes(const std::string& filename, std::vector<std::string>& errors) {
  std::vector<Route> routes;
  std::ifstream file(filename);
  std::string line;
  while (std::getline(file, line)) {
    line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line.empty()) 
      continue;
    std::stringstream ss(line);
    std::string start, end, day, time;
    double price; char extra;
    int commasCount = std::count(line.begin(), line.end(), ',');
    if (commasCount != 4) {
      errors.push_back(line);
      continue;
    }

    if (std::getline(ss, start, ',') && std::getline(ss, end, ',') &&
      std::getline(ss, day, ',') && std::getline(ss, time, ',') &&
      ss >> price && !(ss >> extra)) {
        routes.push_back({start, end, day, time, price}); 
    } else {
      errors.push_back(line);
    }
  } return routes;
}

void writeErrors(const std::string& filename, const std::vector<std::string>& errors) {
  std::ofstream file(filename);
  for (const auto& error : errors) {
    file << error << "\n";
  }
}

void printRoutes(const std::vector<Route>& routes) {
  std::cout << "result:\n";
  for (const auto& route : routes) {
    std::cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " 
      << std::fixed << std::setprecision(2) << route.price << "\n";
    }
}

void printErrors(const std::vector<std::string>& errors) {
  std::cout << "result:\n";
  for (const auto& error : errors) {
    std::cout << error << "\n";
  }
}

int main() {
  std::vector<std::string> errors;
  std::vector<Route> routes = readRoutes("db.csv", errors);
  writeErrors("err.txt", errors);
  char command;
  while (std::cin >> command && command != 'e') {
    switch (command) {
      case 'a': {
        std::string start, end;
        std::cin >> start >> end;
        std::vector<Route> result;
        for (const auto& route : routes) {
          if (route.start == start && route.end == end) {
            result.push_back(route);
          }
        } printRoutes(result); break;
      }
      case 'b': {
        std::string day;
        std::cin >> day;
        std::vector<Route> result;
        for (const auto& route : routes) {
          if (route.day == day) {
            result.push_back(route);
          }
        } printRoutes(result); break;
      }
      case 'c': {
        double maxPrice;
        std::cin >> maxPrice;
        std::vector<Route> result;
        for (const auto& route : routes) {
          if (route.price <= maxPrice) {
            result.push_back(route);
          }
        } printRoutes(result); break;
      }
      case 'd': {
        printErrors(errors); break;
      }
    }
  } return 0;
}
