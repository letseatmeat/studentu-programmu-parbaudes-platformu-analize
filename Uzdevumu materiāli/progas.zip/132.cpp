
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// Sakum pietura = sP
// Gala pietura = gP
// Diena = day
// time = time
// Biletes cena = cen
struct Route {
    string sP;
    string gP;
    string day;
    string time;
    double cen;
};

vector<Route> checkRT(const string& filename, vector<string>& erroneousLines) {
    vector<Route> routes;
    ifstream file(filename);
    ofstream errFile("err.txt");
    string line;

    while (getline(file, line)) {
            if (line.empty()) {
            continue;}

        istringstream ss(line);
        string sP, gP, day, time;
        double cen;

        if (!(getline(ss, sP, ',') && getline(ss, gP, ',') &&
              getline(ss, day, ',') && getline(ss, time, ',') &&
              ss >> cen && ss.eof())) {  
            erroneousLines.push_back(line); 
            continue;  
        }

        sP.erase(0, sP.find_first_not_of(' '));
        sP.erase(sP.find_last_not_of(' ') + 1);
        gP.erase(0, gP.find_first_not_of(' '));
        gP.erase(gP.find_last_not_of(' ') + 1);
        day.erase(0, day.find_first_not_of(' '));
        day.erase(day.find_last_not_of(' ') + 1);
        time.erase(0, time.find_first_not_of(' '));
        time.erase(time.find_last_not_of(' ') + 1);
        routes.push_back({sP, gP, day, time, cen});
    }
    return routes;
}

void prtRT(const vector<Route>& routes) {
    for (const auto& route : routes) {
        cout << route.sP << " " << route.gP << " " << route.day << " "
                  << route.time << " " << fixed << setprecision(2)
                  << route.cen << endl;
    }
}

int main() {
    vector<string> erroneousLines;
    vector<Route> routes = checkRT("db.csv", erroneousLines);

    char command;
    while (cin >> command && command != 'e') {
        cout << "result:" << endl;

        if (command == 'a') {
            string sP, gP;
            cin >> sP >> gP;

            vector<Route> result;
            for (const auto& route : routes) {
                if (route.sP == sP && route.gP == gP) {
                    result.push_back(route);
                }
            }

            prtRT(result);
        } else if (command == 'b') {
            string day;
            cin >> day;

            vector<Route> result;
            for (const auto& route : routes) {
                if (route.day == day) {
                    result.push_back(route);
                }
            }

            prtRT(result);
        } else if (command == 'c') {
            double maxcen;
            cin >> maxcen;

            vector<Route> result;
            for (const auto& route : routes) {
                if (route.cen <= maxcen) {
                    result.push_back(route);
                }
            }

            prtRT(result);
        } else if (command == 'd') {
            for (const auto& line : erroneousLines) {
                cout << line << endl;
            }
        }
          else if (command == 'x'){
            cout << "Autors:\tKamilla Saleniece\nApl.Nr:\t221RDB076";
          }
        
    }

    return 0;
}