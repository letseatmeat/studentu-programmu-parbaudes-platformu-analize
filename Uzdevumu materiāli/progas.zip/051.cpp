
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector> 

using namespace std;

const string days[] = { "Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv" };

class BusR {
private:
  string staBuSstop, endBuSstop, time;
  string day;
  double price;

public:
  BusR(string sbs, string ebs, string d, string t,
       string p) {
    this->staBuSstop = sbs;
    this->endBuSstop = ebs;
    this->day = d;
    this->time = t;
    this->price = stod(p);
  }

  string getStartBuSstop() { return staBuSstop; }
  string getEndBuSstop() { return endBuSstop; }
  string getDayString() { return day; }
  string getTime() { return time; }
  double getPrice() { return price; }

  string toString() const {
    stringstream streamPrice;
    streamPrice << fixed << setprecision(2) << price;
    return staBuSstop + " " + endBuSstop + " " + day + " " + time +
           " " + streamPrice.str();
  }
};

class BusRValidation {
public:
  bool validStop(const string &stop) const {
    return all_of(stop.begin(), stop.end(), ::isalpha) && stop.length() > 2;
  }

  bool validDay(const string &day) const {
    return day == "Pr" || day == "Ot" || day == "Tr" || day == "Ce" || day == "Pt" || day == "St" || day == "Sv";
  }

  bool validTime(const string &time) const {
    return time.length() == 5 && isdigit(time[0]) && isdigit(time[1]) &&
           time[2] == ':' && isdigit(time[3]) && isdigit(time[4]);
  }

  bool validPrice(const string &price) const {
    try {
      stod(price);
      return true;
    } catch (...) {
      return false;
    }
  }
};

vector<string> splitWords(const string &line) {
  char delimiter = ',';
  vector<string> data;
  stringstream strStream(line);
  string word;
  while (getline(strStream, word, delimiter)) {
    data.push_back(move(word));
  }
  return data;
}

bool dataIsValid(const vector<string> &data, const BusRValidation &brv) {
  return data.size() == 5 && brv.validStop(data[0]) && brv.validStop(data[1]) &&
         brv.validDay(data[2]) && brv.validTime(data[3]) &&
         brv.validPrice(data[4]);
}

void commandA(const vector<BusR> &busRs) {
  string staBuSstop, endBuSstop;
  cin >> staBuSstop >> endBuSstop;
  cout << "result:" << endl;
  for (BusR br : busRs) {
    if (br.getStartBuSstop() == staBuSstop &&
        br.getEndBuSstop() == endBuSstop) {
      cout << br.toString() << endl;
    }
  }
}

void commandB(const vector<BusR> &busRs) {
  string day;
  cin >> day;
  cout << "result:" << endl;
  for (BusR br : busRs) {
    if (br.getDayString() == day) {
      cout << br.toString() << endl;
    }
  }
}

void commandC(const vector<BusR> &busRs) {
  double price;
  while (!(cin >> price)) {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "You have entered wrong input. Please, try again." << endl;
  }

  cout << "result:" << endl;
  for (BusR br : busRs) {
    if (br.getPrice() <= price) {
      cout << br.toString() << endl;
    }
  }
}

void commandD() {
  cout << "result:" << endl;
  ifstream inFile("err.txt");
  if (inFile) {
    string line;
    while (getline(inFile, line)) {
      cout << line << endl;
    }
    inFile.close();
  }
}

int main() {
  ifstream inFile("db.csv");
  if (!inFile)
    return 0;

  ofstream errFile("err.txt");
  if (!errFile)
    return 0;

  string line;
  vector<BusR> busRs;

  BusRValidation brv;

  while (getline(inFile, line)) {
    string invalidLine = line;
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

    if (line.empty())
      continue;

    vector<string> data = splitWords(line);

    if (dataIsValid(data, brv)) {
      busRs.emplace_back(move(data[0]), move(data[1]), move(data[2]),
                             move(data[3]), move(data[4]));
    } else {
      errFile << invalidLine << endl;
    }
  }

  errFile.close();
  inFile.close();

  char command;
  while (cin >> command) {
    switch (command) {
    case 'a':
      commandA(busRs);
      break;
    case 'b':
      commandB(busRs);
      break;
    case 'c':
      commandC(busRs);
      break;
    case 'd':
      commandD();
      break;
    case 'e':
      return 0;
    }
  }
}


