#include <iostream>
#include <fstream>
#include <vector>
#include <regex>
#include <algorithm>

using namespace std;

void remove_spaces(string &txt) {
  string temp = "";
  for (int i = 0; i < txt.length(); i++) {
    if (!isspace(txt[i])) {
      temp = temp + txt[i];
    }
  }
  txt = temp;
}

void validate_text(vector<string> &array) {
  vector<string> temp_array;
  ofstream errorfile("err.txt");
  if (errorfile.is_open()) {
    for (string a : array) {
      if (regex_match(a, regex("[A-Z][a-z]*,[A-Z][a-z]*,[A-z]{2},\\d{2}:\\d{2},\\d+.\\d{2}"))) {
        replace(a.begin(), a.end(), ',', ' ');
        temp_array.push_back(a);
      } else {
        errorfile << a << endl;
      }
    }
    errorfile.close();
    array = temp_array;
  }
}

void a (vector<string> &array, string sakuma_pietura, string beigu_pietura) {
  string a, r;
  r = sakuma_pietura + "\\s" + beigu_pietura;
  for (string a : array) {  
    if (regex_search(a, regex(r))) {
      cout << a << endl;
    }
  }
}

void b (vector<string> &array, string b) {
  string a, r;
  r = "\\s" + b + "\\s";
  for (string a : array) {  
    if (regex_search(a, regex(r))) {
      cout << a << endl;
    }
  }
}

void c (vector<string> &array, float x) {
  string a;
  smatch m;
  for (string a : array) {
    regex_search(a, m ,regex("(\\d+[.]\\d{2})"));
    if (stof(m.str(0)) < x) {
      cout << a << endl;
    }
  }
}

int main() {
  char input_key;
  float number;
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  vector<string> textArray;

  string s, day, sakuma_pietura, beigu_pietura; 
  
  while (getline(inFile, s)) {
    remove_spaces(s);
    if (s.length() > 0) {
      textArray.push_back(s);
    }
  }

  inFile.close();
  
  validate_text(textArray);

  while (input_key != 'e') {
    cin >> input_key;
    
    switch(input_key) {
      case 'a':

        cin >> sakuma_pietura;

        cin >> beigu_pietura;
        
        cout << "result:" << endl;

        a(textArray, sakuma_pietura, beigu_pietura);
      break;
      
      case 'b':

        cin >> day;
        
        cout << "result:" << endl;;

        b(textArray, day);
      break;
      
      case 'c':
        
        cin >> number;
        
        cout << "result:" << endl;;

        c(textArray, number);
      break;
      
      case 'd':
        cout << "result:" << endl;;
        
        inFile.open("err.txt");
  
        if (!inFile) cout << "error";
  
        while (getline(inFile, s)) {
          cout << s << endl;
        }
        inFile.close();
      break;
      
      default:
      break;
    }
  }
  
} 