

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cctype>
#include <iomanip>

using namespace std;

//Konstantes
const string FILENAME = "db.csv";
const string ERROR_FILE = "err.txt";

// Struktūra, kas glabā informāciju par autobusa maršrutu
struct AutobusaMarsruts {
  string sakumaPietura;
  string galaPietura;
  string nedelasDiena;
  string laiks;
  double biletesCena;
};

// Funkcija, kas nolasa datus no faila un pievieno tos vektoram
void readFile(const string &filename, vector<AutobusaMarsruts> &autobusi, ofstream &fileForErrors) {
  ifstream file(filename);
  if (!file.is_open()) {
    cerr << "Error opening file: " << filename << endl;
    exit(1);
  }

  string line;
  while (getline(file, line)) {
    // Noņem atstarpes un pārbauda, vai rinda nav tukša
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line.empty()) {
      continue;
    }

    // Sadala rindu pēc komata un saglabā datus vektorā
    istringstream iss(line);
    vector<string> tokens;
    string token;
    while (getline(iss, token, ',')) {
      tokens.push_back(token);
    }

    // Pārbauda, vai ir pieejami 5 dati (sakumaPietura, galaPietura, nedelasDiena, laiks, biletesCena)
    if (tokens.size() != 5) {
      // Ja dati nav korekti, ieraksta tos kļūdu failā
      fileForErrors << line << endl;
      continue;
    }

    // Izveido un pievieno jaunu autobusa maršrutu vektoram
    AutobusaMarsruts autobusaMarsruts;
    autobusaMarsruts.sakumaPietura = tokens[0];
    autobusaMarsruts.galaPietura = tokens[1];
    autobusaMarsruts.nedelasDiena = tokens[2];
    autobusaMarsruts.laiks = tokens[3];

    try {
      
      // Pārvērš cenu (biletesCena) no string uz double
      size_t pos;
      
      autobusaMarsruts.biletesCena = stod(tokens[4], &pos);
      if (pos != tokens[4].size()) {
        throw invalid_argument("");
      }
    } catch (const invalid_argument &) {
      
      // Ja cena nav korekta, ieraksta to kļūdu failā
      
      fileForErrors << line << endl;
      continue;
    } catch (...) {
      fileForErrors << line << endl;
      continue;
    }

    autobusi.push_back(autobusaMarsruts);
  }
}

// Funkcija, kas izvada informāciju par autobusa maršrutiem
void printAutobusaMarsruts(const vector<AutobusaMarsruts> &autobusi) {
  for (const auto &autobusaMarsruts : autobusi) {
    cout << autobusaMarsruts.sakumaPietura << " " << autobusaMarsruts.galaPietura << " " << autobusaMarsruts.nedelasDiena << " "
         << autobusaMarsruts.laiks << " " << fixed << setprecision(2) << autobusaMarsruts.biletesCena << endl;
  }
}

int main() {
  
  // Izveido vektoru, kur glabāsies autobusa maršrutu informācija
  vector<AutobusaMarsruts> autobusi;
  
  // Izveido failu, kur glabāsies kļūdas
  ofstream fileForErrors(ERROR_FILE);

  // Nolasa informāciju no faila un ievieto vektorā
  readFile(FILENAME, autobusi, fileForErrors);

  char command;
  
  // Cikls, kurš lasa lietotāja komandas un veic atbilstošas darbības
  while (true) {
    cout << "";
    cin >> command;

    switch (command) {
      
    // Atrod un izvada maršrutus pēc sākuma un gala pieturas
    case 'a': {
      string sakumaPietura, galaPietura;
      cout << "";
      cin >> sakumaPietura >> galaPietura;

      cout << "result:" << endl;
      for (const auto &autobusaMarsruts : autobusi) {
        if (autobusaMarsruts.sakumaPietura == sakumaPietura && autobusaMarsruts.galaPietura == galaPietura) {
          cout << autobusaMarsruts.sakumaPietura << " " << autobusaMarsruts.galaPietura << " " << autobusaMarsruts.nedelasDiena
               << " " << autobusaMarsruts.laiks << " " << fixed << setprecision(2) << autobusaMarsruts.biletesCena << endl;
        }
      }
      break;
    }

    // Atrod un izvada maršrutus pēc nedēļas dienas
    case 'b': {
      
      string nedelasDiena;
      cout << "";
      cin >> nedelasDiena;

      cout << "result:" << endl;
      for (const auto &autobusaMarsruts : autobusi) {
        if (autobusaMarsruts.nedelasDiena == nedelasDiena) {
          cout << autobusaMarsruts.sakumaPietura << " " << autobusaMarsruts.galaPietura << " " << autobusaMarsruts.nedelasDiena
               << " " << autobusaMarsruts.laiks << " " << fixed << setprecision(2) << autobusaMarsruts.biletesCena << endl;
        }
      }
      break;
    }

    // Atrod un izvada maršrutus ar biletēm, kuru cena ir mazāka vai vienāda ar ievadīto summu
    case 'c': {
      
      double maxBiletesCena;
      cout << "";
      cin >> maxBiletesCena;

      cout << "result:" << endl;
      for (const auto &autobusaMarsruts : autobusi) {
        if (autobusaMarsruts.biletesCena <= maxBiletesCena) {
          cout << autobusaMarsruts.sakumaPietura << " " << autobusaMarsruts.galaPietura << " " << autobusaMarsruts.nedelasDiena
               << " " << autobusaMarsruts.laiks << " " << fixed << setprecision(2) << autobusaMarsruts.biletesCena << endl;
        }
      }
      break;
    }

    // Izvada kļūdas no faila
    case 'd': {
      
      ifstream fileForErrorsIn(ERROR_FILE);
      cout << "result:" << endl;
      cout << fileForErrorsIn.rdbuf();
      break;
    }

    // Beidz programmas izpildi
    case 'e': {
      
      return 0;
    }

    // Izvada ziņojumu, ja ievadītā komanda nav pareiza
    default: {
      
      cout << "wrong command." << endl;
    }
    }
  }

  return 0;
}