#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <vector>
#include <algorithm>
#include <regex>


// cout << "result:\n";

// ifstream inFile;
// inFile.open("db.csv");
// if (!inFile) return;
// string s;

// while (inFile >> s) {
// 	cout << s << endl;
// }
// inFile.close();

using namespace std;


string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r");
    size_t last = str.find_last_not_of(" \t\n\r");

    if (first == string::npos || last == string::npos) {
        return ""; // String contains only whitespaces
    }

    return str.substr(first, last - first + 1);
}

bool isValidTimeFormat(const string& input) {
    regex timeRegex(R"(\b(?:[01]\d|2[0-3]):[0-5]\d\b)");

    return regex_match(input, timeRegex);
}

bool isValidFormat(const string& input) {
    size_t dotPos = input.find('.');

    // Check if dot exists in the string
    if (dotPos == string::npos) {
        //Invalid format: No dot found in the string
        return false;
    }

    // Extract the two parts
    string firstPart = input.substr(0, dotPos);
    string secondPart = input.substr(dotPos + 1);

    // Check if the first part is an integer
    istringstream firstStream(firstPart);
    int intValue;
    if (!(firstStream >> intValue)) {
        //Invalid format: First part is not an integer
        return false;
    }

    // Check if the second part has exactly two digits
    if (secondPart.size() != 2 || !isdigit(secondPart[0]) || !isdigit(secondPart[1])) {
        //Invalid format: Second part is not exactly two digits
        return false;
    }

    // If all checks pass, the format is valid
    return true;
}

void c() {
  
  static const string jabut[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  
  double x;
  int countL = 1;
  cin >> x;
  while (cin.fail()) {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "error. mēģiniet vēlreiz\n" << endl;
    cin >> x;
  }

  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return;

  string line;
  cout << "result:" << endl;

  while (getline(inFile, line)) {
    // Check for and remove carriage return character if it exists
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }

    vector<string> result;
    string token;
    istringstream stream(line);

    while (getline(stream, token, ',')) {
      result.push_back(token);
    }
    
    // cout<<countL++<<endl;
    if (result.size()!=5) {   //5 field test
      // cout<<"#1"<<line<<endl;
    }
    else if (std::find(std::begin(jabut), std::end(jabut), trim(result[2])) == std::end(jabut)) {
      // cout<<"#1"<<line<<endl;
    }
    else if (!isValidTimeFormat(trim(result[3]))) { //hh:mm
      // cout<<"#3"<<line<<endl;
    }
    else if (!isValidFormat(trim(result[4]))) { //vai skaitlis, 2 dec 
      // cout<<"#4"<<line<<endl;
    }
    else if (stod(result[4]) <= x) {
      // cout<<result.size()<<endl;
      for (const auto& str : result) {
          cout << trim(str) << " ";
      }
      cout<<endl;
    }

  }

  inFile.close();
  
}
void b() {

  static const string jabut[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

  string x;
  cin >> x;
  bool found = true;
  for (const auto& str : jabut) {
      if (x == str) {
          found = false;
          break;
      }
  }
  while (found) {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "error. mēģiniet vēlreiz\n" << endl;
    cin >> x;
    for (const auto& str : jabut) {
        if (x == str) {
            found = false;
            break;
        }
    }
  }

  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return;

  string line;
  cout << "result:" << endl;

  while (getline(inFile, line)) {
    // Check for and remove carriage return character if it exists
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }

    vector<string> result;
    string token;
    istringstream stream(line);

    while (getline(stream, token, ',')) {
      result.push_back(token);
    }
    if (result.size()!=5) {   //5 field test
      // cout<<"#1"<<line<<endl;
    }
    // cout<<countL++<<endl;
    if (result.size()!=5) {   //5 field test
      // cout<<"#1"<<line<<endl;
    }
    else if (std::find(std::begin(jabut), std::end(jabut), trim(result[2])) == std::end(jabut)) {
      // cout<<"#1"<<line<<endl;
    }
    else if (!isValidTimeFormat(trim(result[3]))) { //hh:mm
      // cout<<"#3"<<line<<endl;
    }
    else if (!isValidFormat(trim(result[4]))) { //vai skaitlis, 2 dec 
      // cout<<"#4"<<line<<endl;
    }
    else if (trim(result[2]) == x) {
      // cout<<result.size()<<endl;
      for (const auto& str : result) {
          cout << trim(str) << " ";
      }
      cout<<endl;
    }

  }

  inFile.close();

}
void a() {

  static const string jabut[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

  string a,b;
  cin >> a;
  cin >> b;
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return;

  string line;
  cout << "result:" << endl;

  while (getline(inFile, line)) {
    // Check for and remove carriage return character if it exists
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }

    vector<string> result;
    string token;
    istringstream stream(line);

    while (getline(stream, token, ',')) {
      result.push_back(token);
    }

    // cout<<countL++<<endl;
    if (result.size()!=5) {   //5 field test
      // cout<<"#1"<<line<<endl;
    }
    else if (std::find(std::begin(jabut), std::end(jabut), trim(result[2])) == std::end(jabut)) {
      // cout<<"#1"<<line<<endl;
    }
    else if (!isValidTimeFormat(trim(result[3]))) { //hh:mm
      // cout<<"#3"<<line<<endl;
    }
    else if (!isValidFormat(trim(result[4]))) { //vai skaitlis, 2 dec 
      // cout<<"#4"<<line<<endl;
    }
    else if (trim(result[0]) == a && trim(result[1]) == b) {
      // cout<<result.size()<<endl;
      for (const auto& str : result) {
          cout << trim(str) << " ";
      }
      cout<<endl;
    }

  }

  inFile.close();

}
void d() {

  static const string jabut[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};


  ofstream outputFile("err.txt");

  // Check if the file was successfully opened
  if (!outputFile.is_open()) {
      cerr << "Error opening file 'err.txt'\n";
      return;  // Return an error code
  }
  
  
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return;

  string line;
  cout << "result:" << endl;

  while (getline(inFile, line)) {
    // Check for and remove carriage return character if it exists
    if (!line.empty() && line.back() == '\r') {
        line.pop_back();
    }

    if (line.empty()) {
        continue;
    }

    vector<string> result;
    string token;
    istringstream stream(line);

    while (getline(stream, token, ',')) {
      result.push_back(token);
    }

    // cout<<countL++<<endl;
    if (result.size()!=5) {   //5 field test
      if (result.size()!=1) {
        outputFile << line<<endl;
        cout << line<<endl;
      }
    }
    else if (std::find(std::begin(jabut), std::end(jabut), trim(result[2])) == std::end(jabut)) {
      if (result.size()!=1) {
        outputFile << line<<endl;
        cout << line<<endl;
      }
    }
    else if (!isValidTimeFormat(trim(result[3]))) { //hh:mm
      outputFile << line<<endl;
      cout << line<<endl;
    }
    else if (!isValidFormat(trim(result[4]))) { //vai skaitlis, 2 dec 
      outputFile << line<<endl;
      cout << line<<endl;
    }
  }

  inFile.close();
  outputFile.close();

}

int main() {
  
  // static const string jabut[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  
  // ifstream inFile;
  // inFile.open("db.csv");

  // if (!inFile) return 0;

  // string line;
  
  
  
  
  
  // while (getline(inFile, line)) {
  //   cout<<"###"<<line<<endl;
  //   vector<string> result;  
  //   string token;    
  //   istringstream stream(line);
  //   while (getline(stream, token, ',')) {
  //       result.push_back(token);
  //   }
  //   if (result.size()!=5) {   //5 field test
  //     cout<<"1"<<line<<endl;
  //   }
  //   else if (std::find(begin(jabut), end(jabut), trim(result[2])) == end(jabut)) { //ned dienas
  //     cout<<"2"<<line<<endl;
  //   }
  //   else if (!isValidTimeFormat(trim(result[3]))) { //hh:mm
  //     cout<<"3"<<line<<endl;
  //   }
  //   else if (!isValidFormat(trim(result[4]))) { //vai skaitlis, 2 dec 
  //     cout<<"4"<<line<<endl;
  //   }

  // }

  // inFile.close();
  
  char userInput;

  while (true) {

    cin >> userInput;

    switch (userInput) {
    case 'a':
      a();
      break;
    case 'b':
      b();
      break;
    case 'c':
      c();
      break;
    case 'd':
      d();
      break;
    case 'e':
      return 0; // Terminate the program
    default:
      cout << "error. mēģiniet vēlreiz\n";
    }
  }
  return 0;
}