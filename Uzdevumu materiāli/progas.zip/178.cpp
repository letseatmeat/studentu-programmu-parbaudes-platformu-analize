#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>

using namespace std;

struct Marsuts {
  string sakums;
  string beigas;
  string nedelasDiena;
  string laiks;
  double cena;

  bool operator==(const Marsuts &other) const {
    return sakums == other.sakums && beigas == other.beigas && nedelasDiena == other.nedelasDiena &&
           laiks == other.laiks && cena == other.cena;
  }

  bool operator<(const Marsuts &other) const {
    return tie(sakums, beigas, nedelasDiena, laiks, cena) <
           tie(other.sakums, other.beigas, other.nedelasDiena, other.laiks, other.cena);
  }
};

int main() {
  string fails = "db.csv";
  string kludasfails = "err.txt";
  vector<Marsuts> marsuti;
  ofstream errorFile(kludasfails);
  ifstream inFile(fails);

  if (!inFile.is_open()) {
    cerr << "Error opening file: " << fails << endl;
    return 1;
  }

  set<Marsuts> citsMarsuts;
  string rinda;
  while (getline(inFile, rinda)) {
    if (rinda.empty())
      continue;
    
    string result;
      for (char c : rinda) {
        if (!isspace(c)) {
          result += c;
        }
      }
      rinda = result;

    bool parbaude = true;
    istringstream sstream(rinda);
    string skaititajs;

    for (int i = 0; i < 5; ++i) {
      if (!getline(sstream, skaititajs, ',')) {
        parbaude = false;
      }
    }
    if(!sstream.eof()){
        parbaude = false;
    }
    if (!parbaude) {
      errorFile << rinda << endl;
      continue;
    }

    Marsuts route;
    try {
      istringstream sstream(rinda);
      string sakums, beigas, nedelasDiena, laiks, cena;

      getline(sstream, sakums, ',');
      getline(sstream, beigas, ',');
      getline(sstream, nedelasDiena, ',');
      getline(sstream, laiks, ',');
      getline(sstream, cena, ',');

      route.sakums = sakums;
      route.beigas = beigas;
      route.nedelasDiena = nedelasDiena;

      if (laiks.size() != 5 || laiks[2] != ':' || stoi(laiks.substr(0, 2)) < 0 || stoi(laiks.substr(0, 2)) > 23 || stoi(laiks.substr(3, 2)) < 0 || stoi(laiks.substr(3, 2)) > 59) {
        errorFile << rinda << endl;
        continue;
      }
      route.laiks = laiks;
      route.cena = stod(cena);

      static const vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
      if (find(days.begin(), days.end(), route.nedelasDiena) == days.end()) {
        errorFile << rinda << endl;
        continue;
      }

      if (citsMarsuts.count(route) == 0) {
        marsuti.push_back(route);
        citsMarsuts.insert(route);
      }
    } catch (const exception &e) {
      errorFile << rinda << endl;
    }
  }
  inFile.close();
  

  char komanda;
  do {
    cout << "Command: ";
    cin >> komanda;
    try {
      if (!komanda) {
        throw runtime_error("Input error");
      }

      switch (komanda) {
      case 'a': {
        string sakums2, beigas2;
        cout << "Start point: ";
        cin >> sakums2;
        cout << "End point: ";
        cin >> beigas2;
        cout << "result:" << endl;
        for (const auto &marsuts : marsuti) {
          if (marsuts.sakums == sakums2 && marsuts.beigas == beigas2) {
            cout << marsuts.sakums << " " << marsuts.beigas << " " << marsuts.nedelasDiena << " "
                 << marsuts.laiks << " " << fixed << setprecision(2) << marsuts.cena
                 << endl;
          }
        }
        break;
      }
      case 'b': {
        string nedelasDiena2;
        cout << "Day of week: ";
        cin >> nedelasDiena2;
        cout << "result:" << endl;
        for (const auto &marsuts : marsuti) {
          if (marsuts.nedelasDiena == nedelasDiena2) {
            cout << marsuts.sakums << " " << marsuts.beigas << " " << marsuts.nedelasDiena << " "
                 << marsuts.laiks << " " << fixed << setprecision(2) << marsuts.cena
                 << endl;
          }
        }
        break;
      }
      case 'c': {
        double cena2;
        cout << "Price: ";
        cin >> cena2;
        cout << "result:" << endl;
        for (const auto &marsuts : marsuti) {
          if (marsuts.cena <= cena2) {
            cout << marsuts.sakums << " " << marsuts.beigas << " " << marsuts.nedelasDiena << " "
                 << marsuts.laiks << " " << fixed << setprecision(2) << marsuts.cena
                 << endl;
          }
        }
        break;
      }
      case 'd': {
        cout << "result:" << endl;
        ifstream errFile("err.txt");
        if (errFile) {
          string errorLine;
          while (getline(errFile, errorLine)) {
            if (!errorLine.empty()) {
              cout << errorLine << endl;
            }
          }
        }
        break;
      }
      default:
        break;
      }

    } catch (const exception &e) {
      cout << e.what() << endl;
      continue;
    }
  } while (komanda != 'e');
  return 0;
}
