

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <stdexcept>


using namespace std;

struct reisa_ieraksts {

string sakuma_pietura;
string galamerka_pietura;
string nedelas_diena;
string attiesanas_laiks;
string biletes_cena;

};

void izvade_faila(ofstream& onFile, vector<reisa_ieraksts> reisi, int i) {
  
  if (!reisi[i].sakuma_pietura.empty()) {
      onFile << reisi[i].sakuma_pietura;
    } 
    if (!reisi[i].galamerka_pietura.empty()){
      onFile << "," << reisi[i].galamerka_pietura;
    }
    if (!reisi[i].nedelas_diena.empty()){
      onFile << "," << reisi[i].nedelas_diena;
    }
    if (!reisi[i].attiesanas_laiks.empty()){
      onFile << "," << reisi[i].attiesanas_laiks;
    } 
    if (!reisi[i].biletes_cena.empty()){
      onFile << "," << reisi[i].biletes_cena;
    } 
    onFile << endl;   
}

void izvade_ekrana(vector<reisa_ieraksts> reisi, int i) {

  cout << reisi[i].sakuma_pietura << " "
    << reisi[i].galamerka_pietura << " "
    << reisi[i].nedelas_diena << " " 
    << reisi[i].attiesanas_laiks << " "
    << reisi[i].biletes_cena << endl;   

}

void meklet_marsrutu(vector<reisa_ieraksts> reisi) {
  
  string sakuma_pietura, galamerka_pietura;
  //cout << "Ievadi sākuma pieturu: ";
  cin >> sakuma_pietura;
  //cout << "Ievadi galamērķa pieturu: ";
  cin >> galamerka_pietura;
  cout << "result:\n";
  
  for (int i=0; i < reisi.size(); i++) {
    if (reisi[i].sakuma_pietura == sakuma_pietura &&
      reisi[i].galamerka_pietura == galamerka_pietura) {
      
      izvade_ekrana(reisi, i);
      
    }
  }

}

void reisi_konkretaja_diena(vector<reisa_ieraksts> reisi) {
  
  string diena;
  //cout << "Ievadi meklējamo dienu: ";
  cin >> diena;
  cout << "result:\n";
  
  for (int i=0; i < reisi.size(); i++) {
    if (reisi[i].nedelas_diena == diena) {
      
      izvade_ekrana(reisi, i);
      
    }
  }
  
}

void reisi_kuriem_neparsniedz_ievade(vector<reisa_ieraksts> reisi) {
  
  double biletes_cena;
  // cout << "Ievadi maksimālo biļetes cenu: ";
  cin >> biletes_cena;
  cout << "result:\n";

  for (int i=0; i < reisi.size(); i++) {
    
    try {
      
      if (stod(reisi[i].biletes_cena) < biletes_cena) {
        
        izvade_ekrana(reisi, i);
        
      }

    } catch (const invalid_argument e) {
    }
    
  }
  
}

void erorr_reisi() {
  
  ifstream file("err.txt");

  string i;
  cout << "result:\n";
  while (file >> i) {
    cout << i  << endl;
  }
  
}

int main() {

  // tiek atvērts fails "db.csv"
  ifstream inFile;
  inFile.open("db.csv");

  //tiek izveidota datu struktūra kur saglbāsies visi reisi
  vector<reisa_ieraksts> reisi;

	if (!inFile){
    return 0;
  }

  // tiek izveidots fails "err.txt"
  ofstream onFile;
  onFile.open("err.txt");
  
  string elementi; 

  // tiek nolasīts fails pa vienai rindiņai
	while (getline(inFile, elementi)) {

    // katrā iterācijā tiek definēts jauns reiss 
    reisa_ieraksts atsevisks_reiss;
    
    string rinda_bez_liekam_atstarpem;

    // iterēšana cauri rindai, pārbaudot katru simbolu
    for (char ch : elementi) {
      
     if (ch != ' ') {
        rinda_bez_liekam_atstarpem = rinda_bez_liekam_atstarpem + ch;
      } else {
       continue;
      }
      
    }
    
    // string tiek pārveidots par stringstream, lai veiktu ierakstu sadalīšanu
    stringstream rinda_bez_ats(rinda_bez_liekam_atstarpem);
    
    getline(rinda_bez_ats, atsevisks_reiss.sakuma_pietura, ',');

    getline(rinda_bez_ats, atsevisks_reiss.galamerka_pietura, ',');
   
    getline(rinda_bez_ats, atsevisks_reiss.nedelas_diena, ',');
      
    getline(rinda_bez_ats, atsevisks_reiss.attiesanas_laiks, ',');
 
    getline(rinda_bez_ats, atsevisks_reiss.biletes_cena);
    
    reisi.push_back(atsevisks_reiss);
    
  }

  // iterēšana cauri ierakstiem un kļūdaino ierakstu ierakstīšana failā
  for (int i=0; i < reisi.size(); i++) {

    if (reisi[i].galamerka_pietura != "") {
      if (reisi[i].nedelas_diena != "Pr" &&
          reisi[i].nedelas_diena != "Ot" &&
          reisi[i].nedelas_diena != "Tr" &&
          reisi[i].nedelas_diena != "Ce" &&
          reisi[i].nedelas_diena != "Pt" &&
          reisi[i].nedelas_diena != "St" &&
          reisi[i].nedelas_diena != "Sv") {
        
          izvade_faila(onFile, reisi, i);
        
      } else if (!(reisi[i].biletes_cena.empty())) {
        
        for (char ch : reisi[i].biletes_cena) {
          if (ch == ',') {
            
            izvade_faila(onFile, reisi, i);
            reisi.erase(reisi.begin() + i);
            
          }
        }
          
      }
    } else {
      continue;
      
    }
    
  }
 
  bool cikls = true;
  char komanda;
  
  while (cikls) {
    
    //cout << "Ievadi komandu: ";
    cin >> komanda;

    switch (komanda) {
      
        case 'a' : meklet_marsrutu(reisi); break;
        case 'b' : reisi_konkretaja_diena(reisi); break;
        case 'c' : reisi_kuriem_neparsniedz_ievade(reisi); break;
        case 'd' : erorr_reisi(); break;
        case 'e' : cikls = false; break;
      
    }
    
  }
  
  inFile.close();
  onFile.close();

  return 0;
}



