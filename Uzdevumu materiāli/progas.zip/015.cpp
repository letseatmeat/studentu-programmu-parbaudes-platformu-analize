
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

// Funkcija, lai apgrieztu virknes sākuma un beigu atstarpes
string trim(string s) {
    size_t start = s.find_first_not_of(" \t");
    size_t end = s.find_last_not_of(" \t");
    return (start != string::npos && end != string::npos) ? s.substr(start, end - start + 1) : "";
}

// Autobusa maršrutu apstrādes un drukāšanas funkcija
void processRoutes(const vector<string>& routes) {
    for (const string& route : routes) {
        cout << route << endl;
    }
}

int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");

    vector<string> routes;
    string line;

    const int expectedFields = 5; // Cik daudz field vajadzētu būt .csv failā

    while (getline(inFile, line)) {
        // izlaiž tukšās līnijas
        if (line.empty()) {
            continue;
        }

        istringstream iss(line);
        string start, end, day, time, price;

        // Nolasa katru rindu no .csv faila
        vector<string> fields;
        string field;
        while (getline(iss, field, ',')) {
            fields.push_back(trim(field));
        }

        // Pārbauda cik field ir līnijā
        if (fields.size() != expectedFields) {
            // Ieraksta līniju kurā nav pietiekami daudz vai ir par daudz laukumi err.txt failā
            errFile << line << endl;
            continue;
        }

        // Katru field pēc kārtas piesaista nosaukumam
        start = fields[0];
        end = fields[1];
        day = fields[2];
        time = fields[3];
        price = fields[4];

        // Apgriež atstarpes
        start = trim(start);
        end = trim(end);
        day = trim(day);
        time = trim(time);
        price = trim(price);

        // Pārbauda dienas formatāciju
        if (day.size() != 2 || (day != "Pr" && day != "Ot" && day != "Tr" && day != "Ce" && day != "Pt" && day != "Se" && day != "Sv")) {
            errFile << line << endl;
            continue;
        }

        // Pārbaud laiku (teorētiski ja iemetīs vienkārši burtus xx:xx formātā arī darbosies bet nu tas tā)
        if (time.size() != 5 || time[2] != ':') {
            errFile << line << endl;
            continue;
        }

        // Apstrādātos maršrutus pieliek vektoram
        string processedRoute = start + " " + end + " " + day + " " + time + " " + price;
        routes.push_back(processedRoute);
    }

    char choice;
    do {
        cin >> choice;

        ifstream inFile;
        string errtxt, usrStart, usrEnd, usrDay;
        double bigMoney;

        bool resultPrinted = false;

        switch (choice) {
            case 'a':
                cin >> usrStart;
                cin >> usrEnd;

                for (const string& route : routes) {
                    size_t startPos = route.find(usrStart);
                    size_t endPos = route.find(usrEnd);

                    if (startPos != string::npos && endPos != string::npos && startPos < endPos){
                        if (!resultPrinted) {
                            cout << "result:\n";
                            resultPrinted = true;
                        }
                        cout << route << endl;
                    }
                } 
                break;
            case 'b':
                cin >> usrDay;

                for (const string& route : routes) {
                    size_t dayz = route.find(usrDay);

                    if (dayz != string::npos){
                        if (!resultPrinted) {
                            cout << "result:\n";
                            resultPrinted = true;
                        }
                        cout << route << endl;
                    }
                }
                break;
            case 'c':
                cin >> bigMoney;

                for (const string& route : routes) {
                    istringstream iss(route);
                    string start, end, day, time, priceStr;

                    if (getline(iss, start, ' ') &&
                        getline(iss, end, ' ') &&
                        getline(iss, day, ' ') &&
                        getline(iss, time, ' ') &&
                        getline(iss, priceStr)) {
                        try {
                            double price = stod(priceStr);

                            if (price < bigMoney) {
                                if (!resultPrinted) {
                                    cout << "result:\n";
                                    resultPrinted = true;
                                }
                                cout << route << endl;
                            }
                        } catch (const invalid_argument& e) {                           
                            errFile << route << endl;
                        }
                    }
                }
                break;
            case 'd':
                inFile.open("err.txt");
                if(!inFile) return 0;

                while(inFile >> errtxt)
                {
                    if (!resultPrinted) {
                        cout << "result:\n";
                        resultPrinted = true;
                    }
                    cout << errtxt << endl;
                }
                break;
            case 'e':
                ////////////////////////////////////////////yep
                break;
            default:
                cout << "Nepareiza ievade" << endl; 
        }

    } while (choice != 'e');

    inFile.close();
    errFile.close();

    return 0;
}