
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <iomanip>

using namespace std;

class route {
public:
    string from;
    string to;
    string day;
    string time;
    double price;
};


static route wrapRoute(vector<string> data, route routePar) {
    try{
    routePar.from = data[0];
    routePar.to = data[1];
    routePar.day = data[2];
    routePar.time = data[3];
    routePar.price = stod(data[4]);
    return routePar;
    } catch (...){
      cout << "Error:" << endl;
      return routePar;
    }
    }
    
string trimSpaces(const string &str) {
    string noEmptySpaces = str;
    while (noEmptySpaces[0] == ' ') { // from the beginning
        noEmptySpaces = noEmptySpaces.substr(1, str.length());
    }
    while(noEmptySpaces[noEmptySpaces.length()-1] == ' '){ // from end
      noEmptySpaces = noEmptySpaces.substr(0, noEmptySpaces.length()-1);
    }
    return noEmptySpaces;
}

bool isNumeric(string str) {
    for (char c : str) {
        if (!isdigit(c)) {
            return false;
        }
    }
    return true;
}

static bool checkData(vector<string> data){
try{
  if(data.size() == 5 && !isNumeric(data[0]) && !isNumeric(data[1]) && data[2].length() == 2 && data[3].length() == 5 && data[3].find(':') != string::npos && stod(data[4])){
    
    return true;
  } else{
    throw -1;
  }
  }  catch(int num){
    return false;
  }

}

pair<vector<route>, vector<vector<string>>> static readCsv(){
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) {
      cerr << "Error opening file!" << endl;
      return {};
  }
  map<vector<route>, vector<vector<string>>> allRoutes;
  vector<vector<string>> wrongRoutes;
  
  string line;
  vector<route> routes;
  while (getline(inFile, line)) {
      istringstream s(line);
      string field;
      int i = 0;
      vector<string> lineData;
      route routeParameter;
      while (getline(s, field, ',')) {
          lineData.push_back(trimSpaces(field));
          i++;
      }
      if (checkData(lineData)) {
          routeParameter = wrapRoute(lineData, routeParameter);
          routes.push_back(routeParameter);
      } else if (checkData(lineData) == false && lineData.size() > 1) {
        wrongRoutes.push_back(lineData);
      }
  }
  inFile.close();
  return make_pair(routes, wrongRoutes);

  }
    

static void outputFromTo(vector<route> routes, string from, string to) {
  cout << "result:" << endl;
  for (route route : routes) {
    if (route.from == from && route.to == to) {
      cout << route.from << " " << route.to << " " << route.day << " " << route.time << " " << fixed <<  setprecision(2) << route.price << endl;
    }
  }
}

static void outputByDay(vector<route> routes, string day) {
  cout << "result:" << endl;
  for (route route : routes) {
    if (route.day == day) {
      cout << route.from << " " << route.to << " " << route.day << " " << route.time << " " << fixed <<  setprecision(2) << route.price << endl;
    }
  }
}

static void outputByPrice(vector<route> routes, double price) {
  cout << "result:" << endl;
  for (route route : routes) {
    if (route.price <= price) {
      cout << route.from << " " << route.to << " " << route.day << " " << route.time << " " << fixed <<  setprecision(2) << route.price << endl;
    }
  }
}

static void outputWrongRoutes(vector<vector<string>> wrongRoutes) {
    cout << "result: " << endl;

    for (vector<string> wrongRoute : wrongRoutes) {
        for (int i = 0; i < wrongRoute.size(); ++i) {
            cout << wrongRoute[i];
            if (i < wrongRoute.size() - 1) {
                cout << ",";
            }
        }
        cout << endl;
    }
}

static void writeWrongRoutes(vector<vector<string>> wrongRoutes){
  ofstream errorTXT("err.txt");
  for (vector<string> wrongRoute : wrongRoutes) {
      for (int i = 0; i < wrongRoute.size(); ++i) {
          errorTXT << wrongRoute[i];
          if (i < wrongRoute.size() - 1) {
              errorTXT << ",";
          }
      }
      errorTXT << endl;
  }
    errorTXT.close();
}

int main() {
  vector<route> routes = readCsv().first;
  vector<vector<string>> wrongRoutes = readCsv().second;
  writeWrongRoutes(wrongRoutes);
  
  char input = '-';
  while (input != 'e'){
    cin >> input;
    switch(input){
      case 'a': {
        string from;
        string to;
        cin >> from >> to;
        outputFromTo(routes, from, to);
        break;
      }
      
      case 'b': {
        string day;
        cin >> day;
        outputByDay(routes, day);
        break;
      }

      case 'c':{
        double price;
        cin >> price;
        outputByPrice(routes, price);
        break;
      }

      case 'd':{
        outputWrongRoutes(wrongRoutes);
        break;
      }
        
    }
  }
    return 0;
}
