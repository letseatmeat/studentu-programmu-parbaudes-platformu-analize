
#include <iostream> //cin,cout
#include <fstream> //filestream
#include <cstring> //strtok()
#include <vector> //vector<>
#include <iomanip> //setprecision()
#include <cctype> //isdigit()
#include <algorithm> //all_of()
//#include <bits/stdc++.h> can be used instead of all these but using them individually saves memory

using namespace std;

bool stodcheck(string s) { //output[4] / price validation
  try {
    stod(s);
  } catch (invalid_argument) {
    return false;
  }
  return true;
}

int main() {
	ifstream inFile;
	ofstream outFile ("err.txt");
	inFile.open("db.csv");
	if (!inFile) return 0;
	vector<string> startstop, endstop, day, time;
	vector<double> price;
	char str[50];
	while (inFile.getline(str, 50))
	{
		if(str[0] != '\r' && str[0] != '\n') {
			string currentline = str;
			char *ptr;
			ptr = strtok(str, " , "); // use strtok() function to separate string using comma (,) delimiter.
			int counter = 0;
			string output[5];
			while (ptr != NULL) // use while loop to check ptr is not null
			{
				if (counter==5) {
					counter++;
					break;
				}
				output[counter] = ptr;
				ptr = strtok(NULL, " , ");
				counter++;
			}
			if(counter == 5 && !all_of(output[0].begin(), output[0].end(), ::isdigit) && !all_of(output[1].begin(), output[1].end(), ::isdigit) && output[3].length() == 5 && stodcheck(output[4])) {
        if (output[2] == "Pr" || output[2] == "Ot" || output[2] == "Tr" || output[2] == "Ce" || output[2] == "Pt" || output[2] == "St" || output[2] == "Sv") {
          startstop.push_back(output[0]);
          endstop.push_back(output[1]);
          day.push_back(output[2]);
          time.push_back(output[3]);
          price.push_back(stod(output[4])); //stod: Parses string interpreting its content as a floating-point number, which is returned as a value of type double.
        } else {
          outFile << currentline;
        }
			} else {
				outFile << currentline;
			}
		}
	}
	inFile.close();
  outFile.close();




  
	while (true) {
		string input;
		cin >> input;
		if (input=="a") {
      string start, finish;
      cin >> start >> finish;
      cout << "result:" << endl;
      for (int i=0; i<startstop.size(); i++) {
        if (startstop[i] == start && endstop[i] == finish) {
          cout << startstop[i] << " " << endstop[i] << " " << day[i] << " " << time[i] << " " << fixed << setprecision(2) << price[i] << endl;
        }
      }
		} else if (input=="b") {
      string daycheck;
      cin >> daycheck;
      cout << "result:" << endl;
      for (int i=0; i<startstop.size(); i++) {
        if (day[i] == daycheck) {
          cout << startstop[i] << " " << endstop[i] << " " << day[i] << " " << time[i] << " " << fixed << setprecision(2) << price[i] << endl;
        }
      }
		} else if (input=="c") {
      double pricecheck;
      cin >> pricecheck;
      cout << "result:" << endl;
      for (int i=0; i<startstop.size(); i++) {
        if (price[i] < pricecheck) {
          cout << startstop[i] << " " << endstop[i] << " " << day[i] << " " << time[i] << " " << fixed << setprecision(2) << price[i] << endl;
        }
      }
		} else if (input=="d") {
      inFile.open("err.txt");
      cout << "result:" << endl;
      string s; 
      while (inFile >> s)
      {
        cout << s << endl;
      }
      inFile.close();
		} else if (input=="e") {
			return 0;
		} else {
			cout << "[!] Unrecognized command" << endl;
		}
	}
} 