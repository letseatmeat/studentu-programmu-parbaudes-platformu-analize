

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
#include <algorithm>

struct Route {
    std::string departure;
    std::string destination;
    std::string travelDay;
    std::string travelTime;
    double ticketPrice;
};

struct InterfaceRoute {
    std::string departure;
    std::string destination;
    std::string travelDay;
    std::string travelTime;
    std::string ticketPrice;
    std::string rest;
};

std::vector<Route> travelRoutes;
const std::string DaysOfWeek = "Pr,Ot,Tr,Ce,Pt,St,Sv";

void trim(std::string &str) {
    size_t start = str.find_first_not_of(" \t");
    size_t end = str.find_last_not_of(" \t");

    if (start != std::string::npos && end != std::string::npos)
        str = str.substr(start, end - start + 1);
    else
        str.clear();
}

bool isFloat(const std::string &str) {
    std::istringstream iss(str);
    float f;
    iss >> std::noskipws >> f;
    return iss.eof() && !iss.fail();
}

bool containsOnlyCharacters(const std::string &str) {
    return std::all_of(str.begin(), str.end(), [](char ch) {
        return std::isalpha(ch);
    });
}


bool validRecord(const InterfaceRoute &route, Route &newRoute) {
    std::string departure = route.departure;
    std::string destination = route.destination;
    std::string travelDay = route.travelDay;
    std::string travelTime = route.travelTime;
    std::string ticketPrice = route.ticketPrice;  // Corrected data type

    trim(departure);
    trim(destination);
    trim(travelDay);
    trim(travelTime);
    trim(ticketPrice);

    if (departure.empty() || destination.empty() || travelDay.empty() ||
        travelTime.empty() || ticketPrice.empty())
        return false;

    if (!containsOnlyCharacters(departure) || !containsOnlyCharacters(destination))
        return false;

    if (DaysOfWeek.find(travelDay) == std::string::npos)
        return false;

    if (travelTime.size() != 5 || !std::isdigit(travelTime[0]) || !std::isdigit(travelTime[1]) ||
        travelTime[2] != ':' || !std::isdigit(travelTime[3]) || !std::isdigit(travelTime[4]))
        return false;

    if (ticketPrice.size() == 0 || !isFloat(ticketPrice))
        return false;

    newRoute.departure = departure;
    newRoute.destination = destination;
    newRoute.travelDay = travelDay;
    newRoute.travelTime = travelTime;
    newRoute.ticketPrice = std::stod(ticketPrice);

    return true;
}


void readRoutes() {
    std::ifstream inFile("db.csv");
    std::ofstream outErr("err.txt");

    if (!inFile || !outErr) {
        std::cerr << "Error opening files" << std::endl;
        return;
    }

    std::string s;
    while (std::getline(inFile, s)) {
        if (s.size() <= 1)
            continue;

        std::istringstream iss(s);
        InterfaceRoute route;
        Route newRoute;
        std::string token;
        bool added = false;

        if (std::getline(iss, route.departure, ',') &&
            std::getline(iss, route.destination, ',') && std::getline(iss, route.travelDay, ',') &&
            std::getline(iss, route.travelTime, ',') && std::getline(iss, route.ticketPrice, ',') &&
            !std::getline(iss, route.rest) && validRecord(route, newRoute)) {
            travelRoutes.push_back(newRoute);
        } else {
            outErr << s << std::endl;
        }
    }

    inFile.close();
    outErr.close();
}

void printRoute(const Route &route) {
    std::cout << route.departure << " " << route.destination << " " << route.travelDay << " "
              << route.travelTime << " " << std::fixed << std::setprecision(2) << route.ticketPrice << std::endl;
}

void filterAndPrintRoutesByDepartureAndDestination(const std::string &departure,
    const std::string &destination) {
    std::cout << "result:" << std::endl;
    for (const Route &route : travelRoutes) {
        if (route.departure == departure && route.destination == destination) {
            printRoute(route);
        }
    }
}

void filterAndPrintRoutesByDay(const std::string &day) {
    std::cout << "result:" << std::endl;
    for (const Route &route : travelRoutes) {
        if (route.travelDay == day) {
            printRoute(route);
        }
    }
}

void filterAndPrintRoutesByMaxTicketPrice(double maxPrice) {
    std::cout << "result:" << std::endl;
    for (const Route &route : travelRoutes) {
        if (route.ticketPrice <= maxPrice) {
            printRoute(route);
        }
    }
}

int main() {
    readRoutes();

    char choice;
    do {
        std::cout << "Enter command (a, b, c, d, e): ";
        std::cin >> choice;

        switch (choice) {
            case 'a': {
                std::string departure, destination;
                std::cout << "Enter departure and destination: ";
                std::cin >> departure >> destination;
                filterAndPrintRoutesByDepartureAndDestination(departure, destination);
                break;
            }
            case 'b': {
                std::string day;
                std::cout << "Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                std::cin >> day;
                filterAndPrintRoutesByDay(day);
                break;
            }
            case 'c': {
                double maxPrice;
                std::cout << "Enter maximum ticket price: ";
                std::cin >> maxPrice;
                filterAndPrintRoutesByMaxTicketPrice(maxPrice);
                break;
            }
            case 'd': {
                std::ifstream errFile("err.txt");
                if (errFile.is_open()) {
                    std::cout << "result:" << std::endl;
                    std::string errLine;
                    while (std::getline(errFile, errLine)) {
                        std::cout << errLine << std::endl;
                    }
                    errFile.close();
                } else {
                    std::cerr << "Error opening err.txt" << std::endl;
                }
                break;
            }
            case 'e':
                std::cout << "Exiting program." << std::endl;
                break;
            default:
                std::cout << "Invalid command. Try again." << std::endl;
        }
    } while (choice != 'e');

    return 0;
}
