#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
using namespace std;


void removeAtstarpe(string& str) {
    str.erase(remove_if(str.begin(), str.end(), ::isspace), str.end());
}

int main() {
    ifstream inFile;
    inFile.open("db.csv");
    ofstream errFile("errText.txt");
    if (!inFile) return 0;
    vector <string> VsakumaPilseta, VbeiguPilseta, VDiena, VLaiks, VCena;
    string line;


  
    while (getline(inFile,line)) {
      if (!all_of(line.begin(),line.end(),::isspace)) {
        string sakumaPilseta,beiguPilseta,Diena,stundasLaiks,minutesLaiks,eiroCena,centiCena;
        istringstream rinda(line);
        getline(rinda,sakumaPilseta, ',');
        getline(rinda,beiguPilseta, ',');
        getline(rinda,Diena, ',');
        getline(rinda,stundasLaiks, ':');
        getline(rinda,minutesLaiks, ',');
        getline(rinda,eiroCena, '.');
        getline(rinda,centiCena, '\n');
        
        removeAtstarpe(sakumaPilseta);
        removeAtstarpe(beiguPilseta);
        removeAtstarpe(Diena);
        removeAtstarpe(stundasLaiks);
        removeAtstarpe(minutesLaiks);
        removeAtstarpe(eiroCena);
        removeAtstarpe(centiCena);

        if (!sakumaPilseta.empty() && !beiguPilseta.empty() && !Diena.empty() && !stundasLaiks.empty() && !minutesLaiks.empty() && !eiroCena.empty() && !centiCena.empty() && !(stundasLaiks>"23"||stundasLaiks<"0") && !(minutesLaiks>"59"||minutesLaiks<"0") && !(centiCena>"99"||centiCena<"0") && isdigit(centiCena.back())) {
            VsakumaPilseta.push_back(sakumaPilseta);
            VbeiguPilseta.push_back(beiguPilseta);
            VDiena.push_back(Diena);
            VLaiks.push_back(stundasLaiks + ":" + minutesLaiks);
            VCena.push_back(eiroCena + "." + centiCena);
        } else {
            errFile<<line<<'\n';
        }
      }
    }

    inFile.close();
    errFile.close();
  
    while (true) {
        string command;
        cin>>command;
        if (command=="a") {
            string sakumaPilseta,beiguPilseta;
            cin>>sakumaPilseta;
            cin>>beiguPilseta;
            cout<<"result:"<<endl;
            for (int i=0; i<VsakumaPilseta.size(); i++) {
                if (VsakumaPilseta[i]==sakumaPilseta && VbeiguPilseta[i]==beiguPilseta) {
                  cout<<VsakumaPilseta[i]<<" "<<VbeiguPilseta[i]<<" "<<VDiena[i]<<" "<<VLaiks[i]<<" "<<VCena[i]<<endl;
                }
            }
        } else if (command=="b"){
          string diena;
          cin>>diena;
          cout<<"result:"<<endl;
          for (int i=0; i<VsakumaPilseta.size(); i++) {
            if(VDiena[i]==diena){
              cout<<VsakumaPilseta[i]<<" "<<VbeiguPilseta[i]<<" "<<VDiena[i]<<" "<<VLaiks[i]<<" "<<VCena[i]<<endl;
            }
          }
        } else if (command=="c"){
          string summa_string;
          cin>>summa_string;
          double summa = stod(summa_string);
          cout<<"result:"<<endl;
          for(int i=0; i<VsakumaPilseta.size();i++){
            double cena=stod(VCena[i]);
            if(summa>=cena){
              cout<<VsakumaPilseta[i]<<" "<<VbeiguPilseta[i]<<" "<<VDiena[i]<<" "<<VLaiks[i]<<" "<<VCena[i]<<endl;
            }
          }
        } else if (command=="d"){
            cout<<"result:"<<endl;
            ifstream errFileReader("errText.txt");
            if (errFileReader.is_open()) {
                string line;
                while (getline(errFileReader,line)) {
                    cout<<line<<endl;
                }
                errFileReader.close();
            }
        } else if (command=="e") {
            break;
        }
    }
    inFile.close();
    errFile.close();
    return 0;
}
