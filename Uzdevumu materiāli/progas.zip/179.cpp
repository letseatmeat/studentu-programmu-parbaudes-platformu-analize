#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

struct BusRoute {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};

// laika formata parbaude
bool isValidTimeFormat(const string &time) {   
  string trimmedTime = time;
  // atstarpes dzēšana        
  trimmedTime.erase(remove_if(trimmedTime.begin(), trimmedTime.end(), ::isspace), trimmedTime.end());

  // formata parbaude   
  return  trimmedTime.size() == 5 && isdigit (trimmedTime[0]) && isdigit (trimmedTime[1]) && trimmedTime[2] == ':' && isdigit (trimmedTime[3]) && isdigit (trimmedTime[4]);
}  


bool isValidRoute(const BusRoute &route, const string &line) {
  return  !route.startStop.empty() && !route.endStop.empty() && !route.dayOfWeek.empty() && isValidTimeFormat(route.time) && route.ticketPrice > 0;  
}


// maršruta lasīšana, parbaude, kļūdainu mašrutu ierakstīšana err.txt failā
vector<BusRoute> readAndProcessRoutes(const string &filename, ofstream &errFile) {   
  vector<BusRoute> routes;
  ifstream file(filename);    
         
  if (!file.is_open()) 
  {
    cerr << "Unable to open file: " << filename << endl;
    exit(EXIT_FAILURE);   
  }

  string line;
  while (getline(file, line)) 
  {
    istringstream iss(line);
    BusRoute route;

    // rindu sadilīšana pa ,
    if (getline(iss, route.startStop, ',') &&
        getline(iss, route.endStop, ',') &&
        getline(iss, route.dayOfWeek, ',') && getline(iss, route.time, ',') &&
        (iss >> route.ticketPrice)) 
    {
        //atstarpju dzēšana
        route.startStop.erase(remove_if(route.startStop.begin(), route.startStop.end(), ::isspace),route.startStop.end());
        route.endStop.erase(remove_if(route.endStop.begin(), route.endStop.end(), ::isspace),route.endStop.end());
        route.dayOfWeek.erase(remove_if(route.dayOfWeek.begin(), route.dayOfWeek.end(), ::isspace),route.dayOfWeek.end());
        route.time.erase(remove_if(route.time.begin(), route.time.end(), ::isspace),route.time.end());

      // nav simbolu pēc ticketPrice
      string afterTicketPrice;
      getline(iss >> ws, afterTicketPrice);
      if (afterTicketPrice.find_first_not_of(" \t") == string::npos) 
      {
        if (isValidRoute(route, line)) 
        {
          routes.push_back(route);
        } 
        else 
        {
          errFile << line << endl;
        }
      } 
      else 
      {
        errFile << line << endl;
      }

    } 
    else 
    {
      errFile << line << endl;
    }
  }

  file.close();
  return routes;
}

// ieraksta tikai pareizus maršrutus jaunā faila, lai labāk saprast
// void writeRoutesToFile(const vector<BusRoute>& routes, const string&
// outputFilename) {
//     ofstream outputFile(outputFilename);

//     if (!outputFile.is_open()) {
//         cerr << "Unable to open file: " << outputFilename << endl;
//         exit(EXIT_FAILURE);
//     }

//     for (const auto& route : routes) {
//         outputFile << route.startStop << "," << route.endStop << "," <<
//         route.dayOfWeek << ","<< route.time << "," << fixed <<
//         setprecision(2) << route.ticketPrice << endl;
//     }

//     outputFile.close();
// }

//-------------------------------------------------------------------

int main() {
  string inputFilename = "db.csv";
  string errorFilename = "err.txt";
  // string outputFilename = "correct_routes.csv";

  //err.txt fails katru reizi tiek rakstīts no jauna
  ofstream errFile(errorFilename, ios::trunc);
  vector<BusRoute> routes = readAndProcessRoutes(inputFilename, errFile);
  // writeRoutesToFile(routes, outputFilename);
  errFile.close();
  // string input;
  char command;

  while (command != 'e') {   
    cout << "Enter command (a, b, c, d, e): ";
    cin >> command;

    switch (command) {
    case 'a': {
      string startStop, endStop;
      cin >> startStop >> endStop;
      cout << "result:" << endl;
        
      bool foundRoutes = false;
      for (const auto &route : routes) 
      {    
        if (route.startStop == startStop && route.endStop == endStop) 
        {
          foundRoutes = true;
          cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
      }

      if (!foundRoutes) {
        cout << "No routes found from " << startStop << " to " << endStop
             << endl;
      }
      break;
    }
      //----------------------------------------------------------------
    case 'b': {
      string dayOfWeek;
      cout << "Day of the week (Pr,Ot,Tr,Ce,Pt,St,Sv): ";
      cin >> dayOfWeek;
      cout << "result:" << endl;

      bool foundRoutes = false;
      for (const auto &route : routes) 
      {
        if (route.dayOfWeek == dayOfWeek) 
        {
          foundRoutes = true;
          cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
      }

      if (!foundRoutes) {
        cout << "No routes found on " << dayOfWeek << endl;
      }
      break;
    }
      //----------------------------------------------------------------
    case 'c': {
      string ticketPriceStr;
      cin >> ticketPriceStr;

      // parveidošana par skaitli
      double ticketPrice = stod(ticketPriceStr);
      cout << "result:" << endl;

      bool foundRoutes = false;
      for (const auto &route : routes) 
      {
        if (route.ticketPrice <= ticketPrice) 
        {
          foundRoutes = true;
          cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
      }

      if (!foundRoutes) {
        cout << "No routes found " << endl;
      }
      break;
    }
      //----------------------------------------------------------------
    case 'd': {

      ifstream errFile("err.txt");
      if (!errFile.is_open()) {
        cerr << "Unable to open file: err.txt" << endl;
        return 1;
      }

      cout << "result:" << endl;
      string line;
      while (getline(errFile, line)) 
      {
        line.erase(remove_if(line.begin(), line.end(),[](char c) { return isspace(c); }),line.end());
        
        if (!line.empty()) 
        {
          cout << line << endl;
        }
      }
      errFile.close();
      break;
    }
      //----------------------------------------------------------------
    case 'e': {
      break;
    }
    default: {
      cout << "Wrong command, try again" << endl;
    }
    }
  }
  return 0;
}