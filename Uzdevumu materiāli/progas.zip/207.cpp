
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>
#include <regex>

using namespace std;

bool isValidDay(string diena) {
  vector<string> validDays = { "Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv" };
  return find(validDays.begin(), validDays.end(), diena) != validDays.end();
}

bool isValidTime(string laiks) {
  regex regexTime("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
  return regex_match(laiks, regexTime);
}

bool isValidPrice(string cena) {
  regex regexPrice("^\\d+(\\.\\d+)?$");
  return regex_match(cena, regexPrice);
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  ofstream outFile("err.txt");
  
  if (!inFile)
    return 0;

  string line;

  char choice;

  while (true) {
    cout << "a, b, c, d vai e" << endl;
    cin >> choice;

    switch (choice) {
    case 'a': {
      string pietura1;
      string pietura2;
      cin >> pietura1;
      cin >> pietura2;
      cout << "result:"<<endl;
      
      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        if (all_of(line.begin(), line.end(), [](char ch) {
          return isspace(static_cast<unsigned char>(ch));
        })) {
          continue;
        }
        line.erase(remove(line.begin(), line.end(), ' '), line.end());

        vector<string> dati;
        string data;
        istringstream ss(line);
        while (getline(ss, data, ',')) {

          dati.push_back(data);
        }

        if (dati.size() == 5) {
          string &diena = dati[2];
          string &laiks = dati[3];
          string &cena = dati[4];

          if (isValidDay(diena) && isValidTime(laiks)
              && isValidPrice(cena)) {
            if (pietura1 == dati[0] && pietura2 == dati[1]) {
              for (const auto &data : dati) {
                cout << data << " ";
              }
              cout << endl;
            }
          } //if
          else {

            dati.clear();

          } //else
        } else {

          dati.clear();

        }
      }
    }
      break;
    case 'b': {

      string dienas;
      cin >> dienas;
      cout << "result:"<<endl;
      
      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        if (all_of(line.begin(), line.end(), [](char ch) {
          return isspace(static_cast<unsigned char>(ch));
        })) {
          continue;
        }
        line.erase(remove(line.begin(), line.end(), ' '), line.end());

        vector<string> dati;
        string data;
        istringstream ss(line);
        while (getline(ss, data, ',')) {

          dati.push_back(data);
        }

        if (dati.size() == 5) {
          string &diena = dati[2];
          string &laiks = dati[3];
          string &cena = dati[4];

          if (isValidDay(diena) && isValidTime(laiks)
              && isValidPrice(cena)) {
            if (dienas == dati[2]) {
              for (const auto &data : dati) {
                cout << data << " ";
              }
              cout << endl;
            }
          } //if
          else {

            dati.clear();

          } //else
        } else {

          dati.clear();

        }
      }
    }
      break;
    case 'c': {
      float biletesCena;
      cin >> biletesCena;
      cout << "result:"<<endl;
      
      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        if (all_of(line.begin(), line.end(), [](char ch) {
          return isspace(static_cast<unsigned char>(ch));
        })) {
          continue;
        }
        line.erase(remove(line.begin(), line.end(), ' '), line.end());

        vector<string> dati;
        string data;
        istringstream ss(line);
        while (getline(ss, data, ',')) {

          dati.push_back(data);
        }

        if (dati.size() == 5) {
          string &diena = dati[2];
          string &laiks = dati[3];
          string &cena = dati[4];

          if (isValidDay(diena) && isValidTime(laiks) && isValidPrice(cena)) {
            float cenaFloat = stof(cena);
            if (cenaFloat <= biletesCena) {
              for (const auto &data : dati) {
                cout << data << " ";
              }
              cout << endl;
            }
          } //if
          else {
            dati.clear();
          } //else
        } else {
          dati.clear();
        }
      }

    }
      break;
      case 'd': {
        inFile.clear();
        inFile.seekg(0, ios::beg);

        cout << "result:"<<endl;
        
        while (getline(inFile, line)) {
          if (all_of(line.begin(), line.end(), [](char ch) {
            return isspace(static_cast<unsigned char>(ch));
          })) {
            continue;
          }
          line.erase(remove(line.begin(), line.end(), ' '), line.end());

          vector<string> dati;
          string data;
          istringstream ss(line);
          while (getline(ss, data, ',')) {

            dati.push_back(data);
          }

          string &diena = dati[2];
          string &laiks = dati[3];
          string &cena = dati[4];

          if (dati.size() != 5) {
            for (int i = 0; i < dati.size(); ++i) {
              outFile << dati[i];
              if (i < dati.size() - 1) {
                outFile << ",";
              }
            }
            outFile << endl;
            dati.clear();
          }

          if (!isValidDay(diena) || !isValidTime(laiks) || !isValidPrice(cena)) {
            for (int i = 0; i < dati.size(); ++i) {
              outFile << dati[i];
              if (i < dati.size() - 1) {
                outFile << ",";
              }
            }
            outFile << endl;
            dati.clear();
          } // if
        } // while
        outFile.close();
        ifstream outFileRead("err.txt");
        while (getline(outFileRead, line)) {
          if (all_of(line.begin(), line.end(), [](char ch) {
            return isspace(static_cast<unsigned char>(ch));
          })) {
            continue;
          }
          cout << line << endl;
        } // while
      } // case
        break;
    case 'e':
      return 0;
    }
  }

  inFile.close();
  outFile.close();
  return 0;
}
