

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Routes{
  string Start;
  string End;
  string Day;
  string Time;
  double Price;
};

bool isValidDay(const string& day){
  static const vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return find(days.begin(), days.end(), day) != days.end();
}

void printRoute(const Routes& route){
  cout <<route.Start << " " << route.End << " " << route.Day << " " << route.Time << " " << fixed << setprecision(2) << route.Price << endl;
}

int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

	if (!inFile || !errFile) return 0;

  vector<Routes> routes;
  
  string s; 
	while (getline(inFile, s)){
    s.erase(0, s.find_first_not_of(" \t\r\n"));
    s.erase(s.find_last_not_of(" \t\r\n")+1);

    if (s.empty()) continue;
    
    stringstream strs(s);
    vector<string> tokens;
    string token;

    while (getline(strs,token, ',')){
      token.erase(0, token.find_first_not_of(" \t\r\n"));
      token.erase(token.find_last_not_of(" \t\r\n")+1);
      tokens.push_back(token);
    }

    if(tokens.size() != 5){
      errFile << s << endl;
      continue;
    }

    Routes route;
    route.Start = tokens[0];
    route.End = tokens[1];
    route.Day = tokens[2];
    route.Time = tokens[3];

    try{
      route.Price = stod(tokens[4]);
      
    } catch(const invalid_argument& e){
      errFile << s << endl;
      continue;
    }

    if(!isValidDay(route.Day)){
      errFile << s << endl;
      continue;
    }
      
    routes.push_back(route);
  }
char request;
do{
  cin>>request;

  switch(request){
    case 'a':{
      string start, end;
      cin>>start>>end;
      cout<< "result:"<<endl;
      for (const auto & route : routes){
        if (route.Start == start && route.End == end){
          printRoute(route);
        }
      }
      break;
    }
    case 'b':{
      string day;
      cin>>day;
      cout<< "result:"<<endl;
      for(const auto& route : routes){
        if (route.Day == day){
          printRoute(route);
        }
      }
      break;
    }
    case 'c':{
      double PriceMax;
      cin>>PriceMax;
      cout<< "result:"<<endl;
      for(const auto& route : routes){
        if (route.Price <= PriceMax){
          printRoute(route);
        }
      }
      break;
    }
    case 'd':{
      ifstream errFile("err.txt");
      if(errFile){
        cout<<"result:"<<endl;
        string error;
        while(getline(errFile, error)){
          cout<<error<<endl;
        }
      }
      break;
    }
    case 'e':
      break;
    default:
      cout<<"error"<<endl;
  }
}while(request != 'e');

return 0;
}
