

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Marshruts {
string sakpietura;
string galpietura;
string neddiena;
string laiks;
double bilcena;
};

string apgriezt(const string& str) {
  size_t pirmais = str.find_first_not_of(' ');
  if (string::npos == pirmais) {
    return str;
  }
  size_t pedejais = str.find_last_not_of(' ');
  return str.substr(pirmais,(pedejais - pirmais + 1));
}

int main() {
  vector<Marshruts> marshruti;
  string rinda, vards;

  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) {
    return 0;
  }
  ofstream outFile;
  outFile.open("err.txt");
  if (!outFile) {
    return 0;
  }

  while (getline(inFile,rinda)) {
    stringstream pl(rinda);
    vector<string> vardi;
    while (getline(pl,vards,',')) {
      vardi.push_back(apgriezt(vards));
    }
    if (vardi.size() != 5) { 
        outFile << rinda << endl;
    }
    else {
      try {
        Marshruts m;
        m.sakpietura = vardi[0];
        m.galpietura = vardi[1];
        m.neddiena = vardi[2];
        m.laiks = vardi[3];
        m.bilcena = stod(vardi[4]);
        if (isalpha(m.galpietura[0])) {
          marshruti.push_back(m);
        }
        else {
          throw invalid_argument("error");
        }
      }
      catch (...) {
        outFile << rinda << endl;
      }
    }
  }

  char vaicajums;
  do {
    cin >> vaicajums;
    switch (vaicajums) {

      case 'a': {
        string sakpietura;
        string galpietura;
        cin >> sakpietura >> galpietura;
        cout << "result:" << endl;
        for (Marshruts m : marshruti) {
          if (m.sakpietura == sakpietura && m.galpietura == galpietura) {
            cout << m.sakpietura << " " << m.galpietura << " " << m.neddiena << " " << m.laiks << " " << fixed << setprecision(2) << m.bilcena << endl;
          }
        }
        break;
      }

      case 'b': {
        string neddiena;
        cin >> neddiena;
        cout << "result:" << endl;
        for (Marshruts m : marshruti) {
          if (m.neddiena == neddiena) {
            cout << m.sakpietura << " " << m.galpietura << " " << m.neddiena << " " << m.laiks << " " << fixed << setprecision(2) << m.bilcena << endl;
          }
        }
        break;
      }

      case 'c': {
        double bilcena;
        cin >> bilcena;
        cout << "result:" << endl;
        for (Marshruts m : marshruti) {
          if (m.bilcena <= bilcena) {
            cout << m.sakpietura << " " << m.galpietura << " " << m.neddiena << " " << m.laiks << " " << fixed << setprecision(2) << m.bilcena << endl;
          }
        }
        break;
      }

      case 'd': {
        ifstream outFile("err.txt");
        cout << "result:" << endl;
        while (getline(outFile,rinda)) {
          if (!rinda.empty() && !std::all_of(rinda.begin(), rinda.end(), ::isspace)) {
            cout << rinda << endl;
          }
        }
        break;
      }

      case 'e': {
        break;
      }
      
      default: {
        break;
      }
    }
  }
    
    while (vaicajums != 'e'); {
    return 0;
    }
}
