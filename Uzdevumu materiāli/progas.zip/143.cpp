
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm> 


using namespace std;

struct AutobusaMaršruts {
  string sakumaPietura;
  string galaPietura;
  string nedelasDiena;
  string laiks;
  double billetesCena;
};

bool isValidTime(const string& time) {
  if (time.length() != 5) { // Laika formātam jābūt hh:mm
    return false;
  }

  if (!isdigit(time[0]) || !isdigit(time[1]) || time[2] != ':' || !isdigit(time[3]) || !isdigit(time[4])) {
    return false;
  }

  int hours = stoi(time.substr(0, 2));
  int minutes = stoi(time.substr(3, 2));

  if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
    return false;
  }

  return true;
}


bool isValidDay(const string& day) {
  vector<string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

  return find(validDays.begin(), validDays.end(), day) != validDays.end();
}


bool isValidPrice(const string& price) {
  try {
    stod(price);
    return true;
  } catch (...) {
    return false;
  }
}

bool parseLine(const string& line, AutobusaMaršruts& maršruts) {
  istringstream ss(line);
  string field;

  vector<string> fields; // Saglabājam visus laukus, lai pārbaudītu to skaitu

  while (getline(ss, field, ',')) {
    field.erase(0, field.find_first_not_of(" \t\r\n"));
    field.erase(field.find_last_not_of(" \t\r\n") + 1);

    fields.push_back(field);
  }

  if (fields.size() != 5) {
    return false;
  }

  maršruts.sakumaPietura = fields[0];
  maršruts.galaPietura = fields[1];
  maršruts.nedelasDiena = fields[2];
  maršruts.laiks = fields[3];

  if (!isValidTime(maršruts.laiks) || !isValidDay(maršruts.nedelasDiena)) {
    return false;
  }

  if (!isValidPrice(fields[4])) {
    return false;
  }

  maršruts.billetesCena = stod(fields[4]);
  return true;
}


void readDataFromFile(const string& filename, vector<AutobusaMaršruts>& routes, ofstream& errorFile) {
  ifstream file(filename);
    if (!file.is_open()) {
      cerr << "Nevar atvērt failu." << endl;
      return;
    }

    string line;
    while (getline(file, line)) {
      AutobusaMaršruts maršruts;
      if (parseLine(line, maršruts)) {
          routes.push_back(maršruts);
      } else {
          // kļūdaina info failā err.txt
          errorFile << line << endl;
      }
    }

  file.close();
}

int main() {
  vector<AutobusaMaršruts> autobusaMaršruti;
  ofstream errorFile("err.txt");

  readDataFromFile("db.csv", autobusaMaršruti, errorFile);

  char choice;
  do {
    cin >> choice;
    switch (choice) {
      case 'a': {
        string start, end;
        cin >> start >> end;

        cout << "result:" << endl;
        for (const auto& route : autobusaMaršruti) {
          if (route.sakumaPietura == start && route.galaPietura == end) {
              cout << route.sakumaPietura << " " << route.galaPietura << " "
                   << route.nedelasDiena << " " << route.laiks << " " <<fixed << 
setprecision(2) << route.billetesCena << endl;
            }
        }
      break;
      }
      case 'b': {
        string day;
        
        cin >> day;

        cout << "result:" << endl;
        for (const auto& route : autobusaMaršruti) {
          if (route.nedelasDiena == day) {
            cout << route.sakumaPietura << " " << route.galaPietura << " "
                   << route.nedelasDiena << " " << route.laiks << " " << fixed << setprecision(2) << route.billetesCena << endl;
          }
        }
      break;
      }
      case 'c': {
        double maxPrice;
        cin >> maxPrice;
        cout << "result:" << endl;
        for (const auto& route : autobusaMaršruti) {
          if (route.billetesCena <= maxPrice) {
            cout << route.sakumaPietura << " " << route.galaPietura << " "
                   << route.nedelasDiena << " " << route.laiks << " " << fixed << setprecision(2) << route.billetesCena << endl;
          }
        }
      break;
      }
      case 'd': {
        ifstream errFile("err.txt");
        if (errFile.is_open()) {
          string line;
          while (getline(errFile, line)) {
            cout << line << endl;
            }
            errFile.close();
        } else {
            cerr << "Nevar atvērt err.txt" << endl;
        }
      break;
      }
      case 'e':
      break;
      default:
          cout << "Nepareiza komanda. Lūdzu, izvēlieties pareizu komandu." << endl;
  }
  } while (choice != 'e');

  return 0;
}