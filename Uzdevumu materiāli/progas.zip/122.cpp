#include <algorithm>
#include <fstream>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>
#include <regex>

using namespace std;

// !!!!!!!   2. tests  neiet, lai gan visas izvades sakrīt    !!!!!!!!!!


// Izvadīt ekrānā visus reisus, kas kursē norādīta maršruta 
void printAToZ(vector<vector<string>> data) {
  vector<vector<string>> vec = data;
  string fromB;
  string toB;
  cin >> fromB;
  cin >> toB;

  cout << "result:" << endl;
  for (const auto &row : vec) {
    if (fromB == row[0] && toB == row[1]) {
      for (const auto &elem : row) {
        cout << elem << ' ';
      }
      cout << endl;
    }  
  }
}




//  Tālāk ir datu validācija
// Pārbauda vai dienas ir pareizi ievadītas
bool checkDay(vector<string> row) {
  vector<string> days{"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  bool found = (find(days.begin(), days.end(), row[2]) != days.end());
  return found;
}

// pārbauda vai laiks ir pareizā formātā
bool checkTime(vector<string> row) {
  regex laika_formats ("([01]?[0-9]|2[0-3]):[0-5][0-9]");
  return regex_match (row[3], laika_formats);
}

// pārbauda vai cena ir pareizi ievadīta
bool validatePrices(vector<string> row) {
  try {
    double price = stod(row[4]);

    if (price <= 0) {
        return false; 
    }
    return true;
  } catch (exception e) {
      return false;
  }
}



// Izvadīt ekrānā visus reisus, kas kursē noteiktā nedēļas dienā 
void printMDay(vector<vector<string>> data) {
  vector<vector<string>> vec = data;

  string day;
  cin >> day;
  cout << "result:" << endl;
  for (const auto &row : vec) {
    if (day == row[2]) {
      for (const auto &elem : row) {
        cout << elem << ' ';
      }
      cout << endl;
    }

  }
}



// Izvadīt ekrānā visus reisus, kuru biļetes maksa nepārsniedz ievadīto
void printMPrice(vector<vector<string>> data) {
  vector<vector<string>> vec = data;

  double price;
  cin >> price;
  cout << "result:" << endl;
  for (const auto &row : vec) {
    if (price > stod(row[4])) {
      for (const auto &elem : row) {
        cout << elem << ' ';
      }
      cout << endl;
    }

  }
}



// Izvadīt ekrāna err.txt faila saturu
void printErr() {
  ifstream inErrFile;
  inErrFile.open("err.txt");

  string line;

  cout << "result:" << endl;
  while(getline(inErrFile, line)){
    cout << line << endl;
  }
  inErrFile.close();
}




int main() {
  ifstream inFile;
  inFile.open("db.csv");

  ofstream errFile;
  errFile.open ("err.txt");

  if (!inFile)
    return 0;

  string line;
  vector<vector<string>> data;

  while (getline(inFile, line)) {
    stringstream lineStream(line);
    string cell;
    vector<string> dataRow;
    while (getline(lineStream, cell, ',')) {
      cell.erase(remove_if(cell.begin(), cell.end(), ::isspace), cell.end());
      dataRow.push_back(cell);
    }

    if (cell == "" || cell.empty()) {
      continue;
    }

    if (dataRow.size() != 5 || !checkDay(dataRow) || !checkTime(dataRow) || !validatePrices(dataRow) ){
      errFile << line << endl;
      continue;
    }
    data.push_back(dataRow);
  }
  inFile.close();
  errFile.close();

  char choine;
  bool loopTF = true;

  // Cikls kurā izvēlas kādu darbību veikt 
  while (loopTF) {
    cin >> choine;
    switch (choine) {
    case 'a':
      printAToZ(data);
      break;
    case 'b':
      printMDay(data);
      break;
    case 'c':
      printMPrice(data);
      break;
    case 'd':
      printErr();
      break;
    case 'e':
      loopTF = false;
      break;
    default:
      cout << "Error" << '\n';
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
  }

  // Nodzēšu visu err.txt faila saturu
  ofstream errFileD;
  errFileD.open ("err.txt", ofstream::out | ofstream::trunc);
  errFileD.close();
}
