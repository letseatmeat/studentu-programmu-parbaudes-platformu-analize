#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <regex>

using namespace std;

string trimStar(string str) {
  const string whiteSpaces = " \t\n\r\f\v";
  
  int first_non_space = str.find_first_not_of(whiteSpaces);
  str.erase(0, first_non_space);
  int last_non_space = str.find_last_not_of(whiteSpaces);
  str.erase(last_non_space + 1);
  
  return str;
}

vector<map<string, string>> chickenMap(vector<string> vect) {
  vector<map<string, string>> m;
  fstream outFile("err.txt");
  
  string arr[5];
  int count;

  for(auto n: vect) {
    for(int i=0; i<5; i++) {
      arr[i]="";
    }
    count=0;

    stringstream ss(n);
    string str;
    while (getline(ss, str, ',')) {
      if(count<5) {
        arr[count]=trimStar(str);
      }
      count++;
    }

    if(count == 5) {
      bool check_from = regex_match(arr[0], regex("[A-Z]{1}[a-z]{2,}"));
      bool check_to = regex_match(arr[1], regex("[A-Z]{1}[a-z]{2,}"));
      bool check_day = false;
      bool check_time = regex_match(arr[3], regex("\\d\\d[:]\\d\\d"));
      bool check_price = regex_match(arr[4], regex("\\d+[.]\\d\\d"));
      
      string days[7] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
      for(int i=0; i<7; i++) {
        if(days[i]==arr[2]) {
          check_day = true;
          break;
        }
      }
      
      if (check_from && check_to && check_day && check_time && check_price) {
        m.push_back({
          {"from", arr[0]},
          {"to", arr[1]},
          {"day", arr[2]},
          {"time", arr[3]},
          {"price", arr[4]}
        });
      } else {
        if(!trimStar(n).empty()) {
          outFile << n << endl;
        }
      }
    } else {
      if(!trimStar(n).empty()) {
        outFile << n << endl;
      }
    }
  }
  outFile.close();
  return m;
}

void a(vector<string> vect) {
  string from, to;
  cin >> from >> to;
  cout << "result:" << endl;

  vector<map<string,string>> x = chickenMap(vect);
  for(auto n: x) {
    if (n["from"]==from && n["to"]==to) {
      cout << n["from"] << " " << n["to"] << " " << n["day"] << " " << n["time"] << " " << n["price"] << endl;
    }
  }
  
  return;
}

void b(vector<string> vect) {
  string day;
  cin >> day;
  cout << "result:" << endl;

  vector<map<string,string>> x = chickenMap(vect);
  for(auto n: x) {
    if (n["day"]==day) {
      cout << n["from"] << " " << n["to"] << " " << n["day"] << " " << n["time"] << " " << n["price"] << endl;
    }
  }
  
  return;
}

void c(vector<string> vect) {
  double price;
  cin >> price;
  if(!cin.fail()){
    cout << "result:" << endl;
  
    vector<map<string,string>> x = chickenMap(vect);
    for(auto n: x) {
      try {
        if (stod(n["price"])<price) {
          cout << n["from"] << " " << n["to"] << " " << n["day"] << " " << n["time"] << " " << n["price"] << endl;
        }
      } catch(invalid_argument e) {
        continue;
      }      
    }
  } else{
    cin.clear();
    return;
  }
  return;
}

void d(vector<string> vect) {
  chickenMap(vect);
  
  string errTxt;
  
  ifstream errFile("err.txt");

  cout << "result:" << endl;
  while (getline(errFile, errTxt)) {
    cout << errTxt << endl;
  }

  return;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) {
    inFile.close();
    return 0;
  }

  vector<string> svec;
  string s;
  while (getline(inFile, s)) {
    svec.push_back(s);
  }
  inFile.close();

  char input;
  while (input != 'e') {
    cin >> input;
    switch (int(input)) {
      case 100:
        d(svec);
        break;
      case 97:
        a(svec);
        break;
      case 98:
        b(svec);
        break;
      case 99:
        c(svec);
        break;
      case 101:
        break;
      default:
        break;
    }
  }

  return 0;
}