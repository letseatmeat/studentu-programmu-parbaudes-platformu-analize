
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>

struct cels {
    std::string start;
    std::string end;
    std::string day;
    std::string time;
    double price;
};

bool parseLine(const std::string& line, cels& marsruts) {
    std::stringstream ss(line);
    std::string field;
    std::vector<std::string> fields;

    while (getline(ss, field, ',')) {
        fields.push_back(field);
    }

    if (fields.size() != 5) {
        return false;
    }
      marsruts.start = fields[0];
      marsruts.end = fields[1];
      marsruts.day = fields[2];
      marsruts.time = fields[3];
      marsruts.price = std::stod(fields[4]);
    return true;
}

void printMarsruti(const std::vector<cels>& marsruti) {
    std::cout << "result:" << std::endl;
    for (const auto& marsruts : marsruti) {
        std::cout << marsruts.start << " " << marsruts.end << " " << marsruts.day << " " << marsruts.time << " " << std::fixed << std::setprecision(2) << marsruts.price << std::endl;
    }
}

int main() {
    std::ifstream db("db.csv");
    std::ofstream err("err.txt");
    std::string line;
    cels marsruts;
    std::vector<cels> marsruti;

    while (getline(db, line)) {
        if (parseLine(line, marsruts)) {
            marsruti.push_back(marsruts);
        } else {
            err << line << std::endl;
        }
    }

    char command;
    do {
        std::cin >> command;
        switch (command) {
            case 'a': {
                std::string start, end;
                std::cin >> start >> end;
                std::vector<cels> result;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.start == start && marsruts.end == end) {
                        result.push_back(marsruts);
                    }
                }
                printMarsruti(result);
                break;
            }
            case 'b': {
                std::string day;
                std::cin >> day;
                std::vector<cels> result;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.day == day) {
                        result.push_back(marsruts);
                    }
                }
                printMarsruti(result);
                break;
            }
            case 'c': {
                double maxPrice;
                std::cin >> maxPrice;
                std::vector<cels> result;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.price <= maxPrice) {
                        result.push_back(marsruts);
                    }
                }
                printMarsruti(result);
                break;
            }
            case 'd': {
                std::ifstream err("err.txt");
                std::cout << "result:" << std::endl;
                while (getline(err, line)) {
                    std::cout << line << std::endl;
                }
                break;
            }
        }
    } while (command != 'e');

    return 0;
}


