
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>


using namespace std;


struct Route {
    string start;
    string end;
    string day;
    string time;
    double price;
};


string trim(const string& str) {
  size_t first = str.find_first_not_of(' ');
  if (string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}


void printRoutesByRoute(const vector<Route>& routes, const string& start, const string& end) {
  for (const Route& route : routes) {
    if (route.start == start && route.end == end) {
      cout << route.start << " " << route.end << " " << route.day << " "
      << route.time << " " << fixed << setprecision(2) << route.price << endl;
    }
  }
  cout << endl;
}


void printRoutesByDay(const vector<Route>& routes, const string& day) {
  for (const Route& route : routes) {
    if (route.day == day) {
      cout << route.start << " " << route.end << " " << route.day << " "
      << route.time << " " << fixed << setprecision(2) << route.price << endl;
    }
  }
  cout << endl;
}


void printRoutesByPrice(const vector<Route>& routes, double maxPrice) {
  for (const Route& route : routes) {
    if (route.price <= maxPrice) {
      cout << route.start << " " << route.end << " " << route.day << " "
      << route.time << " " << fixed << setprecision(2) << route.price << endl;
    }
  }
  cout << endl;
}


void printErrFileContent() {
  ifstream errFile("err.txt");
  string line;
  while (getline(errFile, line)) {
    if(!line.empty()) {
    cout << line << endl;
    }
  }
}


void processErrors(ofstream& errFile, const string& line, const bool& errorsFound, const vector<string>& tokens) {
  if (tokens.size() != 5) {
    errFile << line << endl; 
  } else {
    try {
      double price = stod(tokens[4]); 
      string time = tokens[3];
      if (time.size() != 5 || time[2] != ':') {
        errFile << line << endl; 
      }
    } catch (const exception& e) {
      errFile << line << endl; 
    }
  }
}


int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");
  vector<Route> routes;
  string line;
  bool errorsFound = false; 

  if (!inFile) {
    cerr << "Nevar atvert failu db.csv" << endl;
    return 1;
  }

  while (getline(inFile, line)) {
    stringstream ss(line);
    vector<string> tokens;
    string token;

    while (getline(ss, token, ',')) {
      tokens.push_back(trim(token)); 
    }

    processErrors(errFile, line, errorsFound, tokens);

    if ( tokens.size() == 5) {
      try {
         Route route = {tokens[0], tokens[1], tokens[2], tokens[3], stod(tokens[4])};
          routes.push_back(route);
      } catch (const exception& e) {
        errorsFound = true; 
      }
    } else {
      errorsFound = true; 
    }
  }


  char choice;
  do {
    cin >> choice;
    switch (choice) {

      case 'a': {
        string start, end;
        cin.ignore(); 
        cout<<"result:"<<endl;
        getline(cin, start);
        getline(cin, end);
        printRoutesByRoute(routes, start, end);
        break;
      }

      case 'b': {
        string day;
        cin >> day;
        cout<<"result:"<<endl;
        printRoutesByDay(routes, day);
         break;
      }

      case 'c': {
        double maxPrice;
        cin >> maxPrice;
        cout<<"result:"<<endl;
        printRoutesByPrice(routes, maxPrice);
        break;
      }

      case 'd':
        cout<<"result:"<<endl;
        printErrFileContent();
        break;

      case 'e':
        break;

      default:
         cout << "Nepareiza izvele. Meginiet velreiz." << endl;
    }
  } while (choice != 'e');
}