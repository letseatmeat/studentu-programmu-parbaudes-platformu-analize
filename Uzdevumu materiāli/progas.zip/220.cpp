

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

struct autobusa_marsuts {
  string sakums;
  string beigas;
  string diena;
  string laiks;
  double cena;
};

int main() {
  vector<autobusa_marsuts> marsuts;

  ifstream inFile;
  inFile.open("db.csv");

  ofstream file("err.txt");

  string line;

  while (std::getline(inFile, line)) {
    line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (!line.empty()) {
      char delimiter = ',';
      size_t numberOfSplits = count(line.begin(), line.end(), delimiter) + 1;
      
      if (numberOfSplits == 5) {
        string line_part;
        string autobusi[5];
        int numb = 0;
        istringstream ss(line);
        while (getline(ss, line_part, ',')) {
          autobusi[numb] = line_part;
          numb++;
        }
      
        if (autobusi[2].length() == 2 and autobusi[3].length() == 5) {
          autobusa_marsuts new_marsuts = {autobusi[0], autobusi[1], autobusi[2],autobusi[3], stod(autobusi[4])};
          marsuts.push_back(new_marsuts);
        } else {
          file << line << endl;
        }
      } else {
        file << line << endl;
      }
    }
  }
  inFile.close();
  file.close();

  char command;
  while (true) {
    cin >> command;

    if (command == 'e') {
      break;
    }

    switch (command) {
    case 'a': {
      string sakums, beigas;
      cin >> sakums >> beigas;
      cout << "result:" << endl;
      for (int i = 0; i < marsuts.size(); ++i) {
        if (marsuts[i].sakums == sakums && marsuts[i].beigas == beigas) {
          cout << marsuts[i].sakums << " " << marsuts[i].beigas << " "
               << marsuts[i].diena << " " << marsuts[i].laiks << " "
               << fixed << setprecision(2) << marsuts[i].cena << endl;
        }
      }
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      cout << "result:" << endl;
      for (int i = 0; i < marsuts.size(); ++i) {
        if (marsuts[i].diena == diena) {
          cout << marsuts[i].sakums << " " << marsuts[i].beigas << " "
               << marsuts[i].diena << " " << marsuts[i].laiks << " "
               << fixed << setprecision(2) << marsuts[i].cena << endl;
        }
      }
      break;
    }
    case 'c': {
      string cena;
      cin >> cena;
      cout << "result:" << endl;
      for (int i = 0; i < marsuts.size(); ++i) {
        if (marsuts[i].cena <= stod(cena)) {
          cout << marsuts[i].sakums << " " << marsuts[i].beigas << " "
               << marsuts[i].diena << " " << marsuts[i].laiks << " "
               << fixed << setprecision(2) << marsuts[i].cena << endl;
        }
      }
      break;
    }
    case 'd': {
      ifstream file("err.txt");
      string err_line;
      cout << "result:" << endl;
      while (getline(file, err_line)) {
        cout << err_line << endl;
      }
      file.close();
      break;
    }
    }
  }
}