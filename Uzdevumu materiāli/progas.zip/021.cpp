

#include <iostream>
#include <fstream> // Iekļauj sevī 3 klases - ifstream (lasa no faila), ofstream (izveido failu un raksta iekšā failā), fstream (izveido, raksta un lasa)
#include <algorithm> // Noņem liekās atstarpes rindā
#include <sstream> // Sadala vārdus rindā
#include <vector> // Paredzēts sarakstu veidošanai
#include <string> // Tiek izmantots metodei stoi() - simbolu virkni pārveido par veselu skaitli
#include <iomanip> // Tiek izmantots metodei, lai noapaļotu divus skaitļus aiz komata

using namespace std;

struct route {  // Maršruta struktūra
public:
  string startstop;
  string endtstop;
  string day;
  string time;
  double price;
}; 

bool checkstop(string word) {
  
  // any_of(sākums, beigas, lambda_funkcija) - pārbauda katru burtu vārdā
  // Funkcija lambda (char ch) { return std::isalpha(ch); }) pārbauda vai simbols ir burts

  if(word.length() > 2 && any_of(word.begin(), word.end(), [](char ch) { return std::isalpha(ch); })) {
    return true;
  } else {
    return false;
  }
}

bool checkday(string word) {
  if(word == "Pr" || word == "Ot" || word == "Tr" || word == "Ce" || word == "Pt" || word == "St" || word == "Sv") {
    return true;
  } else {
    return false;
  }
}

bool checktime(string word) {
  if(word.length() == 5 && isdigit(word[0]) && isdigit(word[1]) && word[2] == ':' && isdigit(word[3]) && isdigit(word[4])) { // Pārbauda, vai dotais laiks sastāv no cipariem
    
    string hours = word.substr(0, 2);
    string minutes = word.substr(3, 2);

    // stoi() - simbolu virkni pārveido par veselu skaitli
    if(0 <= stoi(hours) && stoi(hours) <= 23 && 0 <= stoi(minutes) && stoi(minutes) <= 59) { // Pārbauda, vai dotais laiks ir reālais laiks
      return true;
    } 
  }

  return false;
}

bool checkprice(string word) {
  try {
    stod(word); // Ja var pārveidot simbolu virkni par reālo skaitli, tad funkcija atgriež true.
    // Ja stod() atrgriež kļūdu (tātad nevar), tad metode atgriež false
    return true;
  } catch (...) {
    return false;
  }
}

route checkedinfo(string line) {
  // Noņem liekās atstarpes pirms, pēc un starp laukiem
  line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
  
  if (line.empty())  // Ja rinda ir tukša
    throw "Invalid information in the line!"; // metode beidzas un atgriež kļūdu ar īssiņu "Invalid information in the line!" 
  // Šī kļūda netiks izvadīta konsolē, jo tiek izmantota metožu pārtraukšanai

  vector<string> words; // Saraksts words, kurā glabā atdalītos vārdus

  stringstream strStream(line);
  string word;

  while (getline(strStream, word, ',')) { // Sadala katru vārdu atsevišķi, atdalītais - ','
    words.push_back(word);
  }

  if (words.size() == 5 && checkstop(words[0]) && checkstop(words[1]) && checkday(words[2]) && checktime(words[3]) && checkprice(words[4]))  {

    route checkedroute; // Izveido struktūru, kurā tiks glabāta pareizā informācija
    checkedroute.startstop = words[0];
    checkedroute.endtstop = words[1];
    checkedroute.day = words[2];
    checkedroute.time = words[3];
    checkedroute.price = stod(words[4]); 

    return checkedroute; // Metode beidzas un atgriež struktūru ar patieso informāciju
  } else {
    throw "Invalid information in the line!"; // Metode beidzas un atgriež kļūdu ar īsziņu "Invalid information in the line!" // šī klūda netiks izvadīta konsolē, jo tiks izmantota, lai pārtrauktu metodi
  }

}

void printroute(route r) { // Maršrutu izvade
  stringstream streamprice;
  streamprice << fixed << setprecision(2) << r.price; // Cena tiek noapaļota līdz 2 cipariem aiz komata un saglabāta streamprice
  // streamprice.str() - pārveido par simbolu virkni
  cout << r.startstop + " " + r.endtstop + " " + r.day + " " + r.time + " " + streamprice.str() << endl;
}

void a(const vector<route> routes) {
  string startstop, endstop;
  cin >> startstop;
  cin >> endstop;
  cout << "result:" << endl;

  for (auto r : routes) {
    if (r.startstop == startstop && r.endtstop == endstop) {
      printroute(r);
    }
  }

}

void b(const vector<route> routes) {
  string day;
  cin >> day;
  cout << "result:" << endl;

  for (auto r : routes) {
    if (r.day == day) {
      printroute(r);
    }
  }

}

void c(const vector<route> routes) {
  string price;
  cin >> price;
  cout << "result:" << endl;

    for (auto r : routes) {
      if (r.price <= stod(price)) {
        printroute(r);
      }
    }
}

void d() { // Izvada konsolē err.txt faila saturu
  string contents;
  ifstream errorFile("err.txt"); // ifstream tiek izmantots, lai lasītu failu
  
  cout << "result:" << endl;
  
  if (errorFile.is_open()) { // Ja fails tiek veiksmīgi atvērts, tad
    while (getline(errorFile, contents)) { // lasa failu saturu pa rindām
      cout << contents << endl; // Izvada faila saturu konsolē
    }
    errorFile.close();
  } else {
    cout << "The file err.txt cannot to open!" << endl; 
  }
}


int main() {

  ifstream inFile("db.csv"); // Atver failu ar nosaukumu db.csv
  if (!inFile)
    return 0;

  ofstream errorFile("err.txt"); 
  if (!inFile)
    return 0;


  string line;
  vector<route> routes; // Saraksts, kurā tiek glabāti pārbaudītie maršruti

  // Lasam katru rindu atsevišķi no faila,
  while (getline(inFile, line)) {
    // Ja visi lauki rindā ir pareizi, tad tie tiek pievienoti sarakstam routes
    try {
      routes.push_back(checkedinfo(line));
    } catch(...) {
        if (!line.empty()) // Ja rinda nav tukša un tā satur nepatiesu informāciju, 
          // tad kļūdainie dati tiek ierakstīti errorFile
          errorFile << line << endl;      
    }
  }

  // Aizver failus
  inFile.close(); 
  errorFile.close();

  // Komandu definēšana
  char command;
  while (cin >> command) {
      switch (command) {
          case 'a': {
              a(routes);
              break;
          }
          case 'b': {
              b(routes);
              break;
          }
          case 'c': {
              c(routes);
              break;
          }
          case 'd': { 
              d();
              break;
          }
          case 'e':
              return 0;
      }
  }
  
} 