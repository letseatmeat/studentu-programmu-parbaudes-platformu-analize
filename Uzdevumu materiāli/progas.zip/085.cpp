
#include <fstream> // lai atvertu csv un txt
#include <iomanip> // lai izvadītu ar 2 cipariem aiz komata
#include <iostream> //BASED(svarigaka lieta ķip cin un cout)
#include <sstream> //erti stradat ar string
#include <vector> //vector :)
#include <limits> //tikai funkcijao safeInputForC

using namespace std;

// struktūra kas apraksta autobusa marsrutu
struct BusRouteStructure {
  string startStop;
  string endStop;
  string weekday;
  string time;
  double ticketPrice;
};

// funkcija lai parbauditu vai ir ievaditais skaitlis, jo kad komanda bija c(ievadit cenu) un cena bija ievadita ka burts, programma gļučeja, bezgaligi printeja 'result:'
double safeInputForC() {
		double value;
		while (true) {
				if (cin >> value) {
						
						break;
				} else {
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout <<"Error. Cenai jābūt skaitlis"<< endl;
				}
		}
		return value;
}

// funkcija lai nolasītu autobusa maršrutus no CSV faila
vector<BusRouteStructure> readBusRoutes(const string &filename) {
  vector<BusRouteStructure> routes;
	
  ifstream file(filename);

  if (!file.is_open()) {
    cerr << "Error. Nevar atvērt failu"<<filename << endl;
    exit(EXIT_FAILURE);
  }
  ofstream clearErrorFile("err.txt",ios::trunc);
  clearErrorFile.close();

  string line;
  while (getline(file, line)) {
    istringstream iss(line);

    BusRouteStructure route;//izmanto BusRoute objektu lai vienkāršotu lauku lasīšanu
    if (getline(iss, route.startStop, ',') &&
        getline(iss,route.endStop, ',') && getline(iss, route.weekday, ',') &&
        getline(iss,route.time, ',') && (iss >> route.ticketPrice)) {

      // Pārbauda, vai ir kādas papildu laukumi
      string extraField;
      
			if (iss >> extraField) {

        // atveru err.txt ar nosauk errorFile
        ofstream errorFile("err.txt", ios::app);
        errorFile << line << endl;
        continue;
      }

      //  noņem atstarpes
      route.startStop.erase(0, route.startStop.find_first_not_of(" \t"));//atstarpes sakumaa
      route.startStop.erase(route.startStop.find_last_not_of(" \t") + 1);//atstarpes beigaas

      route.endStop.erase(0, route.endStop.find_first_not_of(" \t"));
      route.endStop.erase(route.endStop.find_last_not_of(" \t") + 1);

      route.weekday.erase(0, route.weekday.find_first_not_of(" \t"));
      route.weekday.erase(route.weekday.find_last_not_of(" \t") + 1);

      route.time.erase(0, route.time.find_first_not_of(" \t"));
      route.time.erase(route.time.find_last_not_of(" \t") + 1);

      routes.push_back(route);
    } else {
      if (line.size() != 0) {

        ofstream errorFile("err.txt", ios::app);
        errorFile << line << endl;
      }
    }
		
  }

  file.close();
  return routes;
}

// funkcija lai izdrukātu autobusa maršrutus no-lidz
void printRoutesByCities(const vector<BusRouteStructure> &routes) {
  string startStop, endStop;

  getline(cin, startStop);
  getline(cin,endStop);

  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.startStop == startStop && route.endStop == endStop) {
      cout << route.startStop << " "<< route.endStop << " " << route.weekday
           << " " << route.time <<" "<< fixed << setprecision(2)
           << route.ticketPrice << endl;
    }
  }
}

// funkcija lai izdrukātu maršrutus nedēļas dienas
void printRoutesByDay(const vector<BusRouteStructure> &routes) {
  string weekday;
	while (true) { //parbauda dienas ievadi 
		getline(cin, weekday);
		
		if (weekday == "Pr" || weekday == "Ot" || weekday == "Tr" || 
				weekday == "Ce" || weekday == "Pt" || weekday == "St" || 
				weekday == "Sv") {
			break; 
			
		} else {
			cout << "Error. Ievadiet nedēļas dienu (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
		}
	};

  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.weekday == weekday) {
      cout << route.startStop << " " << route.endStop << " " << route.weekday
           << " " << route.time << " " << fixed << setprecision(2) //bus noteiktaa formataa un 2 cipari
           << route.ticketPrice << endl;
    }
  }
}

// funkcija lai izdrukātu zem biļetes cenu
void printRoutesByBiletPrice(const vector<BusRouteStructure>& routes) {
		double maxPrice;


		maxPrice = safeInputForC();

		cout << "result:" << endl;
		for (const auto& route : routes) {
				if (route.ticketPrice <= maxPrice) {
						cout << route.startStop << " " << route.endStop << " " << route.weekday
								 << " " << route.time << " " << fixed << setprecision(2)
								 << route.ticketPrice << endl;
				}
		}
}

// funkcija lai izdrukātu "err.txt"
void printErrors() {
  ifstream errorFile("err.txt");
  string line;
  cout << "result:" << endl;
  while (getline(errorFile, line)) {
    cout << line << endl;
  }
}

int main() {
  vector<BusRouteStructure> routes = readBusRoutes("db.csv");

  char choice;
  do {

    cin >> choice;
    cin.ignore(); // parskipo jaunas rindas simbolu

    switch (choice) {
    case 'a':
      printRoutesByCities(routes);
      break;
    case 'b':
      printRoutesByDay(routes);
      break;
    case 'c':
      printRoutesByBiletPrice(routes);
      break;
    case 'd':
      printErrors();
      break;
    case 'e':

      break;
    default:
      cout << "Error" << endl;
    }
  } while (choice != 'e');

  return 0;
}
