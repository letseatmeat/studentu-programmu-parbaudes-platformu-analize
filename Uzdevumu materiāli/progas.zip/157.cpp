
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Trip {

  string city1;
  string city2;
  string day;
  string time;
  double price;
};


string getty(const string &str) {
  size_t first = str.find_first_not_of(" \t\n\r\f\v");
  if (first == string::npos) {
    return "";
  }
  size_t last = str.find_last_not_of(" \t\n\r\f\v");
  return str.substr(first, (last - first + 1));
}


vector<Trip> readTrips(const string &fileN, const string &errorF) {
  vector<Trip> trips;
  ifstream file(fileN);
  ofstream errFile(errorF);
  string line;

  
  while (getline(file, line)) {
    stringstream ss(line);
    string city1, city2, day, time, maxa, extra;
    getline(ss, city1, ',');
    getline(ss, city2, ',');
    getline(ss, day, ',');
    getline(ss, time, ',');
    getline(ss, maxa, ',');

    city1 = getty(city1);
    city2 = getty(city2);
    day = getty(day);
    time = getty(time);
    maxa = getty(maxa);

    if (city1.empty() || city2.empty() || day.empty() || time.empty() ||
        maxa
.empty() || getline(ss, extra)) {
      if (!line.empty()) {
        errFile << line << endl;
      }
      continue;
    }

    try {
      
      double price = stod(maxa);
      if (time.find(':') == string::npos) {
        if (!line.empty()) {
          errFile << line << endl;
        }
        continue;
      }
      

      Trip trip;
      trip.city1 = city1;
      trip.city2 = city2;
      trip.day = day;
      trip.time = time;
      trip.price = price;

      
      trips.push_back(trip);
    } catch (...) {
      if (!line.empty()) {
        errFile << line << endl;
      }
    }
  }
  

  return trips;
}



void choiceD(const string &errorF) {
  ifstream errFile(errorF);
  string line;
  cout << "result:" << endl;
  while (getline(errFile, line)) {
    line = getty(line);
    if (!line.empty()) {
      cout << line << endl;
    }
  }
}


void choiceA(const vector<Trip> &trips, const string &city1,
             const string &city2) {
  cout << "result:" << endl;
  for (const auto &trip : trips) {
    if (trip.city1 == city1 && trip.city2 == city2) {
      cout << trip.city1 << " " << trip.city2 << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << endl;
    }
  }
}


void choiceB(const vector<Trip> &trips, const string &day) {
  cout << "result:" << endl;
  for (const auto &trip : trips) {
    if (trip.day == day) {
      cout << trip.city1 << " " << trip.city2 << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << endl;
    }
  }
}


void choiceC(const vector<Trip> &trips, double maxaP) {
  cout << "result:" << endl;
  for (const auto &trip : trips) {
    if (trip.price <= maxaP) {
      cout << trip.city1 << " " << trip.city2 << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << endl;
    }
  }
}


int main() {
  vector<Trip> trips = readTrips("db.csv", "err.txt");
  char choice;

  while (true) {

    cin >> choice;
    switch (choice) {
    case 'a': {
      string city1, city2;
      cout << "Enter city1 and city2 stops: ";
      cin.ignore();
      getline(cin, city1);
      getline(cin, city2);
      city1 = getty(city1);
      city2 = getty(city2);
      choiceA(trips, city1, city2);
      break;
    }
    case 'b': {
      string day;
      cout << "Enter day of the week: ";
      cin >> day;
      choiceB(trips, day);
      break;
    }
    case 'c': {
      double maxaP;
      cout << "Enter maximum ticket price: ";
      cin >> maxaP;
      choiceC(trips, maxaP);
      break;
    }

    case 'd':
      choiceD("err.txt");
      break;
    case 'e':
      return 0;
    default:
      cout << "Invalid choice. Please enter a valid command." << endl;
      break;
    }
  }

  return 0;
}
