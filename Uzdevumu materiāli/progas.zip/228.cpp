
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

bool dayFormat(const string &day) {
  if (day != "Pr" && day != "Ot" && day != "Tr" && day != "Ce" && day != "Pt" && day != "St" && day != "Sv")
    return true;
  return false;
}

bool timeFormat(const string &time) {
  string hour="", min="";
  istringstream timeStream(time);
  getline(timeStream, hour, ':');
  getline(timeStream, min, ':');
  try {
    int intHour = stoi(hour);
    int intMin = stoi(min);
    if (intHour < 0 || intHour > 23 || intMin < 0 || intMin > 59)
      return true;
  }  
  catch (const invalid_argument &e) {
      return true;
  } 
  catch (const out_of_range &e) {
      return true;
  }
  return false;
}

bool priceFormat(const string &price) {
  try {
    double doublePrice = stod(price);
  }  
  catch (const invalid_argument &e) {
      return true;
  } 
  catch (const out_of_range &e) {
      return true;
  }
  return false;
}

void printer(vector<string> &route) {
  cout << route[0] << " " << route[1] << " " << route[2] << " " << route[3] << " " << route[4] << endl;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return 0;

  string s;
  vector <string> lines;
  while (getline (inFile, s)) {
    if (s == "\n" || s == "\r" || s == "\0")
      continue;
    s.erase(remove(s.begin(), s.end(), ' '), s.end());
    lines.push_back(s);
  }

  vector<vector<string>> data;
  vector<string> route, err_route;
  string route_el;
  int route_el_nr;
  for (string line : lines) {
    istringstream lineStream(line);
    route_el_nr = 0;
    while (getline(lineStream, route_el, ',')) {
      route_el_nr++;
      
      if (route_el_nr == 3 && dayFormat(route_el)) 
        break;
      if (route_el_nr == 4 && timeFormat(route_el))
        break;
      if (route_el_nr == 5 && priceFormat(route_el))
        break;
      route.push_back(route_el);
    }
    if (route.size() != 5) {
      err_route.push_back(line);
      route.clear();
      continue;
    }
    data.push_back(route);
    route.clear();
  }
  if (err_route.size() != 0) {
    ofstream errFile("err.txt");
    for (string err_line : err_route) {
      errFile << err_line << endl;
    }
    errFile.close();
  }

  char command;
  string city1, city2, day;
  double price, doublePrice;
  while (true) {
    if (!(cin >> command)) {
      cout << "Wrong command!" << endl;
      continue;
    }
    if (command == 'a') {
      cin >> city1;
      cin >> city2;
      cout << "result:" << endl;
      for (auto route : data) {
        if (route[0] == city1 && route[1] == city2) {
          printer(route);
        }
      }
      continue;
    }
    if (command == 'b') {
      cin >> day;
      if (dayFormat(day)) {
        cout << "Wrong day!" << endl;
        continue;
      }
      cout << "result:" << endl;
      for (auto route : data) {
        if (route[2] == day) {
          printer(route);
        }
      }
      continue;
    }
    if (command == 'c') {
      if (!(cin >> price)) {
        cout << "Wrong price!" << endl;
        continue;
      }
      cout << "result:" << endl;
      for (auto route : data) {
        try {
          doublePrice = stod(route[4]);
        }  
        catch (const invalid_argument &e) {
          cerr << "Invalid argument: " << e.what() << endl;
        }
        catch (const out_of_range &e) {
          cerr << "Out of range: " << e.what() << endl;
        }
        if (price >= doublePrice) {
          printer(route);
        }
      }
      continue;
    }
    if (command == 'd') {
      cout << "result:" << endl;
      for (string err_line : err_route) {
        cout << err_line << endl;
      }
      continue;
    }
    if (command == 'e') {
      break;
    }
    cout << "Wrong command!" << endl;
    continue;
  }
  return 0;
}