
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

using namespace std;

struct BusaCels {
    string sakums;
    string beigas;
    string diena;
    string laiks;
    double cena;
};

vector<BusaCels> mekletBusaCels(const string& filename);
bool parseLine(const string& line, BusaCels& route);
void apstradatGad(const vector<BusaCels>& routes);
void gadA(const vector<BusaCels>& routes);
void gadB(const vector<BusaCels>& routes);
void gadC(const vector<BusaCels>& routes);
void gadD();
string trim(const string& str);

int main() {
    vector<BusaCels> routes = mekletBusaCels("db.csv");
    apstradatGad(routes);
    return 0;
}

vector<BusaCels> mekletBusaCels(const string& filename) {
    ifstream inFile(filename);
    ofstream errFile("err.txt", ios::out | ios::trunc);
    vector<BusaCels> routes;
    string line;
    bool pirmaLinija = true;

    if (!inFile) {
        cout << "nesanaca atvert" << endl;
        return routes;
    }

    while (getline(inFile, line)) {
        line = trim(line);

        if (line.empty()) {
            continue;
        }

        BusaCels route;
        if (!parseLine(line, route)) {

            // pa taisno ierakstu faila result liniju, lai velak var to nedarit
            if (pirmaLinija) {
                errFile << "result:" << endl;
                pirmaLinija = false;
            }

            errFile << line << '\n';
        } else {
            routes.push_back(route);
        }
    }

    inFile.close();
    errFile.close();
    return routes;
}

bool parseLine(const string& line, BusaCels& route) {
    stringstream ss(line);
    string item;
    vector<string> items;

    
    while (getline(ss, item, ',')) {
        items.push_back(trim(item));
    }

    if (items.size() != 5) return false;

    if (items[2].length() != 2) return false;

    // nebija prasīts, bet nu, kapec ne
    size_t colon = items[3].find(':');
    if (colon == string::npos || colon != 2 || items[3].length() != 5) return false;

    
    try {
        route.cena = stod(items[4]);
    } catch (const invalid_argument& ia) {
        return false;
    }
 
    route.sakums = items[0];
    route.beigas = items[1];
    route.diena = items[2];
    route.laiks = items[3];

    return true;
}

void apstradatGad(const vector<BusaCels>& routes) {
    char ievade;
    do {

        cin >> ievade;
        switch (ievade) {
            case 'a': gadA(routes); break;
            case 'b': gadB(routes); break;
            case 'c': gadC(routes); break;
            case 'd': gadD(); break;
        }
    } while (ievade != 'e');
}

void gadA(const vector<BusaCels>& routes) {
    string sakums, beigas;

    cin >> sakums;
    cin >> beigas;

    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.sakums == sakums && route.beigas == beigas) {
            cout << route.sakums << " " << route.beigas << " " 
                 << route.diena << " " << route.laiks << " "
                 << fixed << setprecision(2) << route.cena << endl;
        }
    }
}

void gadB(const vector<BusaCels>& routes) {
    string diena;
    cin >> diena;

    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.diena == diena) {
            cout << route.sakums << " " << route.beigas << " " 
                 << route.diena << " " << route.laiks << " " 
                 << fixed << setprecision(2) << route.cena << endl;
        }
    }
}

void gadC(const vector<BusaCels>& routes) {
    double cena;
    cin >> cena;

    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.cena < cena) {
            cout << route.sakums << " " << route.beigas << " " 
                 << route.diena << " " << route.laiks << " " 
                 << fixed << setprecision(2) << route.cena << endl;
        }
    }
}

void gadD() {
    ifstream errFile("err.txt");
    string line;

    if (!errFile) {
        cout << "Nesanaca atvert err.txt )" << endl;
        return;
    }

    while (getline(errFile, line)) {
        cout << line << endl;
    }

    errFile.close();
}


string trim(const string& str) {
    size_t first = str.find_first_not_of(" \r\t\n");
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(" \r\t\n");
    return str.substr(first, (last - first + 1));
}

