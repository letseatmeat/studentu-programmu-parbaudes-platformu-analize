#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

//Agate Šarna 221RDB224
using namespace std;

string cut(const string& str){
  size_t first = str.find_first_not_of(' ');
  if (first == string::npos){
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}


void functionA(const string& from, const string& to,const string& filename);
void functionB(const string& day, const string& filename);
void functionC(const string& price, const string& filename );
void functionD(const string& filename);

int main() {
 // ifstream inFile;
 // inFile.open("db.csv");

	//if (!inFile) return 0;
  
 // string s; 
//	while (inFile >> s)
//	{
//		cout << s << endl;
//  }
  

  string filename = "db.csv";
  //cout << "Enter the file name:";
  //cin >> filename;

  ifstream inFile(filename);

  if (!inFile) {
    cout << "Error: File not found." << endl;
    return 1;
  }

  string outputfile = "err.txt";
  ofstream errorFile(outputfile);

  string line;
  while (getline(inFile, line)){
    if (line.find_first_not_of(' ') == string::npos){
      continue;
    }

    istringstream iss(line);
    vector<string> values;
    string value;
    
    while (getline(iss, value, ',')){
      values.push_back(cut(value));
    }

    if(values.size() != 5){
      errorFile << line << endl;
      continue;
    }
    try{
      double realprice = stod(values[4]);
      if (values[4].find(':') != string::npos) {
        errorFile << line << endl;
    }
    }catch (const invalid_argument& e){
    }

    string from = values[0];
    string to = values[1];
    string day = values[2];
    string time = values[3];
    string price = values[4];

    
  }

  
  inFile.close();
  errorFile.close();

  char choice;
  string from, to, day, price;
 do{
   cin >> choice;

  switch (choice){
    case 'a':
      cout << "result:" << endl;
      cin >> from;
      cin >> to;
      functionA(from, to, filename);
      break;
    case 'b':
      cout << "result:" << endl;
      cin >> day;
      functionB(day, filename);
      break;
    case 'c':
      cout << "result:" << endl;
      cin >> price;
      functionC(price, filename);
      break;
    case 'd':
      cout << "result:" << endl;
      functionD(filename);
      break;
    case 'e':
      break;
    default:
      cout << "Invalid input." << endl;
    
  }
  cin.ignore();
 }while(choice != 'e');
  return 0;
} 




void functionA(const string& from, const string& to, const string& filename){
  ifstream inFile(filename);

  if(!inFile){
    cout << "Error: File not found." << endl;
    return;
  }
  string line;
  while (getline(inFile, line)){
    istringstream iss(line);
    vector<string>values;
    string value;

    while(getline(iss, value, ',')){
      values.push_back(cut(value));
  }
    if(values.size() != 5){
      continue;
    }

    string cityfrom = values[0];
    string cityto = values[1];

    if(cityfrom == from && cityto == to){
      for(const auto& val : values){
        cout << val << " ";
      }
      cout << endl;
    }
}
inFile.close();
}
  




void functionB(const string& day, const string& filename){
  ifstream inFile(filename);

    if(!inFile){
      cout << "Error: File not found." << endl;
      return;
    }
    string line;
    while (getline(inFile, line)){
      istringstream iss(line);
      vector<string>values;
      string value;

      while(getline(iss, value, ',')){
        values.push_back(cut(value));
    }
      if(values.size() != 5){
        continue;
      }

      string dayname = values[2];

      if(dayname == day){
        for(const auto& val : values){
          cout << val << " ";
        }
        cout << endl;
      }
  }
  inFile.close();
}





void functionC(const string& price, const string& filename){
  ifstream inFile(filename);

    if(!inFile){
      cout << "Error: File not found." << endl;
      return;
    }

    double inputprice;
    try{
      inputprice = stod(price);
    }catch(const invalid_argument& e){
      cerr << "Invalid input." << endl;
      inFile.close();
      return;
    }
  
    string line;
    while (getline(inFile, line)){
      istringstream iss(line);
      vector<string>values;
      string value;

      while(getline(iss, value, ',')){
        values.push_back(cut(value));
    }
      if(values.size() != 5){
        continue;
      }

      double realprice;
      try{
        realprice = stod(values[4]);
      } catch (const invalid_argument& e){
        cerr << "Invalid price in the file." << endl;
        inFile.close();
        return;
      }

      if(realprice <= inputprice){
        for(const auto& val : values){
          cout << val << " ";
        }
        cout << endl;
      }
  }
  inFile.close();
}






void functionD(const string& filename){
 ifstream errorFile("err.txt");

  if(!errorFile){
    cout << "Error: File not found." << endl;
    return;
  }
  string line;
  while(getline(errorFile, line)){
    cout << line << endl;
  }
  errorFile.close();
}