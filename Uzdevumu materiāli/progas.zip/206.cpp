#include <iostream>
#include <fstream> // Lai izmantotu ifstream of stream
#include <sstream> // Lai izmantotu istringstream
#include <vector> // Lai veidotu divdimensiju masivus
#include <string> // Lai izmantotu string
#include <algorithm> // Lai izmantotu isspace

using namespace std;

void trim(string &s) {
  // Noņem atstarpes no sākuma
  s.erase(s.begin(), find_if(s.begin(), s.end(), [](unsigned char ch) {
    return !isspace(ch);
  }));
  // Noņem atstarpes no beigām
  s.erase(find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
    return !isspace(ch);
  }).base(), s.end());
}

// Sadala rindas laukos
vector<string> split(const string &s, char delimiter) {
  vector<string> tokens;
  string token;
  istringstream tokenStream(s);
  while (getline(tokenStream, token, delimiter)) {
    trim(token); // Noņem liekās atstarpes no katras vērtības
    tokens.push_back(token);
  }
  return tokens;
}

// Parbauda vai laika standarts atbilst
bool validateTime(const string& time) {
  if (time.size() != 5 || time[2] != ':') return false;
  int hour, minute;
  try {
    hour = stoi(time.substr(0, 2));
    minute = stoi(time.substr(3, 2));
  } catch (...) {
    return false;
  }
  return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

// Parbauda vai diena atbilst standartam
bool validateDay(const string& day){
  if (day!="Pr" || day!="Ot" || day!="Tr" || day!="Ce" || day!="Pt" || day!="St" || day!="Sv") return true;
  else return false;
}

// Parbauda vai izpildas kriteriji
bool isValidRoute(const vector<string>& route) {
  if (route.size() != 5) return false;
  if (!validateTime(route[3])) return false;
  if (!validateDay(route[2])) return false;
  try {
    stod(route[4]); // pārbauda, vai cena ir derīga
  } catch (...) {
    return false;
  }
  return true;
}

// veido divdimensiju masivu kuram velak pieklut,
// nosuta rindas uz parbaudem un izvada kludainas rindas err.txt
vector<vector<string>> readBusRoutes(const string& fileName) {
  vector<vector<string>> routes;
  ifstream file(fileName);
  string line;

  ofstream errFile("err.txt");

  while (getline(file, line)) {
    trim(line); // Noņem liekās atstarpes no rindas sākuma un beigām
    if (line.empty()) continue; // Ignorē tukšās rindas

    auto route = split(line, ',');
    if (isValidRoute(route)) {
      routes.push_back(route);
    } else {
      errFile << line << endl; // Rakstīt kļūdainās rindas uz err.txt
    }
  }
  file.close();
  errFile.close();
  return routes;
}

void printRoutesByStops(const vector<vector<string>>& routes, const string& startStop, const string& endStop) {
  cout << "result:" << endl;
  for (const auto& route : routes) {
    if (route[0] == startStop && route[1] == endStop) {
      for (const auto& field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printRoutesByDay(const vector<vector<string>>& routes, const string& dayOfWeek) {
  cout << "result:" << endl;
  for (const auto& route : routes) {
    if (route[2] == dayOfWeek) {
      for (const auto& field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printRoutesByPrice(const vector<vector<string>>& routes, double maxPrice) {
  cout << "result:" << endl;
  for (const auto& route : routes) {
    if (stod(route[4]) <= maxPrice) {
      for (const auto& field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printErrorLines(const string& fileName) {
  cout << "result:" << endl;
  ifstream file(fileName);
  string line;

  if (file.is_open()) {
    while (getline(file, line)) {
      cout << line << endl; // Izvada katra rinda uz ekrāna
    }
    file.close();
  } else {
    cout << "Nevar atvērt failu: " << fileName << endl;
  }
  file.close();
}



int main() {
  auto routes = readBusRoutes("db.csv");
  
  char decision = 'n';
  while (decision != 'e'){
    cin >> decision;
    // Marsruti
    if (decision == 'a'){
      string BegBusStop, EndBusStop;
      cin >> BegBusStop >> EndBusStop;
      printRoutesByStops(routes, BegBusStop, EndBusStop);
    }
    // Nedēļas diena
    if (decision == 'b'){
      string WeekDay;
      cin >> WeekDay;
      printRoutesByDay(routes, WeekDay);
    }
    // Cena
    if (decision == 'c'){
      double UserPrice;
      cin >> UserPrice;
      printRoutesByPrice(routes, UserPrice);
    }
    if (decision == 'd'){
      printErrorLines("err.txt");
    }
  }
  return 0;
}
