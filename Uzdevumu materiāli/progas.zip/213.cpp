
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

void noLidz(){
  ifstream inFile;
  inFile.open("db.csv");
  
  string pils1, pils2;
  vector <string> tests;
  cin >> pils1;
  cin >> pils2;
  cout << "result:" << endl;
  string s, str; 
  while (getline(inFile,s))
  {
    size_t found = s.find(" ");
    while (found != string::npos) {
        s.replace(found, 1, "");
        found = s.find(" ");
    }
    
    stringstream ss(s);
    tests.clear();
    while (getline(ss, str, ',')){
        {
          tests.push_back(str);
        }
    }
    if (!tests.empty() && (tests[0] == pils1 && tests[1] == pils2) && tests.size() == 5)  {
        for (int i = 0; i < tests.size(); i++) {
            cout << tests[i] << " ";
        }
        cout << endl;
    }
  }
}

void diena(){
  ifstream inFile;
  inFile.open("db.csv");

  string diena;
  vector <string> tests;
  cin >> diena;
  cout << "result:" << endl;
  string s, str;
  while (getline(inFile,s))
  {
    size_t found = s.find(" ");
    while (found != string::npos) {
        s.replace(found, 1, "");
        found = s.find(" ");
    }

    stringstream ss(s);
    tests.clear();
    while (getline(ss, str, ',')){
      {
        tests.push_back(str);
      }
  }
    if (!tests.empty() && (tests[2] == diena) && tests.size() == 5 && (diena == "Pr" || diena == "Ot" || diena == "Tr" || diena == "Ce" || diena == "Pt" || diena == "Se" || diena == "Sv")) {
        for (int i = 0; i < tests.size(); i++) {
            cout << tests[i] << " ";
        }
        cout << endl;
    }
  }
}

void cena(){
  ifstream inFile;
  inFile.open("db.csv");

  double cena;
  vector <string> tests;
  cin >> cena;
  cout << "result:" << endl;
  string s, str, str2; 
  while (getline(inFile, s))
  {
    size_t found = s.find(" ");
    while (found != string::npos) {
        s.replace(found, 1, "");
        found = s.find(" ");
    }

    stringstream ss(s);
    tests.clear();
    while (getline(ss, str, ',')){
        {
          tests.push_back(str);
        }
    }
    if (!tests.empty() && tests.size() == 5) {
        try {
            double cenaMarshruta = stod(tests[4]);
            if (cenaMarshruta <= cena) {
              for (int i = 0; i < tests.size(); i++) {
                cout << tests[i] << " ";
              }
              cout << endl;
            }
        } catch (const invalid_argument& e) {
            cerr << "Kļūda" << endl;
        }
    }
  }
}

void kluda(){
  ifstream inFile;
  inFile.open("db.csv");
  ofstream outFile("err.txt");
  
  vector <string> tests;

  string s, str; 
  while (getline(inFile,s))
  {
    size_t found = s.find(" ");
    while (found != string::npos) {
        s.replace(found, 1, "");
        found = s.find(" ");
    }

    stringstream ss(s);
    tests.clear();
    while (getline(ss, str, ',')){
        {
          tests.push_back(str);
        }
    }
    bool noPil = true;
    for (char c : tests[0]){
      if (!isalpha(c)){
        noPil = false;
        break;
      }
    }
    bool uzPil = true;
    for (char c : tests[1]){
      if (!isalpha(c)){
        uzPil = false;
        break;
      }
    }
    bool dat = true;
    for (char c : tests[2]){
      if (!isalpha(c) || (tests[2] != "Pr" && tests[2] != "Ot" && tests[2] != "Tr" && tests[2] != "Ce" && tests[2] != "Pt" && tests[2] != "Se" && tests[2] != "Sv")){
        dat = false;
        break;
      }
    }
    bool cena = true;
    int skaits = 0;
    for (char c : tests[4]){
      if (c == '.'){
        skaits++;
        if (skaits > 1){
          cena = false;
          break;
        }
      }
      else if (!isdigit(c)){
        cena = false;
        break;
      }
    }
    
    bool laiks = true;
    int koluSkaits = 0;
    for (int i = 0; i < tests[3].size(); i++){
      if (tests[3][i] == ':'){
        koluSkaits ++;
        if (koluSkaits > 1){
          laiks = false;
          break;
        }
      }
      else if (!isdigit(tests[3][i]) && (i != 2 || tests[3][i] != ':') || tests[3].size() > 5){
        laiks = false;
      }
    }
    if (!tests.empty() &&(tests.size() != 5 || noPil == false || uzPil == false || cena == false || dat == false || laiks ==false)) {
      outFile << s << endl;
}
}
}

void errIzvade(){
  ifstream inFile;
  inFile.open("err.txt");
  string s;
  cout << "result:" << endl;
  while (getline(inFile, s)){
    cout << s << endl;
  }
}


int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;
   kluda();
while (true){
  char izvele;
  cin >> izvele;
  switch (izvele){
    case 'a':
      noLidz();
      break;
    case 'b':
      diena();
      break;
    case 'c':
      cena();
      break;
    case 'd':
      errIzvade();
      break;
    case 'e':
      break;
    default:
      cout << "wrong command";
      break;
  }
  if (izvele == 'e'){
    break;
  }
}
} 