#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

vector < string > split(string s, string del) {
  vector < string > result;
  int end = s.find(del);
  while (end != -1) {
    result.push_back(s.substr(0, end));
    s.erase(s.begin(), s.begin() + end + 1);
    end = s.find(del);
  }
  result.push_back(s.substr(0, end));
  return result;
}

string strip(const string & val) {
  string str = val;

  str.erase(str.begin(), find_if(str.begin(), str.end(), [](int ch) {
    return !isspace(ch);
  }));

  str.erase(find_if(str.rbegin(), str.rend(), [](int ch) {
    return !isspace(ch);
  }).base(), str.end());

  return str;
}

vector < string > convertData(const vector < string > & data) {
  vector < string > newData;
  for (const string & item: data) {
    newData.push_back(strip(item));
  }
  return newData;
}

void createErrFile(const vector < string > & errLines) {
  try {
    ofstream file("err.txt");
    for (const string & line: errLines) {
      file << line << endl;
    }
  } catch (const exception & e) {
    cerr << "An error occurred: " << e.what() << endl;
  }
}

bool validateLine(const vector < string > & data) {
  const vector < string > day = {
    "Pr",
    "Ot",
    "Tr",
    "Ce",
    "Pt",
    "St",
    "Sv"
  };
  try {
    return data.size() == 5 &&
      find(day.begin(), day.end(), data[2]) != day.end() &&
      data[3].length() == 5 &&
      count(data[3].begin(), data[3].end(), ':') == 1 &&
      stoi(data[3].substr(0, 2)) >= 0 && stoi(data[3].substr(0, 2)) <= 23 &&
      stoi(data[3].substr(3, 2)) >= 0 && stoi(data[3].substr(3, 2)) <= 59 &&
      data[4].length() >= 4 && data[4].length() <= 5 &&
      stoi(data[4].substr(0, 2)) >= 0 && stoi(data[4].substr(0, 2)) <= 99 &&
      stoi(data[4].substr(3, 2)) >= 0 && stoi(data[4].substr(3, 2)) <= 99;
  } catch (const exception & e) {
    return false;
  }
}

vector < string > readMainFile() {
  vector < string > lines;
  try {
    ifstream file("db.csv");
    string line;
    while (getline(file, line)) {
      string newLine = strip(line);
      lines.push_back(newLine);
    }
  } catch (const exception & e) {
    cerr << "An error occurred: " << e.what() << endl;
  }
  return lines;
}

void readErrFile() {
  try {
    ifstream file("err.txt");
    string line;
    cout << "result:" << endl;
    while (getline(file, line)) {
      cout << line << endl;
    }
  } catch (const exception & e) {
    cerr << "An error occurred: " << e.what() << endl;
  }
}

void aMethod(const string & start,
  const string & stop,
    const vector < string > & correctLines) {
  cout << "result:" << endl;
  for (const string & line: correctLines) {
    vector < string > data = split(line, " ");
    if (data[0] == start && data[1] == stop) {
      cout << line << endl;
    }
  }
}

void bMethod(const string & day,
  const vector < string > & correctLines) {
  cout << "result:" << endl;
  for (const string & line: correctLines) {
    vector < string > data = split(line, " ");
    if (data[2] == day) {
      cout << line << endl;
    }
  }
}

void cMethod(const string & price,
  const vector < string > & correctLines) {
  cout << "result:" << endl;
  for (const string & line: correctLines) {
    vector < string > data = split(line, " ");
    float linePrice = stof(data[4]);
    float inputPrice = stof(price);

    if (inputPrice >= linePrice) {
      cout << line << endl;
    }
  }
}

vector < string > getCorrectLines() {
  vector < string > lines = readMainFile();
  vector < string > result;
  vector < string > errLines;

  for (const string & line: lines) {
    vector < string > data = convertData(split(line, ","));

    if (!validateLine(data) && !line.empty()) {
      errLines.push_back(line);
    } else if (!line.empty()) {
      string resultLine = "";
      for (int i = 0; i < data.size(); i++) {
        resultLine += data[i];
        if (i != 4) {
          resultLine += " ";
        }
      }
      result.push_back(resultLine);
    }
  }

  if (!errLines.empty()) {
    createErrFile(errLines);
  }

  return result;
}

int main() {
  vector < string > lines = getCorrectLines();
  string input;
  do {
    getline(cin, input);
    switch (input[0]) {
    case 'a': {
      string start, stop;
      getline(cin, start);
      getline(cin, stop);
      aMethod(start, stop, lines);
      break;
    }
    case 'b': {
      string day;
      getline(cin, day);
      bMethod(day, lines);
      break;
    }
    case 'c': {
      string price;
      getline(cin, price);
      cMethod(price, lines);
      break;
    }
    case 'd':
      readErrFile();
      break;
    }
  } while (input[0] != 'e');

  return 0;
}