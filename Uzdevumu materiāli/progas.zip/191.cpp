#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include <set>
#include <sstream>



using namespace std;


struct BusRoute {
    string sakumap, beigup, laiks, diena;
    double cena;
};


string izlabo(const string &str) {
    size_t sakumap = str.find_first_not_of(" \t\n\r");
  
    if (sakumap == string::npos) {
        return "";
    }
  
    size_t beigup = str.find_last_not_of(" \t\n\r");
    return str.substr(sakumap, beigup - sakumap + 1);
}


vector<BusRoute> marsruts() {
    vector<BusRoute> celi; 
    ifstream input {"db.csv"}; 
    ofstream nestradafails {"err.txt"};
  
    string linija, vards;
    BusRoute cels;

    if (!input) {
        cerr << "Nevar atvērt db.csv\n";
        throw;
    }
  

    while (getline(input, linija)) {

        if (linija.empty()) continue;
        stringstream sadala(linija);
        vector<string> vertiba;

        while (getline(sadala, vards, ',')) {
            vertiba.push_back(izlabo(vards));
        }

        bool atbilstiba = true;

        if (vertiba.size() != 5) {
            atbilstiba = false;
          
        } else {
            cels.sakumap = vertiba[0];
            cels.beigup = vertiba[1];
            cels.diena = vertiba[2];
            cels.laiks = vertiba[3];

            try {
                cels.cena = stod(vertiba[4]);
            } catch (const invalid_argument &e) {
                atbilstiba = false;
            }
        }

        if (atbilstiba && (cels.diena.length() != 2 || cels.laiks.length() != 5 || cels.laiks[2] != ':')) {
            atbilstiba = false;
        }

        for (char c : cels.laiks) {
            if (!isdigit(c) && c != ':') {
                atbilstiba = false;
            }
        }
      
        if (!atbilstiba) {
              nestradafails << linija << "\n";
        } else {
              celi.push_back(cels);
        }
    }
  
    return celi;
}

void izvada_marsrutu(const BusRoute &cels) {
    cout << cels.sakumap << " " << cels.beigup << " " << cels.diena << " " << cels.laiks << " " << fixed
              << setprecision(2) << cels.cena << "\n";
}

void gadijums_a(const vector<BusRoute> &celi) {
  
    string sakumap, beigup;
  
    cin >> sakumap;
    cin >> beigup;
    cout << "result:\n";
  
    for (const auto &cels : celi) {
        if (cels.sakumap == sakumap && cels.beigup == beigup) {
            izvada_marsrutu(cels);
        }
    }
}

void gadijums_b(const vector<BusRoute> &celi) {
  
    string diena;
  
    cin >> diena;
    cout << "result:\n";
  
    for (const auto &cels : celi) {
        if (cels.diena == diena) {
            izvada_marsrutu(cels);
        }
    }
}

void gadijums_c(const vector<BusRoute> &celi) {
  
    double cena;
  
    cin >> cena;
    cout << "result:\n";
  
    set<string> meklecelu;
    for (const auto &cels : celi) {
        if (cels.cena <= cena) {
            string celaatrasana = cels.sakumap + cels.beigup + cels.diena + cels.laiks;

            if (meklecelu.find(celaatrasana) == meklecelu.end()) {
                  meklecelu.insert(celaatrasana);
                izvada_marsrutu(cels);
            }
        }
    }
}


void gadijums_d() {
    ifstream nestradafails {"err.txt"};
    string linija;
  
    if (!nestradafails) {
        cerr << "Nav iespējams atvērt err.txt\n";
        throw;
    }

    cout << "result:\n";
    while (getline(nestradafails, linija)) {
        string trimmed_line = izlabo(linija);
      
        if (!trimmed_line.empty()) {
            cout << trimmed_line << "\n";
        }
    }
}

int main() {
    vector<BusRoute> celi = marsruts();
  
    char izvele;
  
    do {
        cin >> izvele;
        switch (izvele) {
            case 'a': gadijums_a(celi); 
              break;
            case 'b': gadijums_b(celi); 
              break;
            case 'c': gadijums_c(celi); 
              break;
            case 'd': gadijums_d(); 
              break;
            case 'e': 
              break;
            default: cout << "Nepareiza komanda"; break;
        }
      
    } while (izvele != 'e');
  
}