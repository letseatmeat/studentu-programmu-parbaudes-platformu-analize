
// kludu apstrade nedarbojas, tadel ari neizdevas testi replita.
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

struct AutobusaMarsruts {
    double biletesCena;
    string laiks;
    string sakumaPietura;
    string nedelasDiena;
    string galaPietura;
};
// csv faila nolasisana, sakartosana un atdalisnaa ar komatiem
bool nolasitsCsv(const string& rinda, AutobusaMarsruts& marsruts) {
    stringstream ss(rinda);
    string info;

        // cikls lasa string lidz bridim kad saskaras ar komatu, tad piesaista autobusaMarsruts
    if (getline(ss, info, ','))
        marsruts.sakumaPietura = info;
    else
        return false;

        // tapat notiek talak ar visam parejam kolonnam no csv faila
    if (getline(ss, info, ','))
        marsruts.galaPietura = info;
    else
        return false;

    if (getline(ss, info, ','))
        marsruts.nedelasDiena = info;
    else
        return false;

    if (getline(ss, info, ','))
        marsruts.laiks = info;
    else
        return false;

    if (getline(ss, info, ','))
        marsruts.biletesCena = stod(info);
    else
        return false;

    return true;
}

void printResult(const AutobusaMarsruts& marsruts) {
    cout << "result:" << endl;
    cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " " << marsruts.nedelasDiena << " " << marsruts.laiks << " " << marsruts.biletesCena << endl;
}

int main() {
    ifstream inputFile("db.csv"); // ifstream lasa failus
    ofstream errorFile("err.txt"); // ofstream - failu rakstisanai
    string rinda; // deklarē variables

    char burts;
    do {
        // cout << "a, b, c, d, e: "; // sakotn. vaicajums
        cin >> burts;

        switch (burts) {
            case 'a': { // a izveles gadijums
                string sakumaPietura, galaPietura;
                // cout << "sakuma pietura: ";
                cin >> sakumaPietura;
                // cout << "gala pietura: ";
                cin >> galaPietura;

                AutobusaMarsruts result;
                bool atrasts = false;

                while (getline(inputFile, rinda)) {
                    AutobusaMarsruts marsruts;
                    // mekle sakritibu ar input
                    if (nolasitsCsv(rinda, marsruts)) {
                        if (marsruts.sakumaPietura == sakumaPietura && marsruts.galaPietura == galaPietura) {
                            result = marsruts;
                            atrasts = true;
                            // ja atrasts, beidz ciklu
                            break;
                        }
                    }
                }

                if (atrasts) {
                    printResult(result);
                }
                // else {
                //    cout << "Nav autobusu jusu marsrutam." << endl;
                //}
                break;
            }

            case 'b': {
                string nedelasDiena;
                // cout << "Pr, Ot, Tr, Ce, Pt, St, Sv: ";
                cin >> nedelasDiena;

                while (getline(inputFile, rinda)) { // lasa input failu
                    //ring info par marsrutu
                    AutobusaMarsruts marsruts;
                    if (nolasitsCsv(rinda, marsruts)) { //parbauda vai nolasisana veiksmiga
                        if (marsruts.nedelasDiena == nedelasDiena) { //salidzina marsrutus
                            printResult(marsruts); // ja veiksmigi izdevies nolasit info, printRes
                        }
                    }
                }

                break;
            }

            case 'c': { // biletes cenas kura ir mazaka vai vienada apstrade
                double maxBiletesCena;
                //cout << "cena: ";
                cin >> maxBiletesCena;

                while (getline(inputFile, rinda)) {
                    AutobusaMarsruts marsruts;
                    if (nolasitsCsv(rinda, marsruts)) {
                        if (marsruts.biletesCena <= maxBiletesCena) {
                            printResult(marsruts);
                        }
                    }
                }
                break;
            }

            case 'd': { // err.txt apstrade, ja taja ir kads fails >> skaitas atverts un uzglaba datus
                ifstream errorFileIn("err.txt");
                if (errorFileIn.is_open()) {
                    cout << "result:" << endl;
                    string errtxt;
                    while (getline(errorFileIn, errtxt)) {
                        cout << errtxt << endl;
                    }
                }
                break;
            }
            case 'e':
                break;
        }
        // elements e nosledz ciklu, kamer nav, cikls turpinas un aiziet uz do
    } while (burts != 'e');
    return 0;
}