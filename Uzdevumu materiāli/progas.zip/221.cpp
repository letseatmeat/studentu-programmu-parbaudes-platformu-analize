
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cctype>
#include <limits>
#include <iomanip>
using namespace std;

struct Cels {
    string starts;
    string beigas;
    string diena;
    string laiks;
    double cena;
};
string iss(const string& a) {
    auto starts = a.begin();
    while (starts != a.end() && isspace(*starts)) {
        starts++;
    }

    auto beigas = a.end();
    do {
        beigas--;
    }while (distance(starts,beigas) > 0 && isspace(*beigas));

    return string(starts, beigas + 1);
}

vector<Cels> ladetCelus(const string& filename, const string& errFilename) {
    vector<Cels> celi;
    ifstream inFile(filename);
    ofstream errFile(errFilename);
    string linija;

    while (getline(inFile,linija)) {
        if(!linija.empty() && linija.back() == '\r') {
            linija.pop_back();
        }
        if(linija.find_first_not_of(' ') == string::npos) {
            continue;
        }
        stringstream x(linija);
        string starts, beigas, diena, laiks;
        double cena;
        if(getline(x, starts, ',') && getline(x,beigas,',') &&
            getline(x, diena, ',') && getline(x,laiks,',') &&
            x >> cena && x.eof()) {
            celi.push_back({iss(starts), iss(beigas), iss(diena), iss(laiks), cena});
        } else {
            errFile << linija << '\n';
        }
    }
    return celi;
}

void izvaditCelus(const vector<Cels>&celi) {
    for(const auto& cels : celi) {
        cout << cels.starts << " " << cels.beigas << " " << cels.diena << " "
             << cels.laiks << " " << fixed << setprecision(2) << cels.cena << '\n';
    }
}

int main() {
    vector<Cels> celi = ladetCelus("db.csv", "err.txt");
    string komanda;

    while(true) {
        cin >> komanda;
        if(komanda.length() > 1) {
            continue;
        }
        char a = komanda[0];

        if(a == 'a') {
            string starts, beigas;
            cin >> starts >> beigas;
            vector<Cels> rezultats;
            for(const auto& cels : celi) {
                if (cels.starts == starts && cels.beigas == beigas) {
                    rezultats.push_back(cels);
                }
            }
            cout << "result:\n";
            izvaditCelus(rezultats);
        } else if(a == 'b') {
            string diena;
            cin >> diena;
            vector<Cels> rezultats;
            for(const auto& cels : celi) {
                if(cels.diena == diena) {
                    rezultats.push_back(cels);
                }
            }
            cout << "result:\n";
            izvaditCelus(rezultats);
        } else if (a == 'c') {
            double maxCena;
            if(!(cin >> maxCena)) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "result:\n";
                continue;
            }
            vector<Cels> rezultats;
            for(const auto& cels : celi) {
                if(cels.cena <= maxCena) {
                    rezultats.push_back(cels);
                }
            }
            cout << "result:\n";
            izvaditCelus(rezultats);
        } else if(a == 'd') {
            ifstream inFile("err.txt");
            string linija;
            cout << "result:\n";
            while (getline(inFile,linija)) {
                cout << linija << '\n';
            }
        } else if(a == 'e') {
            break;
        }
    }
    return 0;
}
