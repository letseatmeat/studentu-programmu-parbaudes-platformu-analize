
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <limits>
#include <cctype>

using namespace std;

struct BusRoutes {
    string departure;
    string arrival;
    string day;
    string time;
    double price;
};

string toUpper(const string& str) {
    string result;
    for (char ch : str) {
        result += static_cast<char>(toupper(ch));
    }
    return result;
}

string removeSpaces(const string& str) {
    string result;
    for (char ch : str) {
        if (ch != ' ' && ch != '\t' && ch != '\n' && ch != '\r' && ch != '\f' && ch != '\v') {
            result += ch;
        }
    }
    return result;
}

void printRoute(const BusRoutes& route) {
    cout << route.departure << " ";
    cout << route.arrival << " ";
    cout << route.day << " ";
    cout << route.time << " ";
    cout << fixed << setprecision(2) << route.price << endl;
}

bool isValidLine(const string& line) {
    stringstream ss(line);
    string field;
    int fieldCount = 0;

    while (getline(ss, field, ',')) {
        fieldCount++;
    }

    return fieldCount == 5;
}

void writeToErr(string line) {
    if (!line.empty()) {
        ofstream errorFile("err.txt", ios::app);
        errorFile << line << endl;
        errorFile.close();
    }
}

bool isDouble(const string& s) {
    try {
        size_t pos;
        stod(s, &pos);
        return pos == s.size();
    } catch (const invalid_argument&) {
        return false;
    }
}

void readDataFromFile(vector<BusRoutes>& routes) {
    ifstream inputFile("db.csv");

    if (inputFile.is_open()) {
        string line;
        string trimmedLine;
        while (getline(inputFile, line)) {
            trimmedLine = removeSpaces(line);
            if (!isValidLine(trimmedLine) && !trimmedLine.empty()) {
                writeToErr(trimmedLine);
                continue;
            }

            stringstream ss(trimmedLine);
            BusRoutes route;

            getline(ss, route.departure, ',');
            getline(ss, route.arrival, ',');
            getline(ss, route.day, ',');
            getline(ss, route.time, ',');

            string ticketPrice;
            getline(ss, ticketPrice, ',');

            if (!isDouble(ticketPrice)) {
                writeToErr(trimmedLine);
            } else {
                route.price = stod(ticketPrice);
                routes.push_back(route);
            }
        }

        inputFile.close();
    } 
}

void routesFromTo(const vector<BusRoutes>& routes) {
    string departure, arrival;

    cout << "Enter city of departure: ";
    cin >> departure;

    cout << "Enter city of arrival: ";
    cin >> arrival;

    bool found = false;
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.departure == departure && route.arrival == arrival) {
            found = true;
            printRoute(route);
        }
    }

    if (!found) {
        cout << "No routes from: " << departure << " to: " << arrival << " found" << endl;
    }
    cout << endl;
}

void routesByDay(const vector<BusRoutes>& routes) {
    string weekDay;

    while (true) {
        cout << "Enter weekday (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
        cin >> weekDay;

        for (char& ch : weekDay) {
            ch = toupper(ch);
        }  

        if (weekDay == "PR" || weekDay == "OT" || weekDay == "TR" ||
            weekDay == "CE" || weekDay == "PT" || weekDay == "ST" ||
            weekDay == "SV")
        {
            break;  
        }
        else {
            cout << "Error: input weekday" << endl;
        }

    }   

    bool found = false;
    cout << "result:" << endl;

    for (const auto& route : routes) {
        if (toUpper(route.day) == weekDay) {
            found = true;
            printRoute(route);
        }
    }

    if (!found) {
        cout << "There are no routes on: " << weekDay << endl;
    }

    cout << endl;
}

void routesByPrice(const vector<BusRoutes>& routes) {
    double maxPrice;
    while (true) {
        cout << "Enter the maximum price of ticket: ";

        if (cin >> maxPrice) {
            break;
        } else {
            cout << "Error: input number" << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }

    bool found = false;
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.price <= maxPrice) {
            found = true;
            printRoute(route);
        }
    }

    if (!found) {
        cout << "There are no routes below: " << maxPrice << " EUR" << endl;
    }
    cout << endl;
}

void errTextFile() {
    ifstream errFile("err.txt");
    string line;
    cout << "result:" << endl;
    while (getline(errFile, line)) {
        cout << line << endl;
    }

    errFile.close();
    cout << endl;
}

int main() {
    vector<BusRoutes> routes;
    readDataFromFile(routes);
    char menu;
    while (true) {
        cout << "Main Menu" << endl;
        cout << "a: by departure/arrival" << endl;
        cout << "b: by day" << endl;
        cout << "c: by price" << endl;
        cout << "d: open err.txt" << endl;
        cout << "e: exit" << endl;  
        cout << "Enter your choice: ";
        cin >> menu;

        if (cin.peek() != '\n' || menu < 'a' || menu > 'e') {
            cout << endl << "Error: input letter a - e" << endl;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (menu) {
            case 'a':
                routesFromTo(routes);
                break;
            case 'b':
                routesByDay(routes);
                break;
            case 'c':
                routesByPrice(routes);
                break;
            case 'd':
                errTextFile();
                break;
            case 'e':
                remove("err.txt");
                return 0;
        }
    }

    return 0;
}
