#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <string>
#include <algorithm>
#include <set>


using namespace std;



struct BusRoute {
    string startStop;
    string endStop;
    string weekday;
    string time;
    double ticketPrice;
};


string griezt(const string& str) {
      size_t first = str.find_first_not_of(' ');
      size_t last = str.find_last_not_of(' ');
      return str.substr(first, (last - first + 1));
}


int main() {
  ifstream inFile;
  inFile.open("db.csv");
vector<BusRoute> routes;
  string line;

  while (getline(inFile, line)) {
      replace(line.begin(), line.end(), ',', ' '); // Aizvieto komatus ar atstarpēm
      stringstream ss(line);
      string startStop, endStop, weekday, time, ticketPriceStr;

      if (ss >> startStop >> endStop >> weekday >> time >> ticketPriceStr) {
          // Tīrīšana no atstarpēm un veidojam BusRoute objektu
          startStop = griezt(startStop);
          endStop = griezt(endStop);
          weekday = griezt(weekday);
          time = griezt(time);

          double ticketPrice = 0.0;
          try {
              ticketPrice = stod(griezt(ticketPriceStr));
          } catch (const exception& e) {
              std::cerr << "Kļūda: " << e.what() << "\n";
          }

          BusRoute route{startStop, endStop, weekday, time, ticketPrice};
          routes.push_back(route);
      }
  }
  
  
  char izv;
  do{
    cin >> izv;
    switch(izv){
      // case 
      case 'a':{
        string startStop, endStop;
            cin >> startStop;
            cin >> endStop;
            cout << "result:" << endl;
            for (const auto& route : routes) {
                if (route.startStop == startStop && route.endStop == endStop) {
                  
                  cout << route.startStop << " " << route.endStop << " "
                              << route.weekday << " " << route.time << " " << fixed
                              << setprecision(2) << route.ticketPrice << "\n";
                }
            }
            break;
        }
      case 'b':{
        string inputDay;
        std::cin >> inputDay;

        bool foundRoutes = false;
        cout << "result:" << endl;
        for (const auto& route : routes) {
            if (route.weekday == inputDay) {
                foundRoutes = true;
                
              cout << route.startStop << " " << route.endStop << " "
                          << route.weekday << " " << route.time << " "
                          << std::fixed << std::setprecision(2) << route.ticketPrice << "\n";
            }
        }

        if (!foundRoutes) {
            std::cout << "No routes found for the specified day.\n";
        }
        break;
      }
      case 'c':{
        double cena;
        cin >> cena;

        vector<BusRoute> dceli; 
        cout << "result:" << endl;
        for (const auto& route : routes) {
            if (route.ticketPrice <= cena) {
                bool irtadspats = true;
                for (const auto& uniqueRoute : dceli) {
                    if (route.startStop == uniqueRoute.startStop &&
                        route.endStop == uniqueRoute.endStop &&
                        route.weekday == uniqueRoute.weekday &&
                        route.time == uniqueRoute.time &&
                        route.ticketPrice == uniqueRoute.ticketPrice) {
                        irtadspats = false;
                        break;
                    }
                }
                if (irtadspats) {
                    dceli.push_back(route);
                }
            }
        }

        
        if (dceli.empty()) {
            cout << "kļuda";
          return 0;
         
        } else {
            for (const auto& route : dceli) {
                cout << route.startStop << " " << route.endStop << " "
                          << route.weekday << " " << route.time << " "
                          << fixed << setprecision(2) << route.ticketPrice << "\n";
            }
        }
        break;
      }
      case 'd':{ // nebija laiks pabegt

        return 0;
      }
      case 'e':{
        
        break;
      }
    }
    } while(izv != 'e');
  }
