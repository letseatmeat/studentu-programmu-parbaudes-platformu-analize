
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <cctype> 

using namespace std;

struct Route {
    string startStop;
    string endStop;
    string day;
    string time;
    double price;
};

// Function to parse a CSV line into a Route object
bool parseCSVLine(const string& line, Route& route) {
    istringstream ss(line);
    vector<string> tokens;

    while (ss) {
        string token;
        if (!getline(ss, token, ',')) break;

        // Trim leading and trailing whitespaces from each token
        token.erase(0, token.find_first_not_of(" \t")); // Remove leading spaces
        token.erase(token.find_last_not_of(" \t") + 1); // Remove trailing spaces

        tokens.push_back(token);
    }

    // Check if there are exactly 5 fields
    if (tokens.size() == 5 || (tokens.size() == 4 && !tokens[2].empty())) {  // Allow 4 fields if "day" is not empty
        route.startStop = tokens[0];
        route.endStop = tokens[1];

        // Check if the 3rd field (day) is not empty
        if (!tokens[2].empty()) {
            route.day = tokens[2];
        } else {
            route.day = "";  // If empty, set it to an empty string
        }

        route.time = tokens[3];

        try {
            route.price = stod(tokens[4]);
        } catch (...) {
            return false;
        }

        return true;
    } else {
        return false;
    }
}
// Function to read routes from the file and handle errors
vector<Route> readRoutes() {
    vector<Route> routes;
    ifstream file("db.csv");
    ofstream errorFile("err.txt");

    if (!file.is_open()) {
        cerr << "Error: Unable to open file 'db.csv'" << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) {
        Route route;
        if (parseCSVLine(line, route)) {
            routes.push_back(route);
        } else {
            errorFile << "" << line << endl; //Error in line: 
        }
    }

    file.close();
    errorFile.close();
    return routes;
}

// Function to print routes based on start and end stops
void printRoutesByStops(const vector<Route>& routes, const string& startStop, const string& endStop) { // Print routes based on start and end stops
    bool found = false;  // Flag to check if at least one route is found

    for (const auto& route : routes) {
        if (route.startStop == startStop && route.endStop == endStop) {
            if (!found) {
                cout << "result:" << endl;
                found = true;  // Set the flag to true after the first route is found
            }
            cout << route.startStop << " " << route.endStop << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }

    if (!found) {
        cout << "result:" << endl;
    }
}

// Function to print routes based on the day
void printRoutesByDay(const vector<Route>& routes, const string& day) {
    bool found = false;  // Flag to check if at least one route is found

    for (const auto& route : routes) { // Loop through all routes
        if (route.day == day) {
            if (!found) {
                cout << "result:" << endl;
                found = true; // Set the flag to true after the first route is found
            }
            cout << route.startStop << " " << route.endStop << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }

    if (!found) {
        cout << "result:" << endl;
    }
}

// Function to print routes based on the maximum price
void printRoutesByMaxPrice(const vector<Route>& routes, double maxPrice) {
    bool found = false;  // Flag to check if at least one route is found

    for (const auto& route : routes) {
        if (route.price <= maxPrice) {
            if (!found) {
                cout << "result:" << endl;
                found = true;
            }
            cout << route.startStop << " " << route.endStop << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }

    if (!found) {
        cout << "result:" << endl;
    }
}

// Function to print the content of the error file
void printErrorFile() {
    ifstream errorFile("err.txt");
    cout << "result:" << endl;
    cout << errorFile.rdbuf() << endl;
    errorFile.close();
}

int main() {
    vector<Route> routes = readRoutes();

    char choice;
    do {
        cout << ""; //Enter choice (a, b, c, d, e):
        cin >> choice;

        switch (choice) {
            case 'a': {
                string startStop, endStop;
                cout << ""; //Enter start stop: 
                cin >> startStop;
                cout << ""; //Enter end stop: 
                cin >> endStop;
                printRoutesByStops(routes, startStop, endStop);
                break;
            }
            case 'b': {
                string day;
                cout << ""; //Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): 
                cin >> day;
                printRoutesByDay(routes, day);
                break;
            }
            case 'c': {
                double maxPrice;
                cout << ""; //Enter maximum price: 
                cin >> maxPrice;
                printRoutesByMaxPrice(routes, maxPrice);
                break;
            }
            case 'd':
                printErrorFile();
                break;
            case 'e':
                break;
            default:
                cout << "" << endl; //Invalid choice. Try again.
        }
    } while (choice != 'e');

    return 0;
}