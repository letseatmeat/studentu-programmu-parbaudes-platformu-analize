
#include <iostream>
using namespace std;
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

struct Trip {
  string start;
  string end;
  string day;
  string time;
  double price;
};

void trip_by_stops(string start_stop, string end_stop, vector<Trip> trips) {
  cout << "result:" << '\n';
  for (auto &trip : trips) {
    if (trip.start == start_stop && trip.end == end_stop) {
      cout << trip.start << " " << trip.end << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << '\n';
    }
  }
};

void trip_by_day(string day, vector<Trip> trips) {
  cout << "result:" << '\n';
  for (auto &trip : trips) {
    if (trip.day == day) {
      cout << trip.start << " " << trip.end << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << '\n';
    }
  }
};

void trip_by_price(double price, vector<Trip> trips) {
  cout << "result:" << '\n';
  for (auto &trip : trips) {
    if (trip.price < price && !string(trip.start).empty()) {
      cout << trip.start << " " << trip.end << " " << trip.day << " "
           << trip.time << " " << fixed << setprecision(2) << trip.price
           << '\n';
    }
  }
};

bool check(string s) {
  try {
    stoi(s);
    return false;
  } catch (invalid_argument) {
    return true;
  }
};

bool check_day(string s) {
  bool f = false;
  try {
    stoi(s);
    f = false;
  } catch (invalid_argument) {
    f = true;
  }
  if (s.length() != 2) {
    f = false;
  }
  return f;
};

bool check_time(string s) {
  bool f = false;

  string s2 = ":";
  size_t found = s.find(s2);
  if (found != string::npos) {
    f = true;
  } else
    return false;

  stringstream ss(s);
  string str;
  while ((getline(ss, str, ':'))) {
    try {
      stoi(str);
      f = true;
    } catch (invalid_argument) {
      f = false;
    }
    if (f == false)
      break;
  }
  return f;
};

bool check_price(string s) {
  try {
    stod(s);
    return true;
  } catch (invalid_argument) {
    return false;
  }
};

void read_from_err_file() {
  ifstream myfile("err.txt");
  string a;
  vector<string> lines;
  if (myfile.is_open()) {
    while (getline(myfile, a, '\n')) {
      cout << a << endl;
    }
  }
  myfile.close();
};

void write_to_err_file(vector<vector<string>> result) {
  ofstream MyFile("err.txt");

  for (int i = 0; i < result.size(); i++) {
    for (int y = 0; y < result[i].size(); y++) {

      if (result[i].size() != 5 || !check(result[i][0]) ||
          !check(result[i][1]) || !check_day(result[i][2]) ||
          !check_time(result[i][3]) || !check_price(result[i][4])) {
        // cout<<y<<"-"<<result[i].size()-1<<"   ";

        string s = (y == result[i].size() - 1) ? "\n" : ",";
        if (result[i].size() - 1 == 0) {
          s = "";
        }
        MyFile << result[i][y] << s;
      }
    }
  }
  MyFile.close();
};

int main() {
  ifstream myfile("db.csv");
  string a;
  vector<string> lines_from_file;

  if (myfile.is_open()) {
    while (getline(myfile, a, '\n')) {
      if (a.length() != 0) {
        lines_from_file.push_back(a);
      }
    }
    myfile.close();
  }

  vector<string> str_elements;
  vector<vector<string>> result;

  for (auto &line : lines_from_file) {

    stringstream ss(line);
    str_elements.clear();

    while (ss.good()) {
      string substr;
      getline(ss, substr, ',');

      substr.erase(remove_if(substr.begin(), substr.end(), ::isspace),
                   substr.end());
      str_elements.push_back(substr);
    }

    result.push_back(str_elements);
  }

  vector<Trip> trips(result.size());
  for (int i = 0; i < result.size(); i++) {

    if (result[i].size() == 5 && check(result[i][0]) && check(result[i][1]) &&
        check_day(result[i][2]) && check_time(result[i][3]) &&
        check_price(result[i][4])) {

      trips[i].start = result[i][0];
      trips[i].end = result[i][1];
      trips[i].day = result[i][2];
      trips[i].time = result[i][3];
      trips[i].price = stod(result[i][4]);
    }
  }

  for (int i = 0; i < trips.size(); i++) {
    if (string(trips[i].start).empty())
      trips.erase(trips.begin() + i);
  }

  // for(const auto& trip : trips) {
  //         cout<<trip.start<<" "<<trip.end<<" "<<trip.day<<" "<<trip.time<<"
  //         "<<fixed<<setprecision(2)<<trip.price<<'\n';
  // }

  write_to_err_file(result);

  char cmd = 'n';
  while (cmd != 'e') {
    cin >> cmd;
    switch (cmd) {
    case 'a': {
      string start, end;
      cin >> start;
      cin >> end;
      trip_by_stops(start, end, trips);
      break;
    }
    case 'b': {
      string day;
      cin >> day;
      trip_by_day(day, trips);
      break;
    }
    case 'c': {
      double price;
      cin >> price;
      trip_by_price(price, trips);
      break;
    }
    case 'd': {
      cout << "result:\n";
      read_from_err_file();
      break;
    }
    default:
      break;
    }
  }

  return 0;
};