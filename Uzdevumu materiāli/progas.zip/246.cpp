#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

// maršruta informācija 
struct Trip {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

// datu nolasīšana no faila 
void readFile(const std::string &filename, std::vector<Trip> &trips,
                      std::ofstream &errorFile) {
  std::ifstream file(filename);
  if (!file.is_open()) {
    std::cerr << "Error" << filename << std::endl;
    exit(1);
  }

  std::string line;
  while (std::getline(file, line)) {

    // noņemiet papildu atstarpes 
    line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line.empty()) {
      continue;
    }

    // stgu sadalīšana
    std::istringstream iss(line);
    std::vector<std::string> tokens;
    std::string token;
    while (std::getline(iss, token, ',')) {
      tokens.push_back(token);
    }

    // datu pārbaude
    if (tokens.size() != 5) {
      errorFile << line << std::endl;
      continue;
    }

    // maršruta izveide un pievienjošana
    Trip trip;
      trip.start = tokens[0];
      trip.end = tokens[1];
      trip.day = tokens[2];
      trip.time = tokens[3];

    try {
      try {
        size_t pos;
          trip.price = std::stod(tokens[4], &pos);
        if (pos != tokens[4].size()) {
          throw std::invalid_argument("");
        }
      } catch (...) {
        errorFile << line << std::endl;
        continue;
      }

    } catch (...) {
      errorFile << line << std::endl;
      continue;
    }

      trips.push_back(trip);
  }
}

// informācijas parādīšanai par maršrutiem 
void printTrip(const std::vector<Trip> &trips) {
  for (const auto &trip : trips) {
    std::cout << trip.start << " " << trip.end << " " << trip.day << " "
              << trip.time << " " << std::fixed << std::setprecision(2)
              << trip.price << std::endl;
  }
}

int main() {
  std::vector<Trip> trips;
  std::ofstream errorFile("err.txt"); // error fail 

  // failu 
  readFile("db.csv", trips, errorFile);

  char command;
  while (true) {
    std::cout << "";
    std::cin >> command;

    switch (command) {
    case 'a': {
      std::string start, end;
      std::cout << "";
      std::cin >> start >> end;

      std::cout << "result:" << std::endl;
      for (const auto &trip : trips) {
        if (trip.start == start && trip.end == end) {
          std::cout << trip.start << " " << trip.end << " " << trip.day
                    << " " << trip.time << " " << std::fixed
                    << std::setprecision(2) << trip.price << std::endl;
        }
      }
      break;
    }

    case 'b': {
      std::string day;
      std::cout << "";
      std::cin >> day;

      std::cout << "result:" << std::endl;
      for (const auto &trip : trips) {
        if (trip.day == day) {
          std::cout << trip.start << " " << trip.end << " " << trip.day
                    << " " << trip.time << " " << std::fixed
                    << std::setprecision(2) << trip.price << std::endl;
        }
      }
      break;
    }

    case 'c': {
      double maxPrice;
      std::cout << "";
      std::cin >> maxPrice;

      std::cout << "result:" << std::endl;
      for (const auto &trip : trips) {
        if (trip.price <= maxPrice) {
          std::cout << trip.start << " " << trip.end << " " << trip.day
                    << " " << trip.time << " " << std::fixed
                    << std::setprecision(2) << trip.price << std::endl;
        }
      }
      break;
    }

    case 'd': {
      std::ifstream errorFileIn("err.txt");
      std::cout << "result:" << std::endl;
      std::cout << errorFileIn.rdbuf();
      break;
    }

    case 'e': {
      return 0;
    }
    default: {
      std::cout << "Invalid command." << std::endl;
    }
    }
  }

  return 0;
}




