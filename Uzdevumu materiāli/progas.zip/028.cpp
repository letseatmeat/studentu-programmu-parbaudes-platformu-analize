
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

struct Route {
  string start;
  string destination;
  string day;
  string time;
  double price;
};

vector<Route> routes;
map<string, vector<Route>> routePlan;
map<string, vector<Route>> dayRoutes;

string trim(const string& str){
  size_t first=str.find_first_not_of(' ');
  if(string::npos==first) return "";
  size_t last=str.find_last_not_of(' ');
  return str.substr(first, (last-first+1));
}

void load(const string& fileName){
  ifstream inFile(fileName);
  string line;
  ofstream errFile("err.txt", ios::trunc);

  while(getline(inFile, line)){
    line=trim(line);
    if(line.empty()) continue;

    stringstream ss(line);
    Route route;
    string token;
    vector<string> tokens;

    while(getline(ss, token, ',')) tokens.push_back(trim(token));

    if(tokens.size()!=5){
      errFile<<line<<"\n";
      continue;
    }

    route.start=tokens[0];
    route.destination=tokens[1];
    route.day=tokens[2];
    route.time=tokens[3];

    if(route.time.find(':')==string::npos){
      errFile<<line<<"\n";
      continue;
    }

    try{
      route.price=stod(tokens[4]);
    }catch (...){
      errFile<<line<<"\n";
      continue;
    }
    routes.push_back(route);
    routePlan[route.start+" "+route.destination].push_back(route);
    dayRoutes[route.day].push_back(route);
  }
}

void display(const vector<Route>& routes){
  for(const auto& route : routes) cout<<route.start<<" "<<route.destination<<" "<<route.day<<" "<<route.time<<" "<<fixed<<setprecision(2)<<route.price<<endl;
}

void functionA(){
  string start, end;
  cin>>start>>end;
  cout<<"result:"<<endl;
  display(routePlan[start+" "+end]);
}

void functionB(){
  string day;
  cin>>day;
  cout<<"result:"<<endl;
  display(dayRoutes[day]);
}

void functionC(){
  double price;
  cin>>price;
  cout<<"result:"<<endl;
  for(const auto& route : routes){
    if(route.price <= price) cout<<route.start<<" "<<route.destination<<" "<<route.day<<" "<<route.time<<" "<<fixed<<setprecision(2)<<route.price<<endl;
  }
}

void functionD(){
  ifstream errFile("err.txt");
  string line;
  cout<<"result:"<<endl;
  while (getline(errFile, line)) cout<<line<<endl;
}

int main(){
  ofstream errFile("err.txt", ios::trunc);
  errFile.close();
  load("db.csv");
  char query;
  while (true){
    cin>>query;
    switch (query){
      case 'a': functionA(); break;
      case 'b': functionB(); break;
      case 'c': functionC(); break;
      case 'd': functionD(); break;
      case 'e': return 0;
    }
  }
}
