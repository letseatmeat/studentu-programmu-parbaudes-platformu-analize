#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <regex>
#include <algorithm>

using namespace std;

struct autobuss {
    string sakums;
    string gals;
    string diena;
    string laiks;
    double bilete;
};

void kluduIzvade(const string& rinda) {
 ofstream errorFile("err.txt", ios::app);
    errorFile << rinda << endl;
    errorFile.close();

}

    void output(const autobuss&  cels) {
        cout.precision(2);
        cout << fixed;
        cout << cels.sakums << " " << cels.gals << " " << cels.diena << " " << cels.laiks << " " << cels.bilete << endl;

}

bool format(const string& laiks) {
    regex check(R"([0-2][0-9]:[0-5][0-9])");
    return regex_match(laiks,check);
}

vector<autobuss> nolasitDatus(const string& filename) {
    vector<autobuss> saraksts;
    ifstream inFile(filename);
        if(!inFile.is_open()) {
            exit(1);
        }

    
    string rinda;
    while(getline(inFile,rinda)) {
        rinda.erase(remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());
        if(rinda.empty()) {
            continue;
        }
        istringstream row(rinda);
        autobuss cels;

        getline(row, cels.sakums, ',');
        getline(row, cels.gals, ',');
        getline(row, cels.diena, ',');
        getline(row, cels.laiks, ',');
        row >> cels.bilete;

        if(count(rinda.begin(), rinda.end(), ',') != 4 || cels.bilete <= 0 || !format(cels.laiks)){
            kluduIzvade(rinda);
            continue;
        }
        saraksts.push_back(cels);
    }
    inFile.close();
    return saraksts;
}

    void izvaditPieturas(const vector<autobuss>& saraksts, const string& sakums, const string& gals) {
        cout << "result:" << endl;
        for (const auto& cels : saraksts) {
            if (cels.sakums == sakums && cels.gals == gals) {
                output(cels);
            }
        }
    }

    void izvaditDienas(const vector<autobuss>& saraksts, const string& inputDiena) {
        cout << "result:" << endl;
        for (const auto& cels : saraksts) {
            if (cels.diena == inputDiena) {
                output(cels);
            }
        }
    }

    void izvaditCenas(const vector<autobuss>& saraksts, double maxCena) {
        cout << "result:" << endl;
        for (const auto& cels : saraksts) {
            if(cels.bilete <=maxCena) {
                output(cels);
            }
        }
    }
int main() {
    vector<autobuss> saraksts = nolasitDatus("db.csv");

	char izvele;
    string sakums, gals, inputDiena;
    double maxCena;
    
    //case grupas

    while (true){
        cin >> izvele;
        if(izvele == 'e') {
            break;
        }
    

    switch (izvele) {
        case 'a': 
            cin >> sakums;    
            cin >> gals;
            izvaditPieturas(saraksts,sakums,gals);
            break;
        
        case 'b':
            
            cin >> inputDiena;
            izvaditDienas(saraksts,inputDiena);
            break;
            
        case 'c':
            
            cin >> maxCena;
            izvaditCenas(saraksts,maxCena);
            break;
            
        case 'd':
            {
             ifstream errorFile("err.txt");
             if(errorFile.is_open()) {
                 cout << "result:" << endl;
                 cout << errorFile.rdbuf();
                 errorFile.close();
             }
            }
            break;
            
        default:
        cout << "error" << endl;
        break;
        }
    }
    
    return 0;
}



    