#include <limits>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;

struct Maršruts {
    string sākumaPietura;
    string galaPietura;
    string nedēļasDiena;
    string laiks;
    double biļetesCena;
};

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r\f\v");
    if (first == string::npos)
        return "";
    size_t last = str.find_last_not_of(" \t\n\r\f\v");
    return str.substr(first, (last - first + 1));
}

bool isValidPrice(const string& str) {
    stringstream ss(str);
    double test;
    ss >> test;
    return !ss.fail() && ss.eof();
}

vector<Maršruts> ielādētMaršrutus(const string& failaVārds) {
    ifstream inFile(failaVārds);
    vector<Maršruts> maršruti;
    string rinda, cena;

    ofstream errFile("err.txt", ios_base::trunc);
    errFile.close();
    errFile.open("err.txt", ios_base::app);

    while (getline(inFile, rinda)) {
        stringstream ss(trim(rinda));
        Maršruts maršruts;

        getline(ss, maršruts.sākumaPietura, ',');
        getline(ss, maršruts.galaPietura, ',');
        getline(ss, maršruts.nedēļasDiena, ',');
        getline(ss, maršruts.laiks, ',');
        getline(ss, cena);

        maršruts.sākumaPietura = trim(maršruts.sākumaPietura);
        maršruts.galaPietura = trim(maršruts.galaPietura);
        maršruts.nedēļasDiena = trim(maršruts.nedēļasDiena);
        maršruts.laiks = trim(maršruts.laiks);
        cena = trim(cena);

        if (maršruts.sākumaPietura.empty() || maršruts.galaPietura.empty() ||
            maršruts.nedēļasDiena.empty() || maršruts.laiks.empty() ||
            !isValidPrice(cena)) {
            errFile << rinda << endl;
            continue;
        }

        maršruts.biļetesCena = stod(cena);
        maršruti.push_back(maršruts);
    }
    errFile.close();
    return maršruti;
}

void izvadītReisus(const vector<Maršruts>& maršruti, const string& sākums, const string& beigas) {
    cout << "result:" << endl;
    for (const auto& maršruts : maršruti) {
        if (maršruts.sākumaPietura == sākums && maršruts.galaPietura == beigas) {
            cout << maršruts.sākumaPietura << " " << maršruts.galaPietura << " "
                 << maršruts.nedēļasDiena << " " << maršruts.laiks << " "
                 << fixed << setprecision(2) << maršruts.biļetesCena << endl;
        }
    }
}

void izvadītReisusDienā(const vector<Maršruts>& maršruti, const string& diena) {
    cout << "result:" << endl;
    for (const auto& maršruts : maršruti) {
        if (maršruts.nedēļasDiena == diena) {
            cout << maršruts.sākumaPietura << " " << maršruts.galaPietura << " "
                 << maršruts.nedēļasDiena << " " << maršruts.laiks << " "
                 << fixed << setprecision(2) << maršruts.biļetesCena << endl;
        }
    }
}

void izvadītReisusLētākusPar(const vector<Maršruts>& maršruti, double cena) {
    cout << "result:" << endl;
    for (const auto& maršruts : maršruti) {
        if (maršruts.biļetesCena <= cena) {
            cout << maršruts.sākumaPietura << " " << maršruts.galaPietura << " "
                 << maršruts.nedēļasDiena << " " << maršruts.laiks << " "
                 << fixed << setprecision(2) << maršruts.biļetesCena << endl;
        }
    }
}

void izvadītKļūdasFailu(const string& failaVārds) {
    ifstream errFile(failaVārds);
    cout << "result:" << endl;
    string rinda;
    while (getline(errFile, rinda)) {
        rinda = trim(rinda); 
        if (!rinda.empty()) {
            cout << rinda << endl;
        }
    }
    errFile.close();
}


int main() {
    vector<Maršruts> maršruti = ielādētMaršrutus("db.csv");
    string sākums, beigas, diena;
    double cena;
    char izvēle;

    while (cin >> izvēle) {
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (izvēle) {
            case 'a':
                getline(cin, sākums);
                getline(cin, beigas);
                izvadītReisus(maršruti, sākums, beigas);
                break;
            case 'b':
                getline(cin, diena);
                izvadītReisusDienā(maršruti, diena);
                break;
            case 'c':
                if (!(cin >> cena)) {
                    cout << "Nepareiza cena!" << endl;
                    cin.clear();
                }
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                izvadītReisusLētākusPar(maršruti, cena);
                break;
            case 'd':
                izvadītKļūdasFailu("err.txt");
                break;
            case 'e':
                return 0;
            default:
                cout << "Neatpazīts vaicājums. Lūdzu, mēģiniet vēlreiz." << endl;
                break;
        }
    }

    return 0;
}

