
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>

using namespace std;
void printMarsruts(){
  ifstream inFile;
  inFile.open("db1.csv");
  if (!inFile) return;
  string s;
  string sCity, bCity;
  cin >> sCity >> bCity;
  cout << "result:" << endl;
   while(getline(inFile,s)){
     istringstream info(s);
     vector <string> v;
     string res;
     while(getline(info,res,',')){
       v.push_back(res);
     }
     if(v[0]==sCity && v[1]==bCity){
       replace(s.begin(), s.end(), ',', ' ');
       cout<<s<<endl;
     }
  }

  inFile.close();
}
void printDienas(){
  ifstream inFile;
  inFile.open("db1.csv");
  if (!inFile) return;
  string s;
  string diena;
  cin >> diena;
  cout << "result:" << endl;
   while(getline(inFile,s)){
     istringstream info(s);
     vector <string> v;
     string res;
     while(getline(info,res,',')){
       v.push_back(res);
     }
     if(v[2]==diena){
       replace(s.begin(), s.end(), ',', ' ');
       cout<<s<<endl;
     }
  }

  inFile.close();
}
void printMaksa(){
  ifstream inFile;
  inFile.open("db1.csv");
  if (!inFile) return;
  string s;
  double cena;
  cin >> cena;
  cout << "result:" << endl;
   while(getline(inFile,s)){
     istringstream info(s);
     vector <string> v;
     string res;
     while(getline(info,res,',')){
       v.push_back(res);
     }
     double cenaRes=stod(v[4]);
     if(cenaRes <= cena){
       replace(s.begin(), s.end(), ',', ' ');
       cout<<s<<endl;
     }
  }

  inFile.close();
}
int main() {
  ifstream inFile;
  inFile.open("db.csv");
	if (!inFile) return 0;
  
  ofstream outFile("db1.csv");
  ofstream errFile("err.txt");
  string s;
  int coma=0;

  while(getline(inFile,s)){
    s.erase(remove_if(s.begin(), s.end(), ::isspace),s.end());
    for(char k : s){
      if(k==','){
        coma++;
      }
    }
    istringstream info(s);
    vector <string> v;
    string res;
    while(getline(info,res,',')){
      v.push_back(res);
    }
    char konec='.';
    
    if(!s.empty() && coma==4){
      auto find = v[4].find(konec);
      if(find != string::npos)
        outFile << s << endl;
      else{
        if(!s.empty())
        errFile << s << endl;
      }
    }else{
      if(!s.empty())
      errFile << s << endl;
    }
    coma=0;
  }
  inFile.close();
  outFile.close();
  errFile.close();
  
  char cmd;
  while(cmd!='e'){
   
    cin >> cmd;
    switch (cmd){
      case 'a':
      printMarsruts();
      break;
      case 'b':
      printDienas();
      break;
      case 'c':
      printMaksa();
      break;
      case 'e':
      break;
      case 'd':
        cout << "result:" << endl;
        inFile.open("err.txt");
        if (!inFile) return 0;
        string s;
        while(getline(inFile,s)){
          cout << s << endl;
        }
        inFile.close();
      break;
    }
  }
  
} 
 
