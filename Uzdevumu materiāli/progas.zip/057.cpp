#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

// bus route structure
struct busRoute {
  string firstStop;
  string lastStop;
  string dayOfWeekString;
  string time;
  double price;
};

// string trimmer (removes spaces at beginning & end)
string trim(const string &str) {
  size_t first = str.find_first_not_of(' ');
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

// splits a string using comma
vector<string> split(const string &s) {
  vector<string> tokens;
  istringstream tokenStream(s);
  string token;
  while (getline(tokenStream, token, ',')) {
    tokens.push_back(token);
  }
  return tokens;
}

// process line
void processLine(const string &line, vector<busRoute> &validRoutes,
                 ofstream &errorFile) {

  vector<string> data = split(line);

  // skips line if line empty
  if (data.size() == 1) {
    return;
  }

  if (data.size() == 5) {
    try {

      string firstStop = trim(data[0]);
      string lastStop = trim(data[1]);
      string dayOfWeekString = trim(data[2]);
      string time = trim(data[3]);
      double price = stod(data[4]);

      // check if time is valid by seeing if it contains letters
      for (char c : time) {
        if (isalpha(c)) {
          throw invalid_argument("time incorrect");
        }
      }

      // check if day os valid
      if (dayOfWeekString != "Pr" && dayOfWeekString != "Ot" &&
          dayOfWeekString != "Tr" && dayOfWeekString != "Ce" &&
          dayOfWeekString != "Pt" && dayOfWeekString != "Se" &&
          dayOfWeekString != "Sv") {
        throw invalid_argument("day incorrect");
      }

      busRoute route{firstStop, lastStop, dayOfWeekString, time, price};
      validRoutes.push_back(route);

    } catch (...) {
      errorFile << line << endl;
    }
  } else {
    errorFile << line << endl;
  }
}

// input first and last stop names and print out routes with said first and last
// stops
void functionA(vector<busRoute> &validRoutes) {
  string firstStop, lastStop;
  cin >> firstStop >> lastStop;
  cout << "result:" << endl;
  for (const auto &route : validRoutes) {
    if (route.firstStop == firstStop && route.lastStop == lastStop) {
      cout << route.firstStop << " " << route.lastStop << " "
           << route.dayOfWeekString << " " << route.time << " " << fixed
           << setprecision(2) << route.price << endl;
    }
  }
}

// Input day of week and print out routes in that day of week
void functionB(const vector<busRoute> &validRoutes) {
  string requestedDay;
  cin >> requestedDay;
  cout << "result:" << endl;

  try {

    if (requestedDay != "Pr" && requestedDay != "Ot" && requestedDay != "Tr" &&
        requestedDay != "Ce" && requestedDay != "Pt" && requestedDay != "Se" &&
        requestedDay != "Sv") {
      throw invalid_argument("day incorrect");
    }

    for (const auto &route : validRoutes) {
      if (route.dayOfWeekString == requestedDay) {
        cout << route.firstStop << " " << route.lastStop << " "
             << route.dayOfWeekString << " " << route.time << " " << fixed
             << setprecision(2) << route.price << endl;
      }
    }
  } catch (...) {
    cout << "requested day not valid" << endl;
  }
}

// input price and print out routes cheaper than input price
void functionC(const vector<busRoute> &validRoutes) {
  string requestedPrice;
  cin >> requestedPrice;
  cout << "result:" << endl;

  try {
    for (const auto &route : validRoutes) {
      if (route.price < stod(requestedPrice)) {
        cout << route.firstStop << " " << route.lastStop << " "
             << route.dayOfWeekString << " " << route.time << " " << fixed
             << setprecision(2) << route.price << endl;
      }
    }
  } catch (...) {
    cout << "requested price invalid" << endl;
  }
}

// print out err.txt file
void functionD() {
  cout << "result:" << endl;

  ifstream errorFileStream("err.txt");

  string errorLine;
  while (getline(errorFileStream, errorLine)) {
    cout << errorLine << endl;
  }

  errorFileStream.close();
}

int main() {

  vector<busRoute> validRoutes;

  ifstream inputFileStream("db.csv");
  ofstream outputErrorFile("err.txt");

  string line;
  while (getline(inputFileStream, line)) {
    processLine(line, validRoutes, outputErrorFile);
  }

  inputFileStream.close();
  outputErrorFile.close();

  char choice = ' ';

  // infinite loop unless e pressed
  while (choice != 'e') {

    cin >> choice;

    switch (choice) {
    case 'a':
      functionA(validRoutes);
      break;
    case 'b':
      functionB(validRoutes);
      break;
    case 'c':
      functionC(validRoutes);
      break;
    case 'd':
      functionD();
      break;
    case 'e':
      break;
    default:
      cout << "error" << endl;
    }
  }

  return 0;
}