
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip> 

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

void processInputFile(const string& fileName, vector<BusRoute>& routes, ofstream& errorFile) {
    ifstream inFile(fileName);

    if (!inFile) {
        cerr << "Error opening file: " << fileName << endl;
        return;
    }

    string line;
    while (getline(inFile, line)) {
        if (line.empty()) {
            continue;
        }
        stringstream ss(line);
        string startStop, endStop, dayOfWeek, time, ticketPriceStr;
        getline(ss, startStop, ',');
        getline(ss, endStop, ',');
        getline(ss, dayOfWeek, ',');
        getline(ss, time, ',');
        getline(ss, ticketPriceStr, ',');

        startStop.erase(0, startStop.find_first_not_of(" \t"));
        startStop.erase(startStop.find_last_not_of(" \t") + 1);
        endStop.erase(0, endStop.find_first_not_of(" \t"));
        endStop.erase(endStop.find_last_not_of(" \t") + 1);
        dayOfWeek.erase(0, dayOfWeek.find_first_not_of(" \t"));
        dayOfWeek.erase(dayOfWeek.find_last_not_of(" \t") + 1);
        time.erase(0, time.find_first_not_of(" \t"));
        time.erase(time.find_last_not_of(" \t") + 1);
        ticketPriceStr.erase(0, ticketPriceStr.find_first_not_of(" \t"));
        ticketPriceStr.erase(ticketPriceStr.find_last_not_of(" \t") + 1);

        if (startStop.empty() || endStop.empty() || dayOfWeek.empty() || time.empty() || ticketPriceStr.empty()) {
            errorFile << line << endl;
            continue;
        }

        double ticketPrice;
        try {
            ticketPrice = stod(ticketPriceStr);
        } catch (const invalid_argument&) {
            errorFile << line << endl;
            continue;
        }

        routes.push_back({startStop, endStop, dayOfWeek, time, ticketPrice});
    }
}

void printRoutes(const vector<BusRoute>& routes) {
    for (const auto& route : routes) {
        cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " "
             << route.time << " " << route.ticketPrice << endl;
    }
}

void printErrorFile(const string& errorFileName) {
    ifstream errorFile(errorFileName);

    if (!errorFile) {
        cerr << "Error opening error file: " << errorFileName << endl;
        return;
    }

    string line;
    while (getline(errorFile, line)) {
        cout << line << endl;
    }
}

int main() {
    vector<BusRoute> routes;
    ofstream errorFile("err.txt");

    processInputFile("db.csv", routes, errorFile);

    char choice;
    while (true) {
        cout << "Enter command (a, b, c, d, e): ";
        cin >> choice;

        switch (choice) {


          case 'a': {
              string start, end;
              cout << "Enter start and end stops: ";
              cin >> start >> end;

              cout << "result:" << endl;
              for (const auto& route : routes) {
                  if (route.startStop == start && route.endStop == end) {
                      cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " "
                           << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                  }
              }
              break;
          }

          case 'b': {
              string day;
              cout << "Enter day of the week: ";
              cin >> day;

              cout << "result:" << endl;
              for (const auto& route : routes) {
                  size_t found = route.dayOfWeek.find(day);
                  if (found != string::npos) {
                      if ((found == 0 || !isalpha(route.dayOfWeek[found - 1])) &&
                          (found + day.length() == route.dayOfWeek.length() || !isalpha(route.dayOfWeek[found + day.length()]))) {
                          cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " "
                               << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                      }
                  }
              }
              break;
          }

          case 'c': {
              double maxPrice;
              cout << "Enter maximum ticket price: ";
              cin >> maxPrice;

              cout << "result:" << endl;
              for (const auto& route : routes) {
                  if (route.ticketPrice <= maxPrice) {
                      cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " "
                           << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                  }
              }
              break;
          }



            case 'd':
                cout << "result:" << endl;
                printErrorFile("err.txt");
                break;

            case 'e':
                return 0;

            default:
                cout << "Invalid command. Try again." << endl;
        }
    }

    return 0;
}