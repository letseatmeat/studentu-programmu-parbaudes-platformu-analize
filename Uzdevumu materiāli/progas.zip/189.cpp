
#include <iostream>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct AutobusuSaraksts {
  string sakPiet;
  string galPiet;
  string nedDien;
  string laiks;
  float cena;
};

void izfiltretajs(const string &filename, const int &option,
                              const string &var1, const string &var2){
  ofstream errFails("err.txt");
  string mazStart = var1;
  string mazDest = var2;
  string mazDay = var1;
  
  for (char &c : mazStart){
     c = tolower(c);
  }
  for (char &c : mazDest){
    c = tolower(c);
  }

  ifstream file(filename);
    if (file.is_open()){
    string rinda;
    while (getline(file, rinda)){
      stringstream linestream(rinda);
      string sakPiet, galPiet, nedDien, laiks;
      float cena;
      char limiteris =  ',';

      if (getline(linestream >> ws, sakPiet, limiteris) &&
          getline(linestream >> ws, galPiet, limiteris) &&
          getline(linestream >> ws, nedDien, limiteris) &&
          getline(linestream >> ws, laiks,limiteris)&&
          (linestream >> cena >> ws).eof()){

          sakPiet.erase(sakPiet.find_last_not_of(" \n\r\t") + 1);
          galPiet.erase(galPiet.find_last_not_of(" \n\r\t") + 1);
          nedDien.erase(nedDien.find_last_not_of(" \n\r\t") + 1);
          laiks.erase(laiks.find_last_not_of(" \n\r\t") + 1);

        string lowercaseSakPiet = sakPiet;
        string lowercaseGalPiet = galPiet;
        string lowercaseNedDien = nedDien;
        for (char &c : lowercaseSakPiet) {
          c = tolower(c);
        }
        for (char &c : lowercaseGalPiet) {
          c = tolower(c);
        }
        for (char &c : lowercaseNedDien) {
          c = tolower(c);
        }

        switch (option){
          
        case 1:
          if (lowercaseSakPiet == mazStart && lowercaseGalPiet == mazDest){
            cout << sakPiet << " " << galPiet << " " << nedDien << " "
                 << laiks << " " << std::fixed << std::setprecision(2)
                 << cena << '\n';
          }
          break;

        case 2:
          if (lowercaseNedDien == mazDay){
            cout << sakPiet << " " << galPiet << " " << nedDien << " "
                 << laiks << " " << std::fixed << std::setprecision(2)
                 << cena <<'\n';
          }
          break;

        case 3:
          float price = stof(var1);
          if (cena <= price){

            cout << sakPiet << " " << galPiet << " " << nedDien << " "
                 << laiks << " " << std::fixed << std::setprecision(2)
                 << cena << '\n';
            
            break;
          }
          
        }
      } else {
        if (!rinda.empty()){
            errFails << rinda << endl;
        }}
      
    }
    file.close();
  } else {
    cout << "Nevar atvert failu :(" << endl;
  }
}



int main() {
    char izvele;

    while (true){

        cin >> izvele;
          izvele = tolower(izvele);

        if (izvele == 'e'){
            cout << "Programma beidz darbibu" << endl;
            break;
        } 
          else if (izvele == 'a'){
            string starts, beigas;
            cout << "Ievadiet sakuma pieturas: ";
            cin >> starts;
            for (auto & c: starts) c =tolower(c);
            cout << "Ievadiet gala pieturas: ";
            cin >> beigas;
            for (auto & c: beigas) c = tolower(c);
            cout << "result:\n";
              izfiltretajs("db.csv", 1, starts, beigas);

        }  
        else if (izvele == 'b') {
            string diena;
             cout << "Ievadiet dienu: ";
             cin >> diena;
            for (auto & c: diena) c = tolower(c);
            cout << "result:\n";

              izfiltretajs("db.csv", 2, diena, "0");

        } else if (izvele == 'c'){
            string cena;
            cout << "Ievadiet biletes cenu: ";
            cin >> cena;
            for (auto & c: cena) c = tolower(c);
            cout << "result:\n";
              izfiltretajs("db.csv", 3, cena, "0");
        } 

            else if (izvele == 'd'){
            ifstream inputFile("err.txt", ios::in);
            if (!inputFile.is_open()){
                cerr << "Kluda - file error\n";
                return 1;
            }
            cout << "result:\n";
            string rinda1;
            while( getline(inputFile >> ws, rinda1)){
                if (!rinda1.empty()){
               cout << rinda1 << endl;
                }
            }
            inputFile.close();
        } 
            else{
            cout << "Nepareiza ievades komanda" << endl;
        }
    }
    return 0;
}