
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

// Function to parse a line from the CSV file into a BusRoute structure
BusRoute parseBusRoute(const string& line) {
    BusRoute route;
    stringstream ss(line);
    getline(ss, route.startStop, ',');
    getline(ss, route.endStop, ',');
    getline(ss, route.dayOfWeek, ',');
    getline(ss, route.time, ',');
    ss >> route.ticketPrice;
    return route;
}

// Function to print a BusRoute structure
void printBusRoute(const BusRoute& route) {
    cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " "
         << route.time << " " << route.ticketPrice << endl;
}

int main() {
    ifstream inFile("db.csv");

    if (!inFile) return 0;

    vector<BusRoute> routes;
    string line;

    while (getline(inFile, line)) {
        istringstream iss(line);

        // Skip empty lines
        if (line.empty()) continue;

        // Handle errors and write to err.txt
        try {
            BusRoute route = parseBusRoute(line);
            routes.push_back(route);
        } catch (const exception& e) {
            ofstream errFile("err.txt", ios::app);
            errFile << line << endl;
            errFile.close();
        }
    }

    char choice;
    while (true) {
        cout << "Enter command (a, b, c, d, e): ";
        cin >> choice;

        if (choice == 'e') break;

        cout << "result:" << endl;

        switch (choice) {
            case 'a': {
                string start, end;
                cout << "Enter start and end stops: ";
                cin >> start >> end;
                for (const auto& route : routes) {
                    if (route.startStop == start && route.endStop == end)
                        printBusRoute(route);
                }
                break;
            }
            case 'b': {
                string day;
                cout << "Enter day of the week: ";
                cin >> day;
                for (const auto& route : routes) {
                    if (route.dayOfWeek == day)
                        printBusRoute(route);
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cout << "Enter maximum ticket price: ";
                cin >> maxPrice;
                for (const auto& route : routes) {
                    if (route.ticketPrice <= maxPrice)
                        printBusRoute(route);
                }
                break;
            }
            case 'd': {
                ifstream errFile("err.txt");
                string errLine;
                while (getline(errFile, errLine))
                    cout << errLine << endl;
                errFile.close();
                break;
            }
            default:
                cout << "Invalid command. Please try again." << endl;
        }
    }

    return 0;
}
