
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

string trim(const string& s) {
    size_t start = s.find_first_not_of(" \t");
    size_t end = s.find_last_not_of(" \t");
    return (start == string::npos || end == string::npos) ? "" : s.substr(start, end - start + 1);
}

vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    stringstream ss(s);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(trim(token));
    }
    return tokens;
}

int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");

    if (!inFile || !errFile) {
        cerr << "Error opening files." << endl;
        return 1;
    }

    vector<vector<string>> routes;
    string line;
    while (getline(inFile, line)) {
        vector<string> fields = split(line, ',');

        if (fields.size() != 5) {
            errFile << "Invalid data: " << line << endl;
            continue;
        }

        routes.push_back(fields);
    }

    char choice;
    do {
        cout << "Enter choice (a, b, c, d, e): ";
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cout << "Enter start and end stations: ";
                cin.ignore();
                getline(cin, start);
                getline(cin, end);

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route[0] == start && route[1] == end) {
                        for (const auto& field : route) {
                            cout << field << " ";
                        }
                        cout << endl;
                    }
                }
                break;
            }
            case 'b': {
                string day;
                cout << "Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                cin >> day;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route[2] == day) {
                        for (const auto& field : route) {
                            cout << field << " ";
                        }
                        cout << endl;
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cout << "Enter maximum ticket price: ";
                cin >> maxPrice;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    try {
                        double price = stod(route[4]);
                        if (price <= maxPrice) {
                            for (const auto& field : route) {
                                cout << field << " ";
                            }
                            cout << endl;
                        }
                    } catch (const std::exception& e) {
                    }
                }
                break;
            }
            case 'd': {
                ifstream errFileRead("err.txt");
                if (errFileRead) {
                    cout << "result:" << endl;
                    string errorLine;
                    while (getline(errFileRead, errorLine)) {
                        cout << errorLine << endl;
                    }
                }
                break;
            }
            case 'e':
                break;
            default:
                cout << "Invalid choice. Try again." << endl;
        }

    } while (choice != 'e');

    return 0;
}
