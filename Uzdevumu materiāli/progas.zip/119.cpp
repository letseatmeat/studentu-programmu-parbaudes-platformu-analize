#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
#include <cstring>

using namespace std;

struct Route {
  string startStop;
  string finalStop;
  string day;
  string time;
  double price;
};
bool in_array(const std::string &value, const std::vector<std::string> &array) {
  return std::find(array.begin(), array.end(), value) != array.end();
}

vector<string> splitString(const string &str, char delimiter) {
  stringstream ss(str);
  string item;
  vector<string> tokens;
  while (getline(ss, item, delimiter)) {
    tokens.push_back(item);
  }
  return tokens;
}
bool has_only_spaces(std::string& str)
{
    char* token = strtok(const_cast<char*>(str.c_str()), " ");

    while (token != NULL)
    {   
        if (*token != ' ')
        {   
            return true;
        }   
    }   
    return false;
}

string trimString(string str) {
  std::string::iterator end_pos = std::remove(str.begin(), str.end(), ' ');
  str.erase(end_pos, str.end());
  return str;
}

bool isFloat(const string &str) {
  istringstream iss(str);
  float f;
  iss >> noskipws >> f;
  return iss.eof() && !iss.fail();
}

vector<Route> readCSV(const string &filePath) {
  ifstream inFile(filePath);
  vector<Route> routes;
  string line;

  ofstream errFile("err.txt");

  while (getline(inFile, line)) {
    if(line.empty())continue;
    line = trimString(line);
    // cout << line << endl;
    std::vector<std::string> cities = {"Riga",     "Jelgava", "Daugavpils",
                                       "Liepaja", "Ventspils",
                                       "Kraslava", "Dagda",   "Rezekne"};
    std::vector<std::string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

    auto tokens = splitString(line, ',');
    if (tokens.size() != 5) {
      errFile << line << endl;
      continue;
    }
    if (!in_array(tokens[0], cities)) {
      errFile << line << endl;
      continue;
    }
    if (!in_array(tokens[1], cities)) {
      errFile << line << endl;
      continue;
    }
    if (!in_array(tokens[2], days)) {
      errFile << line << endl;
      continue;
    }

    Route route;
    route.startStop = tokens[0];
    route.finalStop = tokens[1];
    route.day = tokens[2];
    route.time = tokens[3];
    route.price = stof(tokens[4]);
    routes.push_back(route);
  }

  errFile.close();
  return routes;
}

void queryA(const vector<Route> &routes) {
  string start, end;
  // cout << "Enter start and end stops: ";
  cin >> start >> end;

  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.startStop == start && route.finalStop == end) {
      cout << route.startStop << " " << route.finalStop << " " << route.day
           << " " << route.time << " " << route.price << endl;
    }
  }
}

void queryB(const vector<Route> &routes) {
  string day;
  // cout << "Enter day of the week: ";
  cin >> day;

  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.day == day) {
      cout << route.startStop << " " << route.finalStop << " " << route.day
           << " " << route.time << " " << route.price << endl;
    }
  }
}

void queryC(const vector<Route> &routes) {
  float price;
  // cout << "Enter maximum ticket price: ";
  cin >> price;

  cout << "result:" << endl;
  for (Route route : routes) {
    if (route.price <= price) {
      cout << route.startStop << " " << route.finalStop << " " << route.day
           << " " << route.time << " " << route.price << endl;
    }
  }
}

void queryD() {
  ifstream errFile("err.txt");
  string line;
  cout << "result:" << endl;
  while (getline(errFile, line)) {
    if(line.find_first_not_of(' ') != std::string::npos)
    {
      cout << line << endl;
    }
  }
}

int main() {
  vector<Route> routes = readCSV("db.csv");

  char command;
  cout << fixed << setprecision(2);
  // for (Route r : routes) {
  //   cout << r.startStop << " " << r.finalStop << " " << r.day << " " << r.time
  //        << " " << r.price << endl;
  // }
  do {
    // cout << "Enter command (a, b, c, d, e): ";
    cin >> command;
    switch (command) {
    case 'a':
      queryA(routes);
      break;
    case 'b':
      queryB(routes);
      break;
    case 'c':
      queryC(routes);
      break;
    case 'd':
      queryD();
      break;
    }
  } while (command != 'e');

  return 0;
}