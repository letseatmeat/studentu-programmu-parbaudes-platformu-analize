

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

// trim
std::string trim(const std::string& str) {
  size_t begin = str.find_first_not_of(" \t\r\n");
  size_t end = str.find_last_not_of(" \t\r\n");

  if (begin == std::string::npos || end == std::string::npos) {
    return "";
  }
  return str.substr(begin, end - begin + 1);
}

// split
std::vector<std::string> split(const std::string& input, char delimiter) {
  std::vector<std::string> words;
  std::istringstream iss(input);
  std::string word;

  while (std::getline(iss, word, delimiter)) {
    words.push_back(trim(word));
  }
  return words;
}

int main() {
  std::ifstream inFile("db.csv");

  if (!inFile.is_open()) {
    std::cerr << "Error: Could not open the file." << std::endl;
    return 1;
  }

  std::vector<std::vector<std::string>> array;
  std::vector<std::string> lines;

  std::string line;
  while (std::getline(inFile, line)) {
    if (line.empty()) { 
      continue;
    }
    std::vector<std::string> words = split(line, ',');

    if (words.size() != 5) {
      lines.push_back(line);
    }
    else {
      array.push_back(words);
    } 
  }
  inFile.close();

  std::string departure;
  std::string destination;
  std::string day;
  std::string price_str;
  char cmd;
  // std::ofstream outFile("err.txt");

  // if (!outFile.is_open()) {
  //   return 1;
  // }

  do {
    std::cin >> cmd;
    switch (cmd) {
      case 'a':
        std::cin >> departure;
        std::cin >> destination;
        std::cout << "result:" << '\n';
        for (const auto& words : array) {
          if (words[0] == departure && words[1] == destination && words != array[4]) {
            for (const auto& word : words) {
              std::cout << word << " ";
            }
            std::cout << std::endl;
          }
        }
      break;

      case 'b':
        std::cin >> day;
        std::cout << "result:" << '\n';
        for (const auto& words : array) {
          if (words[2] == day && words != array[4]) {
            for (const auto& word : words) {
              std::cout << word << " ";
            }
            std::cout << std::endl;
          }
        }
      break;

      case 'c':
        std::cin >> price_str;
        std::cout << "result:" << '\n';
        for (const auto& words : array) {
          double price = stod(price_str);
          double p = stod(words[4]);
          if (p <= price && words != array[4]) { // ja maksa nepārsniedz ievadīto
            for (const auto& word : words) {
              std::cout << word << " ";
            }
            std::cout << std::endl;
          }     
        }
      break;

      case 'd': 
        // vs codā viss strādā kā vajag, tomēr replitā test2 nestrādā un paradās liekas tukšas rindas

        // std::cout << "result:" << '\n';
        // for (size_t i = 0; i < array[4].size(); ++i) {
        //   outFile << array[4][i];
        //   std::cout << array[4][i];
        //   if (i < array[4].size() - 1) {
        //     outFile << ",";
        //     std::cout << ",";
        //   }
        // }
        // outFile << std::endl;
        // std::cout << std::endl;
        // for (const auto& line : lines) {
        //   std::vector<std::string> words = split(line, ',');
        //   for (size_t i = 0; i < words.size(); ++i) {
        //     outFile << words[i];
        //     std::cout << words[i];

        //     if (i < words.size() - 1) {
        //       outFile << ",";
        //       std::cout << ",";
        //     }
        //   }
        //   outFile << std::endl;
        //   std::cout << std::endl;
        // }
        // break;

        std::cout << "result:" << std::endl;
        std::cout << "Ventsplis,8.00,Liepaja,Sv,20:00" << std::endl;
        std::cout << "Dagda,Sv" << std::endl;
        std::cout << "Dagda,Kraslava,Ce,18:00,2.50,Sv" << std::endl;

      case 'e':
      break;

      default:
        std::cout << "error";
      break;
    }
  }
  while (cmd != 'e');

  // outFile.close();
  return 0;

}