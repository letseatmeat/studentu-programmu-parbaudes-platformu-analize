

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

bool validTime(const string& time) {
  return (time.size() == 5 && isdigit(time[0]) && isdigit(time[1]) && time[2] == ':' && isdigit(time[3]) && isdigit(time[4]));
}

bool validPrice(const string& price) {
  return (price.size() > 2 && price[price.size() - 3] == '.' && isdigit(price[price.size() - 2]) && isdigit(price[price.size() - 1]));
}

bool validDay(const string& day) {
  return (day.size() == 2 && isalpha(day[0]) && isalpha(day[1]));
}

bool validLine(const vector<string>& fields) {
  if (fields.size() != 5) return false;
  if (!validTime(fields[3])) return false;
  if (!validPrice(fields[4])) return false;
  if (!validDay(fields[2])) return false;
  return true;
}

int main() {
  ifstream inFile("db.csv");
  ofstream outFile("err.txt");

  if (!inFile || !outFile) {
    return 1;
  }

  string line;
  while (getline(inFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

    stringstream ss(line);
    vector<string> fields;
    string field;

    while (getline(ss, field, ',')) {
      fields.push_back(field);
    }

    if (validLine(fields)) {

    } else {
      if (!line.empty()) {
        outFile << line << endl;
      }
    }
  }

  inFile.close();
  outFile.close();

  char command;
  ifstream errFile;
  while (true) {
    cin >> command;

    switch (command) {
      case 'a': {
        string start, end;
        cin >> start >> end;

        ifstream inFile("db.csv");
        bool found = false;

        cout << "result:" << endl;
        while (getline(inFile, line)) {
          line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
          
          stringstream ss(line);
          vector<string> fields;
          string field;

          while (getline(ss, field, ',')) {
            fields.push_back(field);
          }

          if (fields.size() == 5 && fields[0] == start && fields[1] == end) {
            cout << line << endl;
            found = true;
          }
        }
        inFile.close();

        break;
      }
      
      case 'b': {
        string day;
        cin >> day;

        ifstream inFile("db.csv");
        bool found = false;

        cout << "result:" << endl;
        while (getline(inFile, line)) {
          line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

          stringstream ss(line);
          vector<string> fields;
          string field;

          while (getline(ss, field, ',')) {
            fields.push_back(field);
          }

          if (fields.size() == 5 && fields[2] == day) {
            cout << line << endl;
            found = true;
          }
        }
        inFile.close();
        break;
      }

      case 'c': {
        double maxPrice;
        cin >> maxPrice;
        
        ifstream inFile("db.csv");
        bool found = false;

        cout << "result:" << endl;
        while (getline(inFile, line)) {
          line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

          stringstream ss(line);
          vector<string> fields;
          string field;

          while (getline(ss, field, ',')) {
            fields.push_back(field);
          }

          if (validLine(fields)) {
            double price = stod(fields[4]);
            if (price <= maxPrice) {
              cout << line << endl;
              found = true;
            }
          }
        }
        inFile.close();
        break;
      }

      case 'd':
        errFile.open("err.txt");
        cout << "result:" << endl;
        while (getline(errFile, line)) {
          cout << line << endl;
        }
        errFile.close();
        break;

      case 'e':
        return 0;

      default:
        cout << "Error" << endl;
    }
  }
  
  return 0;
}
