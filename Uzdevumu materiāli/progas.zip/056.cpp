

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <regex>

using namespace std;

struct AutobusaMarsruts {
    string sakumaPietura;
    string galaPietura;
    string nedelasDiena;
    string laiks;
    double billetesCena;
};

string saglabatNepieciesamosSimbolus(string str) {
    string result;
    size_t i = 0;

    while (i < str.size()) {
        char c = str[i];
        if (c != ' ' && c != '\n' && c != '\t' && c != '\r') {
            result += c;
        }
        i++;
    }

    return result;
}

vector<AutobusaMarsruts> readMarsruti(const string &filename) {
    vector<AutobusaMarsruts> marsruti;
    ifstream file(filename);

    if (!file.is_open())
        return marsruti;

    string line, err = "result:\n";
    regex laiks_format("^\\d{2}:\\d{2}$");

    for (; getline(file, line);) {
        string filteredLine = saglabatNepieciesamosSimbolus(line);
        istringstream ss(filteredLine);
        vector<string> fields;
        string field;
        for (; getline(ss, field, ',');) {
            fields.push_back(field);
        }
    AutobusaMarsruts marsruts;
    if (fields.size() == 5 && regex_match(fields[3], laiks_format)) {
        marsruts.sakumaPietura = fields[0];
        marsruts.galaPietura = fields[1];
        marsruts.nedelasDiena = fields[2];
        marsruts.laiks = fields[3];

        // Pārbaude un apstrāde, ja billetesCena nav derīgs double
        if (istringstream(fields[4]) >> marsruts.billetesCena) {
            marsruti.push_back(marsruts);
        } else {
            // Apstrāde gadījumam, ja billetesCena nav derīgs double
            continue;
        }
    } else {
        if (!field.empty())
            err += line + "\n";
    }
  }

    ofstream err_file("err.txt");
    err.erase(err.find_last_not_of("\n") + 1);
    err_file << err;
    err_file.close();

    return marsruti;
}

void printMarsruti(const vector<AutobusaMarsruts> &marsruti) {
    cout << "result:" << endl;
    for (const auto &marsruts : marsruti) {
        cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " " << marsruts.nedelasDiena << " "
             << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.billetesCena
             << endl;
    }
}

int main() {
    vector<AutobusaMarsruts> visiMarsruti = readMarsruti("db.csv");

    ifstream inputFile("db.csv");
    if (!inputFile.is_open()) {
        cout << "Nevar atvērt datu failu!" << endl;
        return 1;
    }

    char choice;
    do {
        cin >> choice;

        switch (choice) {
        case 'a': {
            string sakumaPietura, galaPietura;
            cout << "";
            cin >> sakumaPietura;

            cout << "";
            cin >> galaPietura;

            vector<AutobusaMarsruts> atlasitieMarsruti;
            for (const auto &marsruts : visiMarsruti) {
                if (marsruts.sakumaPietura == sakumaPietura && marsruts.galaPietura == galaPietura) {
                    atlasitieMarsruti.push_back(marsruts);
                }
            }

            if (atlasitieMarsruti.empty()) {
                cout << "" << endl;
            } else {
                printMarsruti(atlasitieMarsruti);
            }
            break;
        }
        case 'b': {
            string nedelasDiena;
            cout << "";
            cin >> nedelasDiena;

            vector<AutobusaMarsruts> atlasitieMarsruti;
            for (const auto &marsruts : visiMarsruti) {
                if (marsruts.nedelasDiena == nedelasDiena) {
                    atlasitieMarsruti.push_back(marsruts);
                }
            }

            if (atlasitieMarsruti.empty()) {
                cout << "" << endl;
            } else {
                printMarsruti(atlasitieMarsruti);
            }
            break;
        }
        case 'c': {
            double max_billetesCena;
            cout << "";
            cin >> max_billetesCena;

            vector<AutobusaMarsruts> atlasitieMarsruti;
            for (const auto &marsruts : visiMarsruti) {
                if (marsruts.billetesCena <= max_billetesCena) {
                    atlasitieMarsruti.push_back(marsruts);
                }
            }

            if (atlasitieMarsruti.empty()) {
                cout << "" << endl;
            } else {
                printMarsruti(atlasitieMarsruti);
            }
            break;
        }
        case 'd': {
            ifstream errFile("err.txt");
            if (errFile.is_open()) {
                string errLine;
                while (getline(errFile, errLine)) {
                    cout << errLine << endl;
                }
                errFile.close();
            } else {
                cout << "err.txt fails nav atrasts vai nevar tikt atvērts." << endl;
            }
            break;
        }
        default:
            break;
        }
    } while (choice != 'e');

    return 0;
}
