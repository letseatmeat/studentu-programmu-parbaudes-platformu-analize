
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

vector<vector<string>> makeDataVector();
void makeErrTxt(vector<string> errorRows);
bool isCorrectRow(vector<string> row);
bool areStringsEqual(string vectorCity, string userCity);
void print(vector<vector<string>> flightsOnRoute);
string changeCase(string city);
bool isWord(string field);
bool isPrice(string field);
bool isTime(string field);
void displayedFlightsOnDayOfWeek(vector<vector<string>> data);
void displayedFlightsOnRoute(vector<vector<string>> data);
void displayedAffordableFlights(vector<vector<string>> data);
void displayedErrTxt(vector<vector<string>> data);

int main() {
  vector<vector<string>> data = makeDataVector();
  char choice;
  while (true) {
    cin >> choice;
    switch (choice) {
    case 'a':
      displayedFlightsOnRoute(data);
      break;
    case 'b':
      displayedFlightsOnDayOfWeek(data);
      break;
    case 'c':
      displayedAffordableFlights(data);
      break;
    case 'd':
      displayedErrTxt(data);
      break;
    case 'e':
      return 0;
    default:
      cout << "wrong command" << endl;
    }
  }
  return 0;
}

void print(vector<vector<string>> data) {
  for (vector<string> flightDataVector : data) {
    for (string field : flightDataVector) {
      cout << field << " ";
    }
    cout << endl;
  }
  return;
}

void displayedErrTxt(vector<vector<string>> data) {
  cout << "result:" << endl;
  ifstream inputFile("err.txt");
  if (!inputFile) {
    cerr << "Cant open file" << endl;
    return;
  }
  string line;
  while (getline(inputFile, line)) {
    cout << line << endl;
  }
  inputFile.close();

  return;
}

void displayedAffordableFlights(vector<vector<string>> data) {
  vector<vector<string>> affordableFlights;
  vector<string> flightDataVector;
  string price;
  while (true) {
    cin >> price;
    if (isPrice(price)) {
      break;
    }
  }
  cout << "result:" << endl;

  for (int i = 0; i < data.size(); i++) {
    flightDataVector = data[i];
    if (stod(flightDataVector[4]) <= stod(price)) {
      affordableFlights.push_back(flightDataVector);
    }
  }
  print(affordableFlights);
  return;
}

void displayedFlightsOnDayOfWeek(vector<vector<string>> data) {
  vector<vector<string>> flightsOnDayOfWeek;
  vector<string> flightDataVector;
  string dayOfWeek;

  while (true) {
    cin >> dayOfWeek;
    if (isWord(dayOfWeek) && (dayOfWeek.size() == 2)) {
      break;
    }
  }
  cout << "result:" << endl;

  for (int i = 0; i < data.size(); i++) {
    flightDataVector = data[i];
    if (areStringsEqual(flightDataVector[2], dayOfWeek)) {
      flightsOnDayOfWeek.push_back(flightDataVector);
    }
  }
  print(flightsOnDayOfWeek);
  return;
}

void displayedFlightsOnRoute(vector<vector<string>> data) {
  vector<vector<string>> flightsOnRoute;
  vector<string> flightDataVector;
  string firstCity;
  string secondCity;
  while (true) {
    cin >> firstCity;
    if (isWord(firstCity)) {
      break;
    }
  }
  while (true) {
    cin >> secondCity;
    if (isWord(secondCity)) {
      break;
    }
  }
  cout << "result:" << endl;

  for (int i = 0; i < data.size(); i++) {
    flightDataVector = data[i];
    if (areStringsEqual(flightDataVector[0], firstCity)) {
      if (areStringsEqual(flightDataVector[1], secondCity)) {
        flightsOnRoute.push_back(flightDataVector);
      }
    }
  }
  print(flightsOnRoute);
  return;
}

bool areStringsEqual(string firstString, string SecondString) {
  return changeCase(firstString) == changeCase(SecondString);
}

string changeCase(string city) {
  for (char &c : city) {
    c = toupper(c);
  }
  return city;
}

vector<vector<string>> makeDataVector() {
  vector<vector<string>> data;
  vector<string> errorRows;
  vector<string> row;
  ifstream inFile;
  inFile.open("db.csv");

  string s;
  while (getline(inFile, s)) {
    s.erase(remove(s.begin(), s.end(), ' '), s.end());
    if (s.empty()) {
      continue;
    }

    istringstream iss(s);

    string field;
    while (getline(iss, field, ',')) {
      row.push_back(field);
    }

    if (isCorrectRow(row)) {
      data.push_back(row);
    } else {
      errorRows.push_back(s);
    }
    row.clear();
  }
  inFile.close();
  makeErrTxt(errorRows);
  return data;
}

bool isWord(string field) {
  for (char c : field) {
    if (isdigit(c)) {
      return false;
    }
  }
  return true;
}

bool isTime(string field) {
  if (field.size() != 5) {
    return false;
  }
  if (!(isdigit(field[0]) && isdigit(field[1]) && field[2] == ':' &&
        isdigit(field[3]) && isdigit(field[4]))) {
    return false;
  }
  int hh = stod(field.substr(0, 2));
  int mm = stod(field.substr(3, 2));
  if (!(hh < 24 && hh >= 0 && mm >= 0 && mm < 60)) {
    return false;
  }
  return true;
}

bool isPrice(string field) {
  try {
    stod(field);
    return true;
  } catch (const invalid_argument &) {
    return false;
  } catch (const out_of_range &) {
    return false;
  }
}

bool isCorrectRow(vector<string> row) {
  if (row.size() != 5) {
    return false;
  }

  for (int i = 0; i < 3; i++) {
    if (!isWord(row[i])) {
      return false;
    }
  }

  if (!isTime(row[3])) {
    return false;
  }

  if (!isPrice(row[4])) {
    return false;
  }

  return true;
}

void makeErrTxt(vector<string> errorRows) {
  ofstream outputFile("err.txt");
  if (!outputFile) {
    cerr << "Cant open file" << endl;
    return;
  }
  for (string value : errorRows) {
    outputFile << value << endl;
  }
  outputFile.close();
}
