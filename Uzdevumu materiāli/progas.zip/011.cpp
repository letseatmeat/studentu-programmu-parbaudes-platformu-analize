#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>
#include <vector>
using namespace std;

struct Route {
    string start, finish, day, time, price;
};

bool isValid(const string& line, Route& elements) {
    string formattedLine = regex_replace(line, regex("\\s+"), "");
    istringstream iss(formattedLine);

    if (getline(iss, elements.start, ',') && getline(iss, elements.finish, ',') && getline(iss, elements.day, ',') && getline(iss, elements.time, ',') && iss >> elements.price) {
        if (elements.start.size() > 0 && elements.finish.size() > 0 && elements.day.size() == 2 && regex_match(elements.time, regex("\\b([01]?[0-9]|2[0-3]):[0-5][0-9]\\b")) && regex_match(elements.price, regex("\\d+\\.\\d{2}"))) {
            return true;
        }
    }
    return false;
}
void command_a(const vector<Route>& validLines){
  string start, finish;
  cin >> start;
  cin >> finish;
  cout << "result:" << endl;
  for (const auto& line : validLines) {
    if (line.start == start && line.finish == finish) {
      cout << line.start << " " << line.finish << " " << line.day << " " << line.time << " " << line.price << endl;
    }
  }
}
void command_b(const vector<Route>& validLines){
  string day;
  cin >> day;
  cout << "result:" << endl;
  for (const auto& line : validLines) {
    if (line.day == day) {
      cout << line.start << " " << line.finish << " " << line.day << " " << line.time << " " << line.price << endl;
    }
  }
}
void command_c(const vector<Route>& validLines){
  double price;
  cin >> price;
    cout << "result:" << endl;
    for (const auto& line : validLines) {
      if (stod(line.price) < price) {
        cout << line.start << " " << line.finish << " " << line.day << " " << line.time << " " << line.price << endl;
      }
    } 
}
void command_d(){
  ifstream errFile;
  errFile.open("err.txt");
  string line; 
  while (errFile >> line)
  {
    cout << line << endl;
  }
  errFile.close();
}
int main() {
    ifstream inFile;
    inFile.open("db.csv");
    ofstream errFile("err.txt");

    if (!inFile) {
        return 0;
    }

    string line;
    vector<Route> validLines;
      while (getline(inFile, line)) {
      if (line.find_first_not_of(' ') == string::npos || line.find_first_not_of(',') == string::npos) {
          continue;
      }
        Route currentLine;
        if (isValid(line, currentLine)) {
            validLines.push_back(currentLine);
        } 
        else {
            errFile << line << endl;
        }
    }

    inFile.close();
    errFile.close();
    string command;
      do {
      cin >> command;
      switch (command[0]) {
          case 'a':
              command_a(validLines);
              break;
          case 'b':
              command_b(validLines);
              break;
          case 'c':
              command_c(validLines);
              break;
          case 'd':
              cout << "result:" << endl;
              command_d();
              break;
          case 'e':
              break;
          default:
              break;
        }
      } while (command != "e");
    return 0;
}