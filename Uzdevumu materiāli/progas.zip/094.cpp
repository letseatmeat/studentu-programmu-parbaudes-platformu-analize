
#include <iostream>
#include <fstream>
#include <limits>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Saraksts{
  string start;
  string end;
  string day;
  string time;
  double price;
};

void RouteSearch(const vector<Saraksts>& saraksts) {
  string start, end;
  int resultcheck = 1;
  cin >> start;
  cin >> end;
  for (auto c:saraksts) {
    if (c.start == start && c.end == end) {
      if (resultcheck==1) {
        cout << "result:" << endl;
        resultcheck=0;
      }
      cout << c.start << " " << c.end << " " << c.day << " " << c.time << " " << fixed << setprecision(2) << c.price << endl;
    }
  }
}
void DaySearch(const vector<Saraksts>& saraksts) {
  string day;
  int resultcheck = 1;
  cin >> day;
  for (auto c:saraksts) {
    if (c.day == day) {
      if (resultcheck==1) {
        cout << "result:" << endl;
        resultcheck=0;
      }
      cout << c.start << " " << c.end << " " << c.day << " " << c.time << " " << fixed << setprecision(2) << c.price << endl;
    }
  }
}
void PriceSearch(const vector<Saraksts>& saraksts) {
  double price;
  int resultcheck = 1;
  cin >> price;
  for (auto c:saraksts) {
    if (c.price < price) {
      if (resultcheck==1) {
        cout << "result:" << endl;
        resultcheck=0;
      }
      cout << c.start << " " << c.end << " " << c.day << " " << c.time << " " << fixed << setprecision(2) << c.price << endl;
    }
  }
}

void PrintErr() {
  ifstream outFile;
  outFile.open("err.txt");
  if (!outFile) {
    return;
  }
  string s;
  cout << "result:\n";
  while (outFile >> s) {
    cout << s << endl;
  }
  outFile.close();
}

int main() {
  
  vector<Saraksts>saraksts;
  ifstream inFile;
  inFile.open("db.csv");
	if (!inFile) {
    return 0;
  }
  string s;
  ofstream outFile("err.txt");
  while (getline(inFile,s)) {
    istringstream ss(s);
    string cut;
    vector<string>row;
    while (getline(ss, cut, ',')) {
      cut.erase(remove(cut.begin(),cut.end(),' '), cut.end());
      row.push_back(cut);
    }
   
    if (row.size()!=5||row[2].length()!=2||row[3].length()!=5) {
      if (s.length()>2) {
      outFile << s << endl;
      }
      continue;
    }
    Saraksts sar;
    try {
      sar.price = stod(row[4]);
    }
    catch (invalid_argument&e) {
      outFile << s << endl;
      continue;
    }
    try {
      sar.price = stod(row[4]);
    }
    catch (out_of_range&e){
      outFile << s << endl;
      continue;
    }
    sar.start = row[0];
    sar.end = row[1];
    sar.day = row[2];
    sar.time = row[3];
    sar.price = stod(row[4]);
    saraksts.push_back(sar);
  }
  outFile.close();
  inFile.close();

  char choice;
  while (true) {
    cin >> choice;
    if(cin.fail() || cin.peek()!= '\n') {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(),'\n');
      continue;
    }
    switch(choice) {
      case 'a':
        RouteSearch(saraksts);
        break;
      case 'b':
        DaySearch(saraksts);
        break;
      case 'c':
        PriceSearch(saraksts);
        break;
      case 'd':
        PrintErr();
        break;
      case 'e':
        return 0;
      default:
        break;
    }
  }
} 