

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>


using namespace std;

struct Data {
  string from;
  string to;
  string day;
  string time;
  double price;
};

void printFromTo(const vector<Data> &data) {
  string townFrom;
  string townTo;

  cin >> townFrom;
  cin >> townTo;

  cout << "result:" << endl;
  for (int i = 0; i < data.size(); i++) {
    if (townFrom == data[i].from && townTo == data[i].to) {
      cout << data[i].from << " " << data[i].to << " " << data[i].day << " " << data[i].time << " " << setprecision(2) << fixed << data[i].price << endl;
    }
  }
}

void printDay(const vector<Data> &data) {
  string day;

  cin >> day;
  
  cout << "result:" << endl;
  for (int i = 0; i < data.size(); i++) {
    if (day == data[i].day) {
      cout << data[i].from << " " << data[i].to << " " << data[i].day << " " << data[i].time << " " << setprecision(2) << fixed << data[i].price << endl;
    }
  }
}

void printPrice(const vector<Data> &data) {
  double price;

  cin >> price;

  cout << "result:" << endl;
  for (int i = 0; i < data.size(); i++) {
    if (data[i].price <= price) {
      cout << data[i].from << " " << data[i].to << " " << data[i].day << " " << data[i].time << " " << setprecision(2) << fixed << data[i].price << endl;
    }
  }
}

void printErr(const vector<string>& errLines) {
    cout << "result:" << endl;
    for (const auto& line : errLines) {
        cout << line << endl;
    }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  ofstream outFile("err.txt");
  
  string line;
  int i = 0;
  int resSize = 0;
  vector<Data> dataVector;
  vector<string> elements;
  vector<string> lines;
  vector<vector<string>> resEl;
  vector<string> errLines;

  while (getline(inFile, line, '\r')) {
    line.erase(remove(line.begin(), line.end(), ' '), line.end());
    line.erase(remove(line.begin(), line.end(), '\n'), line.end());
    if (!line.empty()) {
        lines.push_back(line);
        resSize++;
    }
  }

  inFile.clear();

  Data currentData;
  for (int i = 0; i < resSize; i++) {
    stringstream lineStream(lines[i]);
    string temp;
    elements.clear();

    while (getline(lineStream, temp, ',')) {
      elements.push_back(temp);
    }
    resEl.push_back(elements);
    
    if (elements.size() != 5) {
        errLines.push_back(lines[i]);
        outFile << lines[i] << endl;
        continue;
    }

    currentData.from = resEl[i][0];
    currentData.to = resEl[i][1];
    currentData.day = resEl[i][2];
    currentData.time = resEl[i][3];
    currentData.price = stod(resEl[i][4]);

    if (!(isdigit(currentData.time[0]) && isdigit(currentData.time[1]) &&
          currentData.time[2] == ':' && isdigit(currentData.time[3]) &&
          isdigit(currentData.time[4]))) {
      
      outFile << lines[i] << endl;
      errLines.push_back(lines[i]);
      continue;
    } else {
      dataVector.push_back(currentData);
    }
  }
  resEl.clear();
  lines.clear();

  string choice;
  while(true){
    cin >> choice;
    switch (choice[0]) {
      case 'a':
        printFromTo(dataVector);
        break;
      case 'b':
        printDay(dataVector);
        break;
      case 'c':
        printPrice(dataVector);
        break;
      case 'd':
        printErr(errLines);
      break;
      case 'e':
       return 0;
      default:
        cout << "error";
    }
  }
}