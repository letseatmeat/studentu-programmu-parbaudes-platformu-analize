
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <cctype>
#include <algorithm>

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string weekday;
    string time;
    double ticketPrice;
};

string trim(const string& s) {    //Izgriež atstarpes
    size_t sak = s.find_first_not_of(" \t");
    size_t beig = s.find_last_not_of(" \t");

    const size_t neatr = string::size_type(-1);

    if (sak == neatr || beig == neatr) {
        return ""; //gadījums, ja nekā nav
    }

    return s.substr(sak, beig - sak + 1);  //Argriež smuku string
}


BusRoute readBusRoute(const string& line) {
    if (count(line.begin(), line.end(), ',') != 4) { //Pārbauda vai ir 4 ,
        return BusRoute();  // 
    }
  
    istringstream iss(line);
    BusRoute route;
    string t;

    for (int i = 0; getline(iss, t, ',') && i < 5; ++i) {
        t = trim(t);
        switch (i) {
            case 0:   //Pirmais v
                route.startStop = t;
                break;
            case 1:   //Ptraos v
                route.endStop =t;
                break;
            case 2:
                // Pārbauda vai ir trešajā daļa diena ierakstīta
                if (t == "Pr" || t == "Ot" || t == "Tr" ||
                    t == "Ce" || t == "Pt" || t == "St" ||
                    t == "Sv") {
                    route.weekday =t;
                } else {
                    return BusRoute();   //neparezs
                }
                break;
          
            case 3:
                // Pārbauda laika noformējumu. respektīvi, vai ir 4 tēli un vai ir : kkur
                if (t.size() != 5 || t[2] != ':') {
                    return BusRoute();  //neparezs
                }
                route.time = t;
                break;
            case 4:
              
              //pārbauda vai ir punkts un aiz tā 2 cipari
                if (t.find('.') != string::npos) {
                  size_t punkts = t.find('.');
                  size_t cippecpunkts = t.size() - punkts - 1;

                  if (cippecpunkts == 2) {
                      route.ticketPrice = stod(t);
                  } else {
    
                      return BusRoute();  //nepareizs
                  }
                } else {
                  
                  return BusRoute(); 
                  //nepareizs
                }
                break;
            default:
                // Ignore other cases
                break;
        }
    }

    //Pārbauda vai ir visi nepieciešamie sektori
    if (route.startStop.empty() || route.endStop.empty() || route.weekday.empty() || route.time.empty()) {
        return BusRoute(); 
    }
    return route;
}

bool validateEntry(const BusRoute& route) {
    return !(route.startStop.empty() ||  route.weekday.empty() || route.endStop.empty()|| route.time.empty());
}

void printRoute(const BusRoute& route) {
    cout << route.startStop << " " << route.endStop << " " << route.weekday << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
}

int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");
    vector<BusRoute> valid;

    string line;
    while (getline(inFile, line)) {
        if (line.empty()) {
            continue;
        }

        BusRoute route = readBusRoute(line);

        if (!validateEntry(route)) {
            errFile << line <<endl;  // Izraksta tikai nepareizos error failā
        } else {
          valid.push_back(route);
        }
    }

    char choice;
    do {
        cin >>choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start;
                cin >> end;

                cout << "result:" <<endl;
                for (const auto& route : valid) {
                    if (route.startStop == start && route.endStop == end) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'b': {
                string day;
                cin >> day;

                cout <<"result:" << endl;
                for (const auto& route : valid) {
                    if (route.weekday == day) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'c': {
                double cena;
                cin >> cena;

                cout << "result:" << endl;
                for (const auto& route : valid) {
                    if (route.ticketPrice <= cena) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'd': {
                ifstream errFile("err.txt");
                if (errFile) {
                    cout << "result:" << endl;
                    string errLine;
                    while (getline(errFile, errLine)) {
                        cout << errLine << endl;
                    }
                } else {
                    cout << "Error" << endl;
                }
                break;
            }
            case 'e':
                remove("err.txt");  // izdzēst err.txt
                break;
          
            default:
                  cout << "Wrong" << endl;
            }
          } 
      while (choice != 'e');
    return 0;
 }