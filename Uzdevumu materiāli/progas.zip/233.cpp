
// Piebilde! Nezinu kāpēc, bet šis kods neizgāja nevienu testu vietnē replit. Testa actual output ar expected output sakrita, bet tas tāpat neuzskatīja to par izgājušu.

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <regex>
#include <set>

using namespace std;

vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    istringstream tokenStream(s);
    string token;
    while (getline(tokenStream, token, delimiter)) {
        size_t start = token.find_first_not_of(" \t");
        size_t end = token.find_last_not_of(" \t");
        if (start != string::npos && end != string::npos)
            tokens.push_back(token.substr(start, end - start + 1));
    }
    return tokens;
}

bool isValidTime(const string& time) {
    regex timeRegex(R"((?:[01]\d|2[0-3]):[0-5]\d)");
    return regex_match(time, timeRegex);
}

void writeErrorToFile(const vector<string>& race) {
    if (race.size() == 5 &&
        !race[0].empty() &&
        !race[1].empty() &&
        !race[2].empty() &&
        isValidTime(race[3]) &&
        !race[4].empty()) {
        return;
    }
    ofstream errorFile("err.txt", ios::app);
    for_each(race.begin(), race.end(), [&](const string& element) {
        errorFile << element << " ";
    });
    errorFile << endl;
    errorFile.close();
}

void findBusRaces(const vector<vector<string>>& races, const string& start, const string& end) {
    for (const vector<string>& race : races) {
        if (race.size() == 5 && race[0] == start && race[1] == end) {
            cout << race[0] << " " << race[1]
                 << " " << race[2] << " " << race[3] << " " << race[4] << endl;
        } else {
            writeErrorToFile(race);
        }
    }
}

void findBusRacesByDay(const vector<vector<string>>& races, const string& day) {
    for (const vector<string>& race : races) {
        if (race.size() == 5 && race[2] == day) {
            cout << race[0] << " " << race[1]
                 << " " << race[2] << " " << race[3] << " " << race[4] << endl;
        } else {
            writeErrorToFile(race);
        }
    }
}

void findBusRacesByTicketPrice(const vector<vector<string>>& races, const string& maxTicketPrice) {
    for (const vector<string>& race : races) {
        if (race.size() == 5 && stof(race[4]) <= stof(maxTicketPrice)) {
            cout << race[0] << " " << race[1]
                 << " " << race[2] << " " << race[3] << " " << race[4] << endl;
        } else {
            writeErrorToFile(race);
        }
    }
}

void printErrorsFromFile() {
    ifstream errorFile("err.txt");
    string line;
    set<string> uniqueErrors;
    bool firstLine = true;
    while (getline(errorFile, line)) {
        if (!line.empty() && uniqueErrors.insert(line).second) {
            if (!firstLine) {
                cout << endl;
            }
            cout << line;
            firstLine = false;
        }
    }
    errorFile.close();
}

vector<vector<string>> readFileToMatrix(const string& filename) {
    vector<vector<string>> matrix;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        matrix.push_back(split(line, ','));
    }
    file.close();
    return matrix;
}

int main() {
    string inFile = "db.csv";
    vector<vector<string>> races = readFileToMatrix(inFile);
    char choice;
    string start, end, day, maxTicketPrice;
    do {
        cin >> choice;
        switch (choice) {
            case 'a':
                cin >> start;
                cin >> end;
                cout << "result:" << endl;
                findBusRaces(races, start, end);
                break;
            case 'b':
                cin >> day;
                cout << "result:" << endl;
                findBusRacesByDay(races, day);
                break;
            case 'c':
                cin >> maxTicketPrice;
                cout << "result:" << endl;
                findBusRacesByTicketPrice(races, maxTicketPrice);
                break;
            case 'd':
                cout << "result:" << endl;
                printErrorsFromFile();
                break;
            case 'e':
                break;
            default:
                cout << "Invalid input. Please enter a valid character." << endl;
                break;
        }
    } while (choice != 'e');
    return 0;
}
