
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <variant>
using namespace std;
int main() {
  ifstream inFile;
  inFile.open("db.csv");
  char ievade;

  if (!inFile) {
    return 0;
  }

  ofstream errors("err.txt", ios::trunc);

  string s;
  while (getline(inFile, s)) {
    s.erase(remove(s.begin(), s.end(), '\n'), s.end());// noņem jaunas rindas simbolus
    if (!s.empty()) {
      istringstream iss(s);
      string dala1;
      int dalas = 0;
      bool otrais = false;// lai pārbaudītu, vai otrais elements ir vai nav skaitlis

      while (getline(iss, dala1, ',')) {
        dala1.erase(remove_if(dala1.begin(), dala1.end(), ::isspace),dala1.end());// noņem tukšuma simbolus
        ++dalas;
        if (dalas == 2) {
          for (char c : dala1) {
            if (!isdigit(c) && c != '.') {
              otrais = true;
              break;
            }
          }
        }
      }
      if (dalas != 5 || !otrais) {
        errors << s << endl;
      }
    }
  }

  while (true) {
    cout << "ievadiet komandu: " << endl;
    cin >> ievade;
    switch (ievade) {
      case 'a': {
        string pietura1, pietura2;
        cin >> pietura1;
        cin >> pietura2;
        string s;
        cout << "result:" << endl;
        inFile.clear();
        inFile.seekg(0, ios::beg);// pārvietojas uz faila sākumu
        while (getline(inFile, s)) {
          s.erase(remove(s.begin(), s.end(), '\n'), s.end());// noņem jaunas rindas simbolus
          size_t sak = s.find(pietura1);// sākuma pieturas pozīcija
          size_t gal = s.find(pietura2);// gala pieturas pozīcija
          bool otrais = false;
          if (sak != string::npos && gal != string::npos && sak < gal) {
            istringstream iss(s);
            string dala;
            while (getline(iss, dala, ',')) {
              dala.erase(remove_if(dala.begin(), dala.end(), ::isspace),dala.end());// noņem tukšuma simbolus
              cout << dala << " ";
            }
            cout << endl;
          }
        }
        break;
      }
      case 'b': {
        string diena;
        cin >> diena;
        string d;
        cout << "result:" << endl;
        inFile.clear();
        inFile.seekg(0, ios::beg);// pārvietojas uz faila sākumu
        
        while (getline(inFile, d)) {
          d.erase(remove(d.begin(), d.end(), '\n'), d.end());// noņem jaunas rindas simbolus
          if (d.find(diena) != string::npos) {
            istringstream iss(d);
            string dala1;
            while (getline(iss, dala1, ',')) {
              dala1.erase(remove_if(dala1.begin(), dala1.end(), ::isspace),dala1.end());// noņem tukšuma simbolus
              cout << dala1 << " ";
            }
            cout << endl;
          }
        }
        break;
      }
      case 'c': {
        double maksa;
        cin >> maksa;
        string m;
        cout << "result:" << endl;
        inFile.clear();
        inFile.seekg(0, ios::beg);// pārvietojas uz faila sākumu
        while (getline(inFile, m)) {
          m.erase(remove(m.begin(), m.end(), '\n'), m.end());// noņem jaunas rindas simbolus
          istringstream iss(m);
          string dala2;
          bool mazaka = false;
          bool otrais = false;
          int skaits2 = 0;
          string rinda = "";
          
          while (getline(iss, dala2, ',')) {
            dala2.erase(remove_if(dala2.begin(), dala2.end(), ::isspace),dala2.end());// noņem tukšuma simbolus
            bool decimals = true;
            for (char c : dala2) {
              if (!isdigit(c) && c != '.') {
                decimals = false;
                break;
              }
            }
            if (decimals) {
              istringstream ss(dala2);
              double cena;
              ss >> cena;
              if (ss.eof() && !ss.fail() && cena <= maksa) {
                mazaka = true;
              }
            }
            ++skaits2;
            rinda += dala2 + " ";
  
            if (skaits2 == 2) {
              for (char s : dala2) {
                if (!isdigit(s) && s != '.') {
                  otrais = true;
                  break;
                }
              }
            }
          }
          if (mazaka && skaits2 == 5 && otrais) {
            cout << rinda << " ";
            cout << endl;
          }
        }
        break;
      }
      case 'd': {
        errors.close();
        ifstream errori("err.txt");
        string rindas;
        cout << "result: " << endl;
  
        while (getline(errori, rindas)) {
          rindas.erase(remove(rindas.begin(), rindas.end(), '\n'), rindas.end());// noņem jaunas rindas simbolus
          cout << rindas << endl;
        }
        errori.close();
        errors.open("err.txt", ios::app);
        inFile.clear();
        inFile.seekg(0, ios::beg);// pārvietojas uz faila sākumu
        break;
      }
      case 'e': {
        inFile.close();
        return 0;
      }
      default: {
        cout << "nepareiza komanda" << endl;
      }
    }
    inFile.clear();
    inFile.seekg(0, ios::beg);// pārvietojas uz faila sākumu
  }
  return 0;
}
