
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Route {
  // class for routs
public:
  string beg;
  string end;
  string day;
  int hour;
  int mins;
  double price;

  // constructor
  Route(string b, string e, string d, int h, int m, double p) {
    beg = b;
    end = e;
    day = d;
    hour = h;
    mins = m;
    price = p;
  }

  void output() {
    // Outputs the route in the following format:
    cout << beg << " ";
    cout << end << " ";
    cout << day << " ";
    // hh:mm;
    cout << std::setw(2) << std::setfill('0') << hour << ":";
    cout << std::setw(2) << std::setfill('0') << mins << " ";
    cout << std::fixed << std::setprecision(2) << price << endl;
  }
};

string trimStr(string str) {
  // trim str from right and left
  str.erase(str.find_last_not_of(" ") + 1);
  str.erase(0, str.find_first_not_of(" "));
  return str;
}

void aStop(vector<Route> routes) {
  // Output routs with begining and end arrival stops
  string beg, end;
  cin >> beg >> end; // input beg and end stops
  cout << "result:" << endl;

  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].beg == beg && routes[i].end == end) {
      routes[i].output();
    }
  }
}

void bDay(vector<Route> routes) {
  // Output routs with arrival day
  string day;
  cin >> day;
  cout << "result:" << endl;

  for (int i = 0; i < routes.size(); i++) {

    if (routes[i].day == day) {
      routes[i].output();
    }
  }
}

void cPrice(vector<Route> routes) {
  // Output routs with arrival price <= to inputed price
  double price;
  cin >> price;
  cout << "result:" << endl;

  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].price <= price) {
      routes[i].output();
    }
  }
}

void dErr() {
  // Outputs error file
  ifstream inFile;
  inFile.open("err.txt");

  cout << "result:" << endl;

  if (!inFile) {
    cout << "File does not exist";
    return;
  }
  string s;
  while (inFile >> s) {
    cout << s << endl;
  }
  inFile.close();
}

int main() {
  vector<Route> routes;

  ifstream inFile;
  inFile.open("db.csv");

  ofstream errFile;
  errFile.open("err.txt", ofstream::out);

  if (!inFile) {
    cout << "File does not exist";
    return 0;
  }
  if (!errFile) {
    cout << "Error file was not created";
    return 0;
  }
  string s;
  string begR, endR, dayR, timeR;
  int hourR, minsR;
  double priceR;
  int start, end;

  while (getline(inFile, s)) {
    // s=trimStr(s); // trim input line
    // cout<<'='<< s << '+' << endl;

    if (s.length() <= 1) // skip empty line
      continue;

    // check line structure (has 5 fields)
    if (count(s.begin(), s.end(), ',') != 4) {
      errFile << s << endl;
      continue;
    }

    // split line into fields
    start = 0;
    end = s.find(',');
    // Start stop
    begR = trimStr(s.substr(start, end - start));

    start = end + 1;
    end = s.find(',', start);
    // End stop
    endR = trimStr(s.substr(start, end - start));

    start = end + 1;
    end = s.find(',', start);
    // Day, check if it is valid
    dayR = trimStr(s.substr(start, end - start));
    if (dayR != "Pr" && dayR != "Ot" && dayR != "Tr" && dayR != "Ce" &&
        dayR != "Pt" && dayR != "St" && dayR != "Sv") {
      errFile << s << endl;
      continue;
    }

    start = end + 1;
    end = s.find(',', start);
    // Time
    timeR = trimStr(s.substr(start, end - start));
    // try to convert time to int and check if it is valid
    try {
      hourR = stoi(timeR.substr(0, 2));
      if (hourR < 0 || hourR > 23)
        throw 1;
      minsR = stoi(timeR.substr(3, 2));
      if (minsR < 0 || hourR > 59)
        throw 1;
      if (timeR[2] != ':')
        throw 1;
    } catch (...) {
      errFile << s << endl;
      continue;
    }

    start = end + 1;
    end = s.length();
    // Price, check if it is positive
    try {
      priceR = stod(trimStr(s.substr(start, end - start)));
      if (priceR < 0)
        throw 1;
    } catch (...) {
      errFile << s << endl;
      continue;
    }

    // Add route to the vector
    routes.push_back(Route(begR, endR, dayR, hourR, minsR, priceR));
  }

  errFile.close();
  inFile.close();

  char command;

  while (true) {
    // cout << "Enter command: ";
    cin >> command;
    switch (command) {
    case 'a':
      // std::cout << "You entered a" << std::endl;
      aStop(routes);
      break;
    case 'b':
      // std::cout << "You entered b" << std::endl;
      bDay(routes);
      break;
    case 'c':
      // std::cout << "You entered c" << std::endl;
      cPrice(routes);
      break;
    case 'd':
      // std::cout << "You entered d" << std::endl;
      dErr();
      break;
    case 'e':
      remove("err.txt");
      return 0;
    default:
      cout << "Invalid command" << endl;
      break;
    }
  }
}