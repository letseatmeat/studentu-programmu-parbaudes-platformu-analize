#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

struct Bus {
    std::string startStop;
    std::string endStop;
    std::string dayOfWeek;
    std::string time;
    double ticket;
};

int main() {
    std::ifstream inputFile("db.csv");
    std::ofstream errorFile("err.txt");
    std::string line;
    std::vector<Bus> busRoutes;

    if (inputFile.is_open()) {
        while (getline(inputFile, line)) {
            std::stringstream ss(line);
            std::string item;
            std::vector<std::string> data;

            while (getline(ss, item, ',')) {
                data.push_back(item);
            }

            if (data.size() != 5) {
                errorFile << line << std::endl;
                continue;
            }

            Bus route;
            route.startStop = data[0];
            route.endStop = data[1];
            route.dayOfWeek = data[2];
            route.time = data[3];
            route.ticket = std::stod(data[4]);

            busRoutes.push_back(route);
        }
        inputFile.close();
        errorFile.close();
    } else {
        std::cout << "";
    }

    char command;
    do {
        std::cout << "";
        std::cin >> command;

        switch (command) {
            case 'a': {
                std::string startStop, endStop;
                std::cout << "";
                std::cin >> startStop;
                std::cout << "";
                std::cin >> endStop;
                    std::cout << "result:" << std::endl;
                    for (const auto& route : busRoutes) {
                      if (route.startStop == startStop && route.endStop == endStop) {
                          std::cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << std::fixed << std::setprecision(2) << route.ticket << std::endl;
                  }
                }
                break;
            }
            case 'b': {
                std::string dayOfWeek;
                std::cout << "";
                std::cin >> dayOfWeek;
                      std::cout << "result:" << std::endl;
                      for (const auto& route : busRoutes) {
                        if (route.dayOfWeek == dayOfWeek) {
                            std::cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << std::fixed << std::setprecision(2) << route.ticket << std::endl;
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                std::cout << "";
                std::cin >> maxPrice;
                      std::cout << "result:" << std::endl;
                      for (const auto& route : busRoutes) {
                        if (route.ticket <= maxPrice) {
                            std::cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << std::fixed << std::setprecision(2) << route.ticket << std::endl;
                    }
                }
                break;
            }
            case 'd': {
                std::ifstream errorFile("err.txt");
                std::string line;
                std::cout << "result:" << std::endl;

                if (errorFile.is_open()) {
                    while (getline(errorFile, line)) {
                        std::cout << line << std::endl;
                    }
                    errorFile.close();
                } else {
                    std::cout << "";
                }
                break;
            }
            case 'e':
                std::cout << "" << std::endl;
                break;
            default:
                std::cout << "" << std::endl;
                break;
        }
    } while (command != 'e');

    return 0;
}