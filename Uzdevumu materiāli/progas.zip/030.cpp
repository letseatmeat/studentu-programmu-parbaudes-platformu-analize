
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int main() {
  ifstream inFile;
  ofstream inFile1("db2.csv");
  inFile.open("db.csv");
  string burts;

	if (!inFile) return 0;
  
  string s; 
  
  while(getline(inFile, s)){
    s.erase(remove_if(s.begin(), s.end(), ::isspace), s.end());
    if (!s.empty()){
      inFile1 << s << endl;
    }
  }
  inFile1.close();
  ifstream inFile2;
  

  while (true){
    cin >> burts;
    if (burts == "a"){
      inFile2.open("db2.csv");
      string sakuma, beigu;
      cin >> sakuma;
      cin >> beigu;
      string vards;
      string mas[6];
      int i = 0;
      cout << "result:" << endl;
      while (inFile2 >> s){ 
        for(char c : s){
          if (c != ',' && c != ' '){
            vards = vards + c;
          }
          else if (c == ','){
            mas[i] = vards;
            vards = "";
            i++;
          }
        }
        mas[5] = vards;
        vards = "";
        i = 0;
        if(mas[4] != ""){
          for(int j = 0; j < 6; j++){
            mas[j].clear();
          }
        }
        if (mas[0] == sakuma && mas[1] == beigu){
          for(int j = 0; j < 6; j++){
            if(mas[j] != ""){
              cout << mas[j] << " ";
              mas[j].clear();
            }
          }
          cout << endl;
        }
      }
      inFile2.close();
      
    }
    else if (burts == "b"){
      inFile2.open("db2.csv");
      string diena;
      cin >> diena;
      string vards;
      string mas[6];
      int i = 0;
      cout << "result:" << endl;
      while (inFile2 >> s){ 
        for(char c : s){
          if (c != ',' && c != ' '){
            vards = vards + c;
          }
          else if (c == ','){
            mas[i] = vards;
            vards = "";
            i++;
          }
        }
        mas[5] = vards;
        vards = "";
        i = 0;
        if(mas[4] != ""){
          for(int j = 0; j < 6; j++){
            mas[j].clear();
          }
        }
        if (mas[2] == diena){
          for(int j = 0; j < 6; j++){
            if(mas[j] != ""){
              cout << mas[j] << " ";
              mas[j].clear();
            }
          }
          cout << endl;
        }
      }
      inFile2.close();
    }
    else if (burts == "c"){
      inFile2.open("db2.csv");
      double nauda;
      double mas5;
      cin >> nauda;
      string vards;
      string mas[6];
      int i = 0;
      cout << "result:" << endl;
      while (inFile2 >> s){ 
        for(char c : s){
          if (c != ',' && c != ' '){
            vards = vards + c;
          }
          else if (c == ','){
            mas[i] = vards;
            vards = "";
            i++;
          }
        }
        mas[5] = vards;
        vards = "";
        i = 0;
        if(mas[4] != ""){
          for(int j = 0; j < 6; j++){
            mas[j].clear();
          }
        }
        try {
            double mas5 = stod(mas[5]);
            if (mas5 <= nauda){
              for(int j = 0; j < 6; j++){
                if(mas[j] != ""){
                  cout << mas[j] << " ";
                  mas[j].clear();
                }
              }
              cout << endl;
            }
            
        } 
        catch (const invalid_argument& ia) {} 
        catch (const out_of_range& oor) {}

        
      }
      inFile2.close();
    }
    else if (burts == "d"){
      ofstream errors;
      errors.open("err.txt");
      inFile2.open("db2.csv");
      double nauda;
      string diena;
      string laiks;
      string vards;
      string mas[6];
      int i = 0;
      cout << "result:" << endl;
      while (inFile2 >> s){ 
        for(char c : s){
          if (c != ',' && c != ' '){
            vards = vards + c;
          }
          else if (c == ','){
            mas[i] = vards;
            vards = "";
            i++;
          }
        }
        mas[5] = vards;
        vards = "";
        i = 0;
      
        bool a = true;
        for(char c : mas[3]){
          if(!isdigit(c) && c != ':') a = false;
        }

        try {
            double mas5 = stod(mas[5]);
            if(!a || (mas[2] != "Pr" && mas[2] != "Ot" && mas[2] != "Tr" && mas[2] != "Ce" && mas[2] != "Pt" && mas[2] != "St" && mas[2] != "Sv") || mas[3] == "" || mas[1] == "" || mas[0] == "" || mas[5] == "" || mas[4] != ""){ 
              for(int j = 0; j < 5; j++){
                if (mas[j] != ""){
                errors << mas[j] << ",";
                }
                else{
                  errors << mas[j];
                }
              }
              errors << mas[5] << endl;
            }

            for(int j = 0; j < 5; j++){
              mas[j].clear();
            }

        } 
        catch (const invalid_argument& ia) {
          for(int j = 0; j < 5; j++){
              if (mas[j] != ""){
              errors << mas[j] << ",";
              }
              else{
                errors << mas[j];
              }
            }
            errors << mas[5] << endl;
          
          for(int j = 0; j < 5; j++){
            mas[j].clear();
          }
      } 
        catch (const out_of_range& oor) {
          for(int j = 0; j < 5; j++){
              if (mas[j] != ""){
              errors << mas[j] << ",";
              }
              else{
                errors << mas[j];
              }
            }
            errors << mas[5] << endl;

          for(int j = 0; j < 5; j++){
            mas[j].clear();
          }
        }


      }
      inFile2.close();
      errors.close();

      string l;
      ifstream errors1;
      errors1.open("err.txt");
      while (errors1 >> l){
        cout << l << endl;
      }
      errors1.close();
    }
    else if (burts == "e"){
      return 0;
    }
  }
  
} 
