


#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <limits>



struct RouteInfo {
    std::string startStation;
    std::string endStation;
    std::string dayOfWeek;
    std::string time;
    double price;
};


std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t");
    if (first == std::string::npos) {
        return str;
    }
    size_t last = str.find_last_not_of(" \t");
    return str.substr(first, (last - first + 1));
}


std::vector<RouteInfo> readDatabase(const std::string& filename) {
    std::vector<RouteInfo> routes;
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(trim(line));
        RouteInfo route;
        if (std::getline(iss, route.startStation, ',') &&
            std::getline(iss, route.endStation, ',') &&
            std::getline(iss, route.dayOfWeek, ',') &&
            std::getline(iss, route.time, ',') &&
            (iss >> route.price)) {
            iss.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            route.startStation = trim(route.startStation);
            route.endStation = trim(route.endStation);
            route.dayOfWeek = trim(route.dayOfWeek);
            route.time = trim(route.time);
            routes.push_back(route);
        } else {
            std::ofstream err("err.txt", std::ios_base::app);
            err << line << '\n';
        }
    }
    return routes;
}

void printRoute(const RouteInfo& route) {
    std::cout << route.startStation << ' '
              << route.endStation << ' '
              << route.dayOfWeek << ' '
              << route.time << ' '
              << std::fixed << std::setprecision(2) << route.price << '\n';
}


int main() {
    std::vector<RouteInfo> routes = readDatabase("db.csv");
    char command;

    while (true) {
        std::cin >> command;
        if (command == 'e') {
            break;
        }

        std::cout << "result:" << '\n';
        if (command == 'a') {
            std::string start, end;
            std::cin >> start >> end;
            bool found = false;
            for (const auto& route : routes) {
                if (route.startStation == start && route.endStation == end) {
                    printRoute(route);
                    found = true;
                }
            }
            if (!found) {
                std::cout << "kludu nav" << '\n';
            }
        } else if (command == 'b') {
            std::string dayOfWeek;
            std::cin >> dayOfWeek;
            bool found = false;
            for (const auto& route : routes) {
                if (route.dayOfWeek == dayOfWeek) {
                    printRoute(route);
                    found = true;
                }
            }
            if (!found) {
                std::cout << "kludu nav" << '\n';
            }
        } else if (command == 'c') {
            double maxPrice;
            std::cin >> maxPrice;
            bool found = false;
            for (const auto& route : routes) {
                if (route.price <= maxPrice) {
                    printRoute(route);
                    found = true;
                }
            }
            if (!found) {
                std::cout << "kludu nav" << '\n';
            }
        } else if (command == 'd') {
            std::ifstream errFile("err.txt");
            if (errFile.peek() != std::ifstream::traits_type::eof()) {
                std::string line;
                while (std::getline(errFile, line)) {
                    std::cout << line << '\n';
                }
            } else {
                std::cout << "kludu nav" << '\n';
            }
            errFile.close();
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    return 0;
}
