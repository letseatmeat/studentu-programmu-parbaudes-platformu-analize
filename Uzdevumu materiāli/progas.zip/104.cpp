#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>


using namespace std;

struct AutobusaMarsruts {
  string sakumaPietura;
  string galaPietura;
  string nedelasDiena;
  string laiks;
  double biletesCena;
};

// Funkcija, lai noņemtu atstarpes no vārdiem
string removeSpaces(string str) {
  str.erase(remove_if(str.begin(), str.end(), ::isspace), str.end());
  return str;
}

void writeErrorToFile(ofstream& errFile, const string& error) {
  if (error.find_first_not_of(" \t\n\v\f\r") == string::npos) { //ja rinda ir tukša to neievada err.txt
    return;
  }
  
  if (errFile.is_open()) {
    errFile << error << endl;
  }
  else {
    cerr << "Nevar atvērt err.txt failu." << endl;
  }
}


void printRoutesByRoute(const vector<AutobusaMarsruts>& marsruti, const string& start, const string& end) {
  cout << "result:" << endl; //Reisi no: uz: ievade
  for (const auto& marsruts : marsruti) {
    if (marsruts.sakumaPietura == start && marsruts.galaPietura == end) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
         << marsruts.nedelasDiena << " " << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.biletesCena << endl;
    }
  }
}

void printRoutesByDay(const vector<AutobusaMarsruts>& marsruti, const string& day) {
  cout << "result:" << endl; //izprintē reisus pēc nedēļas diens
  for (const auto& marsruts : marsruti) {
    if (marsruts.nedelasDiena == day) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
         << marsruts.nedelasDiena << " " << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.biletesCena << endl;
    }
  }
}

void printRoutesByMaxPrice(const vector<AutobusaMarsruts>& marsruti, double maxPrice) {
  cout << "result:" << endl; //izprintē reisus pēc maksimālās cenas
  for (const auto& marsruts : marsruti) {
    if (marsruts.biletesCena <= maxPrice) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
         << marsruts.nedelasDiena << " " << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.biletesCena << endl;
    }
  }
}


int main() {
  ifstream inFile;
  inFile.open("db.csv", ios::in | ios::binary);

  if (!inFile){ //nevar atvert failu
    return 1;
  }

  vector<AutobusaMarsruts> marsruti;

  ofstream errFile("err.txt", ios::app);

  string line; 
  int lineCount = 0;
  while (getline(inFile,line)){
    lineCount++;
    
    if (line.empty()) {
      continue; //izlaiž tukšās rindas
    }
    
    istringstream ss(line);
    string token;

    AutobusaMarsruts marsruts;

    //no katras rindas izvelk info
    getline(ss,marsruts.sakumaPietura,',');
    getline(ss,marsruts.galaPietura,',');
    getline(ss,marsruts.nedelasDiena,',');
    getline(ss,marsruts.laiks,',');

    marsruts.sakumaPietura = removeSpaces(marsruts.sakumaPietura);
    marsruts.galaPietura = removeSpaces(marsruts.galaPietura);
    marsruts.nedelasDiena = removeSpaces(marsruts.nedelasDiena);
    marsruts.laiks = removeSpaces(marsruts.laiks);

    // Pārbauda, vai laiks ir korekts (hh:mm formātā), ja jā, tad ieraksta err.txt
    if (marsruts.laiks.size() != 5 || marsruts.laiks[2] != ':') {
      writeErrorToFile(errFile, line);
      continue;
    }

    // Pārbauda, vai cena ir korekta, ja jā, tad ieraksta err.txt
    if (!(ss >> marsruts.biletesCena)) {
      writeErrorToFile(errFile, line);
      continue;
    }

    // Pārbauda, vai ir lieki lauki, ja jā, tad ieraksta err.txt
    if (ss >> token) {
      writeErrorToFile(errFile, line);
      continue;
    }


    marsruti.push_back(marsruts);
    
  }

  errFile.close();

  char choice;
  while(true){ //Izvēlieties darbību (a, b, c, d, e)
    cin >> choice;

    switch(choice){
      case 'a':{
        string start, end;
        cin >> start;
        cin >> end;
        printRoutesByRoute(marsruti, start, end);
        break;
      }
      case 'b':{
        string day;
        cin >> day;
        printRoutesByDay(marsruti, day);
        break;
      }
      case 'c':{
        double maxPrice;
        cin >> maxPrice;
        printRoutesByMaxPrice(marsruti, maxPrice);
        break;
      }
      case 'd':{
        ifstream errFile("err.txt");
        if (errFile){
          string errorLine;
          cout << "result:" << endl;
          while (getline(errFile, errorLine)){ //Saturs no err.txt faila:
            cout << errorLine << endl;
          }
          errFile.close();
        }
        break;
      }
      case 'e':{ //pārtrauc programmu, iztīra err.txt failu
        remove("err.txt");
        return 0;
      }
      default: 
        cout << "Nepareiza ievade. Lūdzu, ievadiet a, b, c, d vai e." << endl;
    }
  }
  
  inFile.close();
  return 0;
} 