
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <regex>

using namespace std;
struct AutoMarsruts{
string spietura;
string gpietura;
string diena;
string laiks;
double cena;
};

bool formats(const string& laiks){
  regex parbaude(R"([0-2][0-9]:[0-5][0-9])");
  return regex_match(laiks, parbaude);
}
void error(const string& rinda){
  ofstream kludasFails("err.txt", ios::app);
  kludasFails << rinda << endl;
  kludasFails.close();
}
void izvadit(const AutoMarsruts& marsruts){
  cout.precision(2);
  cout << fixed;
  cout << marsruts.spietura << " " << marsruts.gpietura<< " " << marsruts.diena << " " << marsruts.laiks << " " << marsruts.cena << endl;
}

int main() {
  vector<AutoMarsruts> saraksts;
  ifstream ievade("db.csv");
  if (!ievade) {
    cout << "Nevar atvērt failu db.csv" << endl;
    return 1;
  }
  string rinda;
  while (getline(ievade, rinda)) {
    rinda.erase(remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());
    if (rinda.empty()){
      continue;
    }
    istringstream ievade(rinda);
    AutoMarsruts marsruts;

    getline(ievade, marsruts.spietura, ',');
    getline(ievade, marsruts.gpietura, ',');
    getline(ievade, marsruts.diena, ',');
    getline(ievade, marsruts.laiks, ',');
    ievade >> marsruts.cena;

    if (count(rinda.begin(),rinda.end(),',')!=4 || marsruts.cena<=0 || !formats(marsruts.laiks)){
      error(rinda);
      continue;
    }
    saraksts.push_back(marsruts);
  }
  ievade.close();
  char izvele;
  while (true){
    cout << "Izvēlieties darbību (a,b,c,d,e): ";
    cin >> izvele;
    if (izvele == 'e'){
      break;
    }
    switch (izvele){
      case 'a':{
        string spietura, gpietura;
        cout << "Ievadiet sākuma pieturas nosaukumu: ";
        cin >> spietura;
        cout << "Ievadiet gala pieturas nosaukumu: ";
        cin >> gpietura;
        cout << "result:" << endl;
        for (const auto& marsruts : saraksts) {
          if (marsruts.spietura == spietura && marsruts.gpietura == gpietura) {
            izvadit(marsruts);
          }
        }
        break;
      }
      case 'b':{
        string diena;
        cout << "Ievadiet dienas nosaukumu (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
        cin >> diena;
        cout << "result:" << endl;
        for (const auto& marsruts : saraksts) {
          if (marsruts.diena == diena) {
            izvadit(marsruts);
          }
        }
        break;
      }
      case 'c': {
        double maxcena;
        cout << "Ievadiet maksimālo cenu: ";
        cin >> maxcena;
        cout << "result:"<< endl;
        for (const auto& marsruts : saraksts) {
          if (marsruts.cena <= maxcena) {
            izvadit(marsruts);
          }
        }
        break;
      }
      case 'd': {
        ifstream kludasFails("err.txt");
        if (kludasFails){
          cout << "result:"<< endl;
          cout << kludasFails.rdbuf();
        } else {
          cout << "Fails err.txt ir tukšs" << endl;
        }
        break;
      }
      default:
      cout << "Nepareiza izvēle" << endl;
    }
  }
  remove("err.txt");
  return 0;
} 