#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>

using namespace std;

struct Route {
    string start;
    string end;
    string day;
    string time;
    double price;

    bool operator==(const Route &other) const {
        return start == other.start && end == other.end && day == other.day &&
               time == other.time && price == other.price;
    }

    bool operator<(const Route &other) const {
        return tie(start, end, day, time, price) <
               tie(other.start, other.end, other.day, other.time, other.price);
    }
};

bool isValidDay(const string &day) {
    static const vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    return find(days.begin(), days.end(), day) != days.end();
}

bool isValidTime(const string &time) {
    if (time.size() != 5)
        return false;
    if (time[2] != ':')
        return false;
    int hours = stoi(time.substr(0, 2));
    int minutes = stoi(time.substr(3, 2));
    return hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59;
}

bool isValidPrice(const string &price) {
    istringstream iss(price);
    double val;
    iss >> val;
    return iss.eof() && !iss.fail();
}

Route parseRoute(const string &line) {
    istringstream ss(line);
    string start, end, day, time, price;

    getline(ss, start, ',');
    getline(ss, end, ',');
    getline(ss, day, ',');
    getline(ss, time, ',');
    getline(ss, price, ',');

    return {start, end, day, time, stod(price)};
}

string eraseSpaces(const string &str) {
    string result;
    for (char c : str)
    {
        if (!isspace(c))
        {
            result += c;
        }
    }
    return result;
}

bool isValidFormat(const string &line) {
    istringstream ss(line);
    vector<string> fields;
    string field;
    while (getline(ss, field, ','))
    {
        fields.push_back(field);
    }
    return fields.size() == 5;
}


void CaseA(const vector<Route>& routes) {
    string start, end;
    cout << "Sākuma pietura: ";
    cin >> start;
    cout << "Beigu pietura: ";
    cin >> end;
    cout << "result:" << endl;

    bool found = false;
    for (const auto &route : routes)
    {
        if (route.start == start && route.end == end)
        {
            found = true;
            cout << route.start << " " << route.end << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price
                 << endl;
        }
    }

    if (!found)
    {
        cout << "Nav atbilstošu maršrutu." << endl;

        for (const auto &route : routes)
        {
            if (route.start == start && route.end == end)
            {
                string fixedLine = route.start + ", " + route.end + ", " +
                                   route.day + ", " + route.time + ", " +
                                   to_string(route.price);
                cout << "Corrected line: " << fixedLine << endl;
            }
        }
    }
}


void CaseB(const vector<Route>& routes) {
    string day;
    cout << "Nedēļas diena: ";
    cin >> day;
    cout << "result:" << endl;
    for (const auto &route : routes)
    {
        if (route.day == day)
        {
            cout << route.start << " " << route.end << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price
                 << endl;
        }
    }
}


void CaseC(const vector<Route>& routes) {
    double maxPrice;
    cout << "Maksimālā biļetes cena: ";
    cin >> maxPrice;
    cout << "result:" << endl;
    for (const auto &route : routes)
    {
        if (route.price <= maxPrice)
        {
            cout << route.start << " " << route.end << " " << route.day << " "
                 << route.time << " " << fixed << setprecision(2) << route.price
                 << endl;
        }
    }
}

void CaseD() {
    cout << "result:" << endl;
    ifstream errFile("err.txt");
    if (errFile)
    {
        string errorLine;
        while (getline(errFile, errorLine))
        {
            if (!errorLine.empty())
            {
                cout << errorLine << endl;
            }
        }
    }
    else
    {
        cout << "Nav kļūdu failā." << endl;
    }

}

int main() {
    ifstream inFile("db.csv");
    ofstream errorFile("err.txt");
    if (!inFile || !errorFile)
    {
        cerr << "Cannot open files!" << endl;
        return 1;
    }

    if (inFile.peek() == ifstream::traits_type::eof())
    {
        cout << "db.csv nav pieejamu datu!" << endl;
        return 0;
    }

    vector<Route> routes;
    set<Route> uniqueRoutes;

    string line;
    while (getline(inFile, line))
    {
        if (line.empty())
            continue;

        line = eraseSpaces(line);

        if (!isValidFormat(line))
        {
            errorFile << line << endl;
            continue;
        }

        Route route;
        try {
            route = parseRoute(line);

            if (!isValidDay(route.day) || !isValidTime(route.time) ||
                !isValidPrice(to_string(route.price)))
            {
                errorFile << line << endl;
                continue;
            }

            if (uniqueRoutes.count(route) == 0)
            {
                routes.push_back(route);
                uniqueRoutes.insert(route);
            }
        }
        catch (const exception &e)
        {
            errorFile << line << endl;
        }
    }

    char choice;
    cout << "Kristiāns Lauva, 221RDB507, 9.grupa " << endl;

    do {
        cout << "Darbība: ";
        string input;
        cin >> ws;
        getline(cin, input);

        try {
            if (input.empty())
            {
                throw runtime_error("Lūdzu ievadiet darbību!");
            }

            if (input.length() != 1 || (input[0] < 'a' || input[0] > 'e'))
            {
                cout << "Lūdzu ievadiet vienu burtu no a līdz e!" << endl;
                continue;
            }

            choice = input[0];

            switch (choice) {
                case 'a':
                    CaseA(routes);
                    break;
                case 'b':
                    CaseB(routes);
                    break;
                case 'c':
                    CaseC(routes);
                    break;
                case 'd':
                    CaseD();
                    break;
                default:
                    break;
            }

        }
        catch (const exception &e)
        {
            cout << e.what() << endl;
            continue;
        }

    }while (choice != 'e');

    return 0;
}
