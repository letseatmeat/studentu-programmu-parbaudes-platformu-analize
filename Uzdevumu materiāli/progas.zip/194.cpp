

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void deleteSpaces(string &line){
  string temp;
  for (char c : line){
    if (c != ' ' && c != '\t'){
      temp += c;
    }
  }
  line = temp;
}

vector<string> split(const string &line, char comma){
  vector<string> fields;
  string tagField;
  for (char c : line){
    if (c == comma){
      fields.push_back(tagField);
      tagField.clear();
    }else{
      tagField += c;
    }
  }
  fields.push_back(tagField);
  return fields;
}

bool correctCity(const string &city){
  if (!city.empty()){
    for (char c : city){
      if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))){
        return false;
      }
    }
  }
  return true;
}

bool correctDay(const string &day){
  if (!day.empty()){
    if (day.length() != 2){
      return false;
    }
    if (day == "Pr" || day == "Ot" || day == "Tr" || day == "Ce" || day == "Pt" || day == "St" || day == "Sv"){
      return true;
    }else{
      return false;
    }
  }
  return true;
}

bool correctTime(const string &time){
  if (!time.empty()){
    if (time.length() != 5){
      return false;
    }
    if (time[0] >= '0' && time[0] <= '2' || time[1] >= '0' && time[1] <= '3' || time[2] == ':' || time[3] >= '0' && time[3] <= '5' || time[4] >= '0' && time[4] <= '9'){
      return true;
    }else{
      return false;
    }
  }
  return true;
}

bool correctPrice(const string &price){
  if (!price.empty()){
    if (price[0] == '-'){
      return false;
    }
    int dot = price.find('.');
    int lengthADot = price.length() - dot - 1;
    if (lengthADot != 2){
      return false;
    }
  }
  return true;
}

void CaseA(const string &city1, const string &city2, const string &fileName){
  ifstream inFile(fileName);
  if (inFile.is_open()){
    string line;
    cout << "result:" << endl;
    while (getline(inFile, line)){
      deleteSpaces(line);
      vector<string> fields = split(line, ',');
      if (fields.size() == 5){
        if (!correctCity(fields[0]) || !correctCity(fields[1]) || !correctDay(fields[2]) || !correctTime(fields[3]) || !correctPrice(fields[4])){
          continue;
        }
        if (fields[0] == city1 && fields[1] == city2){
          cout << fields[0] << " " << fields[1] << " " << fields[2] << " " << fields[3] << " " << fields[4] << endl;
        }
      }
    }
    inFile.close();
  }
}

void CaseB(const string &day, const string &fileName){
  ifstream inFile(fileName);
  if (inFile.is_open()){
    string line;
    cout << "result:" << endl;
    while (getline(inFile, line)){
      deleteSpaces(line);
      vector<string> fields = split(line, ',');
      if (fields.size() == 5){
        if (!correctCity(fields[0]) || !correctCity(fields[1]) || !correctDay(fields[2]) || !correctTime(fields[3]) || !correctPrice(fields[4])){
          continue;
        }

        if (fields[2] == day){
          cout << fields[0] << " " << fields[1] << " " << fields[2] << " " << fields[3] << " " << fields[4] << endl;
        }
      }
    }
    inFile.close();
  }
}

void CaseC(const double &price, const string &fileName){
  ifstream inFile(fileName);
  if (inFile.is_open()){
    string line;
    cout << "result:" << endl;
    while (getline(inFile, line)){
      deleteSpaces(line);
      vector<string> fields = split(line, ',');
      if (fields.size() == 5){
        if (!correctCity(fields[0]) || !correctCity(fields[1]) || !correctDay(fields[2]) || !correctTime(fields[3]) || !correctPrice(fields[4])){
          continue;
        }
        double linePrice = stod(fields[4]);
        if (linePrice < price){
          cout << fields[0] << " " << fields[1] << " " << fields[2] << " " << fields[3] << " " << fields[4] << endl;
        }
      }
    }
  inFile.close();
  }
}

void CaseD(const string &fileName){
  ifstream inFile(fileName);
  if (inFile.is_open()){
    string line;
    cout << "result:" << endl;
    while (getline(inFile, line)){
      cout << line << endl;
    }
  inFile.close();
  }
}

int main() {
  ifstream inFile("db.csv");
  ofstream outFile("err.txt");
  
  string line;
  while (getline(inFile, line)) {
    deleteSpaces(line);
    bool correctLine = true;

    if (line.find_first_not_of(" \t\n") == string::npos){
      continue;
    }
    vector<string> fields = split(line, ',');
    if (fields.size() != 5){
      correctLine = false;
    }else{
      if (!correctCity(fields[0]) || !correctCity(fields[1]) || !correctDay(fields[2]) || !correctTime(fields[3]) || !correctPrice(fields[4])){
        correctLine = false;
      }
    }
    if (!correctLine){
      outFile << line << endl;
    }
  }
  
  inFile.close();
  outFile.close();

  
  char option;
  string city1, city2, day;
  double price;
  
  do {
    cin >> option;

    switch(option){
      case 'a':
        cin >> city1;
        cin >> city2;
        CaseA(city1, city2, "db.csv");
        break;

      case 'b':
        cin >> day;
        CaseB(day, "db.csv");
        break;

      case 'c':
        cin >> price;
        CaseC(price, "db.csv");
        break;

      case 'd':
        CaseD("err.txt");
        break;
      
      default:
        break;
    
    }
  } while (option != 'e');

  return 0;
} 