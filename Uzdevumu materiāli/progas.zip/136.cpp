

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <cctype>

using namespace std;

struct BusRoute {
    string startPoint;
    string endPoint;
    string travelDay;
    string travelTime;
    double ticketPrice;
};

vector<string> splitString(const string &str, char delimiter) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(str);
    while (getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

string removeExtraSpaces(const string &str) {
    auto start = str.begin();
    while (start != str.end() && isspace(*start)) {
        start++;
    }
    auto end = str.end();
    do {
        end--;
    } while (distance(start, end) > 0 && isspace(*end));
    return string(start, end + 1);
}

vector<BusRoute> readBusRoutes(const string &filename, const string &errorFilename) {
    ifstream inputFile(filename);
    ofstream errorFile(errorFilename);
    vector<BusRoute> busRoutes;
    string line;
    while (getline(inputFile, line)) {
        line = removeExtraSpaces(line);
        if (line.empty()) continue; 
        vector<string> tokens = splitString(line, ',');
        if (tokens.size() != 5) {
            errorFile << line << endl; 
            continue; 
        }
        BusRoute busRoute;
        busRoute.startPoint = removeExtraSpaces(tokens[0]);
        busRoute.endPoint = removeExtraSpaces(tokens[1]);
        busRoute.travelDay = removeExtraSpaces(tokens[2]);
        busRoute.travelTime = removeExtraSpaces(tokens[3]);
        try {
            busRoute.ticketPrice = stod(removeExtraSpaces(tokens[4]));
        } catch (const invalid_argument& ia) {
            errorFile << line << endl; 
            continue; 
        }
        if (isdigit(busRoute.startPoint[0]) || isdigit(busRoute.endPoint[0])) {
            errorFile << line << endl; 
            continue; 
        }
        busRoutes.push_back(busRoute);
    }
    return busRoutes;
}

void displayBusRoutes(const vector<BusRoute>& busRoutes) {
    for (const BusRoute& busRoute : busRoutes) {
        cout << busRoute.startPoint << " " << busRoute.endPoint << " " << busRoute.travelDay << " " << busRoute.travelTime << " " << fixed << setprecision(2) << busRoute.ticketPrice << endl;
    }
}

int main() {
    vector<BusRoute> busRoutes = readBusRoutes("db.csv", "err.txt");
    char userCommand;
    while (true) {
        cin >> userCommand;
        if (userCommand == 'e') break;
        switch (userCommand) {
            case 'a': {
                string start, end;
                cin >> start >> end;
                vector<BusRoute> result;
                for (const BusRoute& busRoute : busRoutes) {
                    if (busRoute.startPoint == start && busRoute.endPoint == end) {
                        result.push_back(busRoute);
                    }
                }
                cout << "result:" << endl;
                displayBusRoutes(result);
                break;
            }
            case 'b': {
                string day;
                cin >> day;
                vector<BusRoute> result;
                for (const BusRoute& busRoute : busRoutes) {
                    if (busRoute.travelDay == day) {
                        result.push_back(busRoute);
                    }
                }
                cout << "result:" << endl;
                displayBusRoutes(result);
                break;
            }
            case 'c': {
                double maxPrice;
                cin >> maxPrice;
                vector<BusRoute> result;
                for (const BusRoute& busRoute : busRoutes) {
                    if (busRoute.ticketPrice <= maxPrice) {
                        result.push_back(busRoute);
                    }
                }
                cout << "result:" << endl;
                displayBusRoutes(result);
                break;
            }
            case 'd': {
                ifstream errorFile("err.txt");
                string line;
                cout << "result:" << endl;
                while (getline(errorFile, line)) {
                    cout << line << endl;
                }
                break;
            }
        }
    }
}