
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <regex>

struct Route {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

struct Data {
  std::vector<Route> routes;
  std::vector<std::string> errors;
};

std::vector<std::string> split(const std::string &s, char delimiter) {
  std::vector<std::string> tokens;
  std::string token;
  std::istringstream tokenStream(s);
  while (std::getline(tokenStream, token, delimiter)) {
    tokens.push_back(token);
  }
  return tokens;
}

std::string trim(const std::string &str) {
  size_t first = str.find_first_not_of(' ');
  if (std::string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

std::vector<Route> readData() {
  std::vector<Route> routes;
  std::ifstream file("db.csv");
  std::ofstream errFile("err.txt");
  std::string line;
  std::vector<std::string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  while (std::getline(file, line)) {
    if (line.empty() || std::all_of(line.begin(), line.end(), isspace)) {
      continue;
    }
    std::vector<std::string> data = split(line, ',');
    if (data.size() != 5) {
      errFile << line << "\n";
      continue;
    }
    Route route;
    route.start = trim(data[0]);
    route.end = trim(data[1]);
    route.day = trim(data[2]);
    route.time = trim(data[3]);
    if (route.time.size() != 5 || route.time[2] != ':' || 
        std::find(validDays.begin(), validDays.end(), route.day) == validDays.end()) {
      errFile << line << "\n";
      continue;
    }
    try {
      route.price = std::stod(trim(data[4]));
    } catch (...) {
      errFile << line << "\n";
      continue;
    }
    routes.push_back(route);
  }
  return routes;
}

void printRoutes(const std::vector<Route> &routes) {
  std::cout << "result:\n";
  for (const auto &route : routes) {
    std::cout << route.start << " " << route.end << " " << route.day << " "
              << route.time << " " << std::fixed << std::setprecision(2)
              << route.price << "\n";
  }
}

int main() {
  std::vector<Route> routes = readData();
  char command;
  while (std::cin >> command && command != 'e') {
    switch (command) {
    case 'a': {
      std::string start, end;
      std::cin >> start >> end;
      std::vector<Route> result;
      std::remove_copy_if(routes.begin(), routes.end(),
                          std::back_inserter(result), [&](const Route &route) {
                            return route.start != start || route.end != end;
                          });
      printRoutes(result);
      break;
    }
    case 'b': {
      std::string day;
      std::cin >> day;
      std::vector<Route> result;
      std::remove_copy_if(routes.begin(), routes.end(),
                          std::back_inserter(result),
                          [&](const Route &route) { return route.day != day; });
      printRoutes(result);
      break;
    }
    case 'c': {
      double price;
      std::cin >> price;
      std::vector<Route> result;
      std::remove_copy_if(
          routes.begin(), routes.end(), std::back_inserter(result),
          [&](const Route &route) { return route.price > price; });
      printRoutes(result);
      break;
    }

    case 'd': {
      std::ifstream file("err.txt");
      std::string line;
      std::cout << "result:\n";
      while (std::getline(file, line)) {
        std::cout << line << "\n";
      }
      break;
    }
    }
  }
  return 0;
}
