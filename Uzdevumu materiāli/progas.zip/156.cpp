

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct Journey
{
    string startStop; // sākuma pietura
    string endStop;   // beigu pietura
    string routeDay;  // ceļojuma diena
    string time;      // laiks
    double price;     // cena
};

// glabā visus ceļojumus
vector<Journey> journeys;

void getRouteJourneys();
void getDateJourneys();
void getCanAfford();
void printErrorFile();
void readDB(ifstream &inFile);
void printJourneys(const Journey &journey);
void toErr(string &line);
void trimLine(string &str);
bool getInput();

int main()
{
    // notīra kļūdu failu
    ofstream clearErrFile("err.txt", ios::trunc);
    clearErrFile.close();

    // atver datu failu
    ifstream inFile;
    inFile.open("db.csv");

    // ja nevar atvēr failu, beidz programmu
    if (!inFile)
        return 0;
    readDB(inFile);

    // turpina ievadu, kamēr lietotājs izlemj iziet
    while (getInput())
    {
    }
    return 0;
}

// saņem lietotāja  ievadu
bool getInput()
{
    char cmd;
    cin >> cmd;
    switch (cmd)
    {
    // izvada visus reisus, kas kursē maršrutā
    case 'a':
    {
        // izvada visus reisus, kas kursē maršrutā
        getRouteJourneys();
        break;
    }
    // izvada resus, kas iet noteiktajā dienā
    case 'b':
    {
        // izvada resus, kas iet noteiktajā dienā
        getDateJourneys();
        break;
    }
    // izvada reisus, kas nepārsniedz ievadīto
    case 'c':
    {
        // izvada reisus, kurus var atļauties
        getCanAfford();
        break;
    }
    // izvada ķļūdu faila err.txt saturu
    case 'd':
        printErrorFile();
        break;

    // pārtrauc prog. izpildi
    case 'e':
        return false;

    default:
        break;
    }
    return true;
}

void getRouteJourneys()
{ // izvada visus reisus, kas noradītājā sākuma un beigu pieturā
    string start, end;
    // paņem mērķa sākumu
    do
    {
        cin >> start;
    } while (start == "");

    // paņem mērķa beigas
    do
    {
        cin >> end;
    } while (end == "");

    cout << "result:" << '\n';
    for (const Journey &journey : journeys)
    { // salīdzina vai ierkasts sakrīt ar mērķi
        if (journey.startStop == start && journey.endStop == end)
        {
            printJourneys(journey);
        }
    }
}

void getDateJourneys()
{ // izvada visus reisus, kas ir norādītajā dienā
    string day;
    // paņem mērķā dienu
    do
    {
        cin >> day;
    } while (day == "");

    cout << "result:" << '\n';
    for (const Journey &journey : journeys)
    { // salīdzina dienas
        if (journey.routeDay == day)
        {
            printJourneys(journey);
        }
    }
}

void getCanAfford()
{ // izvada visus reisus, kurus var atļauties
    double maxPrice;
    // paņem mērķa cenu
    do
    {
        cin >> maxPrice;
    } while (maxPrice <= 0);

    cout << "result:" << '\n';
    for (const Journey &journey : journeys)
    { // salīdzina cenas
        if (journey.price <= maxPrice)
        {
            printJourneys(journey);
        }
    }
}

void trimLine(string &str)
{ // izdzēš tukšumus no sākuma un beigām
    str.erase(str.begin(), find_if_not(str.begin(), str.end(), ::isspace));
    str.erase(find_if_not(str.rbegin(), str.rend(), ::isspace).base(), str.end());
}

void readDB(ifstream &inFile)
{ // lasa datu failu
    string line;
    while (getline(inFile, line))
    {

        if (line.empty())
            continue; // ignorē tukšās līnijas

        // skaita cik vērtības ir līnijā
        int countLine = count(line.begin(), line.end(), ',');

        if (countLine != 4)
        { // pievieno kļūdainās līnijas failā err.txt
            toErr(line);
            continue;
        }

        Journey journey;
        istringstream ss(line);

        getline(ss >> ws, journey.startStop, ',');
        trimLine(journey.startStop);

        getline(ss >> ws, journey.endStop, ',');
        trimLine(journey.endStop);

        getline(ss >> ws, journey.routeDay, ',');
        trimLine(journey.routeDay);

        getline(ss >> ws, journey.time, ',');
        trimLine(journey.time);

        ss >> journey.price;

        if (ss.fail() || ss.get() != EOF)
        {
            toErr(line);
            continue;
        }

        journeys.push_back(journey);
    }
}

void toErr(string &line)
{ // pievieno kļūdainās līnijas failā err.txt
    ofstream errorFile("err.txt", ios::app);
    errorFile << line << '\n';
    errorFile.close();
}

void printJourneys(const Journey &journey)
{ // izdrukā informāciju par reisu

    cout << journey.startStop << " " << journey.endStop << " " << journey.routeDay
         << " " << journey.time << " " << fixed << setprecision(2)
         << journey.price << '\n';
}

void printErrorFile()
{ // izdrukā err.txt faila saturu
    ifstream errorFile("err.txt");
    if (errorFile.is_open())
    {
        cout << "result:" << '\n';
        string line;
        while (getline(errorFile, line))
        {
            cout << line << '\n';
        }
        errorFile.close();
    }
}
