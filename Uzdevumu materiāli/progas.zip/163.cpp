#include <cstring>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


pair <vector<string>, vector<string>> fixed_csv(ifstream &inFile){
  int count = 0;
  int count2 = 0;
  vector<string> good_lines;
  vector<string> bad_lines;
  string check_time[5];
  string normal_string;
  string modified_string;
  int i = 0;
	while (getline(inFile, normal_string)){
  modified_string = "";
  i = 0;
  string mas[normal_string.size()];
  if (normal_string.empty()){
    continue;
  } 
  for(char ch : normal_string){
    if (ch != ' ' && ch != '\n'){
      modified_string = modified_string + ch;
      if (ch == ','){
          i++;
            continue;
      }
      else{
      mas[i] = mas[i] + ch;
      }
    }
  }
    if (i == 4){
      for (char burts: mas[0]){
        if (!isalpha(burts)){
          bad_lines.push_back(modified_string);
          goto outer_continue;
        }
      }

      for (char d: mas[1]){
        if (!isalpha(d)){
          bad_lines.push_back(modified_string);
          goto outer_continue;
        }
      }
      if (mas[2] != "Pr" && mas[2] != "Ot" && mas[2] != "Tr" && mas[2] != "Ce" && mas[2] != "Pt" && mas[2] != "St" && mas[2] != "Sv"){
      bad_lines.push_back(modified_string);
      continue;  
      }
      
      count = 0;
      if (mas[3].length() == 5){
        for (char d:mas[3]){
          check_time[count] = d;
          count++;
        }
        try{
        int pirmais_elements = stoi(check_time[0],0,10);
        if (pirmais_elements > 2){
          bad_lines.push_back(modified_string);
          continue;
        }
        int otrais_elements = stoi(check_time[1],0,10);
        int ceturtais_elements = stoi(check_time[3],0,10);
        if ( ceturtais_elements > 6){
          bad_lines.push_back(modified_string);
          continue;
        }
        int piektais_elements = stoi(check_time[4],0,10);
        }
        catch(invalid_argument& e){
        bad_lines.push_back(modified_string);
        continue;    
        }
        if (check_time[2] != ":"){
          bad_lines.push_back(modified_string);
          continue;
        }
        }
        else{
          bad_lines.push_back(modified_string);
          continue;
        }
        try{
        double summa = stod(mas[4]);
        count2 = 0;
        for (char e: mas[4]){
          if (e == '.'){
            count2++;
            break;
          }
          count2++;
        }
        if (size(mas[4])-count2 != 2){
          bad_lines.push_back(modified_string);
          continue;
        }
        }
        catch (invalid_argument& e){
          bad_lines.push_back(modified_string);
          continue;
        }
        good_lines.push_back(modified_string);
  }
  else{
    bad_lines.push_back(modified_string);
    continue;
  }
  outer_continue:;
    }
    ofstream output_file("err.txt");
  if (output_file.is_open()) {
    for (int g = 0; g < bad_lines.size(); g++){
      output_file << bad_lines.at(g) << endl;
  }
  output_file.close();
  }
  return make_pair(good_lines,bad_lines);
}

void err_txt(vector<string> bad_lines){
cout << "result:" << endl;
for (int j = 0; j < bad_lines.size(); j++){
  cout << bad_lines.at(j) << endl;
}
}

void a(vector<string> good_lines){
  int count2 = 0;
  string start, end;
  bool pareizi = true;
  while(true){
  cout << "Ievadi sākuma pieturu: ";  
  cin >> start;
  pareizi = true;
  for (char burts: start){
        if (!isalpha(burts)){
          cout << "nepareizi ievadīta pietura!" << endl;
          pareizi = false;
          break;
        }
      }
      if (pareizi){
        break;
      }
  }
  while(true){
  cout << "Ievadi beigu pieturu: ";
  cin >> end;
  pareizi = true;
  for (char burts: end){
        if (!isalpha(burts)){
          cout << "nepareizi ievadīta pietura!" << endl;
          pareizi = false;
          break;
        }
      }
      if (pareizi){
        break;
      }
  }
  string start2 = "";
  string end2 = "";
  int count = 0;
  cout << "result:" << endl;
  for (int i = 0; i < good_lines.size(); i++){
    start2 = "";
    end2 = "";
    count = 0;
    for (char c:good_lines.at(i)){
      if (c == ','){
        count++;
      }
      else if (count == 0){
        start2 = start2 + c;
      }
      else if (count == 1){
        end2 = end2 + c;
      }
      else{
        break;
      }
    }
    if (start2 == start && end2 == end){
      cout << good_lines.at(i) << endl;
    }
    else{
      count2++;
    }
  }
  if (count2 == good_lines.size()){
    cout << "result:" << endl;
    cout << "Šāds maršruts neeksistē" << endl;
  }
}

void b(vector<string> good_lines){
int count2 = 0;
string diena;
  while(true){
    cout << "Ievadi nedēļas dienu: ";  
    cin >> diena;
      if (diena != "Pr" && diena != "Ot" && diena != "Tr" && diena != "Ce" && diena != "Pt" && diena != "St" && diena != "Sv"){
        cout << "nepareizi ievadīta diena!" << endl;
        continue;
      }
      else{
        break;
      }
  }
  string diena2 = "";
  int count = 0;
  cout << "result:" << endl;
  for (int i = 0; i < good_lines.size(); i++){
    diena2 = "";
    count = 0;
    for (char c:good_lines.at(i)){
      if (c == ','){
        count++;
        continue;
      }
      else if (count == 2){
        diena2 = diena2 + c;
      }
      else if (count > 2){
        break;
      }
    }
    if (diena == diena2){
      cout << good_lines.at(i) << endl;
    }
    else{
      count2++;
    }
  }
  if (count2 == good_lines.size()){
    cout << "result:" << endl;
    cout << "Šajās dienās nav nevienu maršrutu" << endl;
  }
}

void c(vector<string> good_lines){
int count2 = 0;
double cena;
  while(true){
    cout << "Ievadi minimālo cenu: ";  
    cin >> cena;
      if (cin.fail() || cin.get() != '\n'){
        cin.clear();
        cin.ignore();
        cout << "nepareizi ievadīta cena!" << endl;
        continue;
      }
      else{
        break;
      }
  }
  string cena2 = "";
  int count = 0;
  cout << "result:" << endl;
  for (int i = 0; i < good_lines.size(); i++){
    cena2 = "";
    count = 0;
    for (char c:good_lines.at(i)){
      if (c == ','){
        count++;
        continue;
      }
      else if (count == 4){
        cena2 = cena2 + c;
      }
    }
    double cena3 = stod(cena2);
    if (cena >= cena3){
      cout << good_lines.at(i) << endl;
    }
    else{
      count2++;
    }
  }
  if (count2 == good_lines.size()){
    cout << "result:" << endl;
    cout << "Nav tik lētu maršrutu" << endl;
  }
}
int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) return 0;
  pair <vector<string>,vector<string>> result = fixed_csv(inFile);
  vector<string> good_lines = result.first;
  vector<string> bad_lines = result.second;
  char choise;
  cout << "Ievadi komandu: ";
  cin >> choise;
  while(choise != 'e'){
    switch (choise){
      case 'a':
      a(good_lines);
      break;
      case 'b':
      b(good_lines);
      break;
      case 'c':
      c(good_lines);
      break;
      case 'd':
      err_txt(bad_lines);
      break;
      case 'e':
      break;
    }
  cout << "Ievadi komandu: ";
  cin >> choise;
  }
}
