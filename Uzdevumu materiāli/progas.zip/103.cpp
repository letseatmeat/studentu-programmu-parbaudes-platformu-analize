

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
using namespace std;

struct marsruti {
    string sakums;
    string gals;
    string diena;
    string laiks;
    double cena;

};

bool rinda(const string& rinda, marsruti& marsrutss);

void marsrutus_lasa(const string& fails, vector<marsruti>& marsrutii, ofstream& errorFails);

void pecPieturam(const vector<marsruti>& marsrutii, const string& sakums, const string& gals);
void pecDienas(const vector<marsruti>& marsrutii, const string& diena);
void pecCenas(const vector<marsruti>& marsrutii, double maxCena);


int main() {
    vector<marsruti> marsrutii;
  
    ofstream errorFails("err.txt");

    marsrutus_lasa("db.csv", marsrutii, errorFails);

    char izvele;
  
    do {
        cin >> izvele;

        switch (izvele) {
          case 'a': {
                string sakums, gals;
                cin.ignore();
            
                getline(cin, sakums);
                getline(cin, gals);
                pecPieturam(marsrutii, sakums, gals);
            
                break;
            
            }
          
            case 'b': {
                string diena;
                cin >> diena;
              
                pecDienas(marsrutii, diena);
              
                break;
              
            }
          
            case 'c': {
                double maxCena;
                cin >> maxCena;
              
                pecCenas(marsrutii, maxCena);
              
                break;
              
            }
          
            case 'd': {
                ifstream errFails("err.txt");
              
                if (errFails.peek() != ifstream::traits_type::eof()) {
                  
                    cout << "result:" << endl;

                    cout << errFails.rdbuf();
                  
                }
                
                errFails.close();
              
                cin.ignore();
              
                break;
              
            }

            case 'e': 
              
                break;
        }

    } while (izvele != 'e');

    errorFails.close();
  
    return 0;
  
}

bool rinda(const string& rinda, marsruti& marsrutss) {
    stringstream ss(rinda);
  
    string sakums, gals, diena, laiks, bilete;

    if (getline(ss, sakums, ',') && getline(ss, gals, ',') && getline(ss, diena, ',') && getline(ss, laiks, ',') && getline(ss, bilete)) {

        
        sakums.erase(0, sakums.find_first_not_of(" \t"));
        sakums.erase(sakums.find_last_not_of(" \t") + 1);
      
        gals.erase(0, gals.find_first_not_of(" \t"));
        gals.erase(gals.find_last_not_of(" \t") + 1);
      
        diena.erase(0, diena.find_first_not_of(" \t"));
        diena.erase(diena.find_last_not_of(" \t") + 1);
      
        laiks.erase(0, laiks.find_first_not_of(" \t"));
        laiks.erase(laiks.find_last_not_of(" \t") + 1);
      
        bilete.erase(0, bilete.find_first_not_of(" \t"));
        bilete.erase(bilete.find_last_not_of(" \t") + 1);

        try {
          
          marsrutss.sakums = sakums;
          marsrutss.gals = gals;
          
          marsrutss.diena = diena;
          marsrutss.laiks = laiks;
          
          size_t vieta;
          
          marsrutss.cena = stod(bilete, &vieta);

        
            if (vieta != bilete.size()) {
              
              marsrutss = {};
                return
                  false;
            }
          return
            true;
        } catch (...) {
          
          marsrutss = {};
          
            return false;
        }
    }

  marsrutss = {};
    return 
      false;
  
}

void marsrutus_lasa(const string& fails, vector<marsruti>& rindas, ofstream& errorFails) {
  
    ifstream inputFile(fails);
    string rinda1;
    int nummurs = 0;

    while (getline(inputFile, rinda1)) {
        nummurs++;

        if (rinda1.empty()) {
            continue;
          
        }

        marsruti marsrutss;
      
        if (rinda(rinda1, marsrutss)) {
            rindas.push_back(marsrutss);
          
        } else {
          
            errorFails  << rinda1 << endl;
          
        }
      
    }

    inputFile.close();
  
}

void pecPieturam(const vector<marsruti>& marsrutii, const string& sakums, const string& gals) {
    cout << "result:" << endl;
    
  for (auto rinda : marsrutii) {
    
        if (rinda.sakums == sakums && rinda.gals == gals) {
            cout << rinda.sakums << " " << rinda.gals << " "
                 << rinda.diena << " " << rinda.laiks << " "
                 << fixed << setprecision(2) << rinda.cena << endl;
        }
    }
  
}

void pecDienas(const vector<marsruti>& marsrutii, const string& diena) {
    cout << "result:" << endl;
  
    for (auto marsrutss : marsrutii) {
        if (marsrutss.diena == diena) {
          
            cout << marsrutss.sakums << " " << marsrutss.gals << " "
                 << marsrutss.diena << " " << marsrutss.laiks << " "
                 << fixed << setprecision(2) << marsrutss.cena << endl;
        }
    }
}

void pecCenas(const vector<marsruti>& marsrutii, double maxCena) {
    cout << "result:" << endl;
  
    for (auto marsrutss : marsrutii) {
      
        if (marsrutss.cena <= maxCena) {
            cout << marsrutss.sakums << " " << marsrutss.gals << " "
                 << marsrutss.diena << " " << marsrutss.laiks << " "
                 << fixed << setprecision(2) << marsrutss.cena << endl;
        }
    }
  
}
