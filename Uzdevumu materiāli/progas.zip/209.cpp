


#include <cctype>
#include <fstream>
#include <iostream>
#include <map>
#include <regex>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct TrainRides { // define the variable structure for train rides
  string startCity;
  string endCity;
  string dotw;
  string time;
  string fare;
};

void errOutput() {             // outputs error file
  ifstream errFile("err.txt"); // opens error file
  if (errFile) {
    string errLine;
    while (getline(errFile, errLine)) {
      cout << errLine << endl;
    }
  }
  errFile.close();
}

void printResult(
    const TrainRides &ride) { // simply outputs single line of train ride
                              // details with space seperator
  cout << ride.startCity << " " << ride.endCity << " " << ride.dotw << " "
       << ride.time << " " << ride.fare << endl;
}

void searchByDay(
    vector<TrainRides> rides) { // searches for train rides by day of the week
  string dotw;
  cin >> dotw;
  for (const auto &ride : rides) {
    if (ride.dotw == dotw) { // checks if day matches
      printResult(ride);
    }
  }
}

void searchByTicketPrice(vector<TrainRides> rides) { // checks if price matches
  double fare;
  cin >> fare;
  for (const auto &ride : rides) {
    if (stod(ride.fare) <= fare) { // converts string value to double
      printResult(ride);
    }
  }
}

void searchByStartEndCities(
    vector<TrainRides>
        rides) { // searches for train rides based on start and end cities
  string startCity, endCity;
  cin >> startCity;
  cin >> endCity;
  for (const auto &ride : rides) {
    if (ride.startCity == startCity &&
        ride.endCity == endCity) { // checks for both cities to match
      printResult(ride);
    }
  }
}

bool isNumber(const string &value) { // checks if string is a number
  try {
    stod(value);
    return true;
  } catch (const invalid_argument &e) {
    return false;
  } catch (const out_of_range &e) {
    return false;
  }
}

int main() {

  ifstream inFile("db.csv"); // opens database file
  if (!inFile)
    return 0; // if database empty, program closes

  ofstream outFile(
      "err.txt"); // opens error file in which faulty lines are input

  map<string, int> days = {
      {"Pr", 1}, {"Ot", 2}, {"Tr", 3}, {"Ce", 4},
      {"Pt", 5}, {"St", 6}, {"Sv", 7}}; // maps day names to numbers

  regex timeFormat(
      R"(^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$)"); // regex expression for checking
                                               // if time format for train rides
                                               // is correct

  // regex expression for checking in whole line is correct, but this didn't
  // work
  // formatRegex(R"(^([A-Za-z]+)\s*,\s*([A-Za-z]+)\s*,\s*(Pr|Ot|Tr|Ce|Pt|St|Sv)\s*,\s*(([0-1]?[0-9]|2[0-3]):[0-5][0-9])\s*,\s*(\d+\.\d{2})$)");

  string line;              // stores line from database file
  vector<TrainRides> rides; // vector of train rides

  while (getline(inFile >> ws, line)) { // reads line from database file
    string startCity, endCity, dotw, time, fare;
    int i = 1;
    string value =
        ""; // creates a valuevariable in which singular characters are input
    for (char c : line) {
      if (c != ' ' && c != ',' &&
          c != '\r') { // checks if character is space or comma or end of line
        value += c;    // concatenates char to word
      }
      if (i == 5) { // if looking at 5th word after comma then stores ride fare
        fare = value;
      }
      if (c == ',') {
        if (i ==
            1) { // if looking at 1st word after comma stores ride start city
          if (!isNumber(value)) {
            startCity = value;
            i++;
          } else {
            continue;
          }
        } else if (i == 2) { // if looking at 2nd word after comma stores ride
                             // end city
          if (!isNumber(value)) {
            endCity = value;
            i++;
          } else {
            continue;
          }
        } else if (i == 3) { // if looking at 3rd word after comma stores ride
                             // day of the week
          if (!(days.count(value) == 0)) {
            dotw = value;
            i++;
          } else {
            continue;
          }
        } else if (i ==
                   4) { // if looking at 4th word after comma stores ride time
          try {
            double wordtodouble = stod(value);
          } catch (const invalid_argument
                       &e) { // there are letters in time so regex is used
            continue;
          }
          if (regex_match(value, timeFormat)) { // stores time variable only if
                                                // format is correct
            time = value;
            i++;
          } else {
            continue;
          }
        } else if (i == 5) {
          i++;
        }
        value = ""; // clears stored value for next train ride detail variable
      }
    }
    if (i == 5) {

      try {
        size_t pos; // finds position of comma in line
        string value = fare;
        double wordtodouble = stod(value, &pos); // converts fare to double
        if (pos < value.size()) {                // if fare contains letters
          outFile << line << endl; // outputs faulty line to error file
          continue;
        }
      } catch (const invalid_argument &e) {
        continue;
      } catch (const out_of_range &e) {
        continue;
      }

      rides.push_back(
          {startCity, endCity, dotw, time, fare}); // adds train ride to vector

    } else {
      outFile << line << endl;
    }
  }

  inFile.close(); // closes used files for memory management
  outFile.close();

  string charInput; // defines variable for user input

  while (true) { // main while loop which culminates when user inputs "e"
    cin >> charInput;

    if (charInput == "a") {
      cout << "result:" << endl;
      searchByStartEndCities(rides);
    } else if (charInput == "b") {
      cout << "result:" << endl;
      searchByDay(rides);
    } else if (charInput == "c") {
      cout << "result:" << endl;
      searchByTicketPrice(rides);
    } else if (charInput == "d") {
      cout << "result:" << endl;
      errOutput();
    } else if (charInput == "e") {
      break;
    }
  }
}