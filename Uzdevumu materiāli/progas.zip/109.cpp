#include <algorithm>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>



using namespace std;
void removeCommas(string &str) {
  str.erase(remove(str.begin(), str.end(), ' '), str.end());
}

int main() {
  struct route {
    string *peremnaya1Arr; 
    string peremnaya2;
    string peremnaya3;
    string peremnaya4;
    string peremnaya5;
    string peremnaya6;
    int isFull;
  };

  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) {
    cerr << "Сan't open file." << endl;
    return 1;
  }

  string line;
  vector<string> lineArr;
  vector<string> unliquinArr;

  while (getline(inFile, line)) {
    if (line.size() != 1) {
      int commaCount = 0;
      for (char ch : line) {
        if (ch == ',') {
          commaCount++;
        }
      }
      if (commaCount == 4) {
        lineArr.push_back(line);
      }
    }
  }

  inFile.close();

  route *peremnaya7 = new route[lineArr.size()];

  for (int i = 0; i < lineArr.size(); i++) {
    istringstream ss(lineArr[i]);
    string token;
    int j = 0;

    peremnaya7[i].peremnaya1Arr = new string[5]; 

    while (getline(ss, token, ',')) {
      removeCommas(token);
      if (j < 5) {
        peremnaya7[i].peremnaya1Arr[j++] = token;
      }
    }

   
    removeCommas(peremnaya7[i].peremnaya1Arr[4]);

    if (any_of(peremnaya7[i].peremnaya1Arr[0].begin(), peremnaya7[i].peremnaya1Arr[0].end(),
               [](char c) { return isdigit(c); }) == false) {
      peremnaya7[i].peremnaya2 = peremnaya7[i].peremnaya1Arr[0];
    }
    if (any_of(peremnaya7[i].peremnaya1Arr[1].begin(), peremnaya7[i].peremnaya1Arr[1].end(),
               [](char c) { return isdigit(c); }) == false) {
      peremnaya7[i].peremnaya3 = peremnaya7[i].peremnaya1Arr[1];
    }
    if (any_of(peremnaya7[i].peremnaya1Arr[2].begin(), peremnaya7[i].peremnaya1Arr[2].end(),
               [](char c) { return isdigit(c); }) == false &&
        peremnaya7[i].peremnaya1Arr[2].length() < 3) {
      peremnaya7[i].peremnaya4 = peremnaya7[i].peremnaya1Arr[2];
    }
    string str = peremnaya7[i].peremnaya1Arr[3];
    if (peremnaya7[i].peremnaya1Arr[3].size() == 5) {
      if (isdigit(str[0]) && isdigit(str[1]) && str[2] == ':' &&
          isdigit(str[3]) && isdigit(str[4])) {

        peremnaya7[i].peremnaya5 = peremnaya7[i].peremnaya1Arr[3];
      }
    }

    string str2 = peremnaya7[i].peremnaya1Arr[4];

    if (str2.find('.') != string::npos) {
      peremnaya7[i].peremnaya6 = peremnaya7[i].peremnaya1Arr[4];
    }
  }

  for (int i = 0; i < lineArr.size(); i++) {
    if (peremnaya7[i].peremnaya2.size() < 2 || peremnaya7[i].peremnaya3.size() < 2 ||
        peremnaya7[i].peremnaya4.size() < 2 || peremnaya7[i].peremnaya5.size() < 2 ||
        peremnaya7[i].peremnaya6.size() < 2) {

      peremnaya7[i].isFull = 0;

    } else {
      peremnaya7[i].isFull = 1;
    }
  }
  vector<route> clearedRoutes;
  vector<string> unsipicle;
  for (int i = 0; i < lineArr.size(); i++) {
    if (peremnaya7[i].isFull == 1) {
      clearedRoutes.push_back(peremnaya7[i]);
    } else {
      unsipicle.push_back(lineArr[i]);
    }
  }


  while (true) {
    string check = " ";
    cin >> check;
    if (check == "a") {
      string peremnaya8 = " ";
      string peremnaya9 = " ";
      cin >> peremnaya8;
      cin >> peremnaya9;
      cout << "result:" << endl;
      for (int i = 0; i < clearedRoutes.size(); i++) {
        if (clearedRoutes[i].peremnaya2 == peremnaya8 &&
            clearedRoutes[i].peremnaya3 == peremnaya9) {

          cout << clearedRoutes[i].peremnaya2 << " " << clearedRoutes[i].peremnaya3
               << " " << clearedRoutes[i].peremnaya4 << " "
               << clearedRoutes[i].peremnaya5 << " " << clearedRoutes[i].peremnaya6
               << endl;
        }
      }
    }
    if (check == "b") {
      cout<<"result: "<<endl;
      string peremnaya10;
      cin >> peremnaya10;
      for (int i = 0; i < clearedRoutes.size(); i++) {
        if (clearedRoutes[i].peremnaya4 == peremnaya10) {
          cout << "" << clearedRoutes[i].peremnaya2 << " " << clearedRoutes[i].peremnaya3
               << " " << clearedRoutes[i].peremnaya4 << " "
               << clearedRoutes[i].peremnaya5 << " " << clearedRoutes[i].peremnaya6
               << endl;
        }
      }
    }
    if (check == "c") {
      cout << "result:" << endl;
      float peremnaya11;
      cin >> peremnaya11;
      for (int i = 0; i < clearedRoutes.size(); i++) {
        if (peremnaya11 >= stof(clearedRoutes[i].peremnaya6)) {
          cout << "" << clearedRoutes[i].peremnaya2;
          cout << " " << clearedRoutes[i].peremnaya3;
          cout << " " << clearedRoutes[i].peremnaya4;
          cout << " " << clearedRoutes[i].peremnaya5;
          cout << " " << clearedRoutes[i].peremnaya6;
          cout << endl;
        }
      }
    }
    if (check == "d") {
      ifstream inFile2; 
      inFile2.open("db.csv");

      while (getline(inFile2, line)) {
        
        if (line.size() != 0) {
          string str = "";
          for (char ch : line) {

            if (ch != ' ' && ch != ',') {
              str = str + ch;
            }
          }
          int count = 0;
          for (int i = 0; i < clearedRoutes.size(); i++) {
            string str2 = clearedRoutes[i].peremnaya2 + clearedRoutes[i].peremnaya3 +
                          clearedRoutes[i].peremnaya4 + clearedRoutes[i].peremnaya5 +
                          clearedRoutes[i].peremnaya6;
          
            if (str == str2) {
              count++;
            }
          }
          if (count == 0) {
            unliquinArr.push_back(line);
          }
        }
      }

      inFile.close();
      ofstream outFile("err.txt");
      if (!outFile) {
        std::cerr << "Не удалось открыть файл для записи." << std::endl;
        return 1;
      }

      for (int i = 0; i < unliquinArr.size(); ++i) {
        outFile << unliquinArr[i] << "\n";
      }

      cout << "result:" << endl;

      for (int i = 0; i < unliquinArr.size(); i++) {
        cout << unliquinArr[i] << endl;
      }
    }
    if (check == "e") {
      return 0;
    }

  }
  return 0;
}