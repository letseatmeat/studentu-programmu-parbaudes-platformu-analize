

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

void a() {
    ifstream inFile;
    inFile.open("db.csv");

    ofstream outError;
    outError.open("err.txt");

    string firstCity, secondCity;

    cin >> firstCity;
    cin >> secondCity;

    string csv, line, assembly; 
    int times;
    vector<string> splitLinesRaw, splitLinesSpace, splitLines;

	while (getline(inFile, csv)) {
        if (csv.size() > 1) {
            stringstream LineStream(csv);
            while(getline(LineStream, line, ','))
                splitLinesRaw.push_back(line);
            splitLinesRaw.push_back("endl");
        }
    }

    inFile.close();
    
    for (int i = 0; i < splitLinesRaw.size(); i++) {
        string word = splitLinesRaw[i];
        for (char ch : word)
            if (ch != ' ') assembly += ch;
        splitLinesSpace.push_back(assembly);
        assembly.clear();
    }

    for (int i = 0; i < splitLinesSpace.size(); i++) {
        int k = 0;
        if (splitLinesSpace[i].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
                
        if (splitLinesSpace[i + 1].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
        
        if (splitLinesSpace[i + 2] == "Pr" || splitLinesSpace[i + 2] == "Ot" || splitLinesSpace[i + 2] == "Tr" || splitLinesSpace[i + 2] == "Ce" || splitLinesSpace[i + 2] == "Pt" || splitLinesSpace[i + 2] == "St" || splitLinesSpace[i + 2] == "Sv")
            k++;
        
        if (splitLinesSpace[i + 3].length() == 5) {
            if (splitLinesSpace[i + 3].substr(2, 1) == ":"){
                string hours = splitLinesSpace[i + 3].substr(0 ,2);
                string min = splitLinesSpace[i + 3].substr(3, 2);
                try {
                    int intHours = stoi(hours);
                    int intMin = stoi(min);
                    if (intHours >= 0 & intHours <= 23 && intMin >= 0 & intMin <= 59)
                        k++;
                } catch (const invalid_argument){}
                catch (const out_of_range) {}
            }
        }

        try {
            string tmp = splitLinesSpace[i + 4];
            stoi(tmp);
            k++;
        } catch (const invalid_argument){}
        catch (const out_of_range) {}
        
        if (k == 5  && splitLinesSpace[i + 5] == "endl") {
            splitLines.push_back(splitLinesSpace[i]);
            splitLines.push_back(splitLinesSpace[i + 1]);
            splitLines.push_back(splitLinesSpace[i + 2]);
            splitLines.push_back(splitLinesSpace[i + 3]);
            splitLines.push_back(splitLinesSpace[i + 4]);
            i += 5;
        } else {
            int j = 0;
            string out = "";
            while (splitLinesSpace[i + j] != "endl") {
                if (splitLinesSpace[i + j + 1] == "endl")
                    out += splitLinesSpace[i + j];
                else
                    out += splitLinesSpace[i + j] + ",";
                j++;
            } 
            i += j;
            outError << out << endl;
        }
        
    }

    outError.close();

    cout << "result:" << endl;
    for (int i = 0; i < splitLines.size(); i += 5) {
        if (firstCity == splitLines[i] && secondCity == splitLines[i + 1])
            cout << splitLines[i] << " " << splitLines[i + 1] << " " << splitLines[i + 2] << " " << splitLines[i + 3] << " " << splitLines[i + 4] << endl;
    }

}

void b() {
    ifstream inFile;
    inFile.open("db.csv");

    ofstream outError;
    outError.open("err.txt");

    string day;
    cin >> day;

    string csv, line, assembly; 
    vector<string> splitLinesRaw, splitLinesSpace, splitLines;

	while (getline(inFile, csv)) {
        if (csv.size() > 1) {
            stringstream LineStream(csv);
            while(getline(LineStream, line, ','))
                splitLinesRaw.push_back(line);
            splitLinesRaw.push_back("endl");
        }
    }

    inFile.close();

    for (int i = 0; i < splitLinesRaw.size(); i++) {
        string word = splitLinesRaw[i];
        for (char ch : word) 
            if (ch != ' ') assembly += ch;
        splitLinesSpace.push_back(assembly);
        assembly.clear();
    }

    for (int i = 0; i < splitLinesSpace.size(); i++) {
        int k = 0;
        if (splitLinesSpace[i].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
                
        if (splitLinesSpace[i + 1].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
        
        if (splitLinesSpace[i + 2] == "Pr" || splitLinesSpace[i + 2] == "Ot" || splitLinesSpace[i + 2] == "Tr" || splitLinesSpace[i + 2] == "Ce" || splitLinesSpace[i + 2] == "Pt" || splitLinesSpace[i + 2] == "St" || splitLinesSpace[i + 2] == "Sv")
            k++;
        
        if (splitLinesSpace[i + 3].length() == 5) {
            if (splitLinesSpace[i + 3].substr(2, 1) == ":"){
                string hours = splitLinesSpace[i + 3].substr(0 ,2);
                string min = splitLinesSpace[i + 3].substr(3, 2);
                try {
                    int intHours = stoi(hours);
                    int intMin = stoi(min);
                    if (intHours >= 0 & intHours <= 23 && intMin >= 0 & intMin <= 59)
                        k++;
                } catch (const invalid_argument){}
                catch (const out_of_range) {}
            }
        }

        try {
            string tmp = splitLinesSpace[i + 4];
            stoi(tmp);
            k++;
        } catch (const invalid_argument){}
        catch (const out_of_range) {}
        
        if (k == 5  && splitLinesSpace[i + 5] == "endl") {
            splitLines.push_back(splitLinesSpace[i]);
            splitLines.push_back(splitLinesSpace[i + 1]);
            splitLines.push_back(splitLinesSpace[i + 2]);
            splitLines.push_back(splitLinesSpace[i + 3]);
            splitLines.push_back(splitLinesSpace[i + 4]);
            i += 5;
        } else {
            int j = 0;
            string out = "";
            while (splitLinesSpace[i + j] != "endl") {
                if (splitLinesSpace[i + j + 1] == "endl")
                    out += splitLinesSpace[i + j];
                else
                    out += splitLinesSpace[i + j] + ",";
                j++;
            } 
            i += j;
            outError << out << endl;
        }
        
    }

    outError.close();

    cout << "result:" << endl;
    for (int i = 0; i < splitLines.size(); i += 5){
        if (day == splitLines[i + 2] )
            cout << splitLines[i] << " " << splitLines[i + 1] << " " << splitLines[i + 2] << " " << splitLines[i + 3] << " " << splitLines[i + 4] << endl;
    }

}

void c() {
    ifstream inFile;
    inFile.open("db.csv");

    ofstream outError;
    outError.open("err.txt");

    double price;
    cin >> price;

    string csv, line, assembly; 
    vector<string> splitLinesRaw, splitLinesSpace, splitLines;

	while (getline(inFile, csv)) {
        if (csv.size() > 1) {
            stringstream LineStream(csv);
            while(getline(LineStream, line, ','))
                splitLinesRaw.push_back(line);
            splitLinesRaw.push_back("endl");
        }
    }

    inFile.close();

    for (int i = 0; i < splitLinesRaw.size(); i++) {
        string word = splitLinesRaw[i];
        for (char ch : word) 
            if (ch != ' ') assembly += ch;
        splitLinesSpace.push_back(assembly);
        assembly.clear();
    }

    for (int i = 0; i < splitLinesSpace.size(); i++) {
        int k = 0;
        if (splitLinesSpace[i].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
                
        if (splitLinesSpace[i + 1].find_first_not_of("aābcčdeēfgģhiījkķlļmņoprsštūvzžAĀBCČDEĒFGĢHIĪJKĶLĻMŅOPRSŠTUŪVZŽ"))
            k++;
        
        if (splitLinesSpace[i + 2] == "Pr" || splitLinesSpace[i + 2] == "Ot" || splitLinesSpace[i + 2] == "Tr" || splitLinesSpace[i + 2] == "Ce" || splitLinesSpace[i + 2] == "Pt" || splitLinesSpace[i + 2] == "St" || splitLinesSpace[i + 2] == "Sv")
            k++;
        
        if (splitLinesSpace[i + 3].length() == 5) {
            if (splitLinesSpace[i + 3].substr(2, 1) == ":"){
                string hours = splitLinesSpace[i + 3].substr(0 ,2);
                string min = splitLinesSpace[i + 3].substr(3, 2);
                try {
                    int intHours = stoi(hours);
                    int intMin = stoi(min);
                    if (intHours >= 0 & intHours <= 23 && intMin >= 0 & intMin <= 59)
                        k++;
                } catch (const invalid_argument){}
                catch (const out_of_range) {}
            }
        }

        try {
            string tmp = splitLinesSpace[i + 4];
            stoi(tmp);
            k++;
        } catch (const invalid_argument){}
        catch (const out_of_range) {}
        
        if (k == 5  && splitLinesSpace[i + 5] == "endl") {
            splitLines.push_back(splitLinesSpace[i]);
            splitLines.push_back(splitLinesSpace[i + 1]);
            splitLines.push_back(splitLinesSpace[i + 2]);
            splitLines.push_back(splitLinesSpace[i + 3]);
            splitLines.push_back(splitLinesSpace[i + 4]);
            i += 5;
        } else {
            int j = 0;
            string out = "";
            while (splitLinesSpace[i + j] != "endl") {
                if (splitLinesSpace[i + j + 1] == "endl")
                    out += splitLinesSpace[i + j];
                else
                    out += splitLinesSpace[i + j] + ",";
                j++;
            } 
            i += j;
            outError << out << endl;
        }
        
    }

    cout << "result:" << endl;
    for (int i = 0; i < splitLines.size(); i += 5){
        try {
            string tmp = splitLines[i + 4];
            if (price >= stod(tmp))
                cout << splitLines[i] << " " << splitLines[i + 1] << " " << splitLines[i + 2] << " " << splitLines[i + 3] << " " << splitLines[i + 4] << endl;
        } catch (const invalid_argument){
          continue;
        } catch (const out_of_range) {
          continue;
        }
    }

}

void d() {
    ifstream inFile("err.txt");

    string csv;
    cout << "result:" << endl;
	while (getline(inFile, csv))
        cout << csv << endl;
}


int main() {
    ifstream inFile;
    inFile.open("db.csv");
    if (!inFile) return 0;

    string input;  
    int inputInt;
    while(input != "e"){

        cin >> input;
    
        if (input == "a") inputInt = 1;
        else if (input == "b") inputInt = 2;
        else if (input == "c") inputInt = 3;
        else if (input == "d") inputInt = 4;
        else if (input == "e") inputInt = 5;

        switch (inputInt) {
		    case 1:
		    	a();
                cout << endl;
		    	break;
		    case 2:
			    b();
                cout << endl;
				break;
		    case 3:
			    c();
                cout << endl;
				break;
            case 4:
				d();
                cout << endl;
                break;
            case 5:
				break;
                cout << endl;
			}

    }

} 
