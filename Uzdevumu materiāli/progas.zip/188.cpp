#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

struct Trip {
  string Start;
  string End;
  string Day;
  string Time;
  double Price;
};
string trim(const string &str){
  size_t First =str.find_first_not_of(" \t\n\f\v");
  if (First == string::npos)
    return "";
  size_t Last =str.find_last_not_of(" \t\n\f\v");
  return str.substr(First,(Last - First + 1));
}
bool isDuplicate(const Trip &NewTrip,const Trip *Trips,int TripCount){
  for (int i = 0; i < TripCount; ++i) {
    if (Trips[i].Start == NewTrip.Start && Trips[i].End ==NewTrip.End &&
        Trips[i].Day ==NewTrip.Day && Trips[i].Time ==NewTrip.Time &&
        Trips[i].Price ==NewTrip.Price){
      return true;
    }
  }
  return false;
}
Trip *parseTripsFromFile(const string &Filename,int &TripCount,ofstream &errFile){
  ifstream file(Filename);
  string Line;
  int Cap = 10;
  TripCount = 0;
  Trip *trips = new Trip[Cap];
  bool FirstErrorWritten = false;
  while (getline(file, Line)) {
    if (Line.empty() || all_of(Line.begin(), Line.end(), ::isspace)){
      continue;
    }
    if (TripCount == Cap) {
      Cap *= 2;
      Trip *newTrips = new Trip[Cap];
      for (int i = 0; i < TripCount; ++i) {
        newTrips[i] = trips[i];
      }
      delete[] trips;
      trips = newTrips;
    }
    stringstream ss(Line);
    string start, end, day, time;
    double price;
    if (getline(ss,start, ',') && getline(ss, end, ',') &&
        getline(ss, day, ',') && getline(ss,time, ',') && ss >> price){
      string extra;
      if (ss >> extra) {
        if (!FirstErrorWritten) {
          errFile << "result:\n";
          FirstErrorWritten = true;
        }
        errFile << Line << '\n';
      } else {
        Trip newTrip = {trim(start), trim(end), trim(day), trim(time), price};
        if (!isDuplicate(newTrip, trips, TripCount)) {
          trips[TripCount++] = newTrip;
        }
      }
    } else {
      if (!Line.empty()){
        if (!FirstErrorWritten) {
          errFile <<"result:\n";
          FirstErrorWritten = true;
        }
        errFile << Line<< '\n';
      }
    }
  }
  file.close();
  return trips;
}
void displayTrips(const Trip *Trips,int TripCount){
  cout << "result:"<< endl;
  for (int i = 0;i <TripCount;++i) {
    cout << Trips[i].Start << " "<< Trips[i].End << " " << Trips[i].Day<< " "
         << Trips[i].Time << " " << fixed<< setprecision(2) << Trips[i].Price
         << endl;
  }
}
int main(){
  ofstream errFile("err.txt");
  int TripCount;
  Trip *trips = parseTripsFromFile("db.csv",TripCount,errFile);
  errFile.close();
  char Com;
  while (true) {
    cin >> Com;
    if (Com == 'e')
      break;
    switch (Com){
    case 'a':{
      string start, end;
      cin >> start>> end;
      bool IsFirst = true;
      for (int i = 0;i < TripCount;++i){
        if (trips[i].Start ==start && trips[i].End ==end){
          if (IsFirst){
            cout << "result:" << endl;
            IsFirst = false;
          }
          cout << trips[i].Start << " " << trips[i].End << " " << trips[i].Day
               << " " << trips[i].Time << " " << fixed << setprecision(2)
               << trips[i].Price << endl;
        }
      }
      break;
    }
    case 'b':{
      string Day;
      cin >> Day;
      bool IsFirst = true;
      for (int i = 0;i <TripCount;++i){
        if (trips[i].Day ==Day){
          if (IsFirst) {
            cout << "result:"<< endl;
            IsFirst =false;
          }
          cout << trips[i].Start << " " << trips[i].End << " " << trips[i].Day
               << " " << trips[i].Time << " " << fixed << setprecision(2)
               << trips[i].Price << endl;
        }
      }
      break;
    }
    case 'c':{
      double MaxPrice;
      cin >> MaxPrice;
      bool IsFirst = true;
      for (int i = 0;i < TripCount;++i){
        if (trips[i].Price <= MaxPrice){
          if (IsFirst) {
            cout << "result:" << endl;
            IsFirst = false;
          }
          cout << trips[i].Start << " " << trips[i].End << " " << trips[i].Day
               << " " << trips[i].Time << " " << fixed << setprecision(2)
               << trips[i].Price << endl;
        }
      }
      break;
    }
    case 'd':{
      ifstream errFileRead("err.txt");
      string Line;
      bool hasErrors = errFileRead.peek() != ifstream::traits_type::eof();

      while (getline(errFileRead,Line)){
        cout << Line<< "\n";
      }
      errFileRead.close();
      break;
    }
    default:
      cout << "Invalid command" << endl;
      break;
    }
  }
  delete[] trips;
  return 0;
}