
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
using namespace std;

void creating_temp_files();
void print_err();
void city_route();
void day_route();
void price_route();

int main() {

  creating_temp_files();

  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  string command;
  while (command[0] != 'e') {
    // cout << "command:> ";
    cin >> command;
    if (command == "admin")
      break;

    if (command.length() > 1) {
      cout << "unknown command" << endl;
      continue;
    }
    switch (command[0]) {
    case 'a':
      city_route();
      break;
    case 'b':
      day_route();
      break;
    case 'c':
      price_route();
      break;
    case 'd':
      print_err();
      break;
    case 'e':
      remove("err.txt");
      remove("temp.txt");
      inFile.close();
      return 0;
    default:
      cout << "unknown command" << endl;
    }
  }
}

void creating_temp_files() {
  ifstream inFile;
  inFile.open("db.csv");
  int count = 0;

  ofstream outputFile("temp.txt");
  ofstream errFile("err.txt");

  string s;
  string e;
  int elements = 0;
  while (getline(inFile, s)) {

    // parbaude uz tuksam rindam
    if (s.length() == 0)
      continue;
    // elementu skaitu parbaude
    int countComas = 0;
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ',') {
        countComas++;
      }
    }
    if (countComas != 4) {
      errFile << s << endl;
      continue;
    }

    e = s;

    // parbaude, vai rindaa ir liekas atstarpes
    for (int i = 0; i < e.length(); i++) {
      if (e[i] == ' ') {
        for (int j = i; j < e.length(); j++) {
          e[j] = e[j + 1];
        }
        e.pop_back();
        i = 0;
      }
    }
    if (e[0] == ' ')
      e.erase(e.begin());

    istringstream ss(e);
    string token;

    string arr[5];
    int c = 0;
    bool check = true;
    // Parbaudam elementu secibu un pareizrakstibu
    while (getline(ss, token, ',')) {
      arr[c++] = token;
      // pilsetu nosaukumi
      if (c == 1 || c == 2) {
        for (char t : token) {
          if (!isalpha(t)) {
            check = false;
            break;
          }
        }
      }
      // dienas
      if (c == 3) {
        if (token != "Pr" && token != "Ot" && token != "Tr" && token != "Ce" &&
            token != "Pt") {
          check = false;
          break;
        }
      }
      // laiks
      if (c == 4) {
        if (token.length() == 5 && token[2] == ':') {
          try {
            int hours = stoi(token.substr(0, 2));
            int minutes = stoi(token.substr(3, 2));
            if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59)
              throw invalid_argument("");
          } catch (const std::invalid_argument &e) {
            check = false;
            break;
          }
        }
      }
      // cena
      if (c == 5) {
        try {
          stod(token);
        } catch (const std::invalid_argument &e) {
          check = false;
          break;
        }
      }
    }
    if (!check) {
      errFile << s << endl;
      continue;
    }
    
    outputFile << e << endl;
  }
  outputFile.close();
  errFile.close();
  inFile.close();
}

void print_err() {
  ifstream errFile;
  errFile.open("err.txt");
  cout << "result:" << endl;

  string s;
  while (getline(errFile, s)) {
    cout << s << endl;
  }

  errFile.close();
}

void city_route() {
  ifstream inFile;
  inFile.open("temp.txt");

  string city1;
  string city2;

  cin >> city1;
  cin >> city2;

  string s;
  string arr[2];

  int count;
  cout << "result:" << endl;
  while (getline(inFile, s)) {
    istringstream ss(s);
    string token;
    count = 0;
    while (getline(ss, token, ',')) {
      if (count > 1)
        break;
      arr[count++] = token;
    }
    if (arr[0] == city1 && arr[1] == city2) {
      string e = s;

      for (int i = 0; i < s.length(); i++) {
        if (s[i] == ',')
          e[i] = ' ';
      }
      cout << e << endl;
    }
  }
  inFile.close();
}

void day_route() {
  ifstream inFile;
  inFile.open("temp.txt");

  string day;
  cin >> day;

  if (day != "Pr" && day != "Ot" && day != "Tr" && day != "Ce" && day != "Pt") {
    cout << "wrong day name" << endl;
    return;
  }
  cout << "result:" << endl;
  int count;
  string s;
  while (getline(inFile, s)) {
    istringstream ss(s);
    string token;
    string arr[3];
    count = 0;
    while (getline(ss, token, ',')) {
      if (count > 2)
        break;
      arr[count++] = token;

      if (arr[2] == day) {
        string e = s;
        for (int i = 0; i < s.length(); i++) {
          if (s[i] == ',')
            e[i] = ' ';
        }
        cout << e << endl;
        break;
      }
    }
  }
  inFile.close();
}

void price_route() {
  ifstream inFile;
  inFile.open("temp.txt");

  string price;
  cin >> price;
  double cena;
  // ievaditas cenas parbaude
  try {
    cena = stod(price);
    if (cena < 0)
      throw invalid_argument("");
    for (int i = 0; i < price.length(); i++) {
      if (!isdigit(price[i]) && price[i] != '.') {
        throw invalid_argument("");
      }
    }
  } catch (const std::invalid_argument &e) {
    cout << "invalid price" << endl;
    return;
  }

  string s;
  double price_check;
  cout << "result:" << endl;
  while (getline(inFile, s)) {
    for (int i = s.length(); i >= 0; i--) {
      if (s[i] == ',') {
        price_check = stod(s.substr(i + 1, s.length() - 1));
        break;
      }
    }
    if (price_check <= cena) {
      string e = s;
      for (int i = 0; i < s.length(); i++) {
        if (s[i] == ',')
          e[i] = ' ';
      }
      cout << e << " " << endl;
    }
  }
  inFile.close();
}