

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

// structure for the text
struct File_Info {
  string FirstCity, SecondCity, Day, Time;
  double cost1;
};

// vector of Route of positions
File_Info RoutePositions(string &string1) {
  File_Info position;
  istringstream i(string1);
  string text_part;
  vector<string> FileText;
  while (getline(i, text_part, ',')) {
    FileText.push_back(text_part);
  }

  // declaring size and positions
  if (FileText.size() == 5) {
    position.FirstCity = FileText[0];
    position.SecondCity = FileText[1];
    position.Day = FileText[2];
    position.Time = FileText[3];
    position.cost1 = stod(FileText[4]);
  }
  return position;
}

// checking Line Pattern
void CheckPattern(string &text_line, vector<File_Info> &positions,
                  ofstream &ErrorFile, File_Info &position) {
  if (!(position.FirstCity.empty() ||
        any_of(position.FirstCity.begin(), position.FirstCity.end(),
               ::isdigit) ||
        position.SecondCity.empty() ||
        any_of(position.SecondCity.begin(), position.SecondCity.end(),
               ::isdigit) ||
        position.Day.empty() ||
        any_of(position.Day.begin(), position.Day.end(), ::isdigit) ||
        position.Time.empty() || position.cost1 <= 0.00)) {
    positions.push_back(position);
  } else {
    ErrorFile << text_line << endl;
  }
}

// printing routes by positions
void FindRoutes(const File_Info &position) {
  cout << position.FirstCity << " " << position.SecondCity << " "
       << position.Day << " " << position.Time << " " << fixed
       << setprecision(2) << position.cost1 << endl;
}

bool a(const vector<File_Info> &positions) {
  string FirstCity, SecondCity;
  cin >> FirstCity >> SecondCity;
  cout << "result:" << endl;
  bool found = false;
  for (const auto &position : positions) {
    if (position.FirstCity == FirstCity && position.SecondCity == SecondCity) {
      FindRoutes(position);
      found = true;
    }
  }
  return found;
}

bool b(const File_Info &position, const string &Users_Day) {
  return position.Day == Users_Day;
}

bool c(const vector<File_Info> &positions) {
  double cost;
  cin >> cost;
  cout << "result:" << endl;
  bool found = false;

  for (const auto &position : positions) {
    if (position.cost1 <= cost) {
      FindRoutes(position);
      found = true;
    }
  }
  return found;
}

bool d(const string &errorFilePath) {
  ifstream ErrorFile(errorFilePath);
  if (!ErrorFile.is_open()) {
    return false;
  }

  string s;
  cout << "result:" << endl;
  while (getline(ErrorFile, s)) {
    cout << s << endl;
  }

  ErrorFile.close();
  return true;
}

int main() {
  vector<File_Info> positions;
  string text_line;
  fstream inFile;
  ofstream ErrorFile;
  inFile.open("db.csv");
  ErrorFile.open("err.txt");

  if (inFile.is_open()) {
    while (getline(inFile, text_line)) {
      text_line.erase(
          std::remove_if(text_line.begin(), text_line.end(), ::isspace),
          text_line.end());

      if (text_line.empty())
        continue;
      File_Info position = RoutePositions(text_line);
      CheckPattern(text_line, positions, ErrorFile, position);
    }
    inFile.close();
    ErrorFile.close();
  } else {
    cout << "File is closed" << endl;
    return 1;
  }
  char usersLetter;
  while (true) {
    cin >> usersLetter;

    switch (usersLetter) {
    case 'a': {
      if (!a(positions)) {
      }
      break;
    }
    case 'b': {
      string Users_Day;
      cout << "Day: ";
      cin >> Users_Day;
      cout << "result:" << endl;
      for (const auto &position : positions) {
        if (b(position, Users_Day)) {
          FindRoutes(position);
        }
      }
      break;
    }
    case 'c': {
      if (!c(positions)) {
      }
      break;
    }

    case 'd': {
      if (!d("err.txt")) {
        cout << "Failed to read the error file." << endl;
      }
      break;
    }

    case 'e': {
      exit(0);
    }
    default:
      cout << "not working" << endl;
      break;
    }
  }
}