
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool navSkaitlis(const string &s) {
  bool komats = false;
  for (char c : s) {
    if (!isdigit(c)) {
      if (c == '.' && !komats) {
        komats = true;
      } else {
        return true;
      }
    }
  }
  return false;
}
int main() {
  vector<vector<string>> dati;
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;
  ofstream outfile("err.txt");
  if (!outfile) {
    return 0;
  }
  string rinda;
  while (getline(inFile, rinda)) {
    string sakumaRinda = rinda;
    rinda.erase(remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());
    if (rinda == "") {
      continue;
    }
    int ieraksti = count(rinda.begin(), rinda.end(), ',');
    if (ieraksti != 4) {
      outfile << sakumaRinda << endl;
      continue;
    }
    string sakums = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string galapunkts = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string diena = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string laiks = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string cena = rinda;
    if (navSkaitlis(cena)) {
      outfile << sakumaRinda << endl;
      continue;
    }
    dati.push_back({sakums, galapunkts, diena, laiks, cena});
  }
  inFile.close();
  outfile.close();
  string ievade = "";
  while (ievade != "e") {
    cin >> ievade;
    if (ievade == "e") {
      continue;
    }
    if (ievade == "a") {
      string sakums, galapunkts;
      cin >> sakums >> galapunkts;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (rinda[0] != sakums || rinda[1] != galapunkts) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts<<" ";
        }
        cout << endl;
      }
    }
    if (ievade == "b") {
      string diena;
      cin >> diena;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (rinda[2] != diena) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts << " ";
        }
        cout << endl;
      }
    }
    if (ievade == "c") {
      double biletesCena;
      cin >> biletesCena;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (stod(rinda[4]) >= biletesCena) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts << " ";
        }
        cout << endl;
      }
    }
    if (ievade == "d") {
      cout << "result:" << endl;
      ifstream inFile("err.txt");
      if (!inFile) {
        return 0;
      }
      inFile.clear();
      inFile.seekg(0);
      while (inFile >> rinda) {
        cout << rinda << endl;
      }
      inFile.close();
    }
  }
}