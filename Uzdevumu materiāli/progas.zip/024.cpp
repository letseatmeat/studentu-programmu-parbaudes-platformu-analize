
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

#define _GLIBCXX_USE_CXX11_ABI 0

struct AutobusaMarsruts {
    std::string sakumaPietura;
    std::string galaPietura;
    std::string nedelasDiena;
    std::string laiks;
    double billetesCena;
};

std::vector<AutobusaMarsruts> IelasitDatus(const std::string& failaNosaukums) {
    std::ifstream fails(failaNosaukums);
    std::vector<AutobusaMarsruts> marsruti;

    if (!fails.is_open()) {
        std::cerr << "Nevar atvert failu: " << failaNosaukums << std::endl;
        exit(1);
    }

    std::string rinda;
    while (std::getline(fails, rinda)) {
        if (rinda.empty() || rinda.find_first_not_of(" \t") == std::string::npos) {
            continue;
        }

      
        rinda.erase(std::remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());

        std::replace(rinda.begin(), rinda.end(), ',', ' ');
        std::istringstream s(rinda);
        AutobusaMarsruts marsruts;

        if (s >> marsruts.sakumaPietura >> marsruts.galaPietura
              >> marsruts.nedelasDiena >> marsruts.laiks >> marsruts.billetesCena) {
            marsruti.push_back(marsruts);
        } else {
            std::ofstream kluudasFails("err.txt", std::ios::app);
            kluudasFails << "Kļūda ielasot rindu: " << rinda << std::endl;
        }
    }

    fails.close();
    return marsruti;
}



void IzvaditMarsrutaReisus(const std::vector<AutobusaMarsruts>& marsruti) {
    std::string sakumaPietura, galaPietura;

    std::cout << "";
    std::cin >> std::ws >> sakumaPietura;  

    std::cout << "";
    std::cin >> std::ws >> galaPietura;  
    std::cout << "result:" << std::endl;
    for (const auto& marsruts : marsruti) {
        if (marsruts.sakumaPietura == sakumaPietura && marsruts.galaPietura == galaPietura) {
            std::cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
                      << marsruts.nedelasDiena << " " << marsruts.laiks << " "
                      << std::fixed << std::setprecision(2) << marsruts.billetesCena << std::endl;
        }
    }
}

void IzvaditNedelasDienasReisus(const std::vector<AutobusaMarsruts>& marsruti) {
    std::string nedelasDiena;
    std::getline(std::cin, nedelasDiena);

    std::cout << "result:" << std::endl;
    for (const auto& marsruts : marsruti) {
        if (marsruts.nedelasDiena == nedelasDiena) {
            std::cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
                      << marsruts.nedelasDiena << " " << marsruts.laiks << " "
                      << std::fixed << std::setprecision(2) << marsruts.billetesCena << std::endl;
        }
    }
}

void IzvaditZemasCenasReisus(const std::vector<AutobusaMarsruts>& marsruti) {
    double maksa;
    std::cin >> maksa;

  
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::cout << "result:" << std::endl;
    for (const auto& marsruts : marsruti) {
        if (marsruts.billetesCena <= maksa) {
            std::cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
                      << marsruts.nedelasDiena << " " << marsruts.laiks << " "
                      << std::fixed << std::setprecision(2) << marsruts.billetesCena << std::endl;
        }
    }
}

void IzvaditKluudasFailu() {
    std::ifstream kluudasFails("err.txt");
    if (kluudasFails.is_open()) {
        std::cout << "result:" << std::endl;
        std::string rinda;
        while (std::getline(kluudasFails, rinda)) {
            std::cout << rinda << std::endl;
        }
        kluudasFails.close();
    } else {
        std::cout << "result:" << std::endl << "Kļūdu fails nav atrasts." << std::endl;
    }
}

int main() {
    std::cout.imbue(std::locale("C"));

    std::vector<AutobusaMarsruts> marsruti = IelasitDatus("db.csv");

    char darbiba;
    do {
        std::cin >> darbiba;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (darbiba) {
            case 'a':
                IzvaditMarsrutaReisus(marsruti);
                break;
            case 'b':
                IzvaditNedelasDienasReisus(marsruti);
                break;
            case 'c':
                IzvaditZemasCenasReisus(marsruti);
                break;
            case 'd':
                IzvaditKluudasFailu();
                break;
            case 'e':
                std::cout << std::endl;
                break;
            default:
                break;
        }
    } while (darbiba != 'e');

    return 0;
}
