#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

using namespace std;

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  ofstream outFile;
  outFile.open("err.txt");
  char com;
  double price;
	if (!inFile) return 0;
  
  string s, pils1,pils2, word, diena; 
  int count=0;
  vector<string> words;
  bool flag =true;
  while (getline(inFile, s)) {
    flag=true;
    count=0;
    if(s.length()>10)
      s.erase(remove(s.begin(), s.end(), ' '), s.end());
      for (char &c : s) {
          if (c == ',') {
              c = ' ';
            count++;
          }
      }
    stringstream ss(s),ss2(s);
    if(count==4){
      ss>>word;
      ss>>word;
      ss>>word;
      if (word.length()>2) flag=false;
      ss>>word;
      ss>>word;
      
    }else flag=false;
    if (flag){
      while(ss2>>word){
        words.push_back(word);
    }
  }else{
      if(count>0){
        for (char &c : s) {
            if (c == ' ') {
                c = ',';
              count++;
            }
        }
      outFile<<s<<endl;
      }
  }
  }
  outFile.close();
  inFile.close();
  // cout<<words.size();
  // for(auto w:words){
  //   cout<<w<<endl;
  // }
  while(true){
    cin>>com;
  switch(com){
    case 'a':
      cin >> pils1;
      cin >> pils2;
      cout << "result:" <<endl;
      for (int i = 0; i < words.size() - 1; i++) { 
        if (words[i] == pils1 && words[i + 1] == pils2) {
            cout << words[i] << " " << words[i + 1]<< " " <<words[i + 2] << " " << words[i + 3] << " " << words[i + 4] << endl;
        }
    }
    break;
    case 'b':
      cin >> diena;
      cout << "result:" <<endl;
      for (int i = 0; i < words.size() - 1; i++) { 
          if (words[i] == diena) {
              cout << words[i-2] << " " << words[i - 1]<< " " <<words[i] << " " << words[i + 1] << " " << words[i + 2] << endl;
          }
      }
    break;
    case 'c':
      cin >> price;
      cout << "result:" <<endl;
      for(int i=0;i<words.size()-1;i+=5){
        if(stod(words[i+4])<price){
          cout<<words[i]<<" "<<words[i+1]<<" "<<words[i+2]<<" "<< words[i+3]<< " " <<words[i+4]<<endl;
        }
      }
    break;

    case 'd':
      cout << "result:" <<endl;
      inFile.open("err.txt");
      while(getline(inFile, s)){
        cout << s << endl;
      }
      inFile.close();
    break;

    case 'e':
    return 0;
    break;


  }
  }
}