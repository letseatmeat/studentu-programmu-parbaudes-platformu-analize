
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

using namespace std;

void trim(string &str) {
    size_t first = str.find_first_not_of(' ');
    size_t last = str.find_last_not_of(' ');

    if (first != string::npos && last != string::npos) {
        str = str.substr(first, (last - first + 1));
    } else {
        str.clear();
    }
}

struct Trip {
    string startCity;
    string endCity;
    string day;
    string time;
    double price;
};

bool isValidOrder(const Trip& trip) {
    return trip.day.length() == 2 &&
           trip.time.length() == 5 &&
           trip.time[2] == ':' &&
           count(trip.time.begin(), trip.time.end(), ':') == 1 &&  
           trip.price >= 0.0;
}

int main() {
    ifstream inputFile("db.csv");
    if (!inputFile.is_open()) {
        cerr << "Error opening the file." << endl;
        return 1;
    }

    vector<Trip> trips;
    string line;
    vector<string> errorLines;

  while (getline(inputFile, line)) {
      if (line.empty() || all_of(line.begin(), line.end(), ::isspace)) {
          continue;
      }

      trim(line);

      istringstream ss(line);
      string token;
      vector<string> tokens;


      while (getline(ss, token, ',')) {
          trim(token);
          tokens.push_back(token);
      }

      if (tokens.size() != 5) {
          errorLines.push_back(line);
          continue;
      }

 
      double price;

      try {
          price = stod(tokens[4]);

          Trip newTrip;
          newTrip.startCity = tokens[0];
          newTrip.endCity = tokens[1];
          newTrip.day = tokens[2];
          newTrip.time = tokens[3];
          newTrip.price = price;

    
          if (!isValidOrder(newTrip)) {
              errorLines.push_back(line);
              continue;
          }

          trips.push_back(newTrip);

      } catch (const invalid_argument &e) {
          errorLines.push_back(line);
      }
  }

    inputFile.close();

    
    char option;
    string userStartCity, userEndCity, userDay;
    double userPrice;
  do{
    cin >> option;

    switch (option) {
    case 'a':
        cin >> userStartCity;
        trim(userStartCity);
        cout << "result:" << endl;

        cin >> userEndCity;
        trim(userEndCity);

        for (const auto &trip : trips) {
            if (trip.startCity == userStartCity && trip.endCity == userEndCity) {
                cout << trip.startCity << " "
                     << trip.endCity << " "
                     << trip.day << " "
                     << trip.time << " "
                     << fixed << setprecision(2) << trip.price << endl;
            }
        }
        break;

    case 'b':
        cin >> userDay;
        trim(userDay);
        cout << "result:" << endl;
        for (const auto &trip : trips) {
            if (trip.day == userDay) {
                cout << trip.startCity << " "
                     << trip.endCity << " "
                     << trip.day << " "
                     << trip.time << " "
                     << fixed << setprecision(2) << trip.price << endl;
            }
        }
        break;

    case 'c':
        cin >> userPrice;
        cout << "result:" << endl;
        for (const auto &trip : trips) {
            if (trip.price <= userPrice) {
                cout << trip.startCity << " "
                     << trip.endCity << " "
                     << trip.day << " "
                     << trip.time << " "
                     << fixed << setprecision(2) << trip.price << endl;
            }
        }
        break;

    case 'd':
        cout << "result:" << endl;
        for (const auto &errorLine : errorLines) {
            cout << errorLine << endl;
            }
        break;
    case 'e':
        break;
    default:
        cout << "Error" << endl;
        break;
    }

    ofstream errorFile("err.txt");
    if (errorFile.is_open()) {
        for (const auto &errorLine : errorLines) {
            errorFile << errorLine << endl;
        }
        errorFile.close();
        
    } else {
        cerr << "Error writing to err.txt." << endl;
    }
} while (option != 'e');
    return 0;
}
