#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

struct BusRoute {
    std::string startStop;
    std::string endStop;
    std::string dayOfWeek;
    std::string time;
    double ticketPrice;
};

// Funkcija, lai izdrukātu reisu informāciju
void printRoute(const BusRoute& route) {
    std::cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek
              << " " << route.time << " " << std::fixed << std::setprecision(2)
              << route.ticketPrice << std::endl;
}

// Funkcija, lai nolasītu failu un iegūtu reisu informāciju
std::vector<BusRoute> readRoutesFromFile(const std::string& filename) {
    std::vector<BusRoute> routes;
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return routes;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        BusRoute route;
        if (!(iss >> route.startStop >> route.endStop >> route.dayOfWeek
              >> route.time >> route.ticketPrice)) {
            // Ja kļūdaina informācija, ierakstīt failā err.txt
            std::ofstream errFile("err.txt", std::ios::app);
            errFile << line << std::endl;
            errFile.close();
            continue;
        }
        routes.push_back(route);
    }

    file.close();
    return routes;
}

int main() {
    char command;
    std::vector<BusRoute> routes = readRoutesFromFile("db.csv");

    do {
        std::cout << "Ievadiet komandu (a, b, c, d, e): ";
        std::cin >> command;

        switch (command) {
            case 'a': {
                std::string startStop, endStop;
                std::cout << "Ievadiet sākuma pieturas nosaukumu: ";
                std::cin >> startStop;
                std::cout << "Ievadiet gala pieturas nosaukumu: ";
                std::cin >> endStop;

                std::cout << "result:" << std::endl;
                for (const auto& route : routes) {
                    if (route.startStop == startStop && route.endStop == endStop) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'b': {
                std::string dayOfWeek;
                std::cout << "Ievadiet nedēļas dienas apzīmējumu (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                std::cin >> dayOfWeek;

                std::cout << "result:" << std::endl;
                for (const auto& route : routes) {
                    if (route.dayOfWeek == dayOfWeek) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'c': {
                double maxTicketPrice;
                std::cout << "Ievadiet maksimālo biļetes cenu: ";
                std::cin >> maxTicketPrice;

                std::cout << "result:" << std::endl;
                for (const auto& route : routes) {
                    if (route.ticketPrice <= maxTicketPrice) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'd': {
                std::ifstream errFile("err.txt");
                std::string line;
                std::cout << "result:" << std::endl;
                while (std::getline(errFile, line)) {
                    std::cout << line << std::endl;
                }
                errFile.close();
                break;
            }
            case 'e':
                std::cout << "Programma tiek pārtraukta." << std::endl;
                break;
            default:
                std::cout << "Nepareiza komanda. Lūdzu, ievadiet a, b, c, d vai e." << std::endl;
        }

    } while (command != 'e');

    return 0;
}
