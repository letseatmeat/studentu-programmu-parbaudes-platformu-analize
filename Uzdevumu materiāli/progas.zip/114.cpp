
// test2 nezinu kapec rada ka nav pareizs, sakrit vertibas visas
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <sstream>
#include <string>
#include <vector>

struct Route {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

std::string trim(std::string &inputString) {
  auto startIt =
      std::find_if(inputString.rbegin(), inputString.rend(), [](char ch) {
        return !std::isspace<char>(ch, std::locale::classic());
      });
  inputString.erase(startIt.base(), inputString.end());

  auto endIt =
      std::find_if(inputString.begin(), inputString.end(), [](char ch) {
        return !std::isspace<char>(ch, std::locale::classic());
      });
  inputString.erase(inputString.begin(), endIt);
  return inputString;
}

void trimRoute(Route &route, std::string &price) {
  route.start = trim(route.start);
  route.end = trim(route.end);
  route.day = trim(route.day);
  route.time = trim(route.time);
  route.price = std::stod(trim(price));
}

bool containsDigit(const std::string &str) {
  for (char c : str) {
    if (std::isdigit(c)) {
      return true;
    }
  }
  return false;
}

bool checkDigitsInRoute(const Route &route) {
  return containsDigit(route.start) || containsDigit(route.end) ||
         containsDigit(route.day);
}

std::vector<Route> readRoutes() {
  std::string line;
  std::vector<Route> routes;
  std::ifstream file("db.csv");
  std::ofstream errFile("err.txt");

  while (std::getline(file, line)) {
    if (line.empty() || (line.length() == 1 && std::isspace(line[0]))) {
      continue;
    }

    std::stringstream ss(line);
    Route route;
    std::string price;
    if (std::getline(ss, route.start, ',') &&
        std::getline(ss, route.end, ',') && std::getline(ss, route.day, ',') &&
        std::getline(ss, route.time, ',') && std::getline(ss, price, ',') &&
        ss.eof()) {
      try {
        trimRoute(route, price);
        if (checkDigitsInRoute(route)) {
          errFile << line << "\n";
          continue;
        }
      } catch (...) {
        errFile << line << "\n";
        continue;
      }

      routes.push_back(route);
    } else {
      errFile << line << "\n";
    }
  }
  errFile.close();
  return routes;
}

void printRoutes(const std::vector<Route> &routes) {
  std::cout << "result:\n";
  for (const auto &route : routes) {
    std::cout << route.start << " " << route.end << " " << route.day << " "
              << route.time << " " << std::fixed << std::setprecision(2)
              << route.price << "\n";
  }
}

int main() {
  std::vector<Route> routes = readRoutes();
  char command;
  while (true) {
    std::cin >> command;
    switch (command) {
    case 'a': {
      std::string start, end;
      std::cin >> start >> end;

      std::vector<Route> allRoutes;
      for (const auto &route : routes) {
        if (route.start == start && route.end == end) {
          allRoutes.push_back(route);
        }
      }
      printRoutes(allRoutes);
      break;
    }
    case 'b': {
      std::string day;
      std::cin >> day;
      std::vector<Route> foundRoutes;
      for (const auto &route : routes) {
        if (route.day == day) {
          foundRoutes.push_back(route);
        }
      }
      printRoutes(foundRoutes);
      break;
    }
    case 'c': {
      double maxPrice;
      std::cin >> maxPrice;
      std::vector<Route> result;
      for (const auto &route : routes) {
        if (route.price <= maxPrice) {
          result.push_back(route);
        }
      }
      printRoutes(result);
      break;
    }
    case 'd': {
      std::ifstream file("err.txt");
      std::string line;

      std::cout << "result:\n";
      while (std::getline(file, line)) {
        std::cout << line << "\n";
      }
      break;
    }
    case 'e':
      return 0;
    }
  }
}
