
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <stdio.h>

using namespace std;

class Route;
string removeSpaces(string data);
string addCity(string data, int* isError);
string addWeekDay(string data, int* isError);
string addTime(string data, int* isError);
float addPrice(string data, int* isError);
int addRoute(string data, vector<Route> &list);
void printEntry(vector<Route> list, int i);
void setRoute(vector<Route> list);
void setDay(vector<Route> list);
void setPrice(vector<Route> list);
void printErrors(string errorFile);
void printList(vector<Route> list);

int main() {
  string dataBaseFile = "db.csv";
  string errorFile = "err.txt";
  
  remove(errorFile.c_str());
  ifstream inFile;
  ofstream errFile;
  inFile.open(dataBaseFile);
  errFile.open(errorFile);
	if (!inFile) return 0;
  
  vector<Route> list;
  string data; 
  string emptyCheck;

	while (getline(inFile,data)) // inFile >> data
  {
    if (addRoute(data,list) != 0) {
      emptyCheck = removeSpaces(data);
      if (emptyCheck[0] != '\r' && emptyCheck[0] != '\n')  {
        errFile << data;
      }
    }
  }

  inFile.close();
  errFile.close();

  char cmd;
  while(true) {
    cout << ":>>";
    cin >> cmd;
    switch (cmd) {
      case 'a':
        setRoute(list);
        break;
      case 'b':
        setDay(list);
        break;
      case 'c':
        setPrice(list);
        break;
      case 'd':
        printErrors(errorFile);
        break;
      case 'p':
        printList(list);
        break;
      case 'e':
        return 0;
    }
  }
} 

class Route {
public:
  string startPoint;
  string endPoint;
  string weekDay;
  string time;
  float price;

  Route(string sP, string eP, string wD, string t, float pr) {
    startPoint = sP;
    endPoint = eP;
    weekDay = wD;
    time = t;
    price = pr;
  }
};

string removeSpaces(string data) {
  stringstream temp;
  for (char c : data) {
      if (c != ' ') {
          temp << c;
      }
  }
  return temp.str();
}

string addCity(string data, int* isError) {
  string city = removeSpaces(data);
  if (city.length() <= 1) {
    *isError = 1;
  }
  return city;
}

string addWeekDay(string data, int* isError) {
  data = removeSpaces(data);

  string dayValidation[] = {"Pr","Ot","Tr","Ce","Pt","St","Sv"};
  for (int i = 0; i < 7;i++) {
    if (data.compare(dayValidation[i]) == 0) {
      return data;
    }
  }

  *isError = 2;
  return data;
}

string addTime(string data, int* isError) {
  data = removeSpaces(data);
  int hours, minutes;

  try {
    if (data[0] == '0') {
      hours = data[1] - '0';
    }
    else {
      hours = stoi(data.substr(0,2));
    }

    if (data[3] == '0') {
      minutes = data[4] - '0';
    }
    else {
      minutes = stoi(data.substr(3,2));
    }
  } catch (exception) {
    *isError = 3;
  }

  if (hours > 23 || hours < 0 || minutes > 59 || minutes < 0 || data[2] != ':') {
    *isError = 3;
  }

  return data;
}

float addPrice(string data, int* isError) {
  data = removeSpaces(data);
  float price;

  try {
    price = stof(data);
  } catch (exception){
    *isError = 4;
  }

  return price;
}

int addRoute(string data, vector<Route> &list) {
  string startPoint;
  string endPoint;
  string weekDay;
  string time;
  float price;

  int isError = 0;

  string temp;
  int currentValue = 0;
  int strLength = 0;
  for (int i = 0; i < data.length(); i++) { 
    if (data[i] == ',' || i == data.length() - 1) {
      temp = data.substr(i - strLength, strLength);
      
      switch (currentValue) {
        case 0: 
          startPoint = addCity(temp, &isError);
          break;
        case 1:
          endPoint = addCity(temp, &isError);
          break;
        case 2:
          weekDay = addWeekDay(temp, &isError);
          break;
        case 3:
          time = addTime(temp, &isError);
          break;
        case 4:
          price = addPrice(temp, &isError);
          break;
      } 
      currentValue++;
      strLength = 0;
    }
    else {
      strLength++;
    }
    if (isError != 0) {
      return isError;
    }
  }
  if (currentValue != 5) { 
    isError = 5;
    return isError;
  }
  list.push_back(Route(startPoint,endPoint,weekDay,time,price));
  return 0;
}

void printEntry(vector<Route> list, int i) {
  cout << list[i].startPoint << ' ' << list[i].endPoint << ' ' << list[i].weekDay << ' ' << list[i].time << ' ' << fixed << setprecision(2) << list[i].price << endl;
}

void setRoute(vector<Route> list) {
  string startPoint, endPoint;
  cout << "Ievadi sākuma pieturu: ";
  cin >> startPoint;
  cout << "Ievadi gala pieturu: ";
  cin >> endPoint;

  cout << "result:\n";
  for (int i = 0; i<list.size(); i++) {
    if (startPoint.compare(list[i].startPoint) == 0 && endPoint.compare(list[i].endPoint) == 0) {
      printEntry(list,i);
    }
  }
}

void setDay(vector<Route> list) {
  string weekDay;
  cout << "Ievadi dienu: ";
  cin >> weekDay;

  cout << "result:\n";
  for (int i = 0; i<list.size(); i++) {
    if (weekDay.compare(list[i].weekDay) == 0) {
      printEntry(list,i);
    }
  }
}

void setPrice(vector<Route> list) {
  float price;
  int error;
  cout << "Ievadi cenu: ";
  do {
    error = scanf("%f",&price);
    while (getchar() != '\n' );
  } while (error != 1);

  cout << "result:\n";
  for (int i = 0; i<list.size(); i++) {
    if (list[i].price <= price) {
      printEntry(list,i);
    }
  }
}

void printErrors(string errorFile) {
  ifstream errFile;
  errFile.open(errorFile);
  if (!errFile) return;
  string data;

  cout << "result:" << endl;
  while (errFile >> data)
  {
    cout << data << endl;
  }

  errFile.close();
}

void printList(vector<Route> list) {
  cout << "result:\n";
  for (int i = 0; i<list.size(); i++) {
    printEntry(list,i);
  }
}