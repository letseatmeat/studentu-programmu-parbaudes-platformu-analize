

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct MarsrutaInformacija {
    string sakumaPietura;
    string galaPietura;
    string nedelasDiena;
    string laiks;
    double biletesCena;
};

void trimSpaces(string &str) {
    str.erase(remove_if(str.begin(), str.end(), ::isspace), str.end());
}

bool irKludaRinda(const string &rinda, ofstream &errorFile) {
  if (rinda.empty()) {
      return true;
  }
    stringstream s(rinda);
    int laukuSkaits = 0;
    string lauks;

    while (getline(s, lauks, ',')) {
        laukuSkaits++;
    }

    if (laukuSkaits != 5) {
        errorFile << rinda << endl;
        return true;
    }

    s.clear();
    s.str(rinda);
    getline(s, lauks, ',');
    getline(s, lauks, ',');
    getline(s, lauks, ',');
    getline(s, lauks, ',');

    try {
        stod(lauks);
    } catch (const std::invalid_argument &) {
        errorFile << rinda << endl;
        return true;
    }

    if (lauks.length() != 5 || lauks[2] != ':') {
        errorFile << rinda << endl;
        return true;
    }

    return false;
}

void ielasitDatus(const string &failaNosaukums, vector<MarsrutaInformacija> &marsruti, ofstream &errorFile) {
    ifstream inFile(failaNosaukums);
    if (!inFile) {
        cerr << "Nevar atvert failu: " << failaNosaukums << endl;
        return;
    }

    string rinda;
    while (getline(inFile, rinda)) {
        trimSpaces(rinda);

        if (irKludaRinda(rinda, errorFile)) {
            continue;
        }

        istringstream s(rinda);
        MarsrutaInformacija marsruts;

        getline(s, marsruts.sakumaPietura, ',');
        getline(s, marsruts.galaPietura, ',');
        getline(s, marsruts.nedelasDiena, ',');
        getline(s, marsruts.laiks, ',');
        s >> marsruts.biletesCena;

        if (s.fail() || s.bad()) {
            errorFile << rinda << endl;
            continue;
        }

        marsruti.push_back(marsruts);
    }

    inFile.close();
}

void izvaditReisus(const vector<MarsrutaInformacija> &marsruti, const string &rezultatuPaziņojums) {
    cout << rezultatuPaziņojums << endl;
    for (const auto &marsruts : marsruti) {
        cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " " << marsruts.nedelasDiena << " "
             << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.biletesCena << endl;
    }
}

int main() {
    vector<MarsrutaInformacija> marsruti;
    ofstream errorFile("err.txt");

    ielasitDatus("db.csv", marsruti, errorFile);

    char darbiba;
    do {
        cout << "Izvelieties darbibu: ";
        cin >> darbiba;

        switch (darbiba) {
            case 'a': {
                string sakumaPietura, galaPietura;
                cout << "Sakuma pietura: ";
                cin >> sakumaPietura;
                cout << "Gala pietura: ";
                cin >> galaPietura;

                vector<MarsrutaInformacija> izvelētieMarsruti;
                for (const auto &marsruts : marsruti) {
                    if (marsruts.sakumaPietura == sakumaPietura && marsruts.galaPietura == galaPietura) {
                        izvelētieMarsruti.push_back(marsruts);
                    }
                }

                izvaditReisus(izvelētieMarsruti, "result:");
                break;
            }
            case 'b': {
                string nedelasDiena;
                cout << "Nedelas diena: ";
                cin >> nedelasDiena;

                vector<MarsrutaInformacija> izvelētieMarsruti;
                for (const auto &marsruts : marsruti) {
                    if (marsruts.nedelasDiena == nedelasDiena) {
                        izvelētieMarsruti.push_back(marsruts);
                    }
                }

                izvaditReisus(izvelētieMarsruti, "result:");
                break;
            }
            case 'c': {
                double maksimalaCena;
                cout << "Maksimāla biļetes cena: ";
                cin >> maksimalaCena;

                vector<MarsrutaInformacija> izvelētieMarsruti;
                for (const auto &marsruts : marsruti) {
                    if (marsruts.biletesCena <= maksimalaCena) {
                        izvelētieMarsruti.push_back(marsruts);
                    }
                }

                izvaditReisus(izvelētieMarsruti, "result:");
                break;
            }
            case 'd': {
                ifstream errFile("err.txt");
                string saturs;

                cout << "result:" << endl;
                while (getline(errFile, saturs)) {
                    cout << saturs << endl;
                }

                errFile.close();
                break;
            }
            case 'e':
                cout << "End" << endl;
                break;
            default:
                cout << "Error. Nepareiza darbība" << endl;
                break;
        }
    } while (darbiba != 'e');

    errorFile.close();
    return 0;
}