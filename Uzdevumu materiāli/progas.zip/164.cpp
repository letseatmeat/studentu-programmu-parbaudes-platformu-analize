
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Route {
    string point_a;
    string point_b;
    string day;
    string time;
    double price;

};

string filterString(string str) {
    string result;
    for (char c : str) {
        if (c != ' ' && c != '\n' && c != '\t' && c != '\r') {
            result += c;
        }
    }
    return result;
}

vector<Route> readRoutes(const string &filename) {
    vector<Route> routes;
    ifstream file(filename);

    if (!file.is_open())
        return routes;

    string line, err = "result:\n";
    regex time_format("^\\d{2}:\\d{2}$");

  
    while (getline(file, line)) {
        string filteredLine = filterString(line);
        istringstream ss(filteredLine);
        vector<string> fields;
        string field;
        while (getline(ss, field, ',')) {
            fields.push_back(field);
        }
        if (fields.size() == 5 && regex_match(fields[3], time_format)) {
          
            try {
                Route route;
                route.point_a = fields[0];
                route.point_b = fields[1];
                route.day = fields[2];
                route.time = fields[3];
                route.price = stod(fields[4]);
                routes.push_back(route);
            } catch (const exception &e) {
                continue;
            }
        } else {
            if (!field.empty())
                err += line + "\n";
        }
    }
  

    ofstream err_file("err.txt");
    err.erase(err.find_last_not_of("\n") + 1);
    err_file << err;
    err_file.close();

    return routes;
}

void printRoutes(const vector<Route> &routes) {
    cout << "result:" << endl;
    for (const auto &route : routes) {
        cout << route.point_a << " " << route.point_b << " " << route.day << " "
             << route.time << " " << fixed << setprecision(2) << route.price
             << endl;
    }
}

int main() {
    vector<Route> routes = readRoutes("db.csv");

    char choice;
    while (true) {
        cin >> choice;

        switch (choice) {
        case 'a': {
            string point_a, point_b;
            cin >> point_a >> point_b;
            vector<Route> result;
            for (const auto &route : routes) {
                if (route.point_a == point_a && route.point_b == point_b) {
                    result.push_back(route);
                }
            }
            printRoutes(result);
            break;
        }
        case 'b': {
            string day;
            cin >> day;
            vector<Route> result;
            for (const auto &route : routes) {
                if (route.day == day) {
                    result.push_back(route);
                }
            }
            printRoutes(result);
            break;
        }
        case 'c': {
            double price;
            cin >> price;
            vector<Route> result;
            for (const auto &route : routes) {
                if (route.price <= price) {
                    result.push_back(route);
                }
            }
            printRoutes(result);
            break;
        }
        case 'd': {
            ifstream file("err.txt");
            string line;
            while (getline(file, line)) {
                cout << line << endl;
            }
            break;
        }
        case 'e':
            return 0; 
        }
    }

    return 0;
}
