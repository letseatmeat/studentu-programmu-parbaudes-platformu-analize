
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <limits>

struct Trip {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

std::string spaces(const std::string& line) {
  size_t lStart = line.find_first_not_of(' ');
  if (std::string::npos == lStart) {
    return line;
  }
  size_t lEnd = line.find_last_not_of(' ');
  return line.substr(lStart, (lEnd - lStart + 1));
}

bool valid(std::vector<std::string>& pos) {
  if (pos.size() != 5){
    return false;
  }
  size_t timecheck = pos[3].find(':');
  if (timecheck == std::string::npos) {
    return false;
  }
  try {
    std::stod(pos[4]);
  } 
  catch (std::exception) {
    return false;
  }
  return true;
}

std::vector<Trip> tripList(const std::string& filel, std::ofstream& eList) {
  std::vector<Trip> trips;
  std::ifstream file(filel);
  std::string line;
  while (std::getline(file, line)) {
    if (line.empty() || std::all_of(line.begin(), line.end(), ::isspace))
      continue;
    std::stringstream ss(line);
    std::string x;
    std::vector<std::string> pos;

    while (std::getline(ss, x, ',')) {
        pos.push_back(spaces(x));
    }
    if (!valid(pos)) {
        eList << line << std::endl;
      continue;
    }
    try {
      Trip ctrip = {pos[0], pos[1], pos[2], pos[3], std::stod(pos[4])};
      trips.push_back(ctrip);
    } catch (std::exception) {
        eList << line << " fail "<< std::endl;
    }
  }
  file.close();
  return trips;
}

void results(const std::vector<Trip> &trips) {
  for (auto& t : trips) {
    std::cout <<t.start<< " "<< t.end<< " "<<t.day<<" "<< t.time<< " "<< std::fixed<<std::setprecision(2)<< t.price << std::endl;
  }
}

int main() {
  std::ofstream eList("err.txt");
  std::vector<Trip> trips = tripList("db.csv", eList);
  eList.close();
  char choice;
  
  while(1){
    std::cin >> choice;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    switch (choice) {
    case 'a':{
      std::string start, end;
      std::getline(std::cin, start);
      std::getline(std::cin, end);
      std::cout << "result:" << std::endl;
      for (auto& t : trips) {
        if (t.start == start && t.end == end) {
          results({t});
        }
      }
      break;
    }
    case 'b':{
      std::string day;
      std::getline(std::cin, day);
      std::cout << "result:" << std::endl;
      for (auto& t : trips) {
        if (t.day == day) {
          results({t});
        }
      }
      break;
    }
    case 'c':{
      double pMax;
      std::cin >> pMax;
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      std::cout << "result:" << std::endl;
      for (auto& t : trips) {
        if (t.price <= pMax) {
          results({t});
        }
      }
      break;
    }
    case 'd':{
      std::ifstream inFile("err.txt");
      if (!inFile.is_open()) {
        continue;
      } else {
        std::cout << "result:" << std::endl;
        inFile.seekg(0, std::ios::beg);
        std::string content;
        while (std::getline(inFile, content)) {
          if (!content.empty() && content.find(",,") == std::string::npos) {
            std::cout << content << std::endl;
          }
        }
        inFile.close();
      }
      break;
    }
    case 'e':{
      return 0;
    }
    default:{
      std::cout << "Fail, try again" << std::endl;
      break;
    }
    }
  }
}