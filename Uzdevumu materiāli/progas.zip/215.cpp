#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <set> 
#include <limits>

struct BusRoute {
    std::string startStation;
    std::string endStation;
    std::string dayOfWeek;
    std::string time;
    float ticketPrice;
};

std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t\n\r\f\v");
    if (first == std::string::npos) return str;
    size_t last = str.find_last_not_of(" \t\n\r\f\v");
    return str.substr(first, (last - first + 1));
}

std::vector<BusRoute> readRoutesFromFile(const std::string& fileName, std::vector<std::string>& errorLines) {
    std::vector<BusRoute> routes;
    std::ifstream file(fileName);
    std::string line;

    while (getline(file, line)) {
        std::istringstream iss(trim(line));
        std::string start, end, day, time, priceStr;
        float price;

        getline(iss, start, ',');
        getline(iss, end, ',');
        getline(iss, day, ',');
        getline(iss, time, ',');
        getline(iss, priceStr);

        start = trim(start);
        end = trim(end);
        day = trim(day);
        time = trim(time);
        priceStr = trim(priceStr);

        try {
            price = std::stof(priceStr);
            routes.push_back({start, end, day, time, price});
        } catch (...) {
            errorLines.push_back(line);
        }
    }

    file.close();
    return routes;
}

void writeErrorsToFile(const std::string& fileName, const std::vector<std::string>& errorLines) {
    std::ofstream errFile(fileName);
    for (const auto& line : errorLines) {
        errFile << line << std::endl;
    }
    errFile.close();
}

void displayRoutes(const std::vector<BusRoute>& routes) {
    if (!routes.empty()) {
        std::cout << "result:" << std::endl;
        for (const auto& route : routes) {
            std::cout << route.startStation << " " << route.endStation << " " << route.dayOfWeek << " "
                      << route.time << " " << std::fixed << std::setprecision(2) << route.ticketPrice << std::endl;
        }
    }
}

void queryA(std::vector<BusRoute>& routes) {
    std::string start, end;
    getline(std::cin, start);
    getline(std::cin, end);
    std::vector<BusRoute> filteredRoutes;
    for (const auto& route : routes) {
        if (trim(route.startStation) == trim(start) && trim(route.endStation) == trim(end)) {
            filteredRoutes.push_back(route);
        }
    }
    displayRoutes(filteredRoutes);
}

void queryB(std::vector<BusRoute>& routes) {
    std::string day;
    getline(std::cin, day);
    std::vector<BusRoute> filteredRoutes;
    for (const auto& route : routes) {
        if (trim(route.dayOfWeek) == trim(day)) {
            filteredRoutes.push_back(route);
        }
    }
    displayRoutes(filteredRoutes);
}

void queryC(std::vector<BusRoute>& routes) {
    float maxPrice;
    std::cin >> maxPrice;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::vector<BusRoute> filteredRoutes;
    for (const auto& route : routes) {
        if (route.ticketPrice <= maxPrice) {
            filteredRoutes.push_back(route);
        }
    }
    displayRoutes(filteredRoutes);
}

void queryD(const std::vector<std::string>& errorLines) {
    std::set<std::string> uniqueErrors; 
    if (!errorLines.empty()) {
        std::cout << "result:" << std::endl;
        for (const auto& line : errorLines) {
            uniqueErrors.insert(line); 
        }
        for (const auto& uniqueError : uniqueErrors) {
            std::cout << uniqueError << std::endl;
        }
    }
}

int main() {
    std::vector<std::string> errorLines;
    std::vector<BusRoute> routes = readRoutesFromFile("db.csv", errorLines);

    std::string queryType;
    while (getline(std::cin, queryType)) {
        if (queryType == "a") {
            queryA(routes);
        } else if (queryType == "b") {
            queryB(routes);
        } else if (queryType == "c") {
            queryC(routes);
        } else if (queryType == "d") {
            queryD(errorLines);
        } else if (queryType == "e") {
            break;
        }
    }

    writeErrorsToFile("err.txt", errorLines);
    return 0;
}


