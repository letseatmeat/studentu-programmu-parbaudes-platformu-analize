
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

bool isValidDay(const string& day) {
  return day == "Pr" || day == "Ot" || day == "Tr" || day == "Ce"
  || day == "Pt" || day == "Se" || day == "Sv";
}

bool isValidTime(const string& time) {
  if (
    time.size() == 5 && time[2] == ':' 
    && isdigit(time[0]) && isdigit(time[1]) && isdigit(time[3]) && isdigit(time[4])
    && stoi(time.substr(0,1)) < 3 && stoi(time.substr(3,4)) < 6 
    && stoi(time.substr(0,2)) < 24
    ) return true;
  return false;
}

bool isValidPrice(const string& price) {
  if(stof(price) && price.size() - price.find('.') == 3) return true;
  return false;
}

bool isValidName(const string& city) {
  for (char c : city) {
    if(isdigit(c)) return false;
  }
  return true;
}

int main() {
  ifstream inFile, errorFile;
  ofstream outFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  string line, word, input; 
  vector<vector<string>> routeList;
  vector<string> errorRouteList;
	while (getline(inFile,line))
	{
    stringstream str(line);
    vector<string> route;
    while (getline(str,word,',')) {
      word.erase(0, word.find_first_not_of(" \t\r\n"));
      word.erase(word.find_last_not_of(" \t\r\n") + 1);
      route.push_back(word);
    }
    if (route.size() == 5) {
      bool isCorrect = 
        isValidName(route[0]) && isValidName(route[1]) && isValidDay(route[2])
        && isValidTime(route[3]) && isValidPrice(route[4]);
      if (isCorrect) routeList.push_back(route);
      else errorRouteList.push_back(line);
    }
    else {
      errorRouteList.push_back(line);
    }
  }
  outFile.open("err.txt");
  if (!outFile) return 0;
  for (auto& errorRoute: errorRouteList) {
    if (!errorRoute.empty())
      outFile << errorRoute << endl;
  }
  outFile.close();
  inFile.close();
  
  while (true) {
    cin >> input;
    if (input == "a") {
      string startStation, endStation;
      cin >> startStation >> endStation;
      cout << "result:" << endl;
      for (auto& route: routeList) {
        if (route[0] == startStation && route[1] == endStation) {
          for (auto& detail: route) {
            cout << detail << " ";
          }
          cout << endl;
        }
      }
    }
    else if (input == "b") {
      string day;
      cin >> day;
      cout << "result:" << endl;
      for (auto& route: routeList) {
        if (route[2] == day) {
          for (auto& detail: route) {
            cout << detail << " ";
          }
          cout << endl;
        }
      }
    }
    else if (input == "c") {
      float price;
      cin >> price;
      cout << "result:" << endl;
      for (auto& route: routeList) {
        if (stof(route[4]) <= price) {
          for (auto& detail: route) {
            cout << detail << " ";
          }
          cout << endl;
        }
      }
    }
    else if (input == "d") {
      cout << "result:" << endl;
      errorFile.open("err.txt");
      while (errorFile >> line) {
        cout << line << endl;
      }
      errorFile.close();
    }
    else if (input == "e") {
      return 0;
    }
    else {
      continue;
    }
  }
} 