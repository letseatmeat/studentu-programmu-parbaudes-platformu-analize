

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <sstream>

using namespace std;

const char COMMA = ',';
const string DAYS_OF_WEEK[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
const char ODD_CHARACTERS[] = {' ', '\n', '\r'};
const regex TIME_FORMAT("^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$");
const int NUMBER_OF_COMMAS = 4;
ofstream outFile;

struct Ticket {
  string departure;
  string arrival;
  string dayOfWeek;
  string departureTime;
  string price;
};

void writeExceptions(string line) { outFile << line << endl; }

void filterByRoute() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return;

  string departure, arrival;
  cin >> departure >> arrival;

  string line, field;
  Ticket ticket;

  cout << "result:" << endl;
  outFile.open("err.txt");

  while (getline(inFile, line, '\n')) {
    for (char ch : ODD_CHARACTERS)
      line.erase(remove(line.begin(), line.end(), ch), line.end());
    stringstream entry(line);

    // check if an entry is empty
    if (line.empty())
      continue;

    // check the number of fields in a request.
    if (count(begin(line), end(line), COMMA) != NUMBER_OF_COMMAS) {
      writeExceptions(line);
      continue;
    }

    // check if an entry is structured correctly
    getline(entry, field, COMMA);
    ticket.departure = field;

    getline(entry, field, COMMA);
    ticket.arrival = field;

    getline(entry, field, COMMA);
    if (!count(begin(DAYS_OF_WEEK), end(DAYS_OF_WEEK), field)) {
      writeExceptions(line);
      continue;
    }
    ticket.dayOfWeek = field;

    getline(entry, field, COMMA);
    if (!regex_match(field, TIME_FORMAT)) {
      writeExceptions(line);
      continue;
    }
    ticket.departureTime = field;

    getline(entry, field, COMMA);
    try {
      if (stod(field) < 0) {
        writeExceptions(line);
        continue;
      }
    } catch (exception ex) {
      writeExceptions(line);
      continue;
    }
    ticket.price = field;

    if (ticket.departure == departure && ticket.arrival == arrival) {
      auto [departure, arrival, dayOfWeek, departureTime, price]{ticket};
      cout << departure << " " << arrival << " " << dayOfWeek << " "
           << departureTime << " " << price << endl;
    }
  }

  outFile.close();
  inFile.close();
}

void filterByDay() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return;

  string dayOfWeek;
  cin >> dayOfWeek;

  string line, field;
  Ticket ticket;

  cout << "result:" << endl;
  outFile.open("err.txt");

  while (getline(inFile, line, '\n')) {
    for (char ch : ODD_CHARACTERS)
      line.erase(remove(line.begin(), line.end(), ch), line.end());
    stringstream entry(line);

    // check if an entry is empty
    if (line.empty())
      continue;

    // check the number of fields in a request.
    if (count(begin(line), end(line), COMMA) != NUMBER_OF_COMMAS) {
      writeExceptions(line);
      continue;
    }

    // check if an entry is structured correctly
    getline(entry, field, COMMA);
    ticket.departure = field;

    getline(entry, field, COMMA);
    ticket.arrival = field;

    getline(entry, field, COMMA);
    if (!count(begin(DAYS_OF_WEEK), end(DAYS_OF_WEEK), field)) {
      writeExceptions(line);
      continue;
    }
    ticket.dayOfWeek = field;

    getline(entry, field, COMMA);
    if (!regex_match(field, TIME_FORMAT)) {
      writeExceptions(line);
      continue;
    }
    ticket.departureTime = field;

    getline(entry, field, COMMA);
    try {
      if (stod(field) < 0) {
        writeExceptions(line);
        continue;
      }
    } catch (exception ex) {
      writeExceptions(line);
      continue;
    }
    ticket.price = field;

    if (ticket.dayOfWeek == dayOfWeek) {
      auto [departure, arrival, dayOfWeek, departureTime, price]{ticket};
      cout << departure << " " << arrival << " " << dayOfWeek << " "
           << departureTime << " " << price << endl;
    }
  }

  outFile.close();
  inFile.close();
}

void filterByPrice() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return;

  double price;
  cin >> price;

  string line, field;
  Ticket ticket;

  cout << "result:" << endl;
  outFile.open("err.txt");

  while (getline(inFile, line, '\n')) {
    for (char ch : ODD_CHARACTERS)
      line.erase(remove(line.begin(), line.end(), ch), line.end());
    stringstream entry(line);

    // check if an entry is empty
    if (line.empty())
      continue;

    // check the number of fields in a request.
    if (count(begin(line), end(line), COMMA) != NUMBER_OF_COMMAS) {
      writeExceptions(line);
      continue;
    }

    // check if an entry is structured correctly
    getline(entry, field, COMMA);
    ticket.departure = field;

    getline(entry, field, COMMA);
    ticket.arrival = field;

    getline(entry, field, COMMA);
    if (!count(begin(DAYS_OF_WEEK), end(DAYS_OF_WEEK), field)) {
      writeExceptions(line);
      continue;
    }
    ticket.dayOfWeek = field;

    getline(entry, field, COMMA);
    if (!regex_match(field, TIME_FORMAT)) {
      writeExceptions(line);
      continue;
    }
    ticket.departureTime = field;

    getline(entry, field, COMMA);
    try {
      if (stod(field) < 0) {
        writeExceptions(line);
        continue;
      }
    } catch (exception ex) {
      writeExceptions(line);
      continue;
    }
    ticket.price = field;

    if (stod(ticket.price) <= price) {
      auto [departure, arrival, dayOfWeek, departureTime, price]{ticket};
      cout << departure << " " << arrival << " " << dayOfWeek << " "
           << departureTime << " " << price << endl;
    }
  }

  outFile.close();
  inFile.close();
}

void showError() {
  ifstream inFile;
  string output;

  cout << "result:" << endl;
  inFile.open("err.txt");
  if (inFile.is_open()) {
    while (inFile) {
      getline(inFile, output);
      cout << output << endl;
    }
    inFile.close();
  }
}

int main() {
  char command;
  while (true) {
    cin >> command;

    switch (command) {
    case 'a':
      filterByRoute();
      break;
    case 'b':
      filterByDay();
      break;
    case 'c':
      filterByPrice();
      break;
    case 'd':
      showError();
      break;
    case 'e':
      return 0;
    default:
      continue;
    }
  }
}