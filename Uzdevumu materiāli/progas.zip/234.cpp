

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <regex>

using namespace std;

//Pārbauda vai failā dienas atbilst "Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"
bool validDay(const string& day) {
    static const vector<string> correctDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    return find(correctDays.begin(), correctDays.end(), day) != correctDays.end();
}

//Pārbauda vai failā laiks atbils hh:mm formātam 
bool validTime(const string& time) {
    const regex timeRegex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
  //^ - virknes sākums.
  //([01]?[0-9])- atbilst stundām diapazonā no 0 līdz 19. 
  //? - padara iepriekšējo 0 vai 1 neobligātu, pieļaujot viencipara stundas.
  //|- "vai".
  //2[0-3]- atbilst stundām diapazonā no 20 līdz 23.
  //: - zīme starp stundām un minūtēm.
  //[0-5]- ļauj pirmajam minūšu ciparam būt no 0 līdz 5, un 
  //[0-9] - ļauj otrajam minūšu ciparam būt jebkuram ciparam no 0-9.
  //$ - apstiprina virknes beigas.
    return regex_match(time, timeRegex);
}

//Pārbauda vai failā cenas formāts ir pareizs
bool validPrice(const string& price) {
    const regex priceRegex("^\\d+(\\.\\d{2})$");
  //^ - virknes sākums.
  //\d+: atbilst vienam vai vairākiem cipariem. 
  //\d ir saīsināta rakstzīmju klase, kas apzīmē jebkuru ciparu (ekvivalents [0-9]).
  //'(' un ')' - iekļauj grupu.
  //.: atbilst punktam/komatam.
  //\d{2}: precīzi atbilst diviem cipariem.
  //$ - virknes beigas.
    return regex_match(price, priceRegex);
}

//Pārbauda vai failā iepriekš pārbaudītā informācija ir pareizā secībā
bool isValidRoute(const vector<string>& route) {
    if (route.size() != 5) {
        return false;
    }
    const string& city1 = route[0];
    const string& city2 = route[1];
    const string& day = route[2];
    const string& time = route[3];
    const string& price = route[4];

    return validDay(day) && validTime(time) && validPrice(price);
}

//Uztaisa err.txt failu un atgriež pareizu informāciju ar ko strādāt tālāk main funkcijā.
vector<vector<string>> getValidRoutes(const string& filename) {
    vector<vector<string>> validRoutes;

    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file '" << filename << "'" << endl;
        return validRoutes;
    }

    // izveido err.txt failu
    ofstream errorFile("err.txt");
    if (!errorFile.is_open()) {
        cerr << "Error: Unable to open file 'err.txt'" << endl;
        inputFile.close(); 
        return validRoutes;
    }
    //veic informācijas pārbaudi
    string line;
    while (getline(inputFile, line)) {
        // Neņem vērā atstarpes starp informāciju
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        // Neņem vērā tukšas rindas
        if (line.empty()) {
            continue;
        }
      
        vector<string> route;
        stringstream ss(line);
        string field;

        while (getline(ss, field, ',')) {
            route.push_back(field);
        }

        if (isValidRoute(route)) {
            validRoutes.push_back(route);
        } else {
            errorFile << line << endl; // informāciju, kas neatbilst pārbaudītajiem nosacījumiem iekopē err.txt
        }
    }
    inputFile.close();
    errorFile.close();

    return validRoutes;
}

// Vaicājuma "a" funkcija
void routesCities(const string& city1, const string& city2, const vector<vector<string>>& validRoutes) {
    cout << "result:" << endl;
    for (const auto& route : validRoutes) {
        if (route.size() >= 2 && route[0] == city1 && route[1] == city2) {
            for (const auto& field : route) {
                cout << field << " ";
            }
          cout << endl;
        }
    }
}

// Vaicājuma "b" funkcija
void routesDay(const string& day, const vector<vector<string>>& validRoutes) {
    cout << "result:" << endl;
    for (const auto& route : validRoutes) {
        if (route.size() >= 3 && route[2] == day) {
            for (const auto& field : route) {
                cout << field << " ";
            }
            cout << endl;
        }
    }
}

// Vaicājuma "c" funkcija
void routesPrice(const string& price, const vector<vector<string>>& validRoutes) {
    double price1 = stod(price); // pārveido par double

    cout << "result:" << endl;
    for (const auto& route : validRoutes) {
        if (route.size() >= 5) {
            try {
                double routePrice = stod(route[4]); //pārveido par double un salīdzina
                if (routePrice <= price1) {
                    for (const auto& field : route) {
                        cout << field << " ";
                    }
                    cout << endl;
                }
            } catch (const invalid_argument& e) {
                cerr << "Invalid price format." << endl;
            }
        }
    }
}
// Vaicājuma "d" funkcija
void printErrorFile() {
    ifstream errorFileReader("err.txt");
    if (!errorFileReader.is_open()) {
        cerr << "Error: Unable to open 'err.txt'" << endl;
    } else {
        cout << "result:" << endl;
        string errorLines;
        while (getline(errorFileReader, errorLines)) {
            cout << errorLines << endl;
        }
        errorFileReader.close();
    }
}

int main() {
  vector<vector<string>> validRoutes = getValidRoutes("db.csv");
  
  string command;
  while (true) {
      cin >> command;

      if (command == "a") {
        string city1;
        string city2;
        cin >> city1;
        cin >> city2;
        routesCities(city1, city2, validRoutes);
      } else if (command == "b") {
        string day;
        cin >> day;
        routesDay(day, validRoutes);
      } else if (command == "c") {
        string price;
        cin >> price;
        routesPrice(price, validRoutes);
      } else if (command == "d") {
        printErrorFile();
      } else if (command == "e") {
          break;
      }
  }


    return 0;
}


