
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <set>

using namespace std;

struct Reisi{ //struktūra, kurā glabāsies autobusa reisu dati
  string start;
  string finish;
  string weekday;
  string time;
  double ticket_pr;
};

string trim(const string& str) {  //izdzēš liekas atstarpes no abām pusēm datiem
  size_t start = str.find_first_not_of(" ");
  size_t end = str.find_last_not_of(" ");
  if (start == string::npos || end == string::npos) {
    return "";
  }
  return str.substr(start,end + 1);
}
//funkcija, kas pārveido csv rindas uz nepieciešamo formātu un ieliek datus struktūrā BusRoute
bool parseCSVLine(const string& line,Reisi& route) { 
  istringstream ss(line);
  string token;
  if (getline(ss,route.start,',')&&   //dabū katru informācijas lauciņu
      getline(ss,route.finish,',')&&
      getline(ss,route.weekday,',')&&
      getline(ss,route.time,','))
  {
    if(ss>>route.ticket_pr) { //lasa biļetes cenu
      if(ss>>token) { //pārbauda, vai vēl ir vēl pārpalikuši dati
        return false;  // ja palika vēl kkādi dati, uzskata to par kļūdu
      }
      //noņem liekas atstarpes
      route.start=trim(route.start);
      route.finish=trim(route.finish);
      route.weekday=trim(route.weekday);
      route.time=trim(route.time);

      return true;
    }
  }
  return false;
}
//paņem kļūdas no faila
void printErrF(const string& filename, set<string>& printedErr) {
  ifstream errRead(filename);
  if(errRead){
    cout<<"result:";
    string errLine;
    while(getline(errRead,errLine)) {
      if(errLine.empty()) {
        continue;
      }
    //ja kļūda vēl nav uzrakstīta, tad to uzraksta un pievieno 
      if(printedErr.find(errLine)==printedErr.end()) {
        cout<<errLine<<endl;
        printedErr.insert(errLine);
      }
    }
    errRead.close();
  }else{
    cout<<"nevar atvērt failu "<<filename<<endl;
  }
}

int main(){
  char choice;
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");
  if (!inFile) {
    cerr<<"nevar atvērt failu db.csv"<<endl;
    return 1;
  }

  vector<Reisi> routes;
  set<pair<string,string>>printedReisi; // seko līdzi izvadītajiem maršrutiem
  set<string>printedErr; // seko līdzi izvadītajām kļūdām

  string line;
  while(getline(inFile,line)) {
    if(line.empty())  //igonrē tukšo rindiņu
      continue;
      Reisi route;
      if (!parseCSVLine(line,route)) {
        errFile<<line<<endl;
        continue;
      }
      routes.push_back(route);
  }
  // char choice;
  do{
    cin>>choice;
    cin.ignore(10000, '\n');  
      //if (choice!='e') {
        //printErrF("err.txt");
     // }
    switch(choice){
      case 'a':{
        string start,end;
        cin.ignore();
        getline(cin,start);
        getline(cin,end);

        cout<<"result:"<<endl;
        for(const auto& route : routes) {
          string trimmedS=trim(route.start);
          string trimmedE=trim(route.finish); 
          //ja ievadītās pilsētas saskan ar faila maršutiem, izvada šo maršrutu
          if (route.start.find(start)!=string::npos &&
            route.finish.find(end)!=string::npos) {
            cout<<trimmedS<<' '<<trimmedE<<' '
            <<route.weekday<<' '<<route.time<<' '
            <<fixed<<setprecision(2)<<route.ticket_pr<<endl;
            }
        }
        break;
      }
      case 'b': {
        string weekday;
        cin>>weekday;
        cout<<"result:"<<endl;
        for(const auto& route : routes) {
          if(route.weekday==weekday) {
            pair<string, string> routePair={route.start,route.finish};
            if(printedReisi.find(routePair)==printedReisi.end()) {
              printedReisi.insert(routePair);
              cout<<route.start<< ' ' << route.finish << ' '
              <<route.weekday<<' '<<route.time<<' '
              <<fixed<<setprecision(2)<<route.ticket_pr<<endl;
            }
          }
        }
        break;
      }
      case 'c':{
        double maxPrice;
        cin>>maxPrice;

        cout<<"result:"<<endl;
        for(const auto& route : routes) {
          if(route.ticket_pr<=maxPrice) {
            pair<string, string>routePair={route.start,route.finish};
            if(printedReisi.find(routePair)==printedReisi.end()) {
              printedReisi.insert(routePair);
              cout<<route.start<<' '<<route.finish<<' '
              <<route.weekday<<' '<<route.time<<' '
              <<fixed<<setprecision(2)<<route.ticket_pr<<endl;
            }
          }
        }
        break;
      }
      case 'd':{
          printErrF("err.txt",printedErr);
          errFile.close();
          break;
      }
      case 'e':
        break;
        default:
          cout<<"izvēlies citu"<<endl;
    }
  }while(choice!='e');
  return 0;
}
