#include <cctype>
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Saraksts {
  string pilsetaNo;
  string pilsetaUz;
  string diena;
  string laiks;
  string cena;
};

void printResult(const Saraksts &ieraksts) {
  cout << ieraksts.pilsetaNo << " " << ieraksts.pilsetaUz << " "
       << ieraksts.diena << " " << ieraksts.laiks << " " << ieraksts.cena
       << endl;
}

void reisuMeklesana(vector<Saraksts> saraksts) {
  string no, uz;
  cin >> no;
  cin >> uz;
  for (const auto &ieraksts : saraksts) {
    if (ieraksts.pilsetaNo == no && ieraksts.pilsetaUz == uz) {
      printResult(ieraksts);
    }
  }
}

void dienuMeklesana(vector<Saraksts> saraksts) {
  string diena;
  cin >> diena;
  for (const auto &ieraksts : saraksts) {
    if (ieraksts.diena == diena) {
      printResult(ieraksts);
    }
  }
}

void cenuMeklesana(vector<Saraksts> saraksts) {
  double cena;
  cin >> cena;
  for (const auto &ieraksts : saraksts) {
    if (stod(ieraksts.cena) <= cena) {
      printResult(ieraksts);
    }
  }
}

void errIzvade(vector<Saraksts> saraksts) {
  double cena;
  cin >> cena;
  for (const auto &ieraksts : saraksts) {
    if (stod(ieraksts.cena) <= cena) {
      printResult(ieraksts);
    }
  }
}

bool vaiSkaitlis(const string &vards) {
  try {
    stod(vards);
    return true;
  } catch (const invalid_argument &e) {
    return false;
  } catch (const out_of_range &e) {
    return false;
  }
}

int main() {

  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;

  ofstream outFile("err.txt");

  string rinda;
  vector<Saraksts> saraksts;
  regex laikaFormats("^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$");

  map<string, int> dienas = {{"Pr", 1}, {"Ot", 2}, {"Tr", 3}, {"Ce", 4},
                             {"Pt", 5}, {"St", 6}, {"Sv", 7}};

  while (getline(inFile >> ws, rinda)) {
    string pilsetaNo, pilsetaUz, diena, laiks, cena;
    int i = 1;
    string vards;
    vards = "";
    for (char c : rinda) {
      if (c != ' ' && c != ',' && c != '\r') {
        vards += c;
      }
      if (i == 5) {
        cena = vards;
      }
      if (c == ',') {
        if (i == 1) {
          if (!vaiSkaitlis(vards)) {
            pilsetaNo = vards;
            i++;
          } else {
            continue;
          }
        } else if (i == 2) {
          if (!vaiSkaitlis(vards)) {
            pilsetaUz = vards;
            i++;
          } else {
            continue;
          }
        } else if (i == 3) {
          if (!(dienas.count(vards) == 0)) {
            diena = vards;
            i++;
          } else {
            continue;
          }
        } else if (i == 4) {
          try {
            double test = stod(vards);
          } catch (const std::invalid_argument &e) {
            continue;
          }
          if (regex_match(vards, laikaFormats)) {
            laiks = vards;
            i++;
          } else {
            continue;
          }
        } else if (i == 5) {
          i++;
        }
        vards = "";
      }
    }
    if (i == 5) {

      try {
        size_t poz;
        string vards = cena;
        double test2 = stod(vards, &poz);
        if (poz < vards.size()) {
          outFile << rinda << endl;
          continue;
        }
      } catch (const std::invalid_argument &e) {
        continue;
      } catch (const std::out_of_range &e) {
        continue;
      }

      saraksts.push_back({pilsetaNo, pilsetaUz, diena, laiks, cena});

    } else {
      outFile << rinda << endl;
    }
  }

  inFile.close();
  outFile.close();

  string vaicajums = "";
  cout << "result:" << endl;

  while (true) {
    cin >> vaicajums;

    if (vaicajums == "a") {
      reisuMeklesana(saraksts);
    } else if (vaicajums == "b") {
      dienuMeklesana(saraksts);
    } else if (vaicajums == "c") {
      cenuMeklesana(saraksts);
    } else if (vaicajums == "d") {
      ifstream izvade;
      izvade.open("err.txt");
      if (!izvade)
        return 0;
      while (getline(izvade, rinda)) {
        cout << rinda << endl;
      }
      izvade.close();
    } else if (vaicajums == "e") {
      return 0;
    }

    vaicajums = "";
  }
}
