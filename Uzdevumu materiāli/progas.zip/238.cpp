#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct Route {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};

bool parseRoute(const string &line, Route &route) {
  istringstream iss(line);
  vector<string> tokens;
  string token;

  while (getline(iss, token, ',')) {
    token = token.substr(token.find_first_not_of(" \t"), token.find_last_not_of(" \t") + 1);

    tokens.push_back(token);
  }

  if (tokens.size() != 5) {
    return false;
  }

  route.startStop = tokens[0];
  route.endStop = tokens[1];
  if (tokens[2].length() == 2) {
    route.dayOfWeek = tokens[2];
  } else {
    return false;
  }

  try {
    stod(tokens[3]);
    route.time = tokens[3];
  } catch (...) {
    return false;
  }

  try {
    route.ticketPrice = stod(tokens[4]);
  } catch (...) {
    return false;
  }

  return true;
}

int main() {
  ifstream inFile("db.csv");
  ofstream clearErrFile("err.txt", ios::trunc);
  clearErrFile.close();

  if (!inFile) {
    cout << "Error opening file." << endl;
    return 0;
  }

  vector<Route> routes;
  string line;

  while (getline(inFile, line)) {
    Route route;
    if (parseRoute(line, route)) {
      routes.push_back(route);
    } else {
      ofstream errFile("err.txt", ios::app);
      if (!line.empty()) {
        errFile << line << endl;
      }
      errFile.close();
    }
  }

  char choice;
  while (true) {
    cout << "Enter choice (a, b, c, d, e): ";
    cin >> choice;

    switch (choice) {
    case 'a': {
      string start, end;
      cout << "Enter start stop: ";
      cin >> start;
      cout << "Enter end stop: ";
      cin >> end;

      cout << "result:" << endl;
      for (const auto &route : routes) {
        if (route.startStop == start && route.endStop == end) {
          cout << route.startStop << " " << route.endStop << " "
               << route.dayOfWeek << " " << route.time << " " << fixed
               << setprecision(2) << route.ticketPrice << endl;
        }
      }
      break;
    }

    case 'b': {
      string day;
      cout << "Enter day of week (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
      cin >> day;

      cout << "result:" << endl;
      for (const auto &route : routes) {
        if (route.dayOfWeek == day) {
          cout << route.startStop << " " << route.endStop << " "
               << route.dayOfWeek << " " << route.time << " " << fixed
               << setprecision(2) << route.ticketPrice << endl;
        }
      }
      break;
    }

    case 'c': {
      double maxPrice;
      cout << "Enter maximum ticket price: ";
      cin >> maxPrice;

      cout << "result:" << endl;
      for (const auto &route : routes) {
        if (route.ticketPrice <= maxPrice) {
          cout << route.startStop << " " << route.endStop << " "
               << route.dayOfWeek << " " << route.time << " " << fixed
               << setprecision(2) << route.ticketPrice << endl;
        }
      }
      break;
    }

    case 'd': {
      ifstream errFile("err.txt");
      cout << "result:" << endl;
      cout << errFile.rdbuf();
      break;
    }

    case 'e':
      return 0;

    default:
      cout << "Invalid choice. Try again." << endl;
    }
  }

  return 0;
}