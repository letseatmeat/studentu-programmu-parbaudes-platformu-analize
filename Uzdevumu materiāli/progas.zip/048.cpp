
// Ir kaut kāda problēma ar 2. testu, it kā d komanda izvada err.txt faila saturu bez liekam atstarpēm un tukšam rindām, izvads ir tieši tā, kā testā, bet viņš neiet

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Marsruts { // maršruta struktūra
    string start; // sākuma pietura
    string end;  // beigu pietura
    string dayOfWeek; // dienas nosaukums
    string time; // laiks
    double price; // cena
};

string trim(const string& str) { // Noņemam liekos tukšumus
    size_t first = str.find_first_not_of(' '); 
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

bool isValidTime(const string& time) {
    // Vienkārša laika formāta pārbaude (hh:mm)
    if (time.length() != 5 || time[2] != ':') return false;
    int hour = stoi(time.substr(0, 2));
    int minute = stoi(time.substr(3, 2));
    return hour >= 0 && hour < 24 && minute >= 0 && minute < 60;
}

bool isValidPrice(const string& priceStr) {
    // Pārbauda, vai virkne ir derīgs decimālskaitlis
    try {
        stod(priceStr);
        return true;
    } catch (const exception& e) {
        return false;
    }
}

vector<Marsruts> loadRoutes(ifstream& inFile, ofstream& errFile) {
    vector<Marsruts> routes;
    string line;

    while (getline(inFile, line)) {
      if (line.find_first_not_of(" \t\r\n") == string::npos) {
          continue; // Ignorē tukšās rindas
      }
      
      stringstream ss(line);
      vector<string> tokens;
      string token;
      
      while (getline(ss, token, ',')) { // sadalam rindu vērtībās, izmantojot komatu kā dalītāju
          tokens.push_back(trim(token)); // Pievieno attīrīto vērtību vector.
      }

      if (tokens.size() == 5 && isValidTime(tokens[3]) && isValidPrice(tokens[4])) { // Pārbauda, vai rinda pareizā formatā
        try {
          Marsruts route = {tokens[0], tokens[1], tokens[2], tokens[3], stod(tokens[4])};
          routes.push_back(route);
        } catch (const exception& e) {
            errFile << line << endl; // Rindas pievinošana err.txt failam
        }
      } else {
          errFile << line << endl;// Rindas pievinošana err.txt failam
      }
    }

    return routes;
}



int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");
    vector<Marsruts> routes;

    if (!inFile) {
      cerr << "Nevar atvērt failu db.csv" << endl;
      return 1;
    }

    routes = loadRoutes(inFile, errFile);

    char command;
    while (true) {

      cin >> command;

      switch (command) {
        case 'a': {
            string start, end;
            cin >> start;
            cin >> end;

            cout << "result:" << endl;
            for (const auto& route : routes) {
              if (route.start == start && route.end == end) {
                cout << route.start << " " << route.end << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
              }
            }
            break;
      }
      case 'b': {
        string day;
        cin >> day;

        cout << "result:" << endl;
        for (const auto& route : routes) {
          if (route.dayOfWeek == day) {
            cout << route.start << " " << route.end << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
          }
        }
        break;
      }
        case 'c': {
          double maxPrice;
          cin >> maxPrice;

          cout << "result:" << endl;
          for (const auto& route : routes) {
            if (route.price <= maxPrice) {
              cout << route.start << " " << route.end << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
            }
          }
          break;
        }
        case 'd': {
          ifstream errFile("err.txt");
          string line;
        
          if (!errFile) {
            cout << "Nevar atvērt failu err.txt" << endl;
            break;
          }

          cout << "result:" << endl;
          while (getline(errFile, line)) {
            if(line.find_first_not_of(" \t\r\n") == string::npos) {
              continue; // Ignorē tukšās rindas
            }
            cout << line << endl;
          }
          errFile.close();
          break;
        }
        case 'e':
          return 0;
        default:
          cout << "Nepareiza komanda!" << endl;
        }
    }
}