
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

string trim(const string& str) {
    size_t start = str.find_first_not_of(" \t\r\n");
    size_t end = str.find_last_not_of(" \t\r\n");

    if (start == string::npos || end == string::npos) {
        return "";
    }

    return str.substr(start, end - start + 1);
}

bool isValidDate(const string& date) {
    return (date.size() == 2 && isalpha(date[0]) && isalpha(date[1]));
}

bool parseBusSchedule(const string& line, string& start, string& end, string& week, string& time, double& price) {
    stringstream ss(line);
    string space;

    int dCount = 0;

    if (getline(ss, space, ',') && !space.empty()) {
        start = trim(space);
    } else {
        return false;
    }

    if (getline(ss, space, ',') && !space.empty()) {
        end = trim(space);
    } else {
        return false;
    }

    if (getline(ss, space, ',') && !space.empty()) {
        week = trim(space);
        if (isValidDate(week)) {
            dCount++;
        }
    } else {
        return false;
    }

    if (getline(ss, space, ',') && !space.empty()) {
        time = trim(space);
    } else {
        return false;
    }

    if (getline(ss, space, ',')) {
        try {
            if (!trim(space).empty()) {
                price = stod(trim(space));
            } else {
                return false;
            }
        } catch (const invalid_argument& e) {
            return false;
        }
    } else {
        return false;
    }

    while (ss >> space) {
        if (isValidDate(space)) {
            dCount++;
        } else {
            return false;
        }
    }

    return dCount == 1;
}

void displaySchedule(const vector<string>& starts, const vector<string>& ends, const vector<string>& weeks,
                     const vector<string>& times, const vector<double>& prices) {
    cout << "result:" << endl;
    for (size_t i = 0; i < starts.size(); ++i) {
        cout << starts[i] << " " << ends[i] << " "
             << weeks[i] << " " << times[i] << " "
             << fixed << setprecision(2) << prices[i] << endl;
    }
}

void addScheduleData(const vector<string>& fromStarts, const vector<string>& fromEnds, const vector<string>& fromWeeks, const vector<string>& fromTimes, const vector<double>& fromPrices,
                     vector<string>& toStarts, vector<string>& toEnds, vector<string>& toWeeks, vector<string>& toTimes, vector<double>& toPrices, size_t index) {
    if (index >= fromStarts.size() || index >= fromEnds.size() || index >= fromWeeks.size() || index >= fromTimes.size() || index >= fromPrices.size()) {
        return;
    }

    toStarts.push_back(fromStarts[index]);
    toEnds.push_back(fromEnds[index]);
    toWeeks.push_back(fromWeeks[index]);
    toTimes.push_back(fromTimes[index]);
    toPrices.push_back(fromPrices[index]);
}

int main() {
    vector<string> starts, ends, weeks, times;
    vector<double> prices;

    ifstream file("db.csv");

    string line;
    while (getline(file, line)) {
        if (trim(line).empty()) {
            continue;
        }

        string start, end, week, time;
        double price;

        if (!parseBusSchedule(line, start, end, week, time, price)) {
            ofstream errF("err.txt", ios::app);
            if (errF.is_open()) {
                errF << line << endl;
                errF.close();
            }
        } else {
            starts.push_back(start);
            ends.push_back(end);
            weeks.push_back(week);
            times.push_back(time);
            prices.push_back(price);
        }
    }

char selection;
    do {
        cout << "";
        cin >> selection;

        switch (selection) {
            case 'a': {
              string start, end;
              cin.ignore();
              getline(cin, start);

              getline(cin, end);

              vector<string> sStarts, sEnds, sWeeks, sTimes;
              vector<double> sPrices;

              for (size_t i = 0; i < starts.size(); ++i) {
                  if (starts[i] == start && ends[i] == end) {
                    addScheduleData(starts, ends, weeks, times, prices, sStarts, sEnds, sWeeks, sTimes, sPrices, i);
                  }
              }

              displaySchedule(sStarts, sEnds, sWeeks, sTimes, sPrices);
              break;
            }
            case 'b': {
                string day;
                cout << "";
                cin.ignore();
                getline(cin, day);

                vector<string> sStarts, sEnds, sWeeks, sTimes;
                vector<double> sPrices;

                for (size_t i = 0; i < weeks.size(); ++i) {
                    if (weeks[i] == day) {
                      addScheduleData(starts, ends, weeks, times, prices, sStarts, sEnds, sWeeks, sTimes, sPrices, i);
                    }
                }

                displaySchedule(sStarts, sEnds, sWeeks, sTimes, sPrices);
                break;
            }
            case 'c': {
                double PriceLimit;
                cout << "";
                cin.ignore();
                cin >> PriceLimit;

                vector<string> sStarts, sEnds, sWeeks, sTimes;
                vector<double> sPrices;

                for (size_t i = 0; i < prices.size(); ++i) {
                    if (prices[i] <= PriceLimit) {
                      addScheduleData(starts, ends, weeks, times, prices, sStarts, sEnds, sWeeks, sTimes, sPrices, i);
                    }
                }

                displaySchedule(sStarts, sEnds, sWeeks, sTimes, sPrices);
                break;
            }
          case 'd': {
              ifstream errF("err.txt");
              if (errF.is_open()) {
                  cout << "result:" << endl;
                  string errL;
                  while (getline(errF, errL)) {
                      errL = trim(errL);
                      if (!errL.empty()) {
                          cout << errL << endl;
                      }
                  }
                  errF.close();
              }
              break;
          }
            case 'e': {
                cout << "";
                remove("err.txt");
                break;
            }
        }
    } while (selection != 'e');

    return 0;
}