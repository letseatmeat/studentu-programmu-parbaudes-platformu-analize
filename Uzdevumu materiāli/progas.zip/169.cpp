
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

void routeFilter(const vector<vector<string>> &schedule) {
  string start, end;
  cin >> start >> end;
  cout << "result:" << endl;
  for (auto route : schedule) {
    if (route.at(0) == start && route.at(1) == end) {
      for (const auto &n : route) {
        cout << n << " ";
      }
      cout << endl;
    }
  }
}

void weekDayFilter(const vector<vector<string>> &schedule) {
  string weekday;
  cin >> weekday;
  cout << "result:" << endl;
  for (auto route : schedule) {
    if (route.at(2) == weekday) {
      for (const auto &n : route) {
        cout << n << " ";
      }
      cout << endl;
    }
  }
}

void priceFilter(const vector<vector<string>> &schedule) {
  double price;
  cin >> price;
  cout << "result:" << endl;
  for (auto route : schedule) {
    double routePrice = stod(route.at(4));
    if (routePrice <= price) {
      for (const auto &n : route) {
        cout << n << " ";
      }
      cout << endl;
    }
  }
}

bool NaD(const string &word) {
  char colon = ':';
  bool result;
  auto index = word.find(colon);
  result = index == string::npos;
  return result;
}

bool NaN(const string &word) {
  char dot = '.';
  bool result;
  auto index = word.find(dot);
  result = index == string::npos;
  return result;
}

bool showErrors() {
  ifstream inFile;
  string line;
  inFile.open("err.txt");

  if (!inFile)
    return false;

  string d;
  cout << "result:" << endl;
  while (inFile >> d)
    cout << d << endl;

  inFile.close();
  return true;
}

bool writeError(const vector<string> &lines) {
  ofstream outputFile("err.txt");

  if (!outputFile.is_open())
    return false;
  for (const auto &n : lines)
    outputFile << n << endl;

  outputFile.close();
  return true;
}

pair<vector<vector<string>>, bool> readFile() {
  ifstream inFile;
  vector<vector<string>> schedule;
  vector<string> corrupt;
  string line;
  inFile.open("db.csv");

  if (!inFile)
    return {{}, false};

  while (getline(inFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    istringstream ss(line);
    vector<string> elements;
    string pos;

    if (line.length() == 0)
      continue;

    while (getline(ss, pos, ','))
      elements.push_back(pos);

    if (elements.size() < 5 || elements.size() > 5) {
      corrupt.push_back(line);
      continue;
    }
    if (NaN(elements.at(4)) || NaD(elements.at(3))) {
      corrupt.push_back(line);
      continue;
    }

    schedule.push_back(elements);
  }
  if (!writeError(corrupt))
    return {{}, false};
  inFile.close();
  return {schedule, true};
}

int main() {
  auto file = readFile();
  if (!file.second)
    return 0;

  string input;
  while (true) {
    cin >> input;
    if (input == "e") {
      break;
    } else if (input == "a") {
      routeFilter(file.first);
    } else if (input == "b") {
      weekDayFilter(file.first);
    } else if (input == "c") {
      priceFilter(file.first);
    } else if (input == "d") {
      if (!showErrors()) {
        return 0;
      }
    } else {
      cin.clear();
      cin.ignore(1000, '\n');
      continue;
    }
  }
  return 0;
}