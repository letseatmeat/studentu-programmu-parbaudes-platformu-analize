#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;
struct Train {
    string departureCity;
    string arrivalCity;
    string departureDay;
    string departureTime;
    string arrivalTime;
    double price;
};

map<string, vector<Train>> trains;
string currentRoute;
ifstream inputFile;
ofstream outputFile;
ofstream errorFile;
bool readLine(ifstream& inputFile, string& line) {
    while (getline(inputFile, line)) {
        if (!line.empty()) {
            return true;
        }
    }
    return false;
}

bool processCommand(const string& command, string& result) {
  if (command == "a") {
  string departureCity, arrivalCity;
  cout << "Enter departure city: ";
  getline(cin, departureCity);
  cout << "Enter arrival city: ";
  getline(cin, arrivalCity);
  vector<Train> trainsList = trains[arrivalCity];
  if (trainsList.empty()) {
      result = "No trains found for this route.";
  } else {
      for (const Train& train : trainsList) {
          if (train.departureCity == departureCity) {
              result += train.departureCity + " -> " + train.arrivalCity +
                        " (leaves at " + train.departureTime + ")" +
                        " (price: " + to_string(train.price) + ")" + "\n";
          }
      }
  }
        
  } else if (command == "b") {
  string day;
  cout << "Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
  getline(cin, day);
  for (const auto& trainsList : trains) {
      for (const Train& train : trainsList.second) {
          if (train.departureDay == day) {
              result += train.departureCity + " -> " + train.arrivalCity +
                        " (leaves at " + train.departureTime + ")" +
                        " (price: " + to_string(train.price) + ")" + "\n";
          }
      }
  }   
    } else if (command == "c") {
    double maxPrice;
    cout << "Enter maximum price: ";
    cin >> maxPrice;
    cin.ignore();
    for (const auto& trainsList : trains) {
        for (const Train& train : trainsList.second) {
            if (train.price <= maxPrice) {
                result += train.departureCity + " -> " + train.arrivalCity +
                          " (leaves at " + train.departureTime + ")" +
                          " (price: " + to_string(train.price) + ")" + "\n";
              cout<< result;
            }
        }
    } 
    } else if (command == "d") {
      string errorFileContent;
      ifstream errorFile("err.txt");
      if (errorFile.is_open()) {
          errorFileContent = string((istreambuf_iterator<char>(errorFile)),
                                    istreambuf_iterator<char>());
          errorFile.close();
      } else {
          errorFileContent = "Failed to open the error file.";
      }
      result = errorFileContent;
      return true;

    } else if (command == "e") {
        result = "Closing the program.";
        return false;
    } else if (command == "f") {
        result = "Restarting the program.";
        return true;
    } else {
        errorFile << "Invalid command: " << command << endl;
        result = "Unknown command. Please try again.";
        return true;
    }
    return true;
}
int main() {
    string inputFileName = "db.csv";
    string outputFileName = "output.txt";
    string errorFileName = "err.txt";

    inputFile.open(inputFileName);
    outputFile.open(outputFileName);
    errorFile.open(errorFileName);

    if (!inputFile.is_open()) {
        cout << "Failed to open the input file." << endl;
        return 1;
    }

    string line;
    while (readLine(inputFile, line)) {
       
    }

    string command;
    string result;
    while (true) {
        cout << "Enter a command: ";
        getline(cin, command);
        if (!processCommand(command, result)) {
            break;
        }
        cout << result << endl;
    }

    inputFile.close();
    outputFile.close();
    errorFile.close();

    return 0;
}
