

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>

using namespace std;

class String {
private:
  String();

public:
  static string trim(string str) {
    size_t firstNonSpaceChar = str.find_first_not_of(' ');
    size_t lastNonSpaceChar = str.find_last_not_of(' ');
    return str.substr(firstNonSpaceChar,
                      (lastNonSpaceChar - firstNonSpaceChar + 1));
  }

  static vector<string> split(string str, string delimiter) {
    size_t delPosition = 0;
    string token;
    vector<string> tokens;

    while ((delPosition = str.find(delimiter)) != std::string::npos) {
      token = str.substr(0, delPosition);
      tokens.push_back(token);
      str.erase(0, delPosition + delimiter.length());
    }
    tokens.push_back(str);

    return tokens;
  }
};

class Route {
private:
  string departsFrom;
  string arrivesAt;
  string day;
  string time;
  double price;

public:
  void setDepartsFrom(string departsFrom) {
    this->departsFrom = String::trim(departsFrom);
  }
  string getDepartsFrom() { return departsFrom; }

  void setArrivesAt(string arrivesAt) {
    this->arrivesAt = String::trim(arrivesAt);
  }
  string getArrivesAt() { return arrivesAt; }

  void setDay(string day) {
    day = String::trim(day);
    if (!validateDay(day)) {
      throw invalid_argument("incorrect day format");
    }

    this->day = day;
  }
  string getDay() { return day; }

  void setTime(string time) {
    time = String::trim(time);
    for (char c : time) {
      if (isalpha(c)) {
        throw invalid_argument("incorrect time format");
      }
    }

    this->time = time;
  }
  string getTime() { return time; }

  void setPrice(double price) { this->price = price; }
  double getPrice() { return price; }

  static bool validateDay(string day) {
    if (day == "Pr" || day == "Ot" || day == "Tr" || day == "Ce" ||
        day == "Pt" || day == "Se" || day == "Sv") {
      return true;
    }
    return false;
  }

  Route(string departsFrom, string arrivesAt, string day, string time,
        double price) {
    setDepartsFrom(departsFrom);
    setArrivesAt(arrivesAt);
    setDay(day);
    setTime(time);
    setPrice(price);
  }
};

class RoutesIO {
private:
  RoutesIO();

  static void printRoute(Route route) {
    cout << route.getDepartsFrom() << " " << route.getArrivesAt() << " "
         << route.getDay() << " " << route.getTime() << " " << fixed
         << setprecision(2) << route.getPrice() << endl;
  }

public:
  static void printRoutesByStops(vector<Route> routes) {
    string departsFrom, arrivesAt;
    cin >> departsFrom >> arrivesAt;

    cout << "result:" << endl;
    for (Route route : routes) {
      if (route.getDepartsFrom() == departsFrom &&
          route.getArrivesAt() == arrivesAt) {
        printRoute(route);
      }
    }
  }

  static void printRoutesByDay(vector<Route> routes) {
    string day;
    cin >> day;

    cout << "result:" << endl;

    if (!Route::validateDay(day)) {
      cout << "day invalid" << endl;
    }

    for (Route route : routes) {
      if (route.getDay() == day) {
        printRoute(route);
      }
    }
  }

  static void printRoutesByPrice(vector<Route> routes) {
    string price;
    cin >> price;

    cout << "result:" << endl;

    try {
      for (Route route : routes) {
        if (route.getPrice() <= stod(price)) {
          printRoute(route);
        }
      }
    } catch (...) {
      cout << "price invalid" << endl;
    }
  }

  static void printFaultyLines() {
    ifstream inputFileStream("err.txt");

    cout << "result:" << endl;

    string line;
    while (getline(inputFileStream, line)) {
      cout << line << endl;
    }

    inputFileStream.close();
  }
};

int main() {
  ifstream inputFileStream("db.csv");
  ofstream outputFileStream("err.txt");

  vector<Route> routes;

  string line;
  vector<string> routeData;
  while (getline(inputFileStream, line)) {
    routeData = String::split(line, ",");

    if (routeData.size() == 1) {
      continue;
    }

    try {
      if (routeData.size() != 5) {
        throw invalid_argument("incorrect line format");
      }
      routes.push_back(Route(routeData[0], routeData[1], routeData[2],
                             routeData[3], stod(routeData[4])));
    } catch (...) {
      line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
      outputFileStream << line << endl;
    }
  }

  inputFileStream.close();
  outputFileStream.close();

  char choice = ' ';
  while (choice != 'e') {
    cin >> choice;

    switch (choice) {
    case 'a':
      RoutesIO::printRoutesByStops(routes);
      break;
    case 'b':
      RoutesIO::printRoutesByDay(routes);
      break;
    case 'c':
      RoutesIO::printRoutesByPrice(routes);
      break;
    case 'd':
      RoutesIO::printFaultyLines();
      break;
    case 'e':
      break;
    default:
      cout << "error" << endl;
    }
  }

  return 0;
}
