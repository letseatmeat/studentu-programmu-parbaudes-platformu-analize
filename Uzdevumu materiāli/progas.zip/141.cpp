

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <regex>
#include <set>
using namespace std;

struct busRoute {
  string start;
  string end;
  string day;
  string time;
  double price;
};

bool isCity (const string& str) {
  regex pattern("\\b[A-Z][a-z]*\\b");
  return regex_match(str, pattern);
}

bool isDay (const string& str) {
  set<string> dotw = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return dotw.count(str);
}

bool isTime (const string& str) {
  regex pattern("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
  return regex_match(str, pattern);
}

bool isPrice (const string& str) {
  regex pattern("^\\d+(\\.\\d{2})$");
  return regex_match(str, pattern);
}

void outResult (const vector<busRoute>& routes) {
  cout << "result:" << endl;
  for (const auto& route : routes) {
    cout << route.start << " " << route.end << " " << 
      route.day << " " << route.time << " " << 
      fixed << setprecision(2) << route.price << " " << endl;
  }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) return 0;

  ofstream outFile;
  outFile.open("err.txt");
  if (!outFile) return 0;

  vector<busRoute> routes;
  string line;
  while (getline(inFile, line)) {
    istringstream iss(line);
    vector<string> elements;
    string element;
    busRoute route;

    if (line.empty()) continue;

    while (getline(iss, element, ',')) {
      element.erase(0, element.find_first_not_of(' '));
      element.erase(element.find_last_not_of(' ') + 1);
      elements.push_back(element);
    }

    if (elements.size() == 5 && isCity(elements.at(0)) && 
      isCity(elements.at(1)) && isDay(elements.at(2)) && 
      isTime(elements.at(3)) && isPrice(elements.at(4))) {
      route.start = elements.at(0);
      route.end = elements.at(1);
      route.day = elements.at(2);
      route.time = elements.at(3);
      route.price = stod(elements.at(4));
      routes.push_back(route);
    } else {
      outFile << line << endl;
    }
  }

  inFile.close();
  outFile.close();

  char choice;
  do {
    cin >> choice;

    switch (choice) {
      case 'a': {
        string startStop, endStop;
        cin >> startStop;
        cin >> endStop;
        
        vector<busRoute> matchRoutes;
        for (const auto& route : routes) {
          if (route.start == startStop && route.end == endStop) {
            matchRoutes.push_back(route);
          }
        }
        outResult(matchRoutes);
        break;
      }
      
      case 'b': {
        string dayOfTheWeek;
        cin >> dayOfTheWeek;
        
        vector<busRoute> matchRoutes;
        for (const auto& route : routes) {
          if (route.day == dayOfTheWeek) {
            matchRoutes.push_back(route);
          }
        }
        outResult(matchRoutes);
        break;
      }
      
      case 'c': {
        double ticketPrice;
        cin >> ticketPrice;
        
        vector<busRoute> matchRoutes;
        for (const auto& route : routes) {
          if (route.price <= ticketPrice) {
            matchRoutes.push_back(route);
          }
        }
        outResult(matchRoutes);
        break;
      }
      
      case 'd': {
        ifstream errFile;
        errFile.open("err.txt");
        if (!errFile) return 0;
        
        cout << "result:" << endl;
        
        string errLine;
        while (getline(errFile, errLine)) {
          if (!errLine.empty()) {
            cout << errLine << endl;
          }
        }
        errFile.close();
        break;
      }
      
      case 'e': {
        break;
      }
    }
  } while (choice != 'e');
}
