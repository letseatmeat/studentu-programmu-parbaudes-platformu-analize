
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <string>
#include <vector>
#include <string>
#include <string.h>

using namespace std;
void failaApstrade(string& teksts)
{
  ifstream inFile;
  string sas = ""; 
  string s; 
  inFile.open("db.csv");
  ofstream outfile ("err.txt");
  
  if (!inFile) return 0;
  
  while (getline(inFile, s)) {

      
      sas = sas+s+"\n";
  }
  sas.erase(remove(sas.begin(), sas.end(), ' '), sas.end());
  
  istringstream buffer( sas );
  string token;
  sas = "";
  vector <int> vec;
  size_t found = teksts.find(',');
  while(buffer>>token )
    {
      sas = sas+token + ",\n";
    }

  istringstream bufferq( sas );
  vector <string> sakBeig;
  vector <string> diena;
  vector <string> laiks;
  vector <string> cena;
  vector<string> beigas;
  vector<string> nederigie;
  int i = 0;
  int lineNumber = 0;
  string line;
  sas="";
  
  while (getline(bufferq, line))
{
  istringstream lineStream(line);
  string tokenz;
    
    while( getline( lineStream, tokenz, ',' ) )
    {
      i++;
      if(tokenz.length()>2 && i==1)
        {
          sakBeig.push_back(tokenz);
        }
      else if (tokenz.length()>2 && i==2)
        {
           beigas.push_back(tokenz);
        }
      else if(tokenz.length()==2 && i==3)
        {
          diena.push_back(tokenz);
        }
      else if(tokenz.length()>2 && i==4 )
      {
        if(tokenz.at(2) == ':')
        {
          laiks.push_back(tokenz);
        }
      }
      else if(tokenz.length()>2 &&i==5  )
      {
        
        if(tokenz.at(tokenz.length() - 3) == '.')
          {
            cena.push_back(tokenz);
          }
      }
      else if(i>5)
      {
        nederigie.push_back(tokenz);
      }
    }

    i=0;
  if(sakBeig.size()==1 && diena.size()==1 && laiks.size()==1 && cena.size()==1 && beigas.size()==1 && nederigie.size()==0)
  {
    sas=sas+line+"\n";
    sakBeig.clear();
    beigas.clear();
    diena.clear();
    laiks.clear();
    cena.clear();
    nederigie.clear();
  }
  else
  {
    line.erase(line.begin() +(line.length()- 1));
   outfile<<line<<endl;
    sakBeig.clear();
    beigas.clear();
    diena.clear();
    laiks.clear();
    cena.clear();
    nederigie.clear();
  }
}
  outfile.close();
teksts = sas;
}

void a(string teksts)//izvada visus reisus izveletaja marsrutā, inputs ir sakuma un gala pietura
{
    istringstream bufferq( teksts );
    vector <string> pirma;
    vector <string> otra;
  int i = 0;
    int lineNumber = 0;
    string line;
  string pirmaPilseta;
  string otraPilseta;
  cin>>pirmaPilseta;
  cin>> otraPilseta;
  cout << "result:"<<endl;
  
    while (getline(bufferq, line))
  {
    istringstream lineStream(line);
    string tokenz;
     istringstream lineStreamu(line);
      string tokenu;

      while( getline( lineStream, tokenz, ',' ) )
      {
        i++;
        if(tokenz ==pirmaPilseta && i==1)
          {
            pirma.push_back(tokenz);
          }
        else if (tokenz ==otraPilseta && i==2)
          {
             otra.push_back(tokenz);
          }
      }
      i=0;
    
    if(pirma.size()==1 && otra.size()==1 )
    {
      while( getline( lineStreamu, tokenu, ',' ) )
        {
          cout << tokenu <<" ";
        }
      cout<<endl;
      pirma.clear();
      otra.clear();
    }
    else
    {
      pirma.clear();
      otra.clear();
    }
  }
}
void b(string teksts)//izvada visus reisus, kas kursē noteiktā dienā, inputs ir dienas saīsinājumi
{
    istringstream bufferq( teksts );
    vector <string> pirma;
  int i = 0;
    int lineNumber = 0;
    string line;
  string pirmaDiena;
  cin>>pirmaDiena;
  cout << "result:"<<endl;
  
    while (getline(bufferq, line))
  {
    istringstream lineStream(line);
    string tokenz;
     istringstream lineStreamu(line);
      string tokenu;

      while( getline( lineStream, tokenz, ',' ) )
      {
        i++;
        if(tokenz ==pirmaDiena && i==3)
          {
            pirma.push_back(tokenz);
          }
      }
      i=0;
    
    if(pirma.size()==1)
    {
      while( getline( lineStreamu, tokenu, ',' ) )
        {
          cout << tokenu <<" ";
        }
      cout<<endl;
      pirma.clear();
    }
      
    else
    {
      pirma.clear();
    }
  }
}
void c(string teksts)//izvada visus reisus, kuru biletes neparsniedz ievadito, inputs ir biletes maksa
{
  istringstream bufferq( teksts );
  vector <string> pirma;
  int i = 0;
  int lineNumber = 0;
  string line;
  double eiras;
  cin>>eiras;
  cout << "result:"<<endl;
  int z =0;
  
  while (getline(bufferq, line))
  {
  istringstream lineStream(line);
  string tokenz;
   istringstream lineStreamu(line);
    string tokenu;

    while( getline( lineStream, tokenz, ',' ) )
    {
      i++;
      if( i==5)
        {
          z = stod(tokenz);
          if(z<= eiras)
          {
            pirma.push_back(tokenz);
          }
        }
    }
    i=0;
    
  if(pirma.size()==1)
  {
    while( getline( lineStreamu, tokenu, ',' ) )
      {
        cout << tokenu <<" ";
      }
    cout<<endl;
    pirma.clear();
  }
    
  else
  {
    pirma.clear();
  }
  }
}
void d()//izvadit err.txt saturu
{
  ifstream inFile;
  inFile.open("err.txt");
  string s;
  cout<<"result:"<< endl;
  
  while(inFile>>s)
    {
      cout<<s<<endl;
    }
}

int main() {
  string teksts;
  failaApstrade(teksts);

  char x;
  do
    {
      cin>> x;
  switch (x) { 
    
  case 'a': 
    a(teksts);  
      break; 
  case 'b': 
      b(teksts);
      break; 
  case 'c': 
      c(teksts);
    break;
  case 'd': 
    d();
      break; 
             }
    }
    while(x != 'e');
  return 0; 
} 