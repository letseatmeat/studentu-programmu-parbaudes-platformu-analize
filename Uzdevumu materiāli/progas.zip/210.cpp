#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

struct Marsruts {
  string sakumaPietura;
  string galaPietura;
  string diena;
  string laiks;
  double cena;
};

void printReiss(const Marsruts &reiss) {
  cout <<"result: "<< reiss.sakumaPietura << " - " << reiss.galaPietura << " "
       << reiss.diena << " " << reiss.laiks << " " << fixed<< setprecision(2)<<reiss.cena << endl;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  ofstream errFile("err.txt");
  if (!inFile) {
    cerr << endl;
    return 1;
  }
  vector<Marsruts> marsruti;

  string line;
  while (getline(inFile, line)) {
    istringstream iss(line);
    for (char& c : line){
      if (c!=' '&&c!='\t'){
        iss.putback(c);
        break;
      }
    }
  Marsruts reiss;
  if(iss>>reiss.sakumaPietura>>reiss.galaPietura>>reiss.diena>>reiss.laiks>>reiss.cena){
    marsruti.push_back(reiss);
  }
  else{
    errFile<<line<<endl;
  }
  }
  char choice;
  while (true) {
    cin >> choice;
    switch (choice) {
    case 'a': {
      string sakumaPietura, galaPietura;
      cin >> sakumaPietura >> galaPietura;
      for (const auto &reiss : marsruti) {
        if (reiss.sakumaPietura == sakumaPietura &&
            reiss.galaPietura == galaPietura) {
          printReiss(reiss);
        }
      }
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      for (const auto &reiss : marsruti) {
        if (reiss.diena == diena) {
          printReiss(reiss);
        }
      }
      break;
    }
    case 'c': {
      double maksa;
      cin >> maksa;
      for (const auto &reiss : marsruti) {
        if (reiss.cena <= maksa) {
          printReiss(reiss);
        }
      }
      break;
    }
    case 'd': {
      ifstream errFile("err.txt");
      string line;
      cout << "result: ";
      while (getline(errFile, line)) {
        cout << line << endl;
      }
      break;
    }
    case 'e':
      return 0;
    
    default:
    cout<<"error"<<endl;
  }
  }
  return 0;
}