

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

// Function to split a string based on a delimiter
vector<string> splitString(const string &s, char delimiter) {
  vector<string> tokens;
  stringstream ss(s);
  string token;

  while (getline(ss, token, delimiter)) {
    tokens.push_back(token);
  }

  return tokens;
}

// Function to remove whitespace from both ends of a string
string trimString(const string &s) {
  size_t start = s.find_first_not_of(" \t\r\n");
  size_t end = s.find_last_not_of(" \t\r\n");

  return (start != string::npos && end != string::npos)
             ? s.substr(start, end - start + 1)
             : "";
}

int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

  if (!inFile || !errFile) {
    cout << "Error: Unable to open files!" << endl;
    return 0;
  }

  string command;
  while (true) {
    cin >> command;

    if (command == "a") {
      string start, end;
      cin >> start >> end;
      string line;

      cout << "result:" << endl;

      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        vector<string> tokens = splitString(line, ',');

        if (tokens.size() >= 2) {
          if (trimString(tokens[0]) == start && trimString(tokens[1]) == end) {
            for (const auto &token : tokens) {
              cout << trimString(token) << " ";
            }

            cout << endl;
          } else {
            errFile << line << endl;
          }
        } else {
          errFile << line << endl;
        }
      }
    } else if (command == "b") {
      string day;
      cin >> day;
      string line;

      cout << "result:" << endl;

      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        vector<string> tokens = splitString(line, ',');

        if (tokens.size() >= 3) {
          if (trimString(tokens[2]) ==
              day) { // Assuming day of the week is the third token
            for (const auto &token : tokens) {
              cout << trimString(token) << " ";
            }

            cout << endl;
          } else {
            errFile << line << endl;
          }
        } else {
          errFile << line << endl;
        }
      }
    } else if (command == "c") {
      double maxPrice;
      cin >> maxPrice;
      string line;

      cout << "result:" << endl;

      inFile.clear();
      inFile.seekg(0, ios::beg);

      while (getline(inFile, line)) {
        vector<string> tokens = splitString(line, ',');

        if (tokens.size() == 5) {
          try {
            double ticketPrice = stod(trimString(
                tokens[4])); // Assuming ticket price is the fifth token
            if (!trimString(tokens[3]).empty() && ticketPrice <= maxPrice) {
              for (const auto &token : tokens) {
                cout << trimString(token) << " ";
              }

              cout << endl;
            } else {
              errFile << line << endl;
            }
          } catch (...) {
            errFile << line << endl; // If ticket price cannot be converted to
                                     // double, log to err.txt
          }
        } else {
          errFile << line << endl;
        }
      }
      } else if (command == "d") {
          string query;
          cin.ignore(); // Ignore whitespace/newline in the input buffer
          getline(cin, query); // Read the entire line as the query

          string line;
          inFile.clear();
          inFile.seekg(0, ios::beg);

          cout << "result:" << endl;
          bool found = false;

          while (getline(inFile, line)) {
              if (line.find(query) != string::npos) {
                  cout << line << endl;
                  found = true;
              } else {
                  errFile << line << endl;
              }
          }

          if (!found) {
              cout << "No matching line found." << endl;
          }
          errFile.clear(); // Clear error file for next 'd' command
      } else if (command == "e") {
      break;
    } else {
      cout << "Invalid command. Please enter a valid command." << endl;
    }
  }

  inFile.close();
  errFile.close();
  return 0;
}
