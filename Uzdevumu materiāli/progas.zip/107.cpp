#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct destinationData {
  string start;
  string end;
  string day;
  string time;
  string price;
};

bool isValidData(vector<string> data) {
  if (data.size() != 5)
    return false;

  if (data[0].empty() || data[1].empty())
    return false;

  vector<string> weekdays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  int n = 0;
  for (string day : weekdays) {
    if (data[2] == day) {
      break;
    } else
      n++;
  }
  if (n == 7)
    return false;

  if (data[3].size() != 5 || data[3][2] != ':')
    return false;

  istringstream priceString(data[4]);
  double price;
  if (!(priceString >> price) || data[4][data[4].length() - 4] != '.') {
    cout << data[4][data[4].length() - 4] << endl;
    return false;
  }

  return true;
}

void commandA(const vector<destinationData> validData) {
  string inputStart;
  string inputEnd;
  cin >> inputStart >> inputEnd;
  cout << "result:" << endl;
  for (const auto data : validData) {
    if (data.start == inputStart && data.end == inputEnd) {
      cout << data.start << " " << data.end << " " << data.day << " " << data.time << " " << data.price << endl;
    }
  }
}
void commandB(const vector<destinationData> validData) {
  string inputDay;
  cin >> inputDay;
  cout << "result:" << endl;
  for (const auto data : validData) {
    if (data.day == inputDay) {
      cout << data.start << " " << data.end << " " << data.day << " " << data.time << " " << data.price << endl;
    }
  }
}
void commandC(const vector<destinationData> validData) {
  double inputPrice;
  cin >> inputPrice;
  cout << "result:" << endl;
  for (const auto data : validData) {
    if (inputPrice >= stod(data.price)) {
      cout << data.start << " " << data.end << " " << data.day << " " << data.time << " " << data.price << endl;
    }
  }
}
void commandD() {
  ifstream errFile;
  errFile.open("err.txt");
  if (!errFile) return;
  cout << "result:" << endl;
  string line;
  while (getline(errFile, line)) {
    cout << line << endl;
  }
  errFile.close();
}

int main() {
  ifstream inFile;
  ofstream errFile;
  inFile.open("db.csv");
  errFile.open("err.txt");

  if (!inFile || !errFile)
    return 0;

  string s;
  vector<destinationData> validData;
  while (getline(inFile, s)) {
    s.erase(remove(s.begin(), s.end(), ' '), s.end());
    
    if (s.empty() || all_of(s.begin(), s.end(), ::isspace)) continue;
    
    istringstream line(s);
    vector<string> lineData;
    string data;

    while (getline(line, data, ',')) {
      lineData.push_back(data);
    }
    if (!isValidData(lineData)) {
      errFile << s << endl;
    }
    else {
      destinationData d;
      d.start = lineData[0];
      d.end = lineData[1];
      d.day = lineData[2];
      d.time = lineData[3];
      d.price = lineData[4];
      validData.push_back(d);
    }
    // cout << s << endl;
  }
  
  inFile.close();
  errFile.close();
  
  char cmd;
  while (cmd != 'e') {
    cin >> cmd;
    switch (cmd) {
    case 'a':
      commandA(validData);
      break;
    case 'b':
      commandB(validData);
      break;
    case 'c':
      commandC(validData);
      break;
    case 'd':
      commandD();
      break;
    case 'e':
      break;
    default:
      break;
    }
  }
}