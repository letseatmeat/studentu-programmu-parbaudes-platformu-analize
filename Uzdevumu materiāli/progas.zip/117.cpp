

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// Definē struktūru "Marsruts" ar pieciem laukiem
struct Marsruts {
    string sakuma_punkts;
    string beigu_punkts;
    string diena;
    string laiks;
    float cena;
};

// Funkcija, kas noņem tukšumus no teksta sākuma un beigām
void trim(string &s) {
    s.erase(s.begin(), find_if_not(s.begin(), s.end(), ::isspace)); //isspace funkcija pārbauda, vai simbols ir atstarpe vai citas tukšuma rakstzīmes). Šī funkcija izdzēš tukšumus no teksta sākuma.
    s.erase(find_if_not(s.rbegin(), s.rend(), ::isspace).base(), s.end());
  // tiek atrasts pēdējais simbols, kas nav tukšums, un  noņem visus simbolus no tā līdz rindas beigām.
}

// Funkcija, kas sadala tekstu pēc dotā delimiter simbola
vector<string> split(const string &s, char delimiter) {
  
    // Izveido vektoru, kur glabāsies sadalītie fragmenti
    vector<string> tokens;
  
    // Pagaidu mainīgais, lai glabātu katru atsevišķo sadalīto virkni
    string token;
  
    // Izveido simbolu saklikumu, lai viegli dabūtu sadalītos fragmentus no sākotnējās teksta virknes
    istringstream tokenStream(s);

    // Cikls, kas nolasīs un apstrādās katru sadalīto fragmentu
    while (getline(tokenStream, token, delimiter)) {
      
        // Noņem iespējamos tukšumus no paša fragmenta, izmantojot iepriekšējo trim funkciju
        trim(token);
        // Pievieno apstrādāto fragmentu vektorā
        tokens.push_back(token);
    }

    // Atgriež rezultātu - vektoru ar sadalītajiem fragmentiem
    return tokens;
}

// Funkcija, kas pārbauda vai laika formāts ir pareizs (stundas un minūtes)
bool laikaApskate(const string& time) {
    if (time.size() != 5 || time[2] != ':') return false;
  //funkcija pārbauda vai laiks ir 5 simbolus garš, un vai trešais simbols ir ":"
    try {
        int hour = stoi(time.substr(0, 2));
        int minute = stoi(time.substr(3, 2));
      //konvertē pirmos divus simbolus no teksta virknes time uz veseliem skaitļiem un saglabā rezultātu mainīgajā hour, konvertē nākamos divus simbolus un saglabā rezultātu mainīgajā minute
      
        return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
      //Pārbauda, vai stundas vērtība ir robežās no 0 līdz 23 un vai minūtes vērtība ir robežās no 0 līdz 59
      
    } catch (...) {
      //catch (...) nozīmē, ka tiek uztverts jebkāds izņēmums.Šajā gadījumā funkcija atgriež false, jo laika formāts ir uzskatāms par nepareizu, ja kāda iemesla dēļ nav iespējams iegūt derīgas stundas un minūtes.
      
        return false;
    }
}

// Funkcija, kas pārbauda vai marsruta informācija ir pareiza
bool marsrutsPareizs(const vector<string>& marsruts) {
    if (marsruts.size() != 5) return false;
  //pārbauda vai vektors marsruts satur tieši piecus elementus
  
    return laikaApskate(marsruts[3]) && (stof(marsruts[4]) >= 0.0);
  //izsauc iepriekš definēto funkciju laikaApskate, kura pārbauda, vai laika formāts (stunda:minūte) ir derīgs, (stof(marsruts[4]) >= 0.0) pārbauda, vai cena, kas atrodas vektora piektajā pozīcijā (marsruts[4]), ir lielāka vai vienāda ar 0.0
}

// Funkcija, kas nolasa marsruta informāciju no faila
vector<vector<string>> marsrutaNolasisana(const string& fileName) {
  
  // Izveido tukšu vektoru, lai uzglabātu visus maršrutus
  vector<vector<string>> routes;
  // Nolasa faila saturu
  ifstream file(fileName);
  
  // Mainīgais, kurā tiks nolasīta katra rinda no faila
  string line;

  // Izveido jaunu failu, kurā uzglabās nolasītās rindas ar nederīgu maršruta informāciju
  ofstream errFile("err.txt");

  // Cikls, kas nolasa faila rindas
  while (getline(file, line)) {
      // Izsauc funkciju, lai noņemtu tukšumus no rindas sākuma un beigām
      trim(line);
    
      // Pārbauda, vai rinda nav tukša 
      if (!line.empty()) {
        
          // Sadala rindu pa komatiem un atgriež vektoru ar atsevišķiem fragmentiem
          auto marsruts = split(line, ',');

          // Pārbauda, vai maršruts ir derīgs, izmantojot iepriekš definēto funkciju
          if (marsrutsPareizs(marsruts)) {
            
              // Ja maršruts ir derīgs, pievieno to galvenajam vektoram
              routes.push_back(marsruts);
          } else {
              // Ja maršruts nav derīgs, ieraksta to nederīgo maršrutu failā
              errFile << line << endl;
          }
      }
  }


    errFile.close();
    return routes;
}

// Funkcija, kas pārvērš visus burtus lielos burtos
string toUpper(const string &s) {
  // Izveido jaunu tukšu virkni, kur tiks saglabāta rezultējošā teksta virkne ar lielajiem burtiem
      string upperCaseString;

      // Lai saglabātu rezultātu, tiek izmantots back_inserter, kas pievieno katru pārveidoto burtu rezultātu virknē
      transform(s.begin(), s.end(), back_inserter(upperCaseString), ::toupper);

      // Atgriež rezultējošo teksta virkni ar visiem burtiem lielajiem
      return upperCaseString;
  }

// Funkcija, kas izvada visus marsruta laukus uz ekrāna
void printMarsruts(const vector<string>& marsruts) {
    for (const auto& field : marsruts) {
      // Iterē cauri katram elementam vektorā ar teksta virknēm
        cout << field << " ";
    }
    cout << endl;
}

// Funkcija, kas izvada visus marsrutus, kuri sākas un beidzas noteiktās pieturās
void print_pec_pieturam(const vector<vector<string>>& routes, const string& sakuma_punkts, const string& beigu_punkts) {
    // Pārveido ievades pieturu nosaukumus uz lielajiem burtiem, lai salīdzināšana notiktu neatkarīgi no lieluma
    string upper_sakuma_punkts = toUpper(sakuma_punkts);
    string upper_beigu_punkts = toUpper(beigu_punkts);

    bool found = false;

    // Iterē cauri katram maršrutam vektorā ar maršrutiem
    for (const auto& marsruts : routes) {
      
        // Pārbauda, vai maršruts satur pareizo skaitu lauku un vai sākuma un beigu pieturas nosaukumi sakrīt
        if (marsruts.size() == 5 && toUpper(marsruts[0]) == upper_sakuma_punkts && toUpper(marsruts[1]) == upper_beigu_punkts) {
            // Ja nosacījums izpildās, izvada maršruta informāciju uz ekrāna, izmantojot iepriekš definēto funkciju
            printMarsruts(marsruts);
            // Atzīmē, ka atrasts derīgs maršruts
            found = true;
        }
    }

    // Ja nav atrasts neviens maršruts ar ievadītajiem pieturu nosaukumiem
    if (!found) {
        // Izvada kļūdas paziņojumu uz ekrāna
        cout << "Kļūda ievadot pieturas nosaukumu.\n";
    }
}

// Funkcija, kas izvada visus marsrutus, kuri ir noteiktā nedēļas dienā
void print_pec_dienas(const vector<vector<string>>& routes, const string& dayOfWeek) {
    // Definē nedēļas dienu nosaukumus
    vector<string> acceptableDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    // Pārveido ievadīto dienas nosaukumu uz lielajiem burtiem, lai salīdzināšana notiktu neatkarīgi no lieluma
    string upperDayOfWeek = toUpper(dayOfWeek);

    bool found = false;

    // Iterē cauri katram maršrutam vektorā ar maršrutiem
    for (const auto& marsruts : routes) {
        // Pārbauda, vai maršruta dienas nosaukums sakrīt ar ievadīto dienas nosaukumu
        if (toUpper(marsruts[2]) == upperDayOfWeek) {
            // Ja nosacījums izpildās, izvada maršruta informāciju uz ekrāna, izmantojot iepriekš definēto funkciju
            printMarsruts(marsruts);
            // Atzīmē, ka atrasts derīgs maršruts
            found = true;
        }
    }

    // Ja nav atrasts neviens maršruts ar ievadīto dienas nosaukumu
    if (!found) {
        // Izvada kļūdas paziņojumu uz ekrāna
        cout << "Kļūdaini ievadīta diena.\n";
    }
}

// Funkcija, kas izvada visus marsrutus, kuriem cena ir mazāka vai vienāda ar dotu maksimālo cenu
void print_pec_cenas(const vector<vector<string>>& routes, double maxCena) {
    for (const auto& marsruts : routes) {
        // Pārbauda, vai maršruta cena ir mazāka vai vienāda ar maksimālo pieņemamo cenu
        if (stod(marsruts[4]) <= maxCena) {
            // Ja nosacījums izpildās, izvada maršruta informāciju uz ekrāna, izmantojot iepriekš definēto funkciju
            printMarsruts(marsruts);
        }
    }
}

// Funkcija, kas izvada rindiņas no kļūdu faila
void printErrorLines(const string& fileName) {
    // Faila nolasīšana
    ifstream file(fileName);
    // Mainīgais, kurā tiks nolasīta katra rinda no faila
    string line;

    // Pārbauda, vai izdevās atvērt failu
    if (file.is_open()) {
        // Cikls, kas nolasa faila rindas un izvada tās uz ekrāna
        while (getline(file, line)) {
            cout << line << endl;
        }
        // Aizver failu, kad visas rindas ir izlasītas
        file.close();
    } else {
        // Izvada kļūdas paziņojumu, ja neizdevās atvērt failu
        cout << "Failu nevar atvērt: " << fileName << endl;
    }
}


int main() {
    // Nolasa maršrutu informāciju no faila un saglabā to vektorā
    auto routes = marsrutaNolasisana("db.csv");

    // Nebeidzama cikla sākums, lai programma darbotos nepārtraukti
    while (true) {
        // Nolasa ievades rindu no lietotāja
        string line;
        getline(cin, line);
        // Noņem tukšumus no ievades rindas
        trim(line);
        // Izveido straumi no ievades rindas, lai iegūtu komandas simbolu un atsevišķus parametrus
        istringstream iss(line);
        char action;
        // Iegūst komandas simbolu
        iss >> action;

        // Izpilda atbilstošo darbību, atkarībā no iegūtās komandas
        switch (action) {
            case 'a': {
                string sakuma_punkts, beigu_punkts;
                // Nolasa sākuma un beigu pieturas nosaukumus
                if (getline(cin, sakuma_punkts) && getline(cin, beigu_punkts)) {
                    // Noņem tukšumus no ievades parametriem
                    trim(sakuma_punkts);
                    trim(beigu_punkts);
              
                    cout << "result:\n";
                    print_pec_pieturam(routes, sakuma_punkts, beigu_punkts);
                }
                break;
            }
            case 'b': {
                string diena;
                // Nolasa dienas nosaukumu
                if (getline(cin, diena)) {
                    // Noņem tukšumus no ievades parametra
                    trim(diena);
              
                    cout << "result:\n";
                    print_pec_dienas(routes, diena);
                }
                break;
            }
            case 'c': {
                string priceStr;
                // Nolasa cenas ierobežojumu kā simbolu virkni
                if (getline(cin, priceStr)) {
                    // Noņem tukšumus no ievades parametra
                    trim(priceStr);
                    try {
                        // Pārveido cenas ierobežojumu uz decimāldaļu
                        double maxCena = stod(priceStr);
                     
                        cout << "result:\n";
                        print_pec_cenas(routes, maxCena);
                    } catch (const invalid_argument& e) {
                        cout << "Ķļūda ievadot cenu.\n";
                    }
                }
                break;
            }
            case 'd':
                
                cout << "result:\n";
                // Izvada kļūdu rindas no faila "err.txt"
                printErrorLines("err.txt");
                break;
            case 'e':
                // Beidz programmas izpildi
                return 0;
            default:
                cout << "Ķļūdains ieraksts.\n";
        }
    }
  
    return 0;
}