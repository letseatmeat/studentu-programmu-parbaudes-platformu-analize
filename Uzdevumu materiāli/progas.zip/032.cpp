

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

// DOTĀ FAILA APSTRĀDE
vector<vector<string>> dataProcess(string inFileName, string tempFileName, string resultFileName) {
  
    ifstream inFile;
    inFile.open(inFileName);
    if (!inFile) exit(0);

    vector<string> dati;
    string s; 
  
    // saliek visas netukšās rindas vektorā
    while (getline(inFile, s))
    {
      if (!s.empty())
         dati.push_back(s);
    }
    inFile.close();

    // iterē vektoru, saliek visas līnijas bez liekām atstarpēm temp failā
    ofstream tempFile, resultFile;
    tempFile.open("temp2.txt", ios::out | ios::trunc);
    for (const auto& s : dati) {
        for (char ch : s) {
          if (ch != ' ')
            tempFile << ch;
        }
        tempFile << endl;
    }
    tempFile.close();

    // izveido failu ar kļūdainajiem ierakstiem un failu ar tikai pareizajiem, ar visiem - izdzēš
    resultFile.open(resultFileName, ios::out | ios::trunc);

    int dataFieldCount = 0;

    ifstream readtempFile;
    readtempFile.open("temp2.txt");
    if (!readtempFile) exit(0);

    ofstream tempFile2;
    tempFile2.open(tempFileName, ios::out | ios::trunc);
  
    while (getline(readtempFile, s))
     {
      for (char ch : s) {
        if (ch == ',') dataFieldCount++;
        else {
          if ((dataFieldCount ==  0 || dataFieldCount == 1) && isdigit(ch)) { 
            dataFieldCount = -1;                                                         
          }

          if (dataFieldCount ==  3 && !isdigit(ch))  { 
            if (ch != ':') {
              dataFieldCount = -1;        
            }
          }

          if (dataFieldCount == 4 && !isdigit(ch))  { 
            if (ch != '.') {
              dataFieldCount = -1;                                                         
            }
          }
        }
      } 
      if (dataFieldCount != 4) { 
        resultFile << s << endl;
        dataFieldCount = 0;
      }
      else {
        tempFile2 << s << endl;
        dataFieldCount = 0;
      }
    }
    tempFile2.close();
    resultFile.close();
    readtempFile.close();
    remove("temp2.txt");

    vector<vector<string>> data;

    ifstream file;
    file.open(tempFileName);
    if (!file) exit(0);

  // iterē failu ar tikai valid ierakstiem, saliek ierakstus 2D vektorā, izdzēš temp failu
    while (getline(file, s)) {
        istringstream ss(s);
        vector<string> row;

        while (getline(ss, s, ',')) {
          row.push_back(s);
        }
      data.push_back(row);
  }
  file.close();
  remove("temp.txt");
  
  return data;
}

// IZVADA MARŠRUTU PĒC IEVADĪTĀ SĀKUMPUNTA UN GALUPUNKTA
void outputByRoute(vector<vector<string>> data) {

  string startP, endP;

  cin >> startP >> endP;

  cout << "result:" << endl;
  
  for (const auto& row : data) {
    if (row[0] == startP && row[1] == endP) {
    for (const auto& col : row) {
        cout << col << " ";
    }
    cout << endl;
    }
  }
  
}

// IZVADA MARŠRUTUS KAS KURSĒ EVADĪTĀJĀ DIENĀ
void outputByDay(vector<vector<string>> data) {

  string day;

  cin >> day;
  
  cout << "result:" << endl;
  
  for (const auto& row : data) {
    if (row[2] == day) {
    for (const auto& col : row) {
        cout << col << " ";
    }
    cout << endl;
    }
  }

}

// IZVADA MARŠRUTUS KAS LĒTĀKI PAR IEVADĪTO CENU
void outputByPrice(vector<vector<string>> data) {

  double price;

  cin >> price;

  cout << "result:" << endl;

  for (const auto& row : data) {
    if (stod(row[4]) <= price) {
    for (const auto& col : row) {
        cout << col << " ";
    }
    cout << endl;
    }
  }

}

// IZVADA KĻŪDAINO DATU FAILA SATURU
void outputResultFile(string fileName) {
  
  ifstream file;
  file.open(fileName);
  if (!file) return;

  string s; 
  while (getline(file, s))
  {
    cout << s << endl;
  }
  file.close();
  
}

int main() {

  vector<vector<string>> data = dataProcess("db.csv", "temp.txt", "err.txt");

  string task;
  while (task != "e") {
    cin >> task;
    switch (task[0]) {
      case 'a':
        outputByRoute(data);
        break;
      case 'b':
        outputByDay(data);
        break;
      case 'c':
        outputByPrice(data);
        break;
      case 'd':
        cout << "result:" << endl;
        outputResultFile("err.txt");
        break;
      case 'e':
        break;
      }
  }
  return 0;
}