

#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

void splitVirkne(const string &teksts, vector<string> &elements) {

  stringstream ss(teksts);
  string elementss; //atseviskiem elementiem

  elements.clear(); 

  while (getline(ss, elementss, ',')) {
    elements.push_back(elementss); //sadala virkni elementos un ievieto vektoraa
  }
  
}

void printMasivs(const vector<string> &elements) {
  cout << elements[0] + " " + elements[1] + " " + elements[2] + " " +
              elements[3] + " " + elements[4] + " "
       << endl;
}

void removeAtstarpes(vector<string> &elements) {
  for (string &element : elements) {
    element.erase(remove(element.begin(), element.end(), ' '), element.end()); //noņem atstarpes no katra elementa (gan sakuma gan beigam)
  

    while (!element.empty() && isspace(element[0])) {
      element.erase(element.begin());
    }

    while (!element.empty() && isspace(element.back())) {
      element.pop_back();
    }
  }

  
}

void getMarsruts() {
  // cout << "hi" << endl;

  ifstream inFile;
  inFile.open("db.csv");
  char komanda;
  string sakums;
  string beigas;

  vector<string> elements; //ievietos elementus no faila

  // cout << "Ievadiet sākuma pieturu un gala pieturu:" << endl;
  cin >> sakums;
  cin >> beigas;

  string teksts;

  cout << "result:" << endl;

  while (getline(inFile, teksts)) {
    splitVirkne(teksts, elements); //sadala vikrni elementos

    if (elements.size() == 5) { //parbaude vai ir visi 5 elementi
      removeAtstarpes(elements);
      for (int i = 0; i < 5; i++) {
        string str = elements[i];
      }
      if (elements[0] == sakums && elements[1] == beigas) { //parbauda vai sakrit marsruts
        printMasivs(elements);
      }
    }
  }
  inFile.close();
}
void getDiena() {
  ifstream inFile;
  inFile.open("db.csv");
  char komanda;
  string diena;
  string teksts;

  vector<string> elements; //ievietos elementus no faila

  // cout << "Ievadiet dienu:" << endl;
  cin >> diena;

  cout << "result:" << endl;

  while (getline(inFile, teksts)) {
    splitVirkne(teksts, elements);

    if (elements.size() == 5) {
      removeAtstarpes(elements);
      for (int i = 0; i < 5; i++) {
        string str = elements[i];
      }
      if (elements[2] == diena) { //parbaude vai diena sakrit
        printMasivs(elements);
      }
    }
  }
  inFile.close();
}
void getCena() {
  ifstream inFile;
  inFile.open("db.csv");
  char komanda;
  double cena;
  
  vector<string> elements; //ievietos elementus no faila

  // cout << "Ievadiet cenu:" << endl;
  cin >> cena;

  // double cenaa = stod(cena);

  cout << "result:" << endl;

  string teksts;

 
  while (getline(inFile, teksts)) {
  //while (true) {
    //cout << teksts << endl;
    splitVirkne(teksts, elements);

    if (elements.size() == 5) {
      //cout << teksts << endl;
      removeAtstarpes(elements);
      for (int i = 0; i < 5; i++) {
        string str = elements[i];
      }

      //removeAtstarpes(elements);
      //string cenaaa = elements[4];
      //removeAtstarpes(cenaaa);

      double price = stod(elements[4]); // parveido cenu par double
      removeAtstarpes(elements);
      if (price <= cena) {
        //cout << price << endl;
      
        printMasivs(elements);
      }
    } 
    
  }

  inFile.close();

}
void getError() {
  ifstream inFile;
  ofstream outFile;
  outFile.open("err.txt");
  inFile.open("db.csv");
  char komanda;
  // string diena;
  string teksts;

  vector<string> elements; 

  while (getline(inFile, teksts)) {
    if (teksts.find_first_not_of(" \t\n\v\f\r") != 
        string::npos) { // parbauda vai rinda satur simbolus jeb meklē pirmo kas nav atstarpe

      vector<string> elements;
      stringstream ss(teksts);
      string element;

      while (getline(ss, element, ',')) {
        elements.push_back(element); //sadala elementos
      }

      if (elements.size() == 5) {
        removeAtstarpes(elements);
        for (int i = 0; i < 5; i++) {
          string str = elements[i];
        }

        if (elements[2] != "Pr" && elements[2] != "Ot" && elements[2] != "Tr" &&
            elements[2] != "Ce" && elements[2] != "Pt" && elements[2] != "St" &&
            elements[2] != "Sv") {
          // for (const string& element : elements) {
          outFile << teksts << endl; //ieraksta rindas ar nepareizaam dienaam failaa
        }
      } else if (elements.size() > 5 || elements.size() < 5) {
        outFile << teksts << endl; //ieraksta rindas ar nepareizu garumu failaa
      }
    }
  }

  inFile.close();
  outFile.close();

  ifstream errFile;
  errFile.open("err.txt");
  string err;
  cout << "result:" << endl;
  while (getline(errFile, err)) {
    cout << err << endl; //izvada err failu
  }
  errFile.close();
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  char komanda;

  if (!inFile)
    return 0; 

  while (true) {
    // cout << "Ievadiet komandu: ";
    cin >> komanda;

    switch (komanda) {
    case 'a':
      getMarsruts();
      break;
    case 'b':
      getDiena();
      break;
    case 'c':
      getCena();
      break;
    case 'd':
      getError();
      break;
    case 'e':
      // cout << "Bye" << endl;
      return 0;
    default:
      cout << "Error, ievadiet komandu vēlreiz" << endl;
    }
  }

  // string s;
  // while (inFile >> s)
  //{
  // cout << s << endl;
  //}
}