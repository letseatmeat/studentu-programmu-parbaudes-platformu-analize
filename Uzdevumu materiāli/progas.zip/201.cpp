
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <bits/stdc++.h>
#include <regex>

using namespace std;

bool checkCommand(string com, char c);
void destInfo();
void weekday();
void filterPrice();
bool checkLine(vector<string> s);
void readErr();
inline std::string& trim(std::string& s);
inline std::string& ltrim(std::string& s);
inline std::string& rtrim(std::string& s);




int main() {
  while (true) {
    string com;
    cout << "> ";
    cin >> com;
    char c = com[0];
    if (!checkCommand(com, c)) {
      cout << "Wrong command" << endl;
      continue;
    }
    switch (c) {
      case 'a':
        destInfo();
        continue;
      case 'b':
        weekday();
        continue;
      case 'c':
        filterPrice();
        continue;
      case 'd':
        readErr();
        continue;
      case 'e':
        return 0;
      default:
        cout << "Something went wrong"; 
    }
  }
} 

bool checkCommand(string com, char c) {
  if (com.length() > 1 || (c < 'a' || c > 'e')) {
    return false;
  } else {
    return true;
  }
}

void destInfo() {
  string dep, dest;
  cout << "Departure: ";
  cin >> dep;
  cout << "Destination: ";
  cin >> dest;

  ifstream f;
  f.open("db.csv");
  if (!f) {
    cout << "I/O error";
    return;
  }
  cout << "result: " << endl;
  
  string line, word;
  vector<string> fline;
  int ln = 0;
  ofstream of;
  of.open("err.txt"); 
  of.close();

  while (getline(f, line)) {
    ln++;
    fline.clear();
    if (line.empty()) { 
     continue;
    }

    stringstream strs(line);
    while (!strs.eof()) {
        getline(strs, word, ',');
        fline.push_back(trim(word));
    }

    if (!checkLine(fline)) {

      of.open("err.txt", std::ios_base::app);
      of << line << endl;
      of.close();
      continue;
    }

    if (fline[0] == dep && fline[1] == dest) {
      for (string w : fline) {
        cout << w << " ";
      }
      cout << endl;
    }
  }
}

void weekday() {
  string wday;
  cout << "Day of the week: ";
  cin >> wday;

  ifstream f;
  f.open("db.csv");
  if (!f) {
    cout << "I/O error";
    return;
  }
  cout << "result: " << endl;

  string line, word;
  vector<string> fline;
  int ln = 0;
  ofstream of;
  of.open("err.txt"); 
  of.close();

  while (getline(f, line)) {
    ln++;
    fline.clear();
    if (line.empty()) { 
     continue;
    }

    stringstream strs(line);
    while (!strs.eof()) {
        getline(strs, word, ',');
        fline.push_back(trim(word));
    }
    
    if (!checkLine(fline)) {

      of.open("err.txt", std::ios_base::app);
      of << line << endl;
      of.close();
      continue;
    }

    if (fline[2] == wday) {
      for (string w : fline) {
        cout << w << " ";
      }
      cout << endl;
    }
  }
}

void filterPrice() {
  float price;
  cout << "Price ";
  cin >> price;

  ifstream f;
  f.open("db.csv");
  if (!f) {
    cout << "I/O error";
    return;
  }
  cout << "result: " << endl;

  string line, word;
  vector<string> fline;
  int ln = 0;
  ofstream of;
  of.open("err.txt"); 
  of.close();

  while (getline(f, line)) {
    ln++;
    fline.clear();
    if (line.empty()) { 
     continue;
    }

    stringstream strs(line);
    while (!strs.eof()) {
        getline(strs, word, ',');
        fline.push_back(trim(word));
    }
    
    if (!checkLine(fline)) {
      of.open("err.txt", std::ios_base::app);
      // add ln here for easier debugging
      of << line << endl;
      of.close();
      continue;
    }
    
    if (stof(fline[4]) < price) {
      for (string w : fline) {
        cout << w << " ";
      }
      cout << endl;
    }
  }
}

bool checkLine(vector<string> s) {
  try {
    // size check
    if (s.empty()) {
      throw 0;
    }
    if (s.size() != 5) {
      throw 0;
    }
    // time field check
    const regex pattern("^(?:[01]?[0-9]|2[0-3]):[0-5]?[0-9]");
    if (!regex_match(s[3], pattern)) {
      throw 0;
    }
    // price check
    stof(s[4]);
    // weekday check
    string dayw[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    if (find(begin(dayw), end(dayw), s[2]) == end(dayw)) {
      throw 0;
    } 
    return true;
  } catch (int i) {
    return false;
  }
}

void readErr() {
  ifstream f;
  f.open("err.txt");
  if (!f) {
    cout << "I/O error";
    return;
  }
  string line;
  cout << "result:" << endl;
  while (getline(f, line)) {
    cout << line << endl;
  }
  
}

// https://stackoverflow.com/questions/216823/how-to-trim-a-stdstring
// trim from end of string (right)
inline std::string& rtrim(std::string& s)
{
    s.erase(s.find_last_not_of(" \t\n\r\f\v") + 1);
    return s;
}

// trim from beginning of string (left)
inline std::string& ltrim(std::string& s)
{
    s.erase(0, s.find_first_not_of(" \t\n\r\f\v"));
    return s;
}

// trim from both ends of string (right then left)
inline std::string& trim(std::string& s)
{
    return ltrim(rtrim(s));
}