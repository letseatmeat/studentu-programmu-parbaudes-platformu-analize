

#include <algorithm> // For using trim()
#include <fstream>
#include <iostream>
#include <list>
#include <sstream>
#include <string>

using namespace std;

bool fDebug = false; // Global variable to output debugging information

// Function for removing spaces at the beginning and end of a string
string trim(const string &str) {
  size_t first = str.find_first_not_of(' ');
  if (string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

class BusRoute {
public:
  string from;
  string to;
  string dayOfWeek;
  string time;
  double price;

  BusRoute(string from, string to, string dayOfWeek, string time, double price)
      : from(from), to(to), dayOfWeek(dayOfWeek), time(time), price(price) {}
};

bool isValidDay(const string &day) {
  static const list<string> validDays = {"Pr", "Ot", "Tr", "Ce",
                                         "Pt", "Se", "Sv"};
  return find(validDays.begin(), validDays.end(), day) != validDays.end();
}

bool isValidTime(const string &time) { return time.find(':') != string::npos; }

bool isValidPrice(const string &price) {
  return price.find('.') != string::npos;
}

bool isValidCell(const int count, const string &cell) {
  if (fDebug) {
    cout << "Элемент " << count << ": " << cell << endl;
  }

  switch (count) {
  case 3: // Check the day of the week
    if (!isValidDay(trim(cell))) {
      return false;
    }
    break;
  case 4: // Checking the time
    if (!isValidTime(trim(cell))) {
      return false;
    }
    break;
  case 5: // Checking the price
    if (!isValidPrice(trim(cell))) {
      return false;
    }
    break;
  }
  return true;
}

void printRoute(const BusRoute &route) {
  string aLabels[] = {
      "From: ", "To: ", "Day of Week: ", "Time: ", "Price: "};

  if (!fDebug) {
    for (int i = 0; i < 5; ++i) {
      aLabels[i] = (i == 0 ? "" : " ");
    }
  }

  cout.precision(2);
  cout << aLabels[0] << route.from << aLabels[1] << route.to << aLabels[2]
       << route.dayOfWeek << aLabels[3] << route.time << aLabels[4] << fixed
       << route.price << endl;
}

void printAllRoutes(const list<BusRoute> &routes) {
  // Print the list of routes if BusRoute instances have been created
  if (!routes.empty()) {
    cout << "List of created routes:" << endl;
    for (const auto &route : routes) {
      printRoute(route);
    }
  } else {
    cout << "No routes were created from the file." << endl;
  }
}

void commandA(const string &from, const string &to,
              const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.from == from && route.to == to) {
      printRoute(route);
    }
  }
}

void commandB(const string &dayOfWeek, const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.dayOfWeek == dayOfWeek) {
      printRoute(route);
    }
  }
}

void commandC(double maxPrice, const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.price <= maxPrice) {
      printRoute(route);
    }
  }
}

void commandD(const list<string> &errors) {
  cout << "result:" << endl;
  bool fFirstLine = true;
  for (const auto &err : errors) {
    if (!fFirstLine) {
      cout << endl;
    }
    fFirstLine = false;
    cout << err;
  }
}

// void commandD2() {
//   cout << "result:" << endl;

//   ifstream errFile("err.txt");
//   if (errFile.is_open()) {
//     string line;
//     bool fFirstLine = true;
//     while (getline(errFile, line)) {
//       if (!fFirstLine) {
//         cout << endl;
//       }
//       fFirstLine = false;
//       cout << line;
//     }

//     errFile.close();
//   } else {
//     cout << "Failed to open err.txt file." << endl;
//   }
// }

int main() {
  bool fFirstErr = true;
  ofstream errFile("err.txt"); //  Opening the file to record errors
  errFile.close(); // Clear file contents

  ifstream file("db.csv"); // Open db.csv file for reading

  if (file.is_open()) { // Check if the file was successfully opened
    list<BusRoute> routes; // Create a list of routes
    list<string> errors; // Create a list of errors

    string line;
    while (getline(file, line)) { // Read each line of the file
      line = trim(line); // Remove spaces at the beginning and end of the line

      if (line.empty()) {
        continue; // Skip empty lines
      }

      if (fDebug) {
        cout << "Row:" << line << endl << flush;
      }

      istringstream ss(line);
      string cell;
      int count = 1;
      bool isValid = true;

      while (getline(ss, cell, ',')) { // Separate the line into cells by comma
        isValid = isValidCell(count, cell);
        count++;
      }

      if (count < 3) {
        continue; // Skip empty rows
      }

      // If the string contains an incorrect number of elements or fails to pass
      // additional checks, write it to the error file
      if (count != 6 || !isValid) {
        errors.push_back(line);
        ofstream errFile("err.txt", ios::app); // Open file for additional writing
        if (!fFirstErr) {
          errFile << endl;
        }
        fFirstErr = false;
        errFile << line; // Write a line to the error file
        errFile.close(); // Close the file
      } else { // If the line passed the checks, process it
        ss.clear(); // Reset stringstream state
        ss.seekg(0); // Set the position to the beginning of the string

        string from, to, dayOfWeek, time;
        double price;

        getline(ss, from, ',');
        getline(ss, to, ',');
        getline(ss, dayOfWeek, ',');
        getline(ss, time, ',');
        ss >> price;

        BusRoute route(trim(from), trim(to), trim(dayOfWeek), trim(time),
                       price);
        routes.push_back(route);
      }
    }

    if (fDebug) {
      printAllRoutes(routes);

      // Call the commandA function with the parameters "Riga" and "Kraslava"
      commandA("Riga", "Kraslava", routes);
      cout << endl;

      // Call the commandB function with the "Pr" parameter (day of the week).
      commandB("Pt", routes);
      cout << endl;

      // Call of the commandC function with the ticket price parameter
      commandC(5.90, routes);
      cout << endl;

      // Call of the commandD function to output the contents of the err.txt file
      commandD(errors);
      cout << endl;
    }

    file.close(); // Close file

    char command;
    string routeFrom;
    string routeTo;
    string dayOfWeek;
    double ticketPrice;

    while (true) {
      cin >> command;

      switch (command) {
      case 'a':
        cin >> routeFrom;
        cin >> routeTo;
        commandA(routeFrom, routeTo, routes);
        break;
      case 'b':
        cin >> dayOfWeek;
        commandB(dayOfWeek, routes);
        break;
      case 'c':
        cin >> ticketPrice;
        commandC(ticketPrice, routes);
        break;
      case 'd':
        commandD(errors);
        break;
      case 'e':
        return 0; // Exit from the programme after command 'e'
      default:
        cout << "Unknown command!" << endl;
        break;
      }
    }

  } else {
    cout << "Failed to open db.csv file." << endl;
  }

  return 0;
}
