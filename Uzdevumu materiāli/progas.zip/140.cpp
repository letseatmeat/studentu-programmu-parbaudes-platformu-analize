#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <cctype>


struct Route {
    std::string start_stop;
    std::string end_stop;
    std::string day_of_week;
    std::string time;
    double ticket_price;
};

std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(' ');
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

bool isValidDay(const std::string& day) {
    static const std::vector<std::string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    return std::find(validDays.begin(), validDays.end(), day) != validDays.end();
}

bool parseRoute(const std::string& line, Route& route) {
    std::istringstream ss(line);
    std::string start_stop, end_stop, day_of_week, time, ticket_price_str;

    if (std::count(line.begin(), line.end(), ',') != 4) {
        return false;
    }

    if (std::getline(ss, start_stop, ',') &&
        std::getline(ss, end_stop, ',') &&
        std::getline(ss, day_of_week, ',') &&
        std::getline(ss, time, ',') &&
        std::getline(ss, ticket_price_str)) {

        start_stop = trim(start_stop);
        end_stop = trim(end_stop);
        day_of_week = trim(day_of_week);
        time = trim(time);
        ticket_price_str = trim(ticket_price_str);

        if (!isValidDay(day_of_week)) {
            return false;
        }

        try {
            route.start_stop = start_stop;
            route.end_stop = end_stop;
            route.day_of_week = day_of_week;
            route.time = time;
            route.ticket_price = std::stod(ticket_price_str);
        } catch (const std::exception&) {
            return false;
        }

        return true;
    }

    return false;
}

void printRoutes(const std::vector<Route>& routes) {
    std::cout << "result:" << std::endl;
    for (const auto& route : routes) {
        std::cout << route.start_stop << " " << route.end_stop << " " << route.day_of_week << " "
                  << route.time << " " << std::fixed << std::setprecision(2) << route.ticket_price << std::endl;
    }
}

int main() {
    std::ifstream inputFile("db.csv");

    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open input file." << std::endl;
        return 1;
    }

    std::vector<Route> routes;
    std::ofstream errorFile("err.txt");

    std::string line;
    int lineNumber = 0;
    int errline = 0;

    while (std::getline(inputFile, line)) {
        lineNumber++;
        line = line.substr(0, line.length() - 1);


      if (line.find(',') == std::string::npos) {
          continue;
      }

        Route route;
        if (parseRoute(line, route)) {
            routes.push_back(route);
        } else {
          if (errline ==0){
            errorFile<<line;
            errline++;
          }  else  {
              errorFile << std::endl <<line;
            }
        }
    }

    inputFile.close();
    errorFile.close();

    char choice;
    while (true) {
        std::cout << "Enter a choice (a, b, c, d, e): ";
        std::cin >> choice;

        switch (choice) {
            case 'a': {
                std::string start, end;
                std::cout << "Enter start stop: ";
                std::cin >> start;
                std::cout << "Enter end stop: ";
                std::cin >> end;

                std::vector<Route> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.start_stop == start && route.end_stop == end) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }
            case 'b': {
                std::string day;
                std::cout << "Enter day of the week (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                std::cin >> day;

                std::vector<Route> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.day_of_week == day) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }
            case 'c': {
                double maxPrice;
                std::cout << "Enter maximum ticket price: ";
                std::cin >> maxPrice;

                std::vector<Route> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.ticket_price <= maxPrice) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }
            case 'd': {
                std::ifstream errorFile("err.txt");
                std::string errorLine;

                std::cout << "result:" << std::endl;
                while (std::getline(errorFile, errorLine)) {
                    std::cout << errorLine << std::endl;
                }

                errorFile.close();
                break;
            }
            case 'e':
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please enter a valid choice (a, b, c, d, e)." << std::endl;
        }
    }

    return 0;
}
