
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct timeTable {
  string beginCity;
  string endCity;
  string day;
  string time;
  float price;
};

string trim(const string &str) {
  size_t start = str.find_first_not_of(" ");
  if (start == string::npos) {
    return "";
  }

  size_t end = str.find_last_not_of(" ");

  return str.substr(start, (end - start + 1));
}

vector<string> split(const string &s, char spliter) {
  vector<string> tokens;
  string token;
  istringstream tokenStream(s);
  while (getline(tokenStream, token, spliter)) {
    tokens.push_back(trim(token));
  }
  return tokens;
}

void errors(vector<string> errText) {
  ofstream outFile;
  outFile.open("err.txt", ios::app);

  if (!outFile) {
    cout << "error" << endl;
    return;
  }

  for (size_t i = 0; i < errText.size(); ++i) {
    outFile << errText[i];
    if (i < errText.size() - 1) {
      outFile << ",";
    }
  }

  outFile << endl;
  outFile.close();
}

bool isFloat(const string &str) {
  if (str.empty() || (!isdigit(str[0])))
    return false;

  for (size_t i = 1; i < str.size(); ++i) {
    if (!isdigit(str[i]) && str[i] != '.')
      return false;
  }
  return true;
}

void makeTable(const string &line, vector<timeTable> &buses) {
  vector<string> temp = split(trim(line), ',');

  bool hasDigit = false;
  if (temp.size() > 2) {
    for (int i = 0; i < 3; i++) {
      for (char ch : temp[i]) {
        if (isdigit(ch)) {
          hasDigit = true;
          break;
        }
      }
      if (hasDigit)
        break;
    }
  }

  if (temp.size() != 5 || !isFloat(temp[4]) || hasDigit ||
      !isdigit(temp[3][0]) || !isdigit(temp[3][1]) || !isdigit(temp[3][3]) ||
      !isdigit(temp[3][4])) {
    errors(temp);
  } else {
    timeTable bus;
    bus.beginCity = temp[0];
    bus.endCity = temp[1];
    bus.day = temp[2];
    bus.time = temp[3];
    bus.price = stof(temp[4]);
    buses.push_back(bus);
  }
}

// funkcijas parrakstīšanna lai err failā ieraksta visu otrādi
// void makeTable(const string &line, vector<timeTable> &buses) {
//     vector<string> temp = split(trim(line), ',');

//     if (temp.size() == 5 && isFloat(temp[4])) {
//         bool hasDigit = false;
//         for (int i = 0; i < 3; i++) {
//             if (any_of(temp[i].begin(), temp[i].end(), ::isdigit)) {
//                 hasDigit = true;
//                 break;
//             }
//         }

//         // Check if the time format is HH:MM
//         bool correctTimeFormat = temp[3].length() == 5 &&
//                                  isdigit(temp[3][0]) &&
//                                  isdigit(temp[3][1]) &&
//                                  temp[3][2] == ':' &&
//                                  isdigit(temp[3][3]) &&
//                                  isdigit(temp[3][4]);

//         if (!hasDigit && correctTimeFormat) {
//             timeTable bus;
//             bus.beginCity = temp[0];
//             bus.endCity = temp[1];
//             bus.day = temp[2];
//             bus.time = temp[3];
//             bus.price = stof(temp[4]);
//             buses.push_back(bus);
//         } else {
//             errors(temp);
//         }
//     } else {
//         errors(temp);
//     }
// }

void printErr() {
  ifstream fileErr;
  fileErr.open("err.txt");

  if (!fileErr)
    return;

  string lineErr;

  while (getline(fileErr, lineErr)) {
    if (!lineErr.empty()) {
      cout << lineErr << endl;
    }
  }

  fileErr.close();
}

void checkPrices(float price, vector<timeTable> buses) {
  for (size_t n = 0; n < buses.size(); n++) {
    if (buses[n].price <= price) {
      cout << buses[n].beginCity << " " << buses[n].endCity << " "
           << buses[n].day << " " << buses[n].time << " " << fixed
           << setprecision(2) << buses[n].price << endl;
    }
  }
}

void checkDay(string day, vector<timeTable> buses) {
  for (size_t n = 0; n < buses.size(); n++) {
    if (buses[n].day == day) {
      cout << buses[n].beginCity << " " << buses[n].endCity << " "
           << buses[n].day << " " << buses[n].time << " " << fixed
           << setprecision(2) << buses[n].price << endl;
    }
  }
}

void checkCities(string start, string end, vector<timeTable> buses) {
  for (size_t n = 0; n < buses.size(); n++) {
    if (buses[n].beginCity == start && buses[n].endCity == end) {
      cout << buses[n].beginCity << " " << buses[n].endCity << " "
           << buses[n].day << " " << buses[n].time << " " << fixed
           << setprecision(2) << buses[n].price << endl;
    }
  }
}

// funkcija kas dzeš visus neredzamus simbolus no faila, kas varētu izlabot kļūdu replit.com vidē (Atradu risnājumu internētā)
// string readAndCleanFile(const string &filePath) {
//     ifstream inFile(filePath, ios::binary);
//     stringstream cleanContent;

//     if (!inFile.is_open()) {
//         cerr << "Error opening file: " << filePath << endl;
//         return "";
//     }

//     char ch;
//     while (inFile.get(ch)) {
//         if (isprint(static_cast<unsigned char>(ch)) || ch == '\n' || ch == '\r' || ch == '\t') {
//             cleanContent.put(ch);
//         }
//     }

//     return cleanContent.str();
// }

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  ofstream file("err.txt", ios::out | ios::trunc); // deleting everything in output file after previus debugging

  vector<timeTable> buses;

  string line;

  while (getline(inFile, line)) {
    if (!line.empty()) {
      makeTable(line, buses);
    }
  }

  char command;
  bool loop = true;

  while (loop) {
    cin >> command;
    switch (command) {
    case 'a': {
      string first;
      string second;
      cin >> first >> second;
      cout << "result:" << endl;
      checkCities(first, second, buses);
      break;
    }
    case 'b': {
      string day;
      cin >> day;
      cout << "result:" << endl;
      checkDay(day, buses);
      break;
    }
    case 'c': {
      float price;
      cin >> price;
      cout << "result:" << endl;
      checkPrices(price, buses);
      break;
    }
    case 'd':
      cout << "result:" << endl;
      printErr();
      break;
    case 'e':
      loop = false;
      break;
    default:
      cout << "Print command a,b,c,e,d";
    }
  }

  inFile.close();
  return 0;
}