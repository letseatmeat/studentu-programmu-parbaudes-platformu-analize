
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <regex>
#include <string>
#include <vector>
using namespace std;

class JourneyClass {
public:
  bool valid;
  vector<string> myvector;
  int cost;

  JourneyClass(bool inValid, const std::vector<std::string>& inVector = {" "}, int inCost = 0) {
    valid = inValid;
    myvector = inVector;
    cost = inCost;
  }
};

vector<string> delimit(string myline, string delimiter) {
  vector<string> myvector;
  size_t pos = 0;
  while ((pos = myline.find(delimiter)) != string::npos) {
    myvector.push_back(myline.substr(0, pos));
    myline.erase(0, pos + delimiter.length());
  }
  myvector.push_back(myline);
  return myvector;
}

bool checkIfWeek(string s) {
  return (s == "Pr" || s == "Ot" || s == "Tr" || s == "Ce" || s == "Pt" ||
          s == "St" || s == "Sv");
}

int strToNum(string s) { // works only in converting positive numbers
  int num;
  bool all_used;
  try {
    size_t pos;
    num = stoi(s, &pos);
    all_used = pos == s.length();
    if (!all_used) {
      return -1;
    }
  } catch (int e) {
    return -1;
  }

  return num;
}

bool checkIfTime(string myline) {
  vector<string> myvector;
  myvector = delimit(myline, ":");
  if (myvector.size() != 2) {
    return false;
  }
  int hh = strToNum(myvector[0]);
  int mm = strToNum(myvector[1]);

  if (hh < 0 || hh > 23) {
    return false;
  }
  if (mm < 0 || mm > 59) {
    return false;
  }
  return true;
}

int strToCost(string myline) {
  vector<string> myvector;
  myvector = delimit(myline, ".");
  if (myvector.size() != 2) {
    return -1;
  }
  int eu = strToNum(myvector[0]);
  int ce = strToNum(myvector[1]);
  // a dirty ad hoc solution to a problem that 5.9 == 5.09
  if (myvector[1].size() == 1){
    ce = ce*10;
  }
  
  if (eu < 0) {
    return -1;
  }
  if (ce < 0 || ce > 99) {
    return -1;
  }
  // output is in cents
  int cost = eu * 100 + ce;
  return cost;
}

int checkValidityReturnCost(vector<string> myvector){
  // check if vector has the correct size
  if (myvector.size() != 5) {
    return -1;
  }
  // check each item separately 
  if (!(checkIfWeek(myvector[2])))
    return -1;
  if (!(checkIfTime(myvector[3])))
    return -1;
  int cost = strToCost(myvector[4]); // extract cost as a number not a string
  return cost;
}

JourneyClass strToJourney(string myline) {
  
  // remove spaces
  myline.erase(remove_if(myline.begin(), myline.end(), ::isspace),
               myline.end());
  // make an vector of items
  vector<string> myvector;
  myvector = delimit(myline, ",");
  // composition of a vector (assuming it is valid):
  // 0- start point
  // 1- end point
  // 2- day of the week
  // 3- time (str)
  // 4- cost (str)

  // make a default value to return in case of an error
  vector<string> tmpVector{myline};
  JourneyClass defaultAnswer(false, tmpVector);
  // composition of an unvalid vector:
  // 0- the whole string of an unvalid entry

  // call a function that checks validity and returns cost as an integer if everything is correct
  // returns -1 if not a valid entry
  int cost = checkValidityReturnCost(myvector);
  if (cost < 0)
    return defaultAnswer;
  
  // If entries are valid then construct and return an object
  JourneyClass answer(true, myvector, cost);
  return answer;
}

void outputJourney(JourneyClass jc) {
  for(int j = 0; j < jc.myvector.size(); j++){
    cout << jc.myvector[j] << " ";
  }
  cout << endl;
}

void outputJourneys(vector<JourneyClass> journeys){
  for(int i = 0; i < journeys.size(); i++){
    outputJourney(journeys[i]);
  }
}

void commandA(vector<JourneyClass> journeys){
  // prints all jornyes with a given start and end points
  string start, end;
  cin >> start;
  cin >> end;
  cout << "result:" << endl;
  for (int i = 0; i < journeys.size(); i++){
    //cout << "here";
    if (journeys[i].myvector[0] == start && journeys[i].myvector[1] == end){
      outputJourney(journeys[i]);
    }
  }
}

void commandB(vector<JourneyClass> journeys){
  // prints all jornyes with a given day of the week
  string day;
  cin >> day;
  cout << "result:" << endl;
  for (int i = 0; i < journeys.size(); i++){
    if (journeys[i].myvector[2] == day){
      outputJourney(journeys[i]);
    }
  }
}

void commandC(vector<JourneyClass> journeys){
  // prints all jornyes with a given cost or cheaper
  string costIN;
  cin >> costIN;
  int cost = strToCost(costIN);
  cout << "result:" << endl;
  for (int i = 0; i < journeys.size(); i++){
    if (journeys[i].cost < cost){
      outputJourney(journeys[i]);
    }
  }
}

void errorHandle(vector<JourneyClass> journeys){
  // outputs errors to err.txt
  ofstream MyFile("err.txt");
  for (int i = 0; i < journeys.size(); i++){
    MyFile << journeys[i].myvector[0] << endl;
  }
  MyFile.close();
}

void errDisp(){
  // displays err.txt on a console
  ifstream myfile;
  myfile.open("err.txt");
  if (!myfile)
    return;
  
  cout << "result:" << endl;
  string line;
  while (myfile) {
    getline(myfile, line);
    cout << line << endl;
  }
  
  myfile.close();
}

int main() {
  // opening a file
  ifstream myfile;
  myfile.open("db.csv");
  if (!myfile)
    return 0;

  string myline;
  bool valid;
  vector<JourneyClass> journeys;
  vector<JourneyClass> errJourneys;
  JourneyClass tmpJourney(false);
  // extracting values and errors from a file
  while (myfile) {
    getline(myfile, myline);
    tmpJourney = strToJourney(myline);
    if (tmpJourney.valid) {
      journeys.push_back(tmpJourney);
    } else {
      if (tmpJourney.myvector[0] != ""){
        errJourneys.push_back(tmpJourney);
      }
    }
  }
  myfile.close();
  errorHandle(errJourneys);
  
  
  char command;
  while(true){
    //cout << "command: ";
    cin >> command;
    switch (command) {
      case 'a':
        commandA(journeys);
        break;
      case 'b':
        commandB(journeys);
        break;
      case 'c':
        commandC(journeys);
        break;
      case 'd':
        errDisp();
        break;
      case 'e':
        return 0;
    }
  }
}
