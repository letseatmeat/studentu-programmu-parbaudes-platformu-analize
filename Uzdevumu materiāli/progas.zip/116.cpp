#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_set>

using namespace std;

void filterByStartAndEnd(string line, string start, string end) {
  size_t startPos = line.find(start);
  size_t endPos = line.find(end);

  if (startPos != string::npos && endPos != string::npos && startPos < endPos) {
    replace(line.begin(), line.end(), ',', ' ');
    cout << line << endl;
  }
}

void filterByDay(string line, string day) {
  if (line.find(day) != string::npos) {
    replace(line.begin(), line.end(), ',', ' ');
    cout << line << endl;
  }
}

void filterByPrice(string line, string price) {
  size_t lastCommaPos = line.find_last_of(",");
  if (lastCommaPos != string::npos) {
    string lastElement = line.substr(lastCommaPos + 1);

    stringstream ss(lastElement);
    double lastElementValue;
    if (ss >> lastElementValue) {

      if (lastElementValue < stod(price)) {
        replace(line.begin(), line.end(), ',', ' ');
        cout << line << endl;
      }
    }
  }
}

bool isValidNumericFormat(const string &s) {
  size_t dotPos = s.find('.');
  if (dotPos != string::npos) {

    string beforeDot = s.substr(0, dotPos);
    if (all_of(beforeDot.begin(), beforeDot.end(), ::isdigit)) {

      string afterDot = s.substr(dotPos + 1);
      return afterDot.size() == 2 &&
             all_of(afterDot.begin(), afterDot.end(), ::isdigit);
    }
  }
  return false;
}

bool isValidTimeFormat(const string &s) {

  if (s.size() == 5 && s[2] == ':' && isdigit(s[0]) && isdigit(s[1]) &&
      isdigit(s[3]) && isdigit(s[4])) {
    int hours = stoi(s.substr(0, 2));
    int minutes = stoi(s.substr(3, 2));
    return hours >= 0 && hours <= 24 && minutes >= 0 && minutes <= 59;
  }
  return false;
}

bool isValidWeekFormat(const string &s) {
  unordered_set<string> validWeekdays = {"Pr", "Ot", "Tr", "Ce",
                                         "Pt", "Se", "Sv"};
  return validWeekdays.find(s) != validWeekdays.end();
}

bool isValidLineFormat(string line) {
  if (count(line.begin(), line.end(), ',') == 4) {
    istringstream ss(line);

    string element1, element2, element3, element4, element5;
    getline(ss, element1, ',');
    getline(ss, element2, ',');
    getline(ss, element3, ',');
    getline(ss, element4, ',');
    getline(ss, element5, ',');
    if (isValidWeekFormat(element3) && isValidTimeFormat(element4) &&
        isValidNumericFormat(element5)) {
      return true;
    } else {
      return false;
    }
  }

  return false;
}

int main() {
  ifstream dataFile;
  dataFile.open("db.csv");
  if (!dataFile)
    return 0;

  ifstream errorFileRead;
  errorFileRead.open("err.txt");
  if (!errorFileRead)
    return 0;

  ofstream errorFileWrite;
  errorFileWrite.open("err.txt");
  if (!errorFileWrite) {
    return 0;
  }

  string line;
  while (getline(dataFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (isValidLineFormat(line)) {

    } else if (!line.empty()) {

      errorFileWrite << line << endl;
    }
  }
  errorFileWrite.close();

  char choice;
  while (true) {
    cout << "Ievadi (a, b, c, d, or e):" << endl;
    cin >> choice;
    cin.clear();
    switch (choice) {
    case 'a': {
      dataFile.clear();
      dataFile.seekg(0);
      cout << "Sakuma pietura:" << endl;
      string start;
      cin >> start;
      cout << "Beigu pietura:" << endl;
      string end;
      cin >> end;
      cout << "result:" << endl;
      string line;
      while (getline(dataFile, line)) {

        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (isValidLineFormat(line)) {

          filterByStartAndEnd(line, start, end);
        }
      }
    } break;

    case 'b': {
      dataFile.clear();
      dataFile.seekg(0);
      cout << "Ievadi dienu:" << endl;
      string day;
      cin >> day;
      cout << "result:" << endl;
      string line;
      while (getline(dataFile, line)) {

        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (isValidLineFormat(line)) {

          filterByDay(line, day);
        }
      }
    } break;
    case 'c': {
      dataFile.clear();
      dataFile.seekg(0);
      cout << "MAX biletes cena:" << endl;
      string price;
      cin >> price;
      cout << "result:" << endl;
      string line;
      while (getline(dataFile, line)) {

        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (isValidLineFormat(line)) {

          filterByPrice(line, price);
        }
      }
    } break;
    case 'd': {
      errorFileRead.clear();
      errorFileRead.seekg(0);
      cout << "result:" << endl;
      string s;
      while (errorFileRead >> s) {
        cout << s << endl;
      }
    } break;
    case 'e':
      return 0;
    default: {
      cout << "nepareiza ievade" << endl;
    } break;
    }
  }
}
