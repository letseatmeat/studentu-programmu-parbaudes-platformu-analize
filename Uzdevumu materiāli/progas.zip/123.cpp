#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct BusRoute {
  string startStation;
  string endStation;
  string dayOfWeek;
  string time;
  float price;
};

void trim(string &s) {
  s.erase(s.begin(), find_if(s.begin(), s.end(),
                             [](unsigned char ch) { return !isspace(ch); }));
  s.erase(find_if(s.rbegin(), s.rend(),
                  [](unsigned char ch) { return !isspace(ch); })
              .base(),
          s.end());
}

vector<string> split(const string &s, char delimiter) {
  vector<string> tokens;
  string token;
  istringstream tokenStream(s);
  while (getline(tokenStream, token, delimiter)) {
    trim(token);
    tokens.push_back(token);
  }
  return tokens;
}

bool validateTime(const string &time) {
  if (time.size() != 5 || time[2] != ':')
    return false;
  int hour, minute;
  try {
    hour = stoi(time.substr(0, 2));
    minute = stoi(time.substr(3, 2));
  } catch (...) {
    return false;
  }
  return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

bool isValidRoute(const vector<string> &route) {
  if (route.size() != 5)
    return false;

  if (!validateTime(route[3]))
    return false;

  try {
    stof(route[4]);
  } catch (...) {
    return false;
  }

  return true;
}

vector<vector<string>> readBusRoutes(const string &fileName) {
  vector<vector<string>> routes;
  ifstream file(fileName);
  string line;

  ofstream errFile("err.txt");

  while (getline(file, line)) {
    trim(line);
    if (line.empty())
      continue;

    auto route = split(line, ',');
    if (isValidRoute(route)) {
      routes.push_back(route);
    } else {
      errFile << line << endl;
    }
  }

  errFile.close();
  return routes;
}

// Function to convert a string to lowercase
string toLower(const string &s) {
  string lowerCaseString;
  transform(s.begin(), s.end(), back_inserter(lowerCaseString), ::tolower);
  return lowerCaseString;
}

void printRoutesByStops(const vector<vector<string>> &routes,
                        const string &startStop, const string &endStop) {
  string lowerStartStop = toLower(startStop);
  string lowerEndStop = toLower(endStop);

  for (const auto &route : routes) {
    if (route.size() == 5 && toLower(route[0]) == lowerStartStop &&
        toLower(route[1]) == lowerEndStop) {
      for (const auto &field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printRoutesByDay(const vector<vector<string>> &routes,
                      const string &dayOfWeek) {
  for (const auto &route : routes) {
    if (route[2] == dayOfWeek) {
      for (const auto &field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printRoutesByPrice(const vector<vector<string>> &routes, double maxPrice) {
  for (const auto &route : routes) {
    if (stod(route[4]) <= maxPrice) {
      for (const auto &field : route) {
        cout << field << " ";
      }
      cout << endl;
    }
  }
}

void printErrorLines(const string &fileName) {
  ifstream file(fileName);
  string line;

  if (file.is_open()) {
    while (getline(file, line)) {
      cout << line << endl;
    }
    file.close();
  } else {
    cout << "Nevar atvērt failu: " << fileName << endl;
  }
}

int main() {
  auto routes = readBusRoutes("db.csv");
  cout << "result:\n";
  while (true) {
    string line;
    getline(cin, line);
    trim(line);
    istringstream iss(line);
    char action;
    iss >> action;

    if (action == 'a') {
      string startBusStop, endBusStop;
      if (getline(cin, startBusStop) && getline(cin, endBusStop)) {
        trim(startBusStop);
        trim(endBusStop);
        printRoutesByStops(routes, startBusStop, endBusStop);
      }
    } else if (action == 'b') {
      string weekDay;
      if (getline(cin, weekDay)) {
        trim(weekDay);
        printRoutesByDay(routes, weekDay);
      }
    } else if (action == 'c') {
      string priceStr;
      if (getline(cin, priceStr)) {
        trim(priceStr);
        try {
          double maxPrice = stod(priceStr);
          printRoutesByPrice(routes, maxPrice);
        } catch (const invalid_argument &e) {
          cout << "Nepareiza ievade. Lūdzu mēģiniet vēlreiz.\n";
        }
      }

    } else if (action == 'd') {
      printErrorLines("err.txt");
    } else if (action == 'e') {
      break; 
    } else {
      cout << "Nepareiza ievade. Lūdzu mēģiniet vēlreiz.\n";
    }
  }

  return 0;
}
