#include <fstream>
#include <iostream>

using namespace std;

struct trip {
  string city1; // from where
  string city2; // to where
  string wd;    // diena
  string time;  // laiks
  double price; // cena
};
int erfrex = 0;//err file flags
int inptex = 0;//inpt existence file flags


void toerr(string line) { // writing to err.txt file
  ofstream outFile;
  char FileName[25];
  if (erfrex == 1) { //if err.txt jau ir izveidots un ir ieraksti jauns ieraksts
    outFile.open("err.txt", fstream::app);
  } else {
    outFile.open("err.txt"); // izveidot jaunu err.txt failu
    erfrex = 1;// jauns err.txt fails izveidots mainam flagu
  }
  if (!outFile)
    return;
  outFile << line << endl;
  outFile.close();
}

trip find_str(string line, string del) { // funkcija kas grieza stringu uz trip strukturu un ievieto jauno ierakstu err.txt faila, ja ir slikts inputs
  int end, strcount = 0;
  trip t, err;// t - labs inputs, err- slikts inputs
  err.city1 = "0"; // from where
  err.city2 = "0"; // to where
  err.wd = "0";    // diena
  err.time = "0";  // laiks
  err.price = 99999;   // cena
  string checker[5];
  string lineorig = line;
  while (end != -1) { // Loop until no delimiter is left in the string.
    end = line.find(del);
    if (strcount < 5) {
      checker[strcount++] = line.substr(0, end);
      line.erase(line.begin(), line.begin() + end + 1);
    } else {
      toerr(lineorig);
      return err;
    }
  }
  try { // lai parbaudit vai cena ir double
    if ((strcount == 5) && (checker[2].size() == 2) &&
        (checker[3].size() == 5)) {// parbaudam vai ir 5 elementi, ir 2 burti nedelas diena un 5 simbolu laiks
      t.city1 = checker[0];       // from where
      t.city2 = checker[1];       // to where
      t.wd = checker[2];          // diena
      t.time = checker[3];        // laiks
      t.price = stod(checker[4]); // cena
      return t;
    } else {
      toerr(lineorig);
      return err;
      // handle err.txt file
    }
  } catch (std::exception &e) {
    toerr(lineorig);
    return err;
    // handle err.txt file
  }
  return err;
}

void removespacesfromstring(int n) { // funkcija kas iet caur visiem datiem un griez ara liekus spacus
  ifstream inFile;
  trip t;
  inFile.open("db.csv");
  string line, cutline, city1, city2;
  double price;
  string inpt1, inpt2;
  while (!inFile.eof()) {
    getline(inFile, line, '\n');
    if (!(line.size() < 2)) {
      for (char ch : line) {
        if (ch != ' ') {
          cutline += ch;
        }
      }
      t = find_str(cutline, ",");
      
      if(n == 1){ // between two cities - a
        if (inptex == 0){
          cin >> inpt1;
          cin >> inpt2;
          cin.clear();
          cin.ignore(1000, '\n');
          inptex = 1;
          cout << "result:" << endl;
        }
        if ((inpt1 == t.city1) && (inpt2 == t.city2)) {
          printf("%s %s %s %s %.2f\n", t.city1.c_str(), t.city2.c_str(),
                 t.wd.c_str(), t.time.c_str(), t.price);
        }
        n=1;
      }
      else if(n == 2){ // diena - b
        if (inptex == 0){
          cin >> inpt1;
          cin.clear();
          cin.ignore(1000, '\n');
            inptex = 1;
          cout << "result:" << endl;
          }
        if ((inpt1 == t.wd)) {
          printf("%s %s %s %s %.2f\n", t.city1.c_str(), t.city2.c_str(),
                 t.wd.c_str(), t.time.c_str(), t.price);
        }
        n=2;
        }
        else if(n == 3){ // maksa - c
        try {
        if (inptex == 0){
          cin >> inpt1;
          cin.clear();
          cin.ignore(1000, '\n');
            inptex = 1;
          price = stod(inpt1);
          cout << "result:" << endl;
        }
          if (price >= t.price) {
            printf("%s %s %s %s %.2f\n", t.city1.c_str(), t.city2.c_str(),
                   t.wd.c_str(), t.time.c_str(), t.price);
            
          }
        } catch (std::exception &e) {
          return;
        }
        n=3;
        }
      }
      cutline = "";
    }
  inpt1= "";
  inpt2= "";
  erfrex = 2;
  inptex = 0;//inpt existence file flags
  inFile.close();
  }
  


void reederrfile() {
  ifstream inFile;
  inFile.open("err.txt");
  string line;
  cout << "result:" << endl;
  while (!inFile.eof()) {
    getline(inFile, line, '\n');
    cout << line << endl;
  }

  inFile.close();
}

int main() {

  ifstream inFile;
  inFile.open("db.csv");

  string s;

  char choise;
  bool quit = false;
  if (!inFile)
    return 0;
  do {
    cin >> choise;
    switch (choise) {
    case 'a':
      removespacesfromstring(1);
      break;
    case 'b':
      removespacesfromstring(2);
      break;
    case 'c':
      removespacesfromstring(3);
      break;
    case 'd':
      removespacesfromstring(4);
      reederrfile();
      break;
    case 'e':
      quit = true;
    default:
      cin.clear();
      cin.ignore(1000, '\n');
      break;
    }
  } while (!quit);
  inFile.close();
  return 0;
}