

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <cctype>

using namespace std;

void toLowercase(string& str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
}

// saglabā informāciju par maršrutu
struct Route {
    string startStop;
    string endStop;
    string day;
    string time;
    double ticketPrice;
};

// pārbauda, vai rinda satur pareizu maršruta informāciju
bool isValidRoute(const vector<string>& tokens) {
    return tokens.size() == 5 &&
           none_of(tokens.begin(), tokens.end(), [](const string& s) { return s.empty(); }) &&
           (tokens[3].size() == 5) && // Pārbauda, vai laiks ir formātā hh:mm
           (isdigit(tokens[3][0]) && isdigit(tokens[3][1]) && tokens[3][2] == ':' &&
            isdigit(tokens[3][3]) && isdigit(tokens[3][4])); 
  // un vai laiks satur ciparus un atstarpi pēc pirmām divām ciparu pozīcijām
}

// ielasa datus no faila
vector<Route> readRoutesFromFile(const string& fileName, const string& errorFileName) {
    vector<Route> routes;
    ifstream inFile(fileName);
    ofstream errorFile(errorFileName);

    if (!inFile || !errorFile) {
        cerr << "Error opening file." << endl;
        exit(1);
    }

    string line;
    while (getline(inFile, line)) {
        // izņem visus atstarpes no rindas sākuma un beigām
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

        if (!line.empty()) {
            istringstream iss(line);
            vector<string> tokens;
            string token;

            while (getline(iss, token, ',')) {
                tokens.push_back(token);
            }

            if (isValidRoute(tokens)) {
                Route route;
                route.startStop = tokens[0];
                route.endStop = tokens[1];
                route.day = tokens[2];
                route.time = tokens[3];
                route.ticketPrice = stod(tokens[4]);
                routes.push_back(route);
            } else {
                errorFile << line << endl;
            }
        }
    }

    return routes;
}


// kas izvada visus reisus kas kursē maršruta
void printRoutesByRoute(const vector<Route>& routes, const string& startStop, const string& endStop) {
    cout << "result:" << endl;
    bool isFirst = true;

    string lowercaseStartStop = startStop;
    toLowercase(lowercaseStartStop); // pārvērš ievadīto sākumpunktu uz mazajiem burtiem

    string lowercaseEndStop = endStop;
    toLowercase(lowercaseEndStop); 

    for (const auto& route : routes) {
        string lowercaseRouteStart = route.startStop;
        toLowercase(lowercaseRouteStart);

        string lowercaseRouteEnd = route.endStop;
        toLowercase(lowercaseRouteEnd); 

        if (lowercaseRouteStart == lowercaseStartStop && lowercaseRouteEnd == lowercaseEndStop) {
            if (!isFirst) {
                if (cout << " ") {
                    cout << endl;
                }
            }
            cout << route.startStop << " " << route.endStop << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice;
            isFirst = false;
        }
    }
    if (!isFirst) {
        cout << endl;
    } else {
        cout << "No routes found for the specified stops." << endl;
    }
}

// izvada visus reisus, kas kursē noteiktā nedēļas dienā
void printRoutesByDay(const vector<Route>& routes, const string& day) {
    cout << "result:" << endl;
    bool found = false;

    // Pārvērš abas dienas virknes mazajos burtos, lai salīdzinātu neatkarīgi no lieluma
    string lowercaseDay = day;
    transform(lowercaseDay.begin(), lowercaseDay.end(), lowercaseDay.begin(), ::tolower);

    for (const auto& route : routes) {
        string lowercaseRouteDay = route.day;
        transform(lowercaseRouteDay.begin(), lowercaseRouteDay.end(), lowercaseRouteDay.begin(), ::tolower);

        if (lowercaseRouteDay == lowercaseDay) {
            cout << route.startStop << " " << route.endStop << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
            found = true;
        }
    }

    if (!found) {
        cout << "No routes found for the specified day." << endl;
    }
}


// izvada visus reisus kuru maksa nepārsniedz ievadīto
void printRoutesByPrice(const vector<Route>& routes, double maxPrice) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.ticketPrice <= maxPrice) {
            cout << route.startStop << " " << route.endStop << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}

int main() {
    string fileName = "db.csv";
    string errorFileName = "err.txt";
    vector<Route> routes = readRoutesFromFile(fileName, errorFileName);

    string input;
    while (true) {
        cout << "Enter choice (a, b, c, d, e): ";
        getline(cin, input);

        if (input.empty() || input.length() != 1 || !isalpha(input[0])) {
            cout << "Invalid input. Please enter a valid choice." << endl;
            continue;
        }

        char choice = tolower(input[0]); // funkcija lai pārvērstu burtu uz mazo

        if (choice == 'e') {
            break;
        }

        switch (choice) {
            case 'a': {
                string startStop, endStop;
                cout << "Enter start stop: ";
                getline(cin, startStop);
                cout << "Enter end stop: ";
                getline(cin, endStop);

                if (startStop.empty() || endStop.empty()) {
                    cout << "Invalid input. Please enter valid stops." << endl;
                    continue;
                }

                printRoutesByRoute(routes, startStop, endStop);
                break;
            }
            case 'b': {
                string day;
                cout << "Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                getline(cin, day);

                if (day.empty()) {
                    cout << "Invalid input. Please enter a valid day." << endl;
                    continue;
                }

                toLowercase(day); // pārvērš dienas nosaukumu uz mazo
                printRoutesByDay(routes, day);
                break;
            }
            case 'c': {
                double maxPrice;
                cout << "Enter max ticket price: ";
                cin >> maxPrice;

                if (cin.fail()) {
                    cout << "Invalid input. Please enter a valid price." << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    continue;
                }

                printRoutesByPrice(routes, maxPrice);
                break;
            }
            case 'd': {
                ifstream errorFile(errorFileName);
                if (errorFile) {
                    cout << "result:" << endl;
                    string line;
                    while (getline(errorFile, line)) {
                        cout << line << endl;
                    }
                } else {
                    cout << "Error opening error file." << endl;
                }
                break;
            }
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    }

    return 0;
}