
#include <algorithm>
#include <fstream>
#include <iostream>
#include <regex>
#include <vector>

using namespace std;

vector<string> d = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

vector<string> split(string s, char delimiter) {
  vector<string> result;
  int startPos = 0, endPos = 0;
  while ((endPos = s.find(",", startPos)) != -1) {
    result.push_back(s.substr(startPos, endPos - startPos));
    startPos = endPos + 1;
  }
  result.push_back(s.substr(startPos));
  return result;
}

bool checkValidity(string in) {
  if (in.length() < 2) {
    return false;
  }
  vector<string> words = split(in, ',');

  if (words.size() != 5) {
    return false;
  }

  if (find(d.begin(), d.end(), words[2]) == d.end()) {
    return false;
  }

  regex reg("(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]");
  if (!regex_match(words[3], reg)) {
    return false;
  }

  regex reg2("[0-9]+.[0-9][0-9](\r)?");
  if (!regex_match(words[4], reg2)) {
    return false;
  }
  return true;
}

string trim(string in) {
  in.erase(in.find_last_not_of(' ') + 1);
  in.erase(0, in.find_first_not_of(' '));
  return in;
}

string removeSpaces(string in) {
  string out = "";
  if (in.length() < 2) {
    return out;
  }
  vector<string> words = split(in, ',');
  int spacesRemoved = 0;
  if (words.size() > 1) {
    out.append(trim(words[0]) + "," + trim(words[1]));
    spacesRemoved = (words[0] + words[1]).length() + 1 - out.length();
  }
  for (int i = out.length() + spacesRemoved; i < in.size(); i++) {
    if (in.at(i) != ' ') {
      out.push_back(in.at(i));
    }
  }
  return out;
}

int main() {
  ifstream inFile("db.csv");
  ofstream outFile("err.txt");
  vector<string> validLines;
  vector<string> invalidLines;

  if (inFile.is_open()) {
    string line;
    while (getline(inFile, line)) {
      string a = removeSpaces(line);
      if (checkValidity(a)) {
        validLines.push_back(a);
      } else if (a.length() > 1) {
        invalidLines.push_back(line);
      }
    }
    inFile.close();
  }

  if (outFile.is_open()) {
    for (auto a : invalidLines) {
      outFile << a << endl;
    }
    outFile.close();
  }

  string str = "";
  while (true) {
    getline(cin, str);
    if (str == "a") {
      string s, f;
      getline(cin, s);
      getline(cin, f);
      cout << "result:" << endl;
      for (auto a : validLines) {
        vector<string> words = split(a, ',');
        string start = words[0];
        string finish = words[1];
        if (s == start && f == finish) {
          string output = "";
          for (auto b : words) {
            output.append(b + " ");
          }
          cout << trim(output) << "\n";
        }
      }
    } else if (str == "b") {
      getline(cin, str);
      cout << "result:" << endl;
      for (auto a : validLines) {
        vector<string> words = split(a, ',');
        string day = words[2];
        if (day == str) {
          string output = "";
          for (auto b : words) {
            output.append(b + " ");
          }
          cout << trim(output) << "\n";
        }
      }
    } else if (str == "c") {
      getline(cin, str);
      cout << "result:" << endl;
      int priceToSearch = stoi(str);
      for (auto a : validLines) {
        vector<string> words = split(a, ',');
        int price = stoi(words[4]);
        if (price <= priceToSearch) {
          string output = "";
          for (auto b : words) {
            output.append(b + " ");
          }
          cout << trim(output) << "\n";
        }
      }
    } else if (str == "d") {
      cout << "result:" << endl;
      ifstream inFile2("err.txt");
      if (inFile2.is_open()) {
        string line;
        while (getline(inFile2, line)) {
          cout << line << endl;
        }
      }
    } else if (str == "e") {
      return 0;
    }
  }
}