#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <string>

 
using namespace std;

string trim(const string& str);
vector<string> split(const string& s, char delimiter);
 bool isValidTime(const string& time);
bool isValidPrice(const string& price) ;

bool isValidDay(const string& day);


string trim(const string& str)  {
    size_t first = str.find_first_not_of(" \t\n");
    size_t last = str.find_last_not_of (" \t\n");

    if (first ==  string::npos || last == string::npos) {
        return ""; 
    }

    return str.substr(first, (last - first + 1));
}


 vector<string> split(const string& s, char delimiter) {
     vector<string> tokens;
    istringstream  ss(s);
    string token;

     while (getline(ss, token, delimiter)) {
           token = trim(token);
        tokens.push_back(token);
    }

    return  tokens;
}


bool isValidPrice  (const string& price) {
    stringstream  ss(price);
    double value;
    return  (ss >> value) &&  (value >= 0.0);
}


bool isValidDay(const string& day) {
    return  day.size() == 2;
}


bool isValidTime(const string& time) {
   
    return true;
}

struct Schedule {
    string from;
    string  to ;
    string day;
    string time;
    double  price;
 } ;


int  main()  {
    ifstream inFile;
  
    inFile.open("db.csv");

    if (!inFile) {
        cerr << "Error opening file" << endl;
        return 1;
    }

     ofstream errFile("err.txt");

    vector<Schedule> schedules;

    string line;
    while (getline(inFile, line)) {
      
        vector<string> tokens = split(line, ',');
          if (tokens.size() == 5) {
              Schedule schedule;
              schedule.from = tokens[0];
               schedule.to = tokens[1];

          
            if (!isValidDay(tokens[2]) || !isValidTime(tokens[3]) || !isValidPrice(tokens[4])) {
                errFile << line << endl;
                continue;
            }

            schedule.day = tokens [2];
          
              schedule.time = tokens[3];
            schedule.price = stod(tokens[4]);

            schedules.push_back(schedule);
        } else {
            errFile << line << endl;
        }
    }


  
    inFile.close();
    errFile.close();                       

  
    char option;
    string startStop, finalStop, day, maxPrice; 

  //==============================================================================================
    do {
        cin >> option;
        switch(option)   {

 //------------------------------------------------------------------------------------------
            case 'a': {
              
                cin >> startStop >> finalStop;
                cout << "result:" << endl;
              
                for (const Schedule& schedule : schedules)  {
                    if (schedule.from == startStop &&  schedule.to == finalStop )  {
                      
                        cout << schedule.from << " " << schedule.to << " "
                            << schedule.day << " " << schedule.time << " "
                            << fixed << setprecision(2) << schedule.price << endl;
                         }
                 }
             } 
              break;
 //------------------------------------------------------------------------------------------
          

            case 'b':  {
                cin >> day;
                cout << "result:" << endl;
              
                for  (const Schedule& schedule :  schedules) {
                     if (schedule.day == day) {
                       
                        cout << schedule.from << " " << schedule.to << " "
                            << schedule.day << " " << schedule.time << " "
                            << fixed << setprecision(2) << schedule.price << endl;
                    }
                  }
            }   break;
          
   //------------------------------------------------------------------------------------------

            case 'c': {
              
                cin >> maxPrice;
              
                cout << "result:" << endl;

              
                for (const Schedule& schedule : schedules) {
                     if (schedule.price <= stod(maxPrice))     {
                       
                        cout << schedule.from << " " << schedule.to << " "
                            << schedule.day << " " << schedule.time << " "
                            << fixed << setprecision(2) << schedule.price << endl;
                    }
                 }
            }  break;             
//-------------------------------------------------------------------------------------
            
            case 'd': {
              
                ifstream  errInput("err.txt");
                string errLine;
              
                  bool hasResult = false; 

                while (getline(errInput, errLine)) {
                     if (!errLine.empty() && !trim(errLine).empty())  {
                       
                        if (!hasResult) {
                          
                            cout << "result:" << endl;
                            hasResult = true;
                        }
                       
                        cout << errLine << endl;
                     }
                  }   

                if  (!hasResult)   {
                  
                    cout << "No errors found." << endl;
                 }

                errInput.close();
            } 
              
               break;             

 //------------------------------------------------------------------------------------------

            case 'e': 
                  break;

            default:  {
              
                cout << "wrong option" << endl;
            } break;
          }
    } 
      
      while (option != 'e');

    return 0;
}

