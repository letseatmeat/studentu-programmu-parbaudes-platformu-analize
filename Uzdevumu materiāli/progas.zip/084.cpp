
// neiznaca apstradat kļūdas
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <unordered_set>

using namespace std;
ifstream inFile;
ifstream inError;
string from;
string to;
string day;
string laiks;
string price;

unordered_set<string> encounteredLines;

string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}





void a(){
  string no;
  string uz;
  string line;

  cout<< "";
  cin >> no;
  cout<< "";
  cin >> uz;

  inFile.clear();
  inFile.seekg(0,ios::beg);

  cout << "result:" << endl;
  while (getline(inFile, line)){
    stringstream ss(line);

    getline(ss, from, ',');
    getline(ss, to, ',');
    getline(ss, day, ',');
    getline(ss, laiks, ',');
    ss >> price;

    from = trim(from);
    to = trim(to);
    day = trim(day);
    laiks = trim(laiks);
    price = trim(price);

    string combine = from + to + day + laiks + price;

    size_t commaPos=combine.find(",");
    if(commaPos!=string::npos){
      ofstream inError("err.txt");
      inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
      inError.close();

      continue;
    }



    if (ss.fail()){
      cerr << line << endl;
      ofstream inError("err.txt");
      inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
      inError.close();
      continue;
    }


    if (from == no && to == uz){ 
      cout << from << " " << to <<" " << day << " " << laiks << " " << price << endl;

  }
}
}

void b(){
  string diena;
  string line;
  cout<< "";
  cin>>diena;

  inFile.clear();
  inFile.seekg(0,ios::beg);

  cout << "result:" << endl;
  while (getline(inFile, line)){ 
    stringstream ss(line);

    getline(ss, from, ',');
    getline(ss, to, ',');
    getline(ss, day, ',');
    getline(ss, laiks, ',');
    ss >> price;

    from = trim(from);
    to = trim(to);
    day = trim(day);
    laiks = trim(laiks);
    price = trim(price);

    if (ss.fail()){
      cerr << line << endl;
      ofstream inError("err.txt");
      inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
      inError.close();
      continue;
    }

    if (day == diena){
      cout << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
    }

    }
  }



void c(){
  string cena;
  string line;

  cout<< "";
  cin>>cena;

  inFile.clear();
  inFile.seekg(0,ios::beg);

  cout << "result:" << endl;


  while (getline(inFile, line)){
    stringstream ss(line);

    getline(ss, from, ',');
    getline(ss, to, ',');
    getline(ss, day, ',');
    getline(ss, laiks, ',');
    ss >> price;

    from = trim(from);
    to = trim(to);
    day = trim(day);
    laiks = trim(laiks);
    price = trim(price);

    double dprice = 0.0;
    double dcena = 0.0;
    try{

      dprice=stod(price);
      dcena=stod(cena);

    } catch(const invalid_argument& e){
      cerr<< line << endl;
      ofstream inError("err.txt");
      inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
      inError.close();
      continue;
    }

    if (ss.fail()){
        cerr << line << endl;
      ofstream inError("err.txt");
      inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
      inError.close();
        continue;
      }
    string combine = from + to + day + laiks + price;
    if (dprice <= dcena){
      size_t commaPos=combine.find(",");
      if(commaPos!=string::npos){
        ofstream inError("err.txt");
        inError << from << " " << to <<" " << day << " " << laiks << " " << price << endl;
        inError.close();
        continue;
      }else{ 
      cout << from << " " << to <<" " << day << " " << laiks << " " << price << endl; }
    }
  }
}


void d(){
  string line;
  inError.open( "err.txt" );
  while (getline(inError, line)) {
      cout << line << endl;
  }
  inError.close();

}





int main() {

  inFile.open("db.csv");

  if (!inFile) return 0;



  char choice;
  do {
    cout <<"" ;
    cin >> choice;
    switch (choice) {
      case 'a':
         a();
      break;
      case 'b':
         b();
      break;
      case 'c':
         c();
      break;
      case 'd':
         d();
      break;
    }

    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
  } while (choice != 'e');
  inFile.close();
  return 0;
}

