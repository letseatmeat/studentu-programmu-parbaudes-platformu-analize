
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

void komatudaudzums(bool &err, string rinda, vector<string> &kludainas) {
  int komati = 0;
  for (char c : rinda) {
    if (c == ',') {
      komati++;
    }
  }
  if (komati != 4) {
    err = true;
  }
}
void sakumaparbaude(bool &err, vector<string> ieraksts,
                    vector<string> &kludainas) {
  if (err == true)
    return;
  else {
    if (ieraksts.at(0).length() < 3) {
      err = true;
    }
  }
}
void galaparbaude(bool &err, vector<string> ieraksts,
                  vector<string> &kludainas) {
  if (err == true)
    return;
  else {
    if (ieraksts.at(1).length() < 3) {
      err = true;
    }
  }
}
void dienasparbaude(bool &err, vector<string> ieraksts,
                    vector<string> &kludainas) {
  if (err == true)
    return;
  else {
    if (ieraksts.at(2) != "Pr" && ieraksts.at(2) != "Ot" &&
        ieraksts.at(2) != "Tr" && ieraksts.at(2) != "Ce" &&
        ieraksts.at(2) != "Pt" && ieraksts.at(2) != "St" &&
        ieraksts.at(2) != "Sv") {
      err = true;
    }
  }
}
void laikaparbaude(bool &err, vector<string> ieraksts,
                   vector<string> &kludainas) {
  if (err == true)
    return;
  else {
    if (ieraksts.at(3).length() != 5 || ieraksts.at(3).at(2) != ':') {
      err = true;
    }
  }
}
void cenasparbaude(bool &err, vector<string> ieraksts,
                   vector<string> &kludainas) {
  if (err == true)
    return;
  else {
    if (ieraksts.at(4).length() == 0 ||
        ieraksts.at(4).at(ieraksts.at(4).length() - 3) != '.') {
      err = true;
    }
  }
}
int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;
  vector<string> ieraksts;
  vector<string> kludainas;
  vector<string> pareizie;
  string rinda;
  string dala;
  bool err;
  while (getline(inFile, rinda)) {
    err = false;
    komatudaudzums(err, rinda, kludainas);
    if (err == false) {
      stringstream sadalits(rinda);
      while (getline(sadalits, dala, ',')) {
        while (dala.at(0) == ' ') {
          dala = dala.erase(0, 1);
        }
        while (dala.at(dala.length() - 1) == ' ') {
          dala = dala.erase(dala.length() - 1, dala.length());
        }
        ieraksts.push_back(dala);
      }
      sakumaparbaude(err, ieraksts, kludainas);
      galaparbaude(err, ieraksts, kludainas);
      dienasparbaude(err, ieraksts, kludainas);
      laikaparbaude(err, ieraksts, kludainas);
      cenasparbaude(err, ieraksts, kludainas);
      rinda = ieraksts.at(0) + "," + ieraksts.at(1) + "," + ieraksts.at(2) +
              "," + ieraksts.at(3) + "," + ieraksts.at(4);
      ieraksts.clear();
      if (err == true) {
        kludainas.push_back(rinda);
      } else if (err == false) {
        pareizie.push_back(rinda);
      }
    } else if (rinda != "") {
      kludainas.push_back(rinda);
    }
  }
  inFile.close();
  // for (const string& s: pareizie){
  //   cout << s << endl;
  // }
  // for (const string &s : kludainas) {
  //     cout << s << endl;
  // }
  ofstream outputFile;
  outputFile.open("err.txt");
  if (outputFile.is_open()) {
    int i = 0;
    for (const string &s : kludainas) {
      i++;
      if (i < kludainas.size()) {
        outputFile << s << "\n";
      } else {
        outputFile << s;
      }
    }
    outputFile.close();
  } else {
    cout << "Fails err.txt nav atvērts";
  }
  while (true) {
    char izvele;
    string pilseta1;
    string pilseta2;
    string cena;
    string diena;
    cin >> izvele;
    switch (izvele) {
    case 'a':
      cin >> pilseta1 >> pilseta2;
      cout << "result:"
           << "\n";
      for (const string &s : pareizie) {
        stringstream sadalits(s);
        while (getline(sadalits, dala, ',')) {
          ieraksts.push_back(dala);
        }
        if (ieraksts.at(0) == pilseta1 && ieraksts.at(1) == pilseta2) {
          cout << ieraksts.at(0) << " " << ieraksts.at(1) << " "
               << ieraksts.at(2) << " " << ieraksts.at(3) << " "
               << ieraksts.at(4) << "\n";
        }
        ieraksts.clear();
      }
      break;
    case 'b':
      cin >> diena;
      cout << "result:"
           << "\n";
      for (const string &s : pareizie) {
        stringstream sadalits(s);
        while (getline(sadalits, dala, ',')) {
          ieraksts.push_back(dala);
        }
        if (ieraksts.at(2) == diena) {
          cout << ieraksts.at(0) << " " << ieraksts.at(1) << " "
               << ieraksts.at(2) << " " << ieraksts.at(3) << " "
               << ieraksts.at(4) << "\n";
        }
        ieraksts.clear();
      }
      break;
    case 'c':
      cin >> cena;
      cout << "result:"
           << "\n";
      for (const string &s : pareizie) {
        stringstream sadalits(s);
        while (getline(sadalits, dala, ',')) {
          ieraksts.push_back(dala);
        }
        if (stod(ieraksts.at(4)) < stod(cena)) {
          cout << ieraksts.at(0) << " " << ieraksts.at(1) << " "
               << ieraksts.at(2) << " " << ieraksts.at(3) << " "
               << ieraksts.at(4) << "\n";
        }
        ieraksts.clear();
      }
      break;
    case 'd':
      cout << "result:"
           << "\n";
      inFile.open("err.txt");
      if (!inFile)
        return 0;
      while (getline(inFile, rinda)) {
        cout << rinda << endl;
      }
      inFile.close();
      break;
    case 'e':
      return 0;
      break;
    default:
      cout << "error";
      break;
    }
  }
  inFile.close();
}