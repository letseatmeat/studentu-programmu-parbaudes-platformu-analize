
#include <iostream>
#include <fstream>
#include <cstring>
#include <algorithm>
#include <vector>
#include <sstream>
#include <string>
using namespace std;
void error(string);
void cityFunc(string);
void dayFunc(string);
void priceFunc(string);
void readErr(string);
int main() {
  string inFile="db.csv";
  string err="err.txt";
  error(inFile);
  string cmd;
  while(cmd!="e"){
    cin>>cmd;
    if(cmd=="a"){

      cityFunc(inFile);
    }
    if(cmd=="b"){

      dayFunc(inFile);
    }
    if(cmd=="c"){

      priceFunc(inFile);
    }
    if(cmd=="d"){
      readErr(err);
    }
    if(cmd!="a"&&cmd!="b"&&cmd!="c"&&cmd!="d"&&cmd!="f"){
      cout<<"wrong command!"<<endl;
    }
  }
  }
void error(string str){
  ifstream inFile;
  ofstream outFile;
  inFile.open(str);
  outFile.open("err.txt");
  char* days[7]={"Pr","Ot","Tr","Ce","Pt","St","Sv"};
  string s,c1,c2,day,time,price;
  double priced;
  while(getline(inFile,s)){
  s.erase(remove(s.begin(), s.end(), ' '), s.end());
    stringstream ss(s);
    getline(ss,c1,',');
    getline(ss,c2,',');
    getline(ss,day,',');
    getline(ss,time,',');
    getline(ss,price);
    priced=stod(price);
    int day_check=0;
    for(int i=0;i<7;i++){
    if(strcmp(day.c_str(),days[i])==0){
      day_check++;
    }
    }
     int len_check=0;
    for(int i=0;i<s.length();i++){
      if(s[i]==',')len_check++;
    }
    int a,b,c,d;
    int time_check=sscanf(time.c_str(),"%d%d:%d%d",&a,&b,&c,&d);
    string hhs,mms;
    int hh,mm,tfcheck=0;
    int price_check=sscanf(price.c_str(),"%d.%d%d",&a,&b,&c);
    if(time_check==1){
    hhs=time.substr(0,time.find(":"));
    mms=time.substr(time.find(":")+1,time.length());
    hh=stoi(hhs);
    mms=stoi(mms);
     if(hh>23||hh<0||mm>59||mm<0){
       tfcheck++;
     } 
    }
    if(len_check!=4||day_check==0 ||time_check!=1|| tfcheck>0 || price_check!=2){
      if(s.size()!=1)
      outFile<<s<<endl;
      }
  }
  return;
}
void cityFunc(string str){
  string incity1,incity2;
  cin>>incity1;
  cin>>incity2;
  cout<<"result:"<<endl;
  ifstream inFile;
  inFile.open(str);
  char* days[7]={"Pr","Ot","Tr","Ce","Pt","St","Sv"};
  string s,s2,c1,c2,day,time,price;
  double priced;
  while(getline(inFile,s,'\n')){
  s.erase(remove(s.begin(), s.end(), ' '), s.end());
    stringstream ss(s);
    getline(ss,c1,',');
    getline(ss,c2,',');
    getline(ss,day,',');
    getline(ss,time,',');
    getline(ss,price);
    priced=stod(price);
    int day_check=0;
    for(int i=0;i<7;i++){
    if(strcmp(day.c_str(),days[i])==0){
      day_check++;
    }
    }
     int len_check=0;
    for(int i=0;i<s.length();i++){
      if(s[i]==',')len_check++;
    }
    int a,b,c,d;
    int time_check=sscanf(time.c_str(),"%d%d:%d%d",&a,&b,&c,&d);
    string hhs,mms;
    int hh,mm,tfcheck=0;
    int price_check=sscanf(price.c_str(),"%d.%d%d",&a,&b,&c);
    if(time_check==1){
    hhs=time.substr(0,time.find(":"));
    mms=time.substr(time.find(":")+1,time.length());
    hh=stoi(hhs);
    mms=stoi(mms);
     if(hh>23||hh<0||mm>59||mm<0){
       tfcheck++;
     } 
    }
    if(len_check==4&&day_check!=0&&time_check==1&&tfcheck==0&&price_check==2){
      if(incity1==c1&&incity2==c2){
        stringstream ss2(s);
        while(ss2>>s2){
        replace(s2.begin(), s2.end(), ',', ' ');
        cout<<s2<<endl; 
        }
      }
      }
  }
  return;
}
void dayFunc(string str){
  string inday;
  cin>>inday;
  cout<<"result:"<<endl;
  ifstream inFile;
  inFile.open(str);
  char* days[7]={"Pr","Ot","Tr","Ce","Pt","St","Sv"};
  string s,s2,c1,c2,day,time,price;
  double priced;
  while(getline(inFile,s)){
  s.erase(remove(s.begin(), s.end(), ' '), s.end());
    stringstream ss(s);
    getline(ss,c1,',');
    getline(ss,c2,',');
    getline(ss,day,',');
    getline(ss,time,',');
    getline(ss,price);
    priced=stod(price);
    int day_check=0;
    for(int i=0;i<7;i++){
    if(strcmp(day.c_str(),days[i])==0){
      day_check++;
    }
    }
     int len_check=0;
    for(int i=0;i<s.length();i++){
      if(s[i]==',')len_check++;
    }
    int a,b,c,d;
    int time_check=sscanf(time.c_str(),"%d%d:%d%d",&a,&b,&c,&d);
    string hhs,mms;
    int hh,mm,tfcheck=0;
    int price_check=sscanf(price.c_str(),"%d.%d%d",&a,&b,&c);
    if(time_check==1){
    hhs=time.substr(0,time.find(":"));
    mms=time.substr(time.find(":")+1,time.length());
    hh=stoi(hhs);
    mms=stoi(mms);
     if(hh>23||hh<0||mm>59||mm<0){
       tfcheck++;
     } 
    }
    if(len_check==4&&day_check!=0&&time_check==1&&tfcheck==0&&price_check==2){
      if(inday==day){
        stringstream ss2(s);
        while(ss2>>s2){
        replace(s2.begin(), s2.end(), ',', ' ');
        cout<<s2<<endl; 
        }
      }
      }
  }
  return;
}
void priceFunc(string str){
  double inprice;
  cin>>inprice;
  while(cin.fail()){
    cin.clear();
    cin.ignore(1000,'\n');
    cout<<"Wrong price format, try again: ";
    cin>>inprice;
  }
  cout<<"result:"<<endl;
  ifstream inFile;
  inFile.open(str);
  char* days[7]={"Pr","Ot","Tr","Ce","Pt","St","Sv"};
  string s,s2,c1,c2,day,time,price;
  double priced;
  while(getline(inFile,s)){
  s.erase(remove(s.begin(), s.end(), ' '), s.end());
    stringstream ss(s);
    getline(ss,c1,',');
    getline(ss,c2,',');
    getline(ss,day,',');
    getline(ss,time,',');
    getline(ss,price);
    priced=stod(price);
    int day_check=0;
    for(int i=0;i<7;i++){
    if(strcmp(day.c_str(),days[i])==0){
      day_check++;
    }
    }
     int len_check=0;
    for(int i=0;i<s.length();i++){
      if(s[i]==',')len_check++;
    }
    int a,b,c,d;
    int time_check=sscanf(time.c_str(),"%d%d:%d%d",&a,&b,&c,&d);
    string hhs,mms;
    int hh,mm,tfcheck=0;
    int price_check=sscanf(price.c_str(),"%d.%d%d",&a,&b,&c);
    if(time_check==1){
    hhs=time.substr(0,time.find(":"));
    mms=time.substr(time.find(":")+1,time.length());
    hh=stoi(hhs);
    mms=stoi(mms);
     if(hh>23||hh<0||mm>59||mm<0){
       tfcheck++;
     } 
    }
  if(len_check==4&&day_check!=0&&time_check==1&&tfcheck==0&&price_check==2){
    if(priced<=inprice){
      stringstream ss2(s);
      while(ss2>>s2){
      replace(s2.begin(), s2.end(), ',', ' ');
      cout<<s2<<endl; 
      }
    }
      }
  }
  return;
}
void readErr(string str){
  ifstream inFile;
  cout<<"result:"<<endl;
  inFile.open(str);
  string s;
  while(inFile>>s){
    cout<<s<<endl;
  }
}