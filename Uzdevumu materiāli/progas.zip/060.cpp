
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cctype>
#include <set>

using namespace std;
set<string> processedLines;
bool is_valid_format(const vector<string>& row) {
  if (row.empty()) {
    return false;
  }
    // Check if the row has the correct format
    if (row.size() != 5) return false;
    if (row[3].size() != 5 || row[3][2] != ':') return false;
    for (int i = 0; i < 5; ++i) {
        if (i != 2 && row[i].empty()) return false;
    }
    return true;
}
bool is_valid(const vector<string>& row, const string& start, const string& end) {
    if (!is_valid_format(row)) return false;
    if (row[0] != start || row[1] != end) return false;
    return true;
}
void clear_error_file() {
    ofstream errFile("err.txt", ios::trunc);
    errFile.close();
}
void write_error(string line, set<string>& processedLines) {
  line.erase(line.begin(), find_if(line.begin(), line.end(), [](char ch) {
    return !isspace(ch);
  }));
  line.erase(find_if(line.rbegin(), line.rend(), [](char ch) {
    return !isspace(ch);
  }).base(), line.end());
  if (!line.empty()) {
    vector<string> row;
    stringstream ss(line);
    string value;
    while (getline(ss, value, ',')) {
      value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
      row.push_back(value);
    }
    if (!is_valid_format(row)) {
      ofstream errFile;
      errFile.open("err.txt", ios_base::app);
      if (processedLines.find(line) == processedLines.end()) {
        errFile << line << endl;
        processedLines.insert(line);
      }
      errFile.close();
    }
  }
}
void handle_a(set<string>& processedLines) {
  clear_error_file();
  ifstream inFile;
  inFile.open("db.csv");
  string line;
  string start, end;
  //cout << "Enter the start of the route: ";
  cin >> start;
  //cout << "Enter the end of the route: ";
  cin >> end;
  while (getline(inFile, line)) {
    stringstream ss(line);
    string value;
    vector<string> row;
    while (getline(ss, value, ',')) {
      value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
      row.push_back(value);
    }
    if (is_valid(row, start, end)) {
      for (const auto& word : row) {
        cout << word << " ";
      }
      cout << endl;
    }else{
      write_error(line, processedLines);
    }
  }
}
bool is_valid_b(const vector<string>& row, const string& day) {
    if (row.size() != 5) return false;
    if (row[3].size() != 5 || row[3][2] != ':') return false;
    for (int i = 0; i < 5; ++i) {
        if (i != 2 && row[i].empty()) return false;
    }
    if (row[2] != day) return false;
    return true;
}
void handle_b(set<string>& processedLines) {
  clear_error_file();
  ifstream inFile;
  inFile.open("db.csv");
  string line;
  string day;
  cin >> day;
  while (getline(inFile, line)) {
    
    stringstream ss(line);
    string value;
    vector<string> row;
    set<string> processedLines;
    while (getline(ss, value, ',')) {
      value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
      row.push_back(value);
    }
    if (is_valid_b(row, day)) {
      for (const auto& word : row) {
        cout << word << " ";
      }
      cout << endl;
    }else {
      write_error(line, processedLines);
    }
  }
}
bool is_valid_c(const vector<string>& row, float max_price) {
    if (row.size() != 5) return false;
    if (row[3].size() != 5 || row[3][2] != ':') return false;
    for (int i = 0; i < 5; ++i) {
        if (i != 2 && row[i].empty()) return false;
    }
    float price = stof(row[4]);
    if (price > max_price) return false;
    return true;
}
void handle_c(set<string>& processedLines) {
  clear_error_file();
  ifstream inFile;
  inFile.open("db.csv");
  string line;
  float max_price;
  cin >> max_price;
  while (getline(inFile, line)) {
    stringstream ss(line);
    string value;
    vector<string> row;
    set<string> processedLines;
    while (getline(ss, value, ',')) {
      value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
      row.push_back(value);
    }
    if (is_valid_c(row, max_price)) {
      for (const auto& word : row) {
        cout << word << " ";
      }
      cout << endl;
    }else {
      write_error(line, processedLines);
    }
  }
}
void handle_d(set<string>& processedLines){
  ifstream errFile;
  errFile.open("err.txt");
  string line;
  while (getline(errFile, line)) {
    cout << line << endl;
  }
  errFile.close();
}

int main() {
  cout << "result:" << endl;
  char command;
  set<string> processedLines;
  do{
  //cout << "Ievadi komandu:";
  cin >> command;
  switch(command){
    case 'a':
    handle_a(processedLines);
    break;
    case 'b':
    handle_b(processedLines);
    break;
    case 'c':
    handle_c(processedLines);
    break;
    case 'd':
    handle_d(processedLines);
    break;
  } 
    processedLines.clear();
    //cout << "processedLines cleared" << endl;
  }while (command != 'e');
  return 0;
} 