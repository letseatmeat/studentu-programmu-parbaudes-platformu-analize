#include <fstream>
#include <iostream>
#include <map>
#include <vector>

using namespace std;

vector<vector<string>> t;
vector<vector<double>> n;

void print(int a) {
  // locations
  cout << t[a][0] << " " << t[a][1] << " ";

  // day
  int numb = n[a][0];
  switch (numb) {
  case 1:
    cout << "Pr ";
    break;
  case 2:
    cout << "Ot ";
    break;
  case 3:
    cout << "Tr ";
    break;
  case 4:
    cout << "Ce ";
    break;
  case 5:
    cout << "Pt ";
    break;
  case 6:
    cout << "St ";
    break;
  case 7:
    cout << "Sv ";
    break;
  }

  // time
  numb = n[a][1];
  printf("%02d:%02d ", numb, static_cast<int>((numb - (int)numb) * 100));

  // cost
  printf("%2.2f\n", n[a][2]);
}

void b(double b) {
  cout << "result:" << endl;
  for (int i = 0; i < n.size(); i++) {
    if (n[i][0] == b) {
      print(i);
    }
  }
}
void a(string from, string to) {
  cout << "result:" << endl;
  for (int i = 0; i < n.size(); i++) {
    if (t[i][0] == from & t[i][1] == to) {
      print(i);
    }
  }
}
void c(double c) {
  cout << "result:" << endl;
  for (int i = 0; i < n.size(); i++) {
    if (n[i][2] <= c) {
      print(i);
    }
  }
}
void d() {
  cout << "result:" << endl;
  ifstream inFile;
  inFile.open("err.txt");

  string str;
  while (getline(inFile, str)) {
    cout << str << endl;
  }
}

double get_day(string str) {
  if (str == "Pr")
    return 1;
  if (str == "Ot")
    return 2;
  if (str == "Tr")
    return 3;
  if (str == "Ce")
    return 4;
  if (str == "Pt")
    return 5;
  if (str == "St")
    return 6;
  if (str == "Sv")
    return 7;
}
double get_time(string str) {
  // cout << "str=" << str << endl;
  double a = 0;
  double b = 0;
  try {
    a = stoi(str.substr(0, 2));
    b = double(stoi(str.substr(3, 2))) / 100;
  } catch (const exception &e) {
    // cout << "ERRORRRR" << endl;
    return -1;
  }
  // cout << a + b << endl;
  // cout << "__________________" << endl;
  // // return stoi(str.substr(0,2)) + double(stoi(str.substr(3,2)))/100;
  return a + b;
}

bool empty(string str) {
    for (char ch : str) {
        if (!isspace(static_cast<unsigned char>(ch))) {
            return false;
        }
    }
    return true;
}
int check_err(){
  ifstream inFile("err.txt");

  // Open the output file
  ofstream outFile("err_no_empty_lines.txt");

  string line;
  while (getline(inFile, line)) {
      if (!line.empty() && !empty(line)) {
          // Write non-empty lines to the output file
          outFile << line << endl;
      }
  }

  //close both files
  inFile.close();
  outFile.close();
  remove("err.txt");
  rename("err_no_empty_lines.txt", "err.txt");

  return 0;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  ofstream outFile("err.txt");

  if (!inFile) {
    return 0;
  }

  string s, str;
  int l[] = {0, 0, 0, 0, 0, 0};
  string from, to, day, time, cost;

outer:
  while (getline(inFile, str)) {
    if (str == "") {
      cout << "HEEEELLLPPP" << endl;
      goto outer;
    }

    // getting rid of spaces
    s = "";
    for (int i = 0; i < str.size(); i++) {
      if (str.at(i) != ' ') {
        s = s + str.at(i);
      }
    }

    // finding places of commas
    for (int i = 1; i < 5; i++) {
      if (s.find(",", l[i - 1] + 1) == -1) {
        outFile << str << endl;////////////////////
        goto outer;
      }
      l[i] = s.find(",", l[i - 1] + 1) + 1;
      if (i == 4 & s.find(",", l[i] + 1) != -1) {
        outFile << str << endl;/////////////////////
        goto outer;
      }
    }
    l[5] = s.size();

    // outputing info + array
    // cout << str << endl;
    // for (int i = 0; i < 6; ++i) {
    //     cout << l[i] << " ";
    // } cout << endl;

    // putting information in dynamic array
    string from, to, day, time, cost;
    double cost_double, time_double;

    from = s.substr(0, l[1] - 1);
    to = s.substr(l[1], l[2] - l[1] - 1);
    day = s.substr(l[2], l[3] - l[2] - 1);
    time = s.substr(l[3], l[4] - l[3] - 1);
    cost = s.substr(l[4], l[5] - l[4] - 1);

    cost_double = double(stod(cost));
    // cout << "double cost=" << cost_double << endl;
    time_double = get_time(time);
    if (time_double == -1) {
      outFile << str << endl;////////////////////
      goto outer;
    }

    // printf("_%s_\n", from.c_str());
    // printf("_%s_\n", to.c_str());
    // printf("_%s_\n", day.c_str());
    // printf("_%s_\n", time.c_str());
    // printf("_%s_\n", cost.c_str());

    t.push_back({from, to});
    n.push_back({get_day(day), time_double, cost_double});
  }

  check_err();

  string in, in2;
  double in3;

  while (true) {
    cin >> in;
    if (in == "e") {
      break;
    }
    if (in == "a") {
      cin >> in;
      cin >> in2;
      a(in, in2);
    }
    if (in == "b") {
      cin >> in;
      b(get_day(in));
    }
    if (in == "c") {
      cin >> in3;
      c(in3);
    }
    if (in == "d") {
      d();
    }
  }

  // c(5.90);

  // PRINTING EVERYTHING
  // cout << "____________________" << endl;
  // for (int i = 0; i < t.size(); i++) {
  //   cout << t[i][0] << " " << t[i][1] << " " << n[i][0] << " " << n[i][1] <<
  //   " " << n[i][2] << endl;
  // }

  return 1;
}