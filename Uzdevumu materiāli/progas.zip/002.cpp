#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>
#include <algorithm>

using namespace std;

struct autobusuMarsruts {
    string sakumaPietura;
    string galaPietura;
    string nedelasDiena;
    string laiks;
    double biletesCena;
};

string delspaces(const string& str) {
    string trim =str;
    trim.erase(remove_if(trim.begin(), trim.end(), ::isspace), trim.end());

    return trim;
}

bool marsrutaParbaude (const autobusuMarsruts& marsruts) {
    int stundas, minutes;
    char kols;
    istringstream laikaFormats(marsruts.laiks);
    laikaFormats >> stundas >> kols >> minutes;

    return (
        !marsruts.sakumaPietura.empty() &&
        !marsruts.galaPietura.empty() &&
        (marsruts.nedelasDiena == "Pr" || marsruts.nedelasDiena == "Ot" ||
         marsruts.nedelasDiena == "Tr" || marsruts.nedelasDiena == "Ce" ||
         marsruts.nedelasDiena == "Pt" || marsruts.nedelasDiena == "St" || 
         marsruts.nedelasDiena == "Sv") &&
        (laikaFormats && kols == ':' && stundas >= 0 && stundas < 24 && minutes >= 0 && minutes < 60) &&
        (marsruts.biletesCena >= 0.0)
    );
}

void printMarsruts(const vector<autobusuMarsruts>& marsruti) {
    cout << "result:" << endl;
    for (const auto& marsruts : marsruti) {
        cout << marsruts.sakumaPietura <<" "<< marsruts.galaPietura <<" "<< marsruts.nedelasDiena <<" "<< marsruts.laiks <<" "<< fixed << setprecision(2) << marsruts.biletesCena << endl;
    }
}

int main() {
    ifstream Fails("db.csv");
    if (!Fails) {
        cerr << "Error: nevar atvert failu." << endl;
        return 0;
    }

    ofstream errFails("err.txt");
    if (!errFails) {
        cerr << "Error: nevar atvert error failu." << endl;
        return 0;
    }

    vector<autobusuMarsruts> marsruti;
    string line;

    while (getline(Fails, line)) {
        line = delspaces(line);

        if (line.empty()) continue;

        int komati = count(line.begin(), line.end(), ',');
        if (komati != 4) { errFails << line << endl; continue; }

        autobusuMarsruts marsruts;
        istringstream iss(line);

        if (getline(iss, marsruts.sakumaPietura, ',') &&
            getline(iss, marsruts.galaPietura, ',') &&
            getline(iss, marsruts.nedelasDiena, ',') &&
            getline(iss, marsruts.laiks, ',') &&
            (iss >> marsruts.biletesCena)) {

            if (!marsrutaParbaude(marsruts)) {
                errFails << line << endl;
                continue;
            }

            marsruti.push_back(marsruts);
        } else {
            errFails << line << endl;
        }
    }

    Fails.close();
    errFails.close();

    char ievade;
    do {
        cin >> ievade;

        switch (ievade) {
            case 'a': {
                string sakumaPunkts, galaPunkts;
                cin >> sakumaPunkts;
                cin >> galaPunkts;

                vector<autobusuMarsruts> filtretsMarsruts;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.sakumaPietura == sakumaPunkts && marsruts.galaPietura == galaPunkts) {
                        filtretsMarsruts.push_back(marsruts);
                    }
                }

                printMarsruts(filtretsMarsruts);
                break;
            }
            case 'b': {
                string nedelasDiena;
                cin >> nedelasDiena;

                vector<autobusuMarsruts> filtretsMarsruts;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.nedelasDiena == nedelasDiena) {
                        filtretsMarsruts.push_back(marsruts);
                    }
                }

                printMarsruts(filtretsMarsruts);
                break;
            }
            case 'c': {
                double maxCena;
                cin >> maxCena;

                vector<autobusuMarsruts> filtretsMarsruts;
                for (const auto& marsruts : marsruti) {
                    if (marsruts.biletesCena <= maxCena) {
                        filtretsMarsruts.push_back(marsruts);
                    }
                }

                printMarsruts(filtretsMarsruts);
                break;
            }
            case 'd': {
                ifstream errFails("err.txt");
                if (errFails.is_open()) {
                    cout << "result:" << endl;
                    string line;
                    while (getline(errFails, line)) {
                        cout << line << endl;
                    }
                    errFails.close();
                } else {
                }
                break;
            }
            case 'e':
                break;
        }

    } while (ievade != 'e');

    return 0;
}