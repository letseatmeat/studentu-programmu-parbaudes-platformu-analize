
#include <fstream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include <sstream>

struct cels {
  std::string sakums;std::string gals;std::string diena;std::string laiks;
  double bilete;};

bool parbaude(const std::vector<std::string>&atmina){

  if(atmina.size()!=5){return false;}

  size_t kol=atmina[3].find(':');
  if (kol==std::string::npos){return false;}

  try {std::stod(atmina[4]);}catch (const std::exception &) {return false;}return true;}

std::string sakartot(const std::string &s){
  size_t pirm = s.find_first_not_of(' ');
  if (std::string::npos==pirm){return s;}
  size_t pedej=s.find_last_not_of(' ');
  return s.substr(pirm,((pedej-pirm)+1));
}

bool tuksums(const std::string &s) {
  return std::all_of(s.begin(),s.end(),::isspace);
}
std::vector<cels> cela_izvade(const std::string &f_cels,std::ofstream &err) {
  std::vector<cels> r2;std::ifstream fails(f_cels);

  std::string line;
  while (std::getline(fails,line)){
    if (line.empty()||tuksums(line)){continue;}
      

    std::stringstream ss(line);std::string vertiba;std::vector<std::string> atmina;

    while (std::getline(ss,vertiba,',')) {atmina.push_back(sakartot(vertiba));}

    if (!parbaude(atmina)) {
      err<<line<<'\n';continue;}

    try {
      cels j_cels ={atmina[0],atmina[1],atmina[2],atmina[3],std::stod(atmina[4])};
      r2.push_back(j_cels);
    }catch (const std::exception &e) {err<<line<<"Error: "<<e.what();}
  }
  fails.close();return r2;
}

void cels_out(const std::vector<cels> &r2) {
  for (const auto &r:r2){
    std::cout<<r.sakums<<" "<<r.gals<<" "<< r.diena<<" "<<r.laiks<<" "<< std::fixed<< std::setprecision(2)<<r.bilete<<'\n';}
}

int main() {
  std::ofstream err("err.txt");
  std::vector<cels>r2=cela_izvade("db.csv",err);err.close();char ievade;
  do {
    std::cin >> ievade;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

    switch (ievade){
      
    case 'a': {
      std::string sak,beig;std::getline(std::cin,sak);std::getline(std::cin,beig);
      std::cout<<"result:"<<std::endl;
      for (const auto &r:r2){
        if(r.sakums==sak && r.gals==beig){cels_out({r});}
      }
      break;
    }
    case 'b': {
      std::string ned_diena;std::getline(std::cin,ned_diena);
      std::cout<<"result:"<<std::endl;
      for (const auto &r:r2) {
        if (r.diena == ned_diena){cels_out({r});}
      }break;}
      
    case 'c':{
      double liel_cena;
      std::cin>>liel_cena;
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

      std::cout<<"result:"<<'\n';
      for (const auto &r:r2){
        if (r.bilete<=liel_cena){cels_out({r});}
      }break;}
      
    case 'd':{
      std::ifstream saturs("err.txt");
      if (!saturs.is_open()){}else{
        std::cout<<"result:"<<'\n';
        saturs.seekg(0, std::ios::beg);

        std::string content;
        while (std::getline(saturs, content)) {
          if (!content.empty()&&content.find(",,")==std::string::npos){
            std::cout<<content<<'\n';
          }
        }
        saturs.close();
      }break;}
      
    case 'e':{break;}
      
    default:{std::cout<<"Nepareiza komanda"<<'\n';break;}  
      
    }
  }while(ievade!='e');return 0;
}