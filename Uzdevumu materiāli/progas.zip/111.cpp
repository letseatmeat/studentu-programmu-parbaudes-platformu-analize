
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

struct BusRoute {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

std::vector<std::string> split(const std::string &str, char delim) {
  std::vector<std::string> tokens;
  std::stringstream ss(str);
  std::string token;
  while (std::getline(ss, token, delim)) {
    tokens.push_back(token);
  }
  return tokens;
}

std::string trim(const std::string &str) {
  size_t first = str.find_first_not_of(" \t\n\r");
  if (std::string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(" \t\n\r");
  return str.substr(first, (last - first + 1));
}

std::vector<BusRoute> readBusRoutes(const std::string &filename) {
  std::vector<BusRoute> routes;
  std::ifstream file(filename);
  std::string line;
  std::ofstream errFile("err.txt");

  while (std::getline(file, line)) {
    line = trim(line);
    if (line.empty())
      continue;

    auto tokens = split(line, ',');
    // Check if the number of fields is incorrect or if price conversion fails
    if (tokens.size() != 5) {
      errFile << line << std::endl;
      continue;
    }

    try {
      BusRoute route;
      route.start = trim(tokens[0]);
      route.end = trim(tokens[1]);
      route.day = trim(tokens[2]);
      route.time = trim(tokens[3]);
      // Check if the price is a valid double
      std::string trimmedPrice = trim(tokens[4]);
      if (trimmedPrice.find_first_not_of("0123456789.") != std::string::npos) {
        throw std::invalid_argument("Invalid price format");
      }
      route.price = std::stod(trimmedPrice);
      routes.push_back(route);
    } catch (const std::exception &e) {
      errFile << line << std::endl;
    }
  }

  return routes;
}

void displayRoutesByStations(const std::vector<BusRoute> &routes) {
  std::string startStation, endStation;
  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  std::getline(std::cin, startStation);
  std::getline(std::cin, endStation);

  bool found = false;
  std::cout << "result:" << std::endl; // Print the "Result:" message only once

  for (const auto &route : routes) {
    if (trim(route.start) == startStation && trim(route.end) == endStation) {
      found = true;
      std::cout << route.start << " " << route.end << " " << route.day << " "
                << route.time << " " << std::fixed << std::setprecision(2)
                << route.price << std::endl;
    }
  }

  if (!found) {
    std::cout << "No routes found for " << startStation << " to " << endStation
              << std::endl;
  }
}

void displayRoutesByDay(const std::vector<BusRoute> &routes) {
  std::string day;
  std::cin >> day;

  std::cout << "result:" << std::endl; // Print the "Result:" message once

  bool found = false;
  for (const auto &route : routes) {
    if (trim(route.day) == day) {
      found = true;
      std::cout << route.start << " " << route.end << " " << route.day << " "
                << route.time << " " << std::fixed << std::setprecision(2)
                << route.price << std::endl; // Print each route on a new line
    }
  }

  if (!found) {
    std::cout << "No routes found for day " << day << std::endl;
  }
}

void displayRoutesByMaxPrice(const std::vector<BusRoute> &routes) {
  double maxPrice;
  std::cin >> maxPrice;

  // Check for input failure.
  if (std::cin.fail()) {
    std::cin.clear(); // Clear the error flag
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(),
                    '\n'); // Skip to next line
    std::cout << "Invalid input. Please enter a valid price." << std::endl;
    return;
  }

  std::cout << "result:" << std::endl; // Print the "Result:" message once

  bool found = false;
  for (const auto &route : routes) {
    if (route.price <= maxPrice) {
      found = true;
      std::cout << route.start << " " << route.end << " " << route.day << " "
                << route.time << " " << std::fixed << std::setprecision(2)
                << route.price << std::endl; // Print each route on a new line
    }
  }

  if (!found) {
    std::cout << "No routes found with ticket price under " << std::fixed
              << std::setprecision(2) << maxPrice << std::endl;
  }
}

void displayErrorFile() {
  std::ifstream errFile("err.txt");
  std::string line;
  std::cout << "result:" << std::endl;

  if (errFile.is_open()) {
    bool found = false;
    while (getline(errFile, line)) {
      // Trim carriage return character from the end of the line if present
      if (!line.empty() && line[line.size() - 1] == '\r') {
        line.erase(line.size() - 1);
      }

      if (!line.empty()) {
        found = true;
        std::cout << line << std::endl;
      }
    }
    errFile.close();

    if (!found) {
      std::cout << "No errors recorded in err.txt." << std::endl;
    }
  } else {
    std::cout << "Unable to open err.txt." << std::endl;
  }
}

void exitProgram() {}

int main() {
  std::vector<BusRoute> routes = readBusRoutes("db.csv");
  char command;
  do {
    std::cin >> command;
    switch (command) {
    case 'a':
      displayRoutesByStations(routes);
      break;
    case 'b':
      displayRoutesByDay(routes);
      break;
    case 'c':
      displayRoutesByMaxPrice(routes);
      break;
    case 'd':
      displayErrorFile();
      break;
    case 'e':
      exitProgram();
      break;
    default:
      std::cout << "Invalid command." << std::endl;
      break;
    }
  } while (command != 'e');

  return 0;
}