#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;



// Riga,Kraslava,Pr,15:00,11.00

// Riga ,Kraslava,Pr ,18:00,11.00
//    Kraslava,Riga,Pr,08:00,11.00
// Kraslava,Daugavpils,Ot ,10:00, 3.00
// Ventsplis,8.00,Liepaja,Sv,20:00
// Dagda,Sv

// Rezekne,Riga,Tr,13:00,10.50
// Dagda,Kraslava,  Ce,18:00,  2.50
// Dagda,Kraslava,Ce,18:00,2.50,Sv
//   Riga,Ventspils,  Pt,09:00  ,  6.70

// Liepaja,Ventspils,Pt,17:00,5.50

enum class Week { Pr, Ot, Tr, Ce, Pt, St, Sv };

class WeekTransformation {
public:
  string convertWeekToString(Week w) {
    switch (w) {
    case Week::Pr:
      return "Pr";
    case Week::Ot:
      return "Ot";
    case Week::Tr:
      return "Tr";
    case Week::Ce:
      return "Ce";
    case Week::Pt:
      return "Pt";
    case Week::St:
      return "St";
    case Week::Sv:
      return "Sv";
    }
  }

  Week convertStringToWeek(string str) {
    if (str == "Pr") {
      return Week::Pr;
    } else if (str == "Ot") {
      return Week::Ot;
    } else if (str == "Tr") {
      return Week::Tr;
    } else if (str == "Ce") {
      return Week::Ce;
    } else if (str == "Pt") {
      return Week::Pt;
    } else if (str == "St") {
      return Week::St;
    } else if (str == "Sv") {
      return Week::Sv;
    } else {
      throw "Invalid day";
    }
  }
};



class BusRoute {
private:
  string startBusStop;
  string endBusStop;
  Week day;
  string time;
  double price;

public:
  // Constructor
  BusRoute(string startBusStop, string endBusStop, string day, string time,
           string price) {
    setStartBusStop(startBusStop);
    setEndBusStop(endBusStop);
    setDay(day);
    setTime(time);
    setPrice(price);
  }

  // Setters
  void setStartBusStop(string startBusStop) {
    this->startBusStop = startBusStop;
  }

  void setEndBusStop(string endBusStop) { this->endBusStop = endBusStop; }

  void setDay(string day) {
    WeekTransformation wt;
    this->day = wt.convertStringToWeek(day);
  }

  void setTime(string time) { this->time = time; }

  void setPrice(string price) { this->price = stod(price); }

  // Getters
  string getStartBusStop() { return startBusStop; }

  string getEndBusStop() { return endBusStop; }

  string getDay() {
    WeekTransformation wt;
    return wt.convertWeekToString(day);
  }

  string getTime() { return time; }

  double getPrice() { return price; }

  string toString() {
    stringstream streamPrice;
    streamPrice << fixed << setprecision(2) << price;
    return startBusStop + " " + endBusStop + " " + getDay() + " " + time + " " +
           streamPrice.str();
  }
};




class BusRouteValidation {
public:
  // validStop()
  // if stop contains only letters and it length is more than 2 -> return true
  // else -> return false
  bool validStop(const string stop) {
    // any_of() - It accepts iterators pointing to the start & end of a string,
    // and a lambda function as arguments. The lambda function checks if the
    // given character is alphabet or not.
    return any_of(stop.begin(), stop.end(),
                  [](char ch) { // lambda function
                    return std::isalpha(ch);
                  }) &&
           stop.length() > 2;
  }

  bool validDay(const string day) {
    try {
      WeekTransformation wt;
      wt.convertStringToWeek(day);
      return true;

    } catch (const string msg) {
      return false;
    }
  }

  bool validTime(const string time) {
    if (time.length() == 5 && isdigit(time[0]) && isdigit(time[1]) &&
        time[2] == ':' && isdigit(time[3]) && isdigit(time[4])) {
      return true;
    }
    return false;
  }

  // if method can convert string price to double -> return true
  // else -> return false
  bool validPrice(const string price) {
    try {
      // attempt to convert
      stod(price);
      return true;
    } catch (...) {
      return false;
    }
  }
};





vector<string> splitWords(const string line) {
  char delimiter = ',';
  vector<string> data;

  stringstream strStream(line); // A stringstream associates a string object with a stream allowing you to read from the string as if it were a stream (like cin).
  string word;

  // size_t - representing the maximum number of bytes to which a pointer can
  // point (similar to int) size_t pos = 0; // position in the vector
  while (getline(strStream, word, delimiter)) {
    data.push_back(word);
  }

  return data;
}

bool dataIsValid(const vector<string> data) {
  BusRouteValidation brv;
  if (data.size() == 5 && brv.validStop(data[0]) && brv.validStop(data[1]) &&
      brv.validDay(data[2]) && brv.validTime(data[3]) &&
      brv.validPrice(data[4])) {
    return true;
  }
  return false;
}

void commandA(const vector<BusRoute> &busRoutes) {
  string startBusStop, endBusStop;
  cin >> startBusStop >> endBusStop;
  cout << "result:" << endl;
  for (auto br : busRoutes) {
    if (br.getStartBusStop() == startBusStop &&
        br.getEndBusStop() == endBusStop) {
      cout << br.toString() << endl;
    }
  }
}

void commandB(const vector<BusRoute> &busRoutes) {
  string day;
  cin >> day;
  cout << "result:" << endl;
  for (auto br : busRoutes) {
    if (br.getDay() == day) {
      cout << br.toString() << endl;
    }
  }
}

void commandC(const vector<BusRoute> &busRoutes) {
  double price;
  while (!(cin >> price)) {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(),
               '\n'); // clear buffer before taking new
    cout << "You have entered wrong input. Please, try again." << endl;
  }

  cout << "result:" << endl;
  for (auto br : busRoutes) {
    if (br.getPrice() <= price) {
      cout << br.toString() << endl;
    }
  }
}

void commandD() {
  cout << "result:" << endl;
  ifstream inFile;
  inFile.open("err.txt");
  if (!inFile) return;

  string line;
  while (getline(inFile, line)) {
    cout << line << endl;
  }

  inFile.close();
}

int main() {
  // read a file with data
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;

  // create a file for errors
  ofstream errFile;
  errFile.open("err.txt");
  if (!errFile)
    return 0;

  string line;
  string invalidLine;
  vector<string> data;
  vector<BusRoute> busRoutes; // array with all valid bus routes

  // reads and processes each line from the file
  // the correct data is pushed to the busRoutes array
  // the wrong data is pushed to the errFile
  while (getline(inFile, line)) {
    invalidLine = line;

    // remove spaces from the line
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

    // if the line is empty read the next line
    if (line.empty()) {
      continue;
    }

    data = splitWords(line);

    // if a data in the line is correct -> create a bus route
    // else -> write the line in the err.txt file
    if (dataIsValid(data)) {
      busRoutes.push_back(
          BusRoute(data[0], data[1], data[2], data[3], data[4]));
    } else {
      errFile << invalidLine << endl;
    }

    data.clear();
  }

  // close files
  errFile.close();
  inFile.close();

  char command;
  while (cin >> command) {
    switch (command) {
    case 'a': {
      commandA(busRoutes);
    }; break;
    case 'b': {
      commandB(busRoutes);
    }; break;
    case 'c': {
      commandC(busRoutes);
    }; break;
    case 'd': {
      commandD();
    }; break;
    case 'e':
      return 0;
    }
  }
}