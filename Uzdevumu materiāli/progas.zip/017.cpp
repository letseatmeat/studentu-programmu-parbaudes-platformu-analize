
#include <fstream>
#include <iostream>
#include <list>
#include <sstream>
#include <string>
#include <algorithm> 

using namespace std;
bool dbug = false;

using MySizeType = size_t;
string trim(const string &str) {
  MySizeType sstart = str.find_first_not_of(' ');
  if (string::npos == sstart) {
    return str;
  }
  MySizeType endd = str.find_last_not_of(' ');
  return str.substr(sstart, (endd - sstart + 1));
}


class BusRoute {
public:
  string start, end, day, time;
  double price;

  BusRoute(string start, string end, string day, string time, double price)
      : start(start), end(end), day(day), time(time), price(price) { }
};

bool dayExists(const string &day) {
  static const list<string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return find(validDays.begin(), validDays.end(), day) != validDays.end();
}

bool timeExists(const string &time) { return time.find(':') != string::npos; }

bool priceExists(const string &price) {
  return price.find('.') != string::npos;
}

bool cellExists(const int count, const string &cell) {
  if (dbug) {
    cout << "Cell " << count << ": " << cell << endl;
  }

  switch (count) {
  case 3: 
    if (!dayExists(trim(cell))) {
      return false;}
    break;
  case 4: 
    if (!timeExists(trim(cell))) {
      return false;}
    break;
  case 5: 
    if (!priceExists(trim(cell))) {
      return false;}
    break;}
  return true;
}

void displayRoute(const BusRoute &route) {
  string order[] = {
      "Start: ", "Final: ", "Day of week: ", "Time: ", "Price: "};

  if (!dbug) {
    for (int i = 0; i < 5; ++i) {
      order[i] = (i == 0 ? "" : " ");
    }
  }

  cout.precision(2);
  cout << order[0] << route.start << order[1] << route.end 
      << order[2] << route.day << order[3] << route.time << order[4] 
      << fixed << route.price << endl;
}

void displayAllRoutes(const list<BusRoute> &routes) {
 
  if (!routes.empty()) {
    for (const auto & route : routes) {
      displayRoute(route);
    }
  } else {
  }
}

void comA(const string &start, const string &end,
              const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto & route : routes) {
    if (route.start == start && route.end == end) {
      displayRoute(route);
    }
  }
}

void comB(const string &day, const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto & route : routes) {
    if (route.day == day) {
      displayRoute(route);
    }
  }
}

void comC(double maxPrice, const list<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto & route : routes) {
    if (route.price <= maxPrice) {
      displayRoute(route);
    }
  }
}

void comD(const list<string> &errors) {
  cout << "result:" << endl;
  bool fFirstLine = true;
  for (const auto & err : errors) {
    if (!fFirstLine) {
      cout << endl;
    }
    fFirstLine = false;
    cout << err;
  }
}


void comDD() {
  cout << "result:" << endl;
  ifstream errFile("err.txt");
  if (errFile.is_open()) {
    string line;
    while (getline(errFile, line)) {
      cout << line << endl;
    }
    errFile.close();
} else {
    cout << "Error!" << endl;
  }
}

int main() {
  bool err = true;
  ofstream errFile("err.txt");
  errFile.close(); 

  ifstream file("db.csv"); 

  if (file.is_open()) { 
    list<BusRoute> routes;
    list<string> errors;

    string line;
    while (getline(file, line)) { 
      line = trim(line); 

      if (line.empty()) {
        continue;}
      if (dbug) {
        cout << "row:" << line << endl << flush;}

      istringstream ss(line);
      string cell;
      int count = 1;
      bool isValid = true;

      while (getline(ss, cell, ',')) { 
        isValid = cellExists(count, cell);
        count++;}

      if (count < 3) {
        continue;}

      if (count != 6 || !isValid) {
        errors.push_back(line);
        ofstream errFile("err.txt", ios::app);
        if (!err) {
          errFile << endl;
        }
        err = false;
        errFile << line;
        errFile.close(); 
      } else { 
        ss.clear(); 
        ss.seekg(0);

        string start, end, day, time;
        double price;

        getline(ss, start, ',');
        getline(ss, end, ',');
        getline(ss, day, ',');
        getline(ss, time, ',');
        ss >> price;

        BusRoute route(trim(start), trim(end), trim(day), trim(time),
                       price);
        routes.push_back(route);
      }
    }

    if (dbug) {
      displayAllRoutes(routes);

      comA("Riga", "Kraslava", routes);
      cout << endl;
      comB("Pt", routes);
      cout << endl;
      comC(5.90, routes);
      cout << endl;
    }

    file.close(); 

    char com;
      string routeStart, routeEnd, day;
      double ticketPrice;

      while (true) {
        cin >> com;
        switch (com) {
          
          case 'a':
            cin >> routeStart >> routeEnd;
            comA(routeStart, routeEnd, routes);
            cout << "result:" << endl;
            break;
          case 'b':
            
            cin >> day;
            comB(day, routes);
            cout << "result:" << endl;
            break;
          case 'c':
            
            cin >> ticketPrice;
            comC(ticketPrice, routes);
            cout << "result:" << endl;
            break;
          case 'd':
            comDD(); 
            break;
          case 'e':
            return 0; 
          default:
            cout << "Try again!" << endl;
            break;
        }
      }

      return 0;
    }
}
