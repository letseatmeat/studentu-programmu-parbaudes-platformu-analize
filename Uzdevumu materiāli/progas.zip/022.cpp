#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

int count = 0;

void commandA(vector<vector<string>> info) {
  string sakums, beigas;
  cin >> sakums;
  cin >> beigas;
  cout << "result:" << endl;
  
  for (auto vec : info) {
    if (vec[0] == sakums && vec[1] == beigas) {
      for (auto str : vec) {
        if (count++ != 4) {
          cout << str << " ";
        } else {
          cout << str;
        }
      }
      cout << endl;
    }
    count = 0;
  }
}

void commandB(vector<vector<string>> info) {
  string diena;
  cin >> diena;
  cout << "result:" << endl;
  for (auto vec : info) {
    if (vec[2] == diena) {
      for (auto str : vec) {
        if (count++ != 4) {
          cout << str << " ";
        } else {
          cout << str;
        }
      }
      cout << endl;
    }
    count = 0;
  }
}

void commandC(vector<vector<string>> info) {
  double cena;
  cin >> cena;
  cout << "result:" << endl;
  for (auto vec : info) {
    if (stod(vec[4]) <= cena) {
      for (auto str : vec) {
        if (count++ != 4) {
          cout << str << " ";
        } else {
          cout << str;
        }
      }
      cout << endl;
    }
    count = 0;
  }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
	if (!inFile) return 0;
  
  string s, content, newS;
  ofstream fileOfErrors("err.txt");
  int countLines = 0;
  vector<vector<string>> info;
  
  while(getline(inFile,content)) {
    vector<string> newContent;
    istringstream stream(content);
    
    while (getline(stream, s, ',')) {
      for (char ch : s) {
        if (ch != ' ') {
          newS.push_back(ch);
        }
      }
      newContent.push_back(newS);
      newS.clear();
    }
    
    if (newContent.size() == 5) {
      if (isdigit(newContent[0][0]) || isdigit(newContent[1][0]) || isdigit(newContent[2][0]) ||     newContent[2].length() != 2 || !isdigit(newContent[3][0]) || newContent[3][2] != ':' || !isdigit(newContent[4][0]) || newContent[4].find('.') == std::string::npos) {
        fileOfErrors << content << endl;
      } else {
        info.push_back(newContent);
        countLines++;
      }
    } else {
      fileOfErrors << content << endl;
    }
  }
  
  inFile.close();
  fileOfErrors.close();

  char command; 
  while (true) {
    cin >> command;
    switch (command) {
      case 'a': {
        commandA(info);
        break;
      }
      case 'b': {
        commandB(info);
        break;
      }
      case 'c': {
        commandC(info);
        break;
      }
      case 'd': {
        cout << "result:" << endl;
        string errContent;
        ifstream outputFile;
        outputFile.open("err.txt");
        if (!outputFile) return 0;
        while (outputFile >> errContent) {
          cout << errContent << endl;
        }
        outputFile.close();
        break;
      }
      case 'e': {
        return 0;
      }
      default: {
        return 0;
      }
    }
  }
} 