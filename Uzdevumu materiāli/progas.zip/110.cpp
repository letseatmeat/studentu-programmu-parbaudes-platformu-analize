

#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <regex>
#include <vector>

using namespace std;

// izvada reisa datus
void printRoute(vector<string> *route) {
  string result;
  for (string value : *route)
    result += value + ' ';
  result.pop_back(); // noņem pēdējo atstarpi, kas ir lieka
  cout << result << endl;
}

// pārbauda vai dati atbilst formātam
bool validateRoute(vector<string> route) {
  if (route.size() != 5)
    return false;
  else {
    if (!regex_match(route[0], regex("[A-Za-z]+")))
      return false;
    if (!regex_match(route[1], regex("[A-Za-z]+")))
      return false;
    if (!regex_match(route[2], regex("[A-Za-z]{2}")))
      return false;
    if (!regex_match(route[3], regex("\\d{2}:\\d{2}")))
      return false;
    if (!regex_match(route[4], regex("^\\d+\\.\\d{2}")))
      return false;
  }
  return true;
}

// a
void findRoutesA(vector<vector<string>> *routes, string *a, string *b) {
  for (vector<string> route : *routes) {
    if (route[0] == *a && route[1] == *b)
      printRoute(&route);
  }
}

// b
void findRoutesB(vector<vector<string>> *routes, string *day) {
  for (vector<string> route : *routes) {
    if (route[2] == *day)
      printRoute(&route);
  }
}

// c
void findRoutesC(vector<vector<string>> *routes, float *price) {
  for (vector<string> route : *routes) {
    float cost = stof(route[4]);
    if (cost <= *price)
      printRoute(&route);
  }
}

// d (izvada err.txt faila saturu)
void printErrors() {
  ifstream inFile;
  inFile.open("err.txt");
  string text, line;
  if (inFile) {
    while (getline(inFile, line))
      text += line + '\n';
    inFile.close();
  }
  cout << text;
}

int main() {
  // atver failu
  ifstream inFile;
  inFile.open("db.csv");

  // pārbauda vai fails tika veiksmīgi atvērts
  if (!inFile)
    return 0;

  // saglabā faila datus vektorā
  vector<vector<string>> routes; // vektors ar maršrutiem
  string line, text, error;
  // iegūst rindu un atbrīvojas no tukšumiem rindas sānos:
  while (getline(inFile >> ws, line)) {

    vector<string> route;
    string value;

    for (char c : line) {
      // pievieno mainīgajam simbolus, kas nav tukšumi: " "
      if (c == ',') {
        route.push_back(value);
        value = "";
        text += ' ';
      } else if (c != ' ') {
        value += c;
        text += c;
      }
    }
    route.push_back(value);

    // error fails
    if (!validateRoute(route)) {
      for (string value : route)
        error += value + ',';
      error.pop_back();
      error += '\n';
    } else
      routes.push_back(route);
  }
  error.pop_back();

  // for (vector<string> route : routes) {
  //   for (string value : route) cout << value << endl;
  //   cout << endl;
  // }

  // aizver failu
  inFile.close();

  // izveido err.txt failu
  ofstream outFile;
  outFile.open("err.txt");
  if (!outFile)
    return 0;
  outFile << error;
  outFile.close();

  // galvenā daļa
  bool loop = true;
  while (loop) {
    // lietotāja ievade:
    char input;
    cin >> input;
    if (cin.fail() || cin.peek() != '\n') { // peek skatās uz nākamo simbolu
      cin.clear();                          // atbrīvojas no kļūdas
      cin.ignore(
          numeric_limits<streamsize>::max()); // ignorē atlikušos simbolus (max:
                                              // gadījumā, ja tika ievadīta
                                              // simbolu virkne)
      continue;
    }

    switch (input) {
      // izvada visus reisus, kas kursē norādītā maršrutā
    case 'a': {
      string a, b;
      cin >> a;
      cin >> b;
      cout << "result:" << endl;
      findRoutesA(&routes, &a, &b);
      break;
    }

    // izvada visus reisus, kas kursē noteiktā nedēļas dienā
    case 'b': {
      string day;
      cin >> day;
      cout << "result:" << endl;
      findRoutesB(&routes, &day);
      break;
    }

      // izvada visus reisus, kuru biļetes maksa nepārsniedz ievadīto
    case 'c': {
      float price;
      cin >> price;
      if (cin.fail()) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max());
      } else {
        cout << "result:" << endl;
        findRoutesC(&routes, &price);
      }
      break;
    }

      // izvada err.txt faila saturu
    case 'd': {
      cout << "result:" << endl;
      printErrors();
      break;
    }

      // pārtrauc programmu
    case 'e':
      loop = false;
    }
  }

  return 0;
}