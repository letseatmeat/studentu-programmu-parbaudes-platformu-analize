
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct RouteOfBus {
  string startOfRoute;
  string endOfRoute;
  string day;
  string time;
  double price;
};

string trim(const string &str) {
  size_t first = str.find_first_not_of(' ');
  if (string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

vector<string> splitString(const string &str, char delimiter) {
  vector<string> tokens;
  stringstream ss(str);
  string token;
  while (getline(ss, token, delimiter)) {
    tokens.push_back(trim(token));
  }
  return tokens;
}

bool isValidDay(const string &day) {
  static const vector<string> validDays = {"Pr", "Ot", "Tr", "Ce",
                                           "Pt", "St", "Sv"};
  return find(validDays.begin(), validDays.end(), day) != validDays.end();
}

bool isValidTime(const string &time) {
  if (time.length() != 5) {
    return false;
  }
  if (time[2] != ':') {
    return false;
  }
  for (size_t i = 0; i < time.length(); ++i) {
    if (i != 2 && !isdigit(time[i])) {
      return false;
    }
  }
  int hours = stoi(time.substr(0, 2));
  int minutes = stoi(time.substr(3, 2));
  return (hours >= 0 && hours <= 23) && (minutes >= 0 && minutes <= 59);
}

bool isValidPrice(const string &price) {
  try {
    double value = stod(price);
    return value >= 0.0;
  } catch (...) {
    return false;
  }
}

RouteOfBus parseRouteOfBus(const string &line) {
  vector<string> fields = splitString(line, ',');
  if (fields.size() == 5) {
    RouteOfBus route;
    route.startOfRoute = fields[0];
    route.endOfRoute = fields[1];
    route.day = fields[2];
    route.time = fields[3];
    if (isValidDay(route.day) && isValidTime(route.time) &&
        isValidPrice(fields[4])) {
      route.price = stod(fields[4]);
      return route;
    }
  }
  throw invalid_argument("Invalid data format");
}

vector<RouteOfBus> parseRouteOfBuss(const string &filename) {
  vector<RouteOfBus> routes;
  ifstream file(filename);

  if (!file.is_open()) {
    cerr << "Error opening file " << filename << endl;
    return routes;
  }

  string line;
  while (getline(file, line)) {
    try {
      RouteOfBus route = parseRouteOfBus(line);
      routes.push_back(route);
    } catch (const invalid_argument &e) {
      ofstream errFile("err.txt", ios::app);
      errFile << line << "\n";
      errFile.close();
    }
  }

  file.close();
  return routes;
}

void displayRoutes(const vector<RouteOfBus> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    cout << route.startOfRoute << " " << route.endOfRoute << " " << route.day
         << " " << route.time << " " << fixed << setprecision(2)
         << route.price << endl;
  }
}

void displayRoutesByStops(const vector<RouteOfBus> &routes, const string &start,
                          const string &end) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.startOfRoute == start && route.endOfRoute == end) {
      cout << route.startOfRoute << " " << route.endOfRoute << " " << route.day
           << " " << route.time << " " << fixed << setprecision(2)
           << route.price << endl;
    }
  }
}

void displayRoutesByDay(const vector<RouteOfBus> &routes, const string &day) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.day == day) {
      cout << route.startOfRoute << " " << route.endOfRoute<< " " << route.day
           << " " << route.time << " " << fixed << setprecision(2)
           << route.price << endl;
    }
  }
}

void displayRoutesByPrice(const vector<RouteOfBus> &routes, double maxPrice) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.price <= maxPrice) {
      cout << route.startOfRoute << " " << route.endOfRoute << " " << route.day
           << " " << route.time << " " << fixed << setprecision(2)
           << route.price << endl;
    }
  }
}

bool isWhitespace(const string &str) {
  return all_of(str.begin(), str.end(),
                [](unsigned char c) { return isspace(c); });
}

void displayErrorFileContent() {
  ifstream errReadFile("err.txt");
  if (errReadFile.is_open()) {
    cout << "result:" << endl;
    string line;
    while (getline(errReadFile, line)) {
      if (!isWhitespace(line)) {
        line.erase(remove(line.begin(), line.end(), '\n'), line.end());
        line.erase(remove(line.begin(), line.end(), '\r'), line.end());
        cout << line << endl;
      }
    }
    errReadFile.close();
  } else {
    cout << "Error opening err.txt" << endl;
  }
}

int main() {

  if (FILE *file = fopen("err.txt", "r")) {
    fclose(file);
    ofstream ofs("err.txt", ios::trunc);
  }

  string filename = "db.csv";
  vector<RouteOfBus> routes = parseRouteOfBuss(filename);

  char choice;
  while (cin >> choice && choice != 'e') {
    switch (choice) {
    case 'a': {
      string start, end;
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      getline(cin, start);
      getline(cin, end);
      displayRoutesByStops(routes, start, end);
      break;
    }
    case 'b': {
      string day;
      cin >> day;
      displayRoutesByDay(routes, day);
      break;
    }
    case 'c': {
      double maxPrice;
      cin >> maxPrice;
      displayRoutesByPrice(routes, maxPrice);
      break;
    }
    case 'd': {
      displayErrorFileContent();
      break;
    }
    default: {
      cout << "Invalid choice. Please enter a valid option." << endl;
      break;
    }
    }
  }

  return 0;
}