
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class reisi {
public:
  string rinda;
  string sakumaPietura;
  string galaPietura;
  string diena;
  string laiks;
  float cena;

  reisi(string rinda) {
    this->rinda = rinda;
    sakumaPietura = rinda.substr(0, rinda.find(" "));
    rinda.erase(0, rinda.find(" ") + 1);
    galaPietura = rinda.substr(0, rinda.find(" "));
    rinda.erase(0, rinda.find(" ") + 1);
    diena = rinda.substr(0, rinda.find(" "));
    rinda.erase(0, rinda.find(" ") + 1);
    laiks = rinda.substr(0, rinda.find(" "));
    rinda.erase(0, rinda.find(" ") + 1);
    cena = stof(rinda);
  }
};

bool parbaudaRindu(string *s) {
  int komatuSk = 0, datuBeiguVieta[5];
  string rindasKopija = *s, pareizaRinda;

  for (int i = 0; i < rindasKopija.length(); i++) {
    if (rindasKopija[i] == ',') {
      datuBeiguVieta[komatuSk] = i;
      komatuSk++;
    }
  }
  if (komatuSk != 4)
    return 0;

  // Sakuma pieturas pārbaude
  for (int i = 0; i < datuBeiguVieta[0]; i++) {
    if (rindasKopija[i] == ' ')
      continue;
    if ((rindasKopija[i] >= 'A' && rindasKopija[i] <= 'Z') ||
        (rindasKopija[i] >= 'a' && rindasKopija[i] <= 'z'))
      pareizaRinda += rindasKopija[i];
    else
      return 0;
  }
  pareizaRinda += ' ';

  // Gala pieturas pārbaude
  for (int i = datuBeiguVieta[0] + 1; i < datuBeiguVieta[1]; i++) {
    if (rindasKopija[i] == ' ')
      continue;
    if ((rindasKopija[i] >= 'A' && rindasKopija[i] <= 'Z') ||
        (rindasKopija[i] >= 'a' && rindasKopija[i] <= 'z'))
      pareizaRinda += rindasKopija[i];
    else
      return 0;
  }
  pareizaRinda += ' ';

  // Dienas pārbaude
  string visasDienas[7] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  for (int i = datuBeiguVieta[1] + 1; i < datuBeiguVieta[2]; i++) {
    if (rindasKopija[i] == ' ')
      continue;
    if ((rindasKopija[i] >= 'A' && rindasKopija[i] <= 'Z') ||
        (rindasKopija[i] >= 'a' && rindasKopija[i] <= 'z')) {
      string dotaDiena = rindasKopija.substr(i, 2);
      for (string diena : visasDienas) {
        if (diena == dotaDiena) {
          pareizaRinda += dotaDiena;
          i++;
          break;
        }
        if (diena == "Sv")
          return 0;
      }
    }
  }
  pareizaRinda += ' ';

  // Laika pārbaude
  for (int i = datuBeiguVieta[2] + 1; i < datuBeiguVieta[3]; i++) {
    if (rindasKopija[i] == ' ')
      continue;
    if (rindasKopija[i] >= '0' && rindasKopija[i] <= '9') {
      string laiks = rindasKopija.substr(i, 5);
      if (laiks[0] >= '0' && laiks[0] <= '2' && laiks[1] >= '0' &&
          laiks[1] <= '9' && laiks[2] == ':' && laiks[3] >= '0' &&
          laiks[3 <= '9'] && laiks[4] >= '0' && laiks[4] <= '9') {
        if (laiks[0] == '2' && laiks[1] > '3')
          return 0;
        if (laiks[3] > '5')
          return 0;
        pareizaRinda += laiks + ' ';
        i += 4;
      }
      break;
    } else
      return 0;
  }

  // Cenas parbaude
  for (int i = datuBeiguVieta[3] + 1; i < rindasKopija.length(); i++) {
    if (rindasKopija[i] == ' ')
      continue;
    if (rindasKopija[i] >= '0' && rindasKopija[i] <= '9') {
      pareizaRinda += rindasKopija[i];
      continue;
    }
    if (rindasKopija[i] == '.' && rindasKopija[i + 1] >= '0' &&
        rindasKopija[i + 1] <= '9' && rindasKopija[i + 2] >= '0' &&
        rindasKopija[i + 2] <= '9') {
      pareizaRinda += rindasKopija[i];
      pareizaRinda += rindasKopija[i + 1];
      pareizaRinda += rindasKopija[i + 2];
      break;
    }

    return 0;
  }
  *s = pareizaRinda;

  return 1;
}

void vaicajumsA(vector<reisi> reisuSaraksts) {
  string sakums, beigas;
  cin >> sakums >> beigas;
  cout << "result:\n";
  for (int i = 0; i < reisuSaraksts.size(); i++) {
    if (reisuSaraksts[i].sakumaPietura == sakums &&
        reisuSaraksts[i].galaPietura == beigas)
      cout << reisuSaraksts[i].rinda << endl;
  }
}

void vaicajumsB(vector<reisi> reisuSaraksts) {
  string diena;
  cin >> diena;
  cout << "result:\n";
  for (int i = 0; i < reisuSaraksts.size(); i++) {
    if (reisuSaraksts[i].diena == diena)
      cout << reisuSaraksts[i].rinda << endl;
  }
}

void vaicajumsC(vector<reisi> reisuSaraksts) {
  float cena;
  cin >> cena;
  cout << "result:\n";
  for (int i = 0; i < reisuSaraksts.size(); i++) {
    if (reisuSaraksts[i].cena <= cena)
      cout << reisuSaraksts[i].rinda << endl;
  }
}

void vaicajumsD() {
  cout << "result:\n";
  ifstream inFile;
  inFile.open("err.txt");
  if (!inFile) {
    cout << "Fails nav atrasts" << endl;
    return;
  }
  string s;
  while (inFile >> s)
    cout << s << endl;
  inFile.close();
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  ofstream outFile;
  outFile.open("err.txt");
  if (!outFile)
    cout << "Kļūda err.txt izveidē\n";

  vector<reisi> reisuSaraksts;
  string s;
  bool vaiPareizs;
  while (getline(inFile, s)) {
    if (s == "" || s == "\r")
      continue;
    vaiPareizs = parbaudaRindu(&s);
    if (vaiPareizs) {
      // cout << s << endl;
      reisuSaraksts.push_back(reisi(s));
    } else
      outFile << s;
  }
  inFile.close();
  outFile.close();

  string izvele;
  while (true) {
    cin >> izvele;
    if (izvele == "a") {
      vaicajumsA(reisuSaraksts);
      continue;
    }
    if (izvele == "b") {
      vaicajumsB(reisuSaraksts);
      continue;
    }
    if (izvele == "c") {
      vaicajumsC(reisuSaraksts);
      continue;
    }
    if (izvele == "d") {
      vaicajumsD();
      continue;
    }
    if (izvele == "e")
      return 0;
    cout << "Ievadiet a, b, c, d vai e.\n";
  }
}