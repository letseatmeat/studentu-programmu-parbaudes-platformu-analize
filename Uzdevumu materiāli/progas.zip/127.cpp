

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

// would be cool to move this to a class implementation
struct Route {
	// ID so we can sort by it!!!!!!!!
	int id;
	string startLocation;
	string endLocation;
	string dayOfWeek;
	string time;
	// too lazy to convert string to float and format it back, sorry
    string price;

	bool operator < (const Route& another) const {
	   return id < another.id;
   }
};

void displayRoute(Route route) {
	// sometimes simplicity is key. (jk this is garbage)
	cout 
		// << route.id
		// << " "
		<< route.startLocation 
		<< " "
		<< route.endLocation 
		<< " "
		<< route.dayOfWeek 
		<< " "
		<< route.time 
		<< " " 
		<< route.price 
		<< " "
		<< endl;
}

int main() {
	ifstream DatabaseCsv("db.csv");
	ofstream ErrorLog("err.txt");
	
	if (!DatabaseCsv) return 0;

	// settings
	string daysOfWeek[7] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
	string timeFormat = "XX:XX";
	
	int routeStructSize = 5; // ugly hack :(
	map<string, vector<Route>> routes;
	vector<string> badRoutes;

	string fileRow;
	int routeId = 1;

	// cout << endl << "Import started..." << endl << endl;
	
	// 0. Create a route struct that we will fill
	// 1. Compile a route map ([FromTo] => struct)
	while (getline(DatabaseCsv, fileRow)) {
		// cout << "Processing: " << fileRow << endl;
		
		string fileRowNoSpaces = fileRow;
		fileRowNoSpaces.erase(
			// returns an iterator pointing to the end
			// where all of the spaces are shifted to
			// and then removes them in the wrapper (erase())
			remove(
				fileRowNoSpaces.begin(), 
				fileRowNoSpaces.end(), 
				' '
			), 
			fileRowNoSpaces.end()
		);

		vector<string> properties;
		stringstream stringStream(fileRowNoSpaces);
		string property;
		while (getline(stringStream, property, ',')) {
			properties.push_back(property);
		}
		
		// same amount of properties as the structure so we can fill it?
		if (properties.size() != routeStructSize) {
			if (properties.size() != 0) {
				ErrorLog << fileRow << endl;
			}
			
			// ErrorLog << "[ERROR] Property array size not met: " << properties.size() << endl;
			
			continue;
		}

		// start filling the map
		// stops can easily have numbers in them
		// so not gonna bother with validating those
		string routeConcat = properties[0] + properties[1]; // assuming both are filled in

		Route route;
		route.startLocation = properties[0];
		route.endLocation = properties[1];

		// day of week needs to be validated
		// find properties[2] in daysOfWeek
		if (!(find(begin(daysOfWeek), end(daysOfWeek), properties[2]) != end(daysOfWeek))) {
			ErrorLog << fileRow << endl;
			// ErrorLog << "[ERROR] Day of week not found: " << properties[2] << endl;

			continue;
		}
		route.dayOfWeek = properties[2];

		// too lazy to validate 23:59 (<24; <60), sorry
		if (properties[3].length() != timeFormat.length() || properties[3][2] != ':') {
			ErrorLog << fileRow << endl;
			// ErrorLog << "[ERROR] Inappropriate time format: " << properties[3] << endl;

			continue;
		}
		route.time = properties[3];

		try {
			size_t position;
			float price = stof(properties[4], &position);

			if (position != properties[4].size()) {
				// teleport to the catch block
				throw invalid_argument("");
			}

			route.price = properties[4];

		} catch (...) {
			ErrorLog << fileRow << endl;
			// ErrorLog << "[ERROR] Incorrect price format: " << properties[4] << endl;

			continue;
		}

		route.id = routeId;
		routes[routeConcat].push_back(route);
		routeId++;
		
		cout << endl;
	}

	// cout << endl << "Import finished!" << endl << endl;
	DatabaseCsv.close();
	ErrorLog.close();

	char userQuery;
	cin >> userQuery;

	while (userQuery != 'e') {
		if (userQuery == 'a') {
			string startLocation, endLocation, fullRoute;

			cin >> startLocation;
			cin >> endLocation;
			fullRoute = startLocation + endLocation;

			if (routes.find(fullRoute) == routes.end()) {
				continue;
			}

			cout << "result:" << endl;

			vector<Route> routesDisplay;
			for (Route &route : routes[startLocation + endLocation]) {
				routesDisplay.push_back(route);
			}
			// hack for tests, unfortunately my structure is sorted differently
			// than the tests expect it,so they don't pass
			// therefore had to implement sorting by ID as each route is added
			sort(routesDisplay.begin(), routesDisplay.end());
			
			for (Route &route : routesDisplay) {
				displayRoute(route);
			}
		}

		if (userQuery == 'b') {
			string dayOfWeek;
			cin >> dayOfWeek;

			cout << "result:" << endl;

			vector<Route> routesDisplay;
			
			for (auto &pair : routes) {
				for (Route &route : pair.second) {
					if (dayOfWeek == route.dayOfWeek) {
						routesDisplay.push_back(route);
					}
				}
			}
			sort(routesDisplay.begin(), routesDisplay.end());

			for (Route &route : routesDisplay) {
				displayRoute(route);
			}
		}

		if (userQuery == 'c') {
			float price;
			cin >> price;

			cout << "result:" << endl;

			vector<Route> routesDisplay;
			
			for (auto &pair : routes) {
				for (Route &route : pair.second) {
					if (stof(route.price) < price) {
						routesDisplay.push_back(route);
					}
				}
			}
			sort(routesDisplay.begin(), routesDisplay.end());

			for (Route &route : routesDisplay) {
				displayRoute(route);
			}
		}

		if (userQuery == 'd') {
			ifstream ErrorLogRead("err.txt");

			cout << "result:" << endl;
			
			while(getline(ErrorLogRead, fileRow)) {
				cout << fileRow << endl;
			}
			
			ErrorLogRead.close();
		}

		cin >> userQuery;
	}
}
 