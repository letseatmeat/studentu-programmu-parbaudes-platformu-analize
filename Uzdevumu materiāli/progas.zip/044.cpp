
#include <algorithm>
#include <fstream>
#include <iostream>
#include <locale>
#include <sstream>
#include <vector>

using namespace std;

struct Route {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};

vector<string> splitString(const string &line, char delimiter) {
  vector<string> tokens;
  stringstream ss(line);
  string token;
  while (getline(ss, token, delimiter)) {
    tokens.push_back(token);
  }
  return tokens;
}

Route parseRoute(const string &line) {
  Route route;
  vector<string> tokens = splitString(line, ',');

  if (tokens.size() == 5) {
    route.startStop = tokens[0];
    route.endStop = tokens[1];
    route.dayOfWeek = tokens[2];
    route.time = tokens[3];

    char *endptr;
    route.ticketPrice = strtod(tokens[4].c_str(), &endptr);

    if (*endptr != '\0') {
      route = Route();
    }
  } else {
    route = Route();
  }

  return route;
}
void printRoute(const Route &route) {
  if (!route.startStop.empty()) {
    cout.imbue(std::locale("C"));
    printf("%s %s %s %s %.2f\n", route.startStop.c_str(), route.endStop.c_str(),
           route.dayOfWeek.c_str(), route.time.c_str(), route.ticketPrice);
  }
}

int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

  if (!inFile || !errFile) {
    cerr << "Error opening files." << endl;
    return 1;
  }

  vector<Route> routes;
  string line;

  while (getline(inFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

    Route route = parseRoute(line);
    if (route.startStop.empty()) {
      errFile << line << endl; 
      continue;
    }

    routes.push_back(route);
  }
  char choice;
  while (true) {
    printf("Izvēlieties darbību (a, b, c, d, e): ");
    cin >> choice;

    switch (choice) {
    case 'a': {
      cin.ignore();
      string startStop, endStop;
      printf("Ievadiet sākuma un gala pieturas nosaukumus: ");
      getline(cin, startStop);
      getline(cin, endStop);

      printf("result:\n");
      for (const auto &route : routes) {
        if (route.startStop == startStop && route.endStop == endStop) {
          printRoute(route);
        }
      }
      break;
    }
    case 'b': {
      string dayOfWeek;
      printf(
          "Ievadiet nedēļas dienas apzīmējumu (Pr, Ot, Tr, Ce, Pt, St, Sv): ");
      cin >> dayOfWeek;

      printf("result:\n");
      for (const auto &route : routes) {
        if (route.dayOfWeek == dayOfWeek) {
          printRoute(route);
        }
      }
      break;
    }
    case 'c': {
      double maxPrice;
      printf("Ievadiet maksimālo biļetes cenu: ");
      cin >> maxPrice;

      printf("result:\n");
      for (const auto &route : routes) {
        if (route.ticketPrice <= maxPrice) {
          printRoute(route);
        }
      }
      break;
    }
    case 'd': {
      ifstream errFileIn("err.txt");
      if (errFileIn.is_open()) {
        printf("result:\n");
        string errLine;
        bool foundErrors = false;

        while (getline(errFileIn, errLine)) {
          if (errLine.find_first_not_of(" \t\v\r\n") != string::npos) {
            cout << errLine << endl;
            foundErrors = true; 
          }
        }

        if (!foundErrors) {
          cout << "No errors found." << endl;
        }

        errFileIn.close(); // Close the file after reading
      } else {
        cerr << "Error opening err.txt." << endl;
      }
      break;
    }

    case 'e':
      return 0;
    default:
      printf("Nepareiza darbības izvēle.\n");
    }
  }

  return 0;
}
