

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct Route {
  string start;
  string destination;
  string day;
  string time;
  string cost;
};

enum actions { A, B, C, D, E };

// Trimming whitespaces from the beginning and the end of the string
string trim(string &s) {
  string newString = "";
  for (int i = 0; i < s.length(); i++) {
    if (s[i] != ' ') {
      newString += s[i];
    }
  }
  return newString;
}

// To lower case method, used to ignore capital letters
string toLowerCase(string str) {
  string lowerCasedString = str;
  transform(lowerCasedString.begin(), lowerCasedString.end(),
            lowerCasedString.begin(), ::tolower);
  return lowerCasedString;
}

// Fetching data from database (CSV)
void fetchData(vector<Route> &routes, vector<string> &err) {
  string last;
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return;

  string line;
  while (getline(inFile, line)) {
    if (line.empty()) {
      continue;
    }
    line = trim(line);

    // Use istringstream to parse the comma-separated values in the line
    istringstream ss(line);
    Route route;

    // Extract values for route attributes
    getline(ss, route.start, ',');
    getline(ss, route.destination, ',');
    getline(ss, route.day, ',');
    getline(ss, route.time, ',');
    getline(ss, route.cost, ',');

    // Check if there are more than 5 fields
    if (getline(ss, last, ',')) {
      err.push_back(line);
      continue;
    }

    if (!route.start.empty() && !route.destination.empty() &&
        !route.day.empty() && !route.time.empty() && !route.cost.empty() &&
        none_of(route.start.begin(), route.start.end(), ::isdigit) &&
        none_of(route.destination.begin(), route.destination.end(),
                ::isdigit) &&
        none_of(route.day.begin(), route.day.end(), ::isdigit)) {
      routes.push_back(route);
    } else {
      err.push_back(line);
    }
  }

  inFile.close();
}

// Printing the routes as a result
void print(vector<Route> routes) {
  cout << "result:" << endl;
  for (Route route : routes) {
    cout << route.start << " " << route.destination << " " << route.day << " "
         << route.time << " " << route.cost << endl;
  }
}

// Printing the errors as a result
void print(const vector<string> &err) {
  cout << "result:" << endl;
  for (string error : err) {
    // Check if the string contains only whitespace characters
    if (!all_of(error.begin(), error.end(), ::isspace)) {
      cout << error << endl;
    }
  }
}

// Method for finding the routes by starting point and end point
vector<Route> findByRoute(vector<Route> &routes) {
  vector<Route> filteredRoutes;
  string start, destination;
  // cout << "Enter starting point: " << endl;
  cin >> start;
  // cout << "Enter destination point: " << endl;
  cin >> destination;
  for (Route route : routes) {
    if (toLowerCase(route.start) == toLowerCase(start) &&
        toLowerCase(route.destination) == toLowerCase(destination))
      filteredRoutes.push_back(route);
  }

  return filteredRoutes;
}

// Method for finding the routes by day
vector<Route> findByDay(vector<Route> &routes) {
  vector<Route> filteredRoutes;
  string day;
  // cout << "Enter day: " << endl;
  cin >> day;
  for (Route route : routes) {
    if (toLowerCase(route.day) == toLowerCase(day))
      filteredRoutes.push_back(route);
  }

  return filteredRoutes;
}

// Method for finding the routes by maximum price
vector<Route> findByPrice(vector<Route> &routes) {
  vector<Route> filteredRoutes;
  int price;
  // cout << "Enter maximum price: " << endl;
  cin >> price;

  if (cin.fail()) {
    // cout << "Invalid input. Please enter a valid integer." << std::endl;
    cin.clear();
    cin.ignore(256, '\n');
  } else {
    // cout << "You entered: " << price << endl;
  }

  for (Route route : routes) {
    if (stoi(route.cost) <= price)
      filteredRoutes.push_back(route);
  }

  return filteredRoutes;
}

// User Interface
void userInterface(vector<Route> &routes, vector<string> err) {
  while (true) {
    string action = "a";
    actions userAction;
    // cout << "Enter action: " << endl;
    cin >> action;

    if (action == "a") {
      userAction = A;
      print(findByRoute(routes));
    } else if (action == "b") {
      print(findByDay(routes));
      userAction = B;
    } else if (action == "c") {
      print(findByPrice(routes));
      userAction = C;
    } else if (action == "d") {
      print(err);
      userAction = D;
    } else {
      return;
    }
  }
}

int main() {
  vector<Route> routes;
  vector<string> err;

  fetchData(routes, err);
  userInterface(routes, err);
}
