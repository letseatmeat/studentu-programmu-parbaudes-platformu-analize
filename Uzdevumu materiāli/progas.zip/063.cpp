#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>
#include <vector>

struct BusRoute {
  std::string startStop;
  std::string endStop;
  std::string dayOfWeek;
  std::string time;
  double ticketPrice;
};

// Validate if the time is in the format HH:MM
bool isValidTime(const std::string &time) {
  std::regex word_regex("[0-9]{2}:[0-9]{2}");
  if (!std::regex_match(time, word_regex)) {
    return false;
  }

  return true;
}

// Validate if the price is number
bool isValidPrice(const std::string &price) {
  std::regex word_regex("[0-9]+(\\.[0-9]+)?");
  if (!std::regex_match(price, word_regex)) {
    return false;
  }

  return true;
}

// Validate if the day of the week is valid
bool isValidDayOfWeek(const std::string &day) {
  std::regex word_regex("Pr|Ot|Tr|Ce|Pt|St|Sv");
  if (!std::regex_match(day, word_regex)) {
    return false;
  }

  return true;
}

// Delete spaces from the beginning and the end of the string
std::string trimSpaces(std::string &str) {
  str.erase(0, str.find_first_not_of(' '));
  str.erase(str.find_last_not_of(' ') + 1);

  return str;
}

void printBusRoute(const BusRoute &route) {
  // print price with 2 decimal places always
  std::cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek
            << " " << route.time << " " << std::setprecision(2) << std::fixed
            << route.ticketPrice << std::endl;
}

void printErrorFile() {
  std::ifstream file("err.txt");
  std::string line;
  while (std::getline(file, line)) {
    std::cout << line << std::endl;
  }
}

void filterByPrice(std::vector<BusRoute> &routes, double price) {
  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].ticketPrice <= price) {
      printBusRoute(routes[i]);
    }
  }
}

void filterByDayOfWeek(std::vector<BusRoute> &routes, std::string day) {
  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].dayOfWeek == day) {
      printBusRoute(routes[i]);
    }
  }
}

void filterByRoute(std::vector<BusRoute> &routes, std::string startStop,
                   std::string endStop) {
  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].startStop == startStop && routes[i].endStop == endStop) {
      printBusRoute(routes[i]);
    }
  }
}

// Process the bus routes from the file
std::vector<BusRoute> processBusRoutes(const std::string &filename) {
  std::ifstream file(filename);
  std::ofstream errorFile("err.txt");
  std::vector<BusRoute> routes;

  if (file.is_open()) {
    std::string line;
    while (std::getline(file, line)) {
      std::stringstream ss(line);
      std::vector<std::string> tokens;
      std::string token;

      while (std::getline(ss, token, ',')) {
        tokens.push_back(token);
      }

      if (tokens.size() == 5) {
        BusRoute route;
        route.startStop = trimSpaces(tokens[0]);
        route.endStop = trimSpaces(tokens[1]);
        route.dayOfWeek = trimSpaces(tokens[2]);
        route.time = trimSpaces(tokens[3]);
        route.ticketPrice = std::stod(trimSpaces(tokens[4]));

        if (isValidTime(route.time) && isValidPrice(tokens[4]) &&
            isValidDayOfWeek(route.dayOfWeek)) {
          routes.push_back(route);

        } else {
          errorFile << line << "\n";
        }
      } else {
        if (tokens.size() > 0) {
          errorFile << line << "\n";
        }
      }
    }

    file.close();
    errorFile.close();
  } else {
    std::cerr << "Unable to open file: " << filename << std::endl;
  }

  return routes;
}

int main() {
  std::vector<BusRoute> routes = processBusRoutes("db.csv");
  while (true) {
    std::string letter;
    std::cin >> letter;

    switch (letter[0]) {
    case 'a': {
      std::string startStop;
      std::string endStop;
      std::cin >> startStop;
      std::cin >> endStop;

      std::cout << "result: " << std::endl;
      filterByRoute(routes, startStop, endStop);
      break;
    }
    case 'b': {
      std::string day;
      std::cin >> day;
      if (!isValidDayOfWeek(day)) {
        std::cout << "Invalid day of week" << std::endl;
        break;
      }

      std::cout << "result: " << std::endl;
      filterByDayOfWeek(routes, day);
      break;
    }
    case 'c': {
      double price;
      std::cin >> price;

      std::cout << "result: " << std::endl;
      filterByPrice(routes, price);
      break;
    }
    case 'd':
      std::cout << "result: " << std::endl;
      printErrorFile();
      break;
    case 'e':
      return 0;
    }
  }

  return 0;
}
