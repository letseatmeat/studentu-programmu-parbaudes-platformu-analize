
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

// Structure to hold trip information
struct Trip {
  std::string start;
  std::string end;
  std::string day;
  std::string time;
  double price;
};

// Function to read trip data from a file and populate a vector of Trip structures
void readFile(const std::string &filename, std::vector<Trip> &trips, std::ofstream &errorFile) {
  std::ifstream file(filename);
  if (!file.is_open()) {
    std::cerr << "Error opening file: " << filename << std::endl;
    exit(1);
  }

  std::string line;
  while (std::getline(file, line)) {
    // Remove extra spaces from the line
    line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line.empty()) {
      continue;
    }

    // Split the line into tokens using comma as delimiter
    std::istringstream iss(line);
    std::vector<std::string> tokens;
    std::string token;
    while (std::getline(iss, token, ',')) {
      tokens.push_back(token);
    }

    // Check if the line has the correct number of tokens (5)
    if (tokens.size() != 5) {
      errorFile << line << std::endl;
      continue;
    }

    // Create a Trip object and populate it
    Trip trip;
    trip.start = tokens[0];
    trip.end = tokens[1];
    trip.day = tokens[2];
    trip.time = tokens[3];

    // Convert price from string to double and handle conversion errors
    try {
      size_t pos;
      trip.price = std::stod(tokens[4], &pos);
      if (pos != tokens[4].size()) {
        throw std::invalid_argument("Invalid price format");
      }
    } catch (...) {
      errorFile << line << std::endl;
      continue;
    }

    trips.push_back(trip);
  }
}

// Function to print all trips
void printTrips(const std::vector<Trip> &trips) {
  for (const auto &trip : trips) {
    std::cout << trip.start << " " << trip.end << " " << trip.day << " " << trip.time << " " << std::fixed << std::setprecision(2)
              << trip.price << std::endl;
  }
}

int main() {
  std::vector<Trip> trips;
  std::ofstream errorFile("errors.txt");

  // Read trip data from file
  readFile("db.csv", trips, errorFile);

  // User command processing loop
  char command;
  while (true) {
    std::cout << " ";
    std::cin >> command;

    switch (command) {
      case 'a': { // Search and display trips by start and end locations
        std::string start, end;
        std::cout << "result: "<< std::endl;
        std::cin >> start >> end;

        for (const auto &trip : trips) {
          if (trip.start == start && trip.end == end) {
            std::cout << trip.start << " " << trip.end << " " << trip.day
                      << " " << trip.time << " " << std::fixed
                      << std::setprecision(2) << trip.price << std::endl;
          }
        }
        break;
      }
      case 'b': { // Search and display trips by day
        std::string day;
        std::cout << "result: "<< std::endl;
        std::cin >> day;

        for (const auto &trip : trips) {
          if (trip.day == day) {
            std::cout << trip.start << " " << trip.end << " " << trip.day
                      << " " << trip.time << " " << std::fixed
                      << std::setprecision(2) << trip.price << std::endl;
          }
        }
        break;
      }
      case 'c': { // Search and display trips by maximum price
        double maxPrice;
        std::cout << "result: "<< std::endl;
        std::cin >> maxPrice;

        for (const auto &trip : trips) {
          if (trip.price <= maxPrice) {
            std::cout << trip.start << " " << trip.end << " " << trip.day
                      << " " << trip.time << " " << std::fixed
                      << std::setprecision(2) << trip.price << std::endl;
          }
        }
        break;
      }
      case 'd': { // Display error log
        std::ifstream errorFileIn("errors.txt");
        std::cout << "result: "<< std::endl;
        std::cout << errorFileIn.rdbuf();
        break;
      }
      case 'e': { // Exit the program
        std::cout << " "<< std::endl;
        return 0;
      }
      default: {
        std::cout << "Invalid command "<< std::endl;
      }
    }
  }

  return 0;
}
