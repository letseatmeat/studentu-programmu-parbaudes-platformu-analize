

#include <cctype>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printcommandarr(char arr[100][20], char arr2[100][20], char arr3[100][20],
                     char arr4[100][20], char arr5[100][20], int j) {

  for (int i = 0; i < 20; i++) {
    if (arr[j][i] != ' ' && arr[j][i] != '\0' && arr5[j][i] != '\n' &&
        arr5[j][i] != '\r') {
      printf("%c", arr[j][i]);
    }
  }
  printf("%c", ' ');
  for (int i = 0; i < 20; i++) {
    if (arr2[j][i] != ' ' && arr2[j][i] != '\0' && arr5[j][i] != '\n' &&
        arr5[j][i] != '\r') {
      printf("%c", arr2[j][i]);
    }
  }
  printf("%c", ' ');
  for (int i = 0; i < 20; i++) {
    if (arr3[j][i] != ' ' && arr3[j][i] != '\0' && arr5[j][i] != '\n' &&
        arr5[j][i] != '\r') {
      printf("%c", arr3[j][i]);
    }
  }
  printf("%c", ' ');
  for (int i = 0; i < 20; i++) {
    if (arr4[j][i] != ' ' && arr4[j][i] != '\0' && arr5[j][i] != '\n' &&
        arr5[j][i] != '\r') {
      printf("%c", arr4[j][i]);
    }
  }
  printf("%c", ' ');
  for (int i = 0; i < 20; i++) {
    if (arr5[j][i] != ' ' && arr5[j][i] != '\0' && arr5[j][i] != '\n' &&
        arr5[j][i] != '\r') {
      printf("%c", arr5[j][i]);
    }
  }
  printf("%s", "\n");
}

void printdiena(char arr[100][20], char arr2[100][20], char arr3[100][20],
                char arr4[100][20], char arr5[100][20]) {
  char arrned[3];

  scanf("%s", &arrned);
  for (int j = 0; j < 20; j++) {

    if (arr3[j][0] == arrned[0]) {
      if (arr3[j][1] == arrned[1]) {
        printcommandarr(arr, arr2, arr3, arr4, arr5, j);
      }
    }
  }
}

void printcity(char arr[100][20], char arr2[100][20], char arr3[100][20],
               char arr4[100][20], char arr5[100][20]) {
  int can = 0;
  int len = 0;
  char arrno[100];
  char arruz[100];

  scanf("%s", &arrno);
  scanf("%s", &arruz);

  for (int j = 0; j < 20; j++) {
    can = 0;
    len = 0;
    for (int i = 0; i < 20; i++) {
      if (arr[j][i] == arrno[i] && arr[j][i] != 0) {
        can++;
      }
      if (arr[j][i] != 0) {
        len++;
      }
    }
    if (can == len) {
      for (int i = 0; i < 20; i++) {
        if (arr2[j][i] == arruz[i] && arr2[j][i] != 0) {
          can++;
        }
        if (arr2[j][i] != 0) {
          len++;
        }
      }
      if (can == len && len != 0) {
        printcommandarr(arr, arr2, arr3, arr4, arr5, j);
      }
    }
  }
}

void printcena(char arr[100][20], char arr2[100][20], char arr3[100][20],
               char arr4[100][20], char arr5[100][20]) {
  char cena[100];
  scanf("%99s", cena);
  auto lencena = 1;
  float resultcena = atof(cena);
  printf("%s", "result:\n");
  for (int j = 0; j < 20; j++) {

    float result = atof(arr5[j]);
    if (result != 0.0 && result <= resultcena) {
      printcommandarr(arr, arr2, arr3, arr4, arr5, j);
    }
  }
}

int main() {

  FILE *fptr;
  FILE *fptr2;

  // PART 1: PREPARING ARRAYS

  if ((fptr = fopen("db.csv", "r")) != 0) {

    if ((fptr2 = fopen("err.txt", "w")) != 0) {
      fprintf(fptr2, "%s", "result:\n");
      char sakpiet[100][20] = {};
      char galpiet[100][20] = {};
      char neddiena[100][20] = {};
      char laiks[100][20] = {};
      char bilcena[100][20] = {};

      char myString[100];
      int j = 0;

      int shiftline = 1;

      while (fgets(myString, 100, fptr)) {
        

        j++;
        auto g = strlen(myString);
        if (g > 0 && myString[g - 1] == '\r') {
            myString[g - 1] = 'h';
        }
        int distributechar = 0;
        int shiftspace = 0;
        int linelen = 0;
        int linelenreal = 0;
        int prevlen = 0;
        int nas = 0;
        for (int i = 0; i < g; i++) {

          char c;
          c = myString[i];
          linelen++;

          if (true) {
            {
              if (c == ',') {

                distributechar++;
                prevlen = linelenreal;
              } else if (c == '\r') {

              } else if (c == '\n') {
                if (nas) {
                  for (int i = 0; i < g; i++) {
                    sakpiet[j - shiftline][i] = 0;
                    galpiet[j - shiftline][i] = 0;
                    neddiena[j - shiftline][i] = 0;
                    laiks[j - shiftline][i] = 0;
                    bilcena[j - shiftline][i] = 0;
                  }
                }
                nas = 0;
                if (linelen == shiftspace || linelen < 10) {
                  shiftline++;
                }
                if (distributechar != 4 && distributechar != 0) {
                  // printf("%s", myString);
                  for (int i = 0; i < g; i++) {
                    sakpiet[j - shiftline][i] = 0;
                    galpiet[j - shiftline][i] = 0;
                    neddiena[j - shiftline][i] = 0;
                    laiks[j - shiftline][i] = 0;
                    bilcena[j - shiftline][i] = 0;
                  }
                  for (int i = 0; myString[i] != '\0'; i++) {
                      if (myString[i] != '\r' ) {
                          fprintf(fptr2, "%c", myString[i]);
                      }
                  }
                }
                distributechar = 0;
              } else if (c == ' ') {
                shiftspace++;
              } else {
                linelenreal++;
                char temp0, temp1, temp2, temp3, temp4;
                switch (distributechar) {
                case 0:
                  sakpiet[j - shiftline][i - shiftspace] = c;
                  if (!(std::isalpha(c)) && !nas && c != '\r') {
                    // printf("%s", myString);
                    for (int i = 0; myString[i] != '\0'; i++) {
                        if (myString[i] != '\r' ) {
                            fprintf(fptr2, "%c", myString[i]);
                        }
                    }
                    nas++;
                  }
                  break;
                case 1:
                  galpiet[j - shiftline][i - shiftspace - prevlen - 1] = c;

                  if (!(std::isalpha(c)) && !nas && c != '\r') {
                    // printf("%s", myString);
                    for (int i = 0; myString[i] != '\0'; i++) {
                        if (myString[i] != '\r' ) {
                            fprintf(fptr2, "%c", myString[i]);
                        }
                    }
                    nas++;
                  }
                  break;
                case 2:
                  neddiena[j - shiftline][i - shiftspace - prevlen - 2] = c;
                  if (!(std::isalpha(c)) && !nas && c != '\r') {
                    // printf("%s", myString);
                    for (int i = 0; myString[i] != '\0'; i++) {
                        if (myString[i] != '\r' ) {
                            fprintf(fptr2, "%c", myString[i]);
                        }
                    }
                    nas++;
                  }
                  break;
                case 3:
                  laiks[j - shiftline][i - shiftspace - prevlen - 3] = c;
                  if ((std::isalpha(c)) && c != ':' && !nas && c != '\r') {
                    // printf("%s", myString);
                    for (int i = 0; myString[i] != '\0'; i++) {
                        if (myString[i] != '\r') {
                            fprintf(fptr2, "%c", myString[i]);
                        }
                    }
                    nas++;
                  }
                  break;
                case 4:
                  bilcena[j - shiftline][i - shiftspace - prevlen - 4] = c;
                  if ((std::isalpha(c)) && c != '.' && !nas && c != '\r') {
                    // printf("%s", myString);
                    for (int i = 0; myString[i] != '\0'; i++) {
                        if (myString[i] != '\r') {
                            fprintf(fptr2, "%c", myString[i]);
                        }
                    }
                    nas++;
                  }
                  break;
                default:
                  c = c;
                  break;
                }
              }
            }
          }
        }
      }
      fclose(fptr);
      fclose(fptr2);

      // PART 2: COMMAND LOOP

      bool n = 1;
      while (n) {
        char command;
        scanf("%c", &command);
        switch (command) {
        case 'a':
          printf("%s", "result:\n");
          printcity(sakpiet, galpiet, neddiena, laiks, bilcena);
          break;
        case 'b':
          printf("%s", "result:\n");
          printdiena(sakpiet, galpiet, neddiena, laiks, bilcena);
          break;
        case 'c':

          printcena(sakpiet, galpiet, neddiena, laiks, bilcena);
          break;
        case 'd':
          // printf("%s", "result:\n");
          FILE *fptr5;

          if ((fptr5 = fopen("err.txt", "r")) != 0) {
            char myString2[100];

            while (fgets(myString2, 100, fptr5)) {
              printf("%s", myString2);
            }
          }
          break;
        case 'e':
          n = 0;
          break;
        default:
          break;
        }
      }
    }
  }
}