#include <iomanip>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

using namespace std;



struct Route
{
  string departureCity;
  string destinationCity;
  string departureDay;
  string departureTime;
  double ticketPrice;
};

vector<Route> routes;
map<string, vector<Route>> routePlan;
map<string, vector<Route>> dayRoutes;

string removeEmpty(const string &str)
{
  size_t first = str.find_first_not_of(' ');
  if (string::npos == first)
    return "";
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

void load(const string &fileName)
{
  ifstream inFile(fileName);
  string line;
  ofstream errFile("err.txt", ios::trunc);

  while (getline(inFile, line))
  {
    line = removeEmpty(line);
    if (line.empty())
      continue;

    stringstream ss(line);
    Route route;
    string token;
    vector<string> tokens;

    while (getline(ss, token, ','))
      tokens.push_back(removeEmpty(token));

    if (tokens.size() != 5)
    {
      continue;
    }

    route.departureCity = tokens[0];
    route.destinationCity = tokens[1];
    route.departureDay = tokens[2];
    route.departureTime = tokens[3];

    if (route.departureTime.find(':') == string::npos)
    {
      continue;
    }

    try
    {
      route.ticketPrice = stod(tokens[4]);
    }
    catch (...)
    {
      errFile << line << "\n";
      continue;
    }
    routes.push_back(route);
    routePlan[route.departureCity + " " + route.destinationCity].push_back(route);
    dayRoutes[route.departureDay].push_back(route);
  }
}

void printResult(const vector<Route> &routes)
{
  for (const auto &route : routes)
    cout << route.departureCity << " " << route.destinationCity << " " << route.departureDay << " " << route.departureTime << " " << fixed << setprecision(2) << route.ticketPrice << endl;
}

void inputA()
{
  string departureCity, end;
  cin >> departureCity >> end;
  cout << "result:" << endl;
  printResult(routePlan[departureCity + " " + end]);
}

void inputB()
{
  string departureDay;
  cin >> departureDay;
  cout << "result:" << endl;
  printResult(dayRoutes[departureDay]);
}

void inputC()
{
  double ticketPrice;
  cin >> ticketPrice;
  cout << "result:" << endl;
  for (const auto &route : routes)
  {
    if (route.ticketPrice <= ticketPrice)
      cout << route.departureCity << " " << route.destinationCity << " " << route.departureDay << " " << route.departureTime << " " << fixed << setprecision(2) << route.ticketPrice << endl;
  }
}

void inputD()
{
  ifstream errFile("err.txt");
  string line;
  cout << "result:" << endl;
  while (getline(errFile, line))
    cout << removeEmpty(line) << endl;
}

int main()
{
  ofstream errFile("err.txt", ios::trunc);
  errFile.close();
  load("db.csv");
  char query;
  while (true)
  {
    cin >> query;
    switch (query)
    {
    case 'a':
      inputA();
      break;
    case 'b':
      inputB();
      break;
    case 'c':
      inputC();
      break;
    case 'd':
      inputD();
      break;
    case 'e':
      return 0;
    }
  }
}
