

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <limits>
#include <map>

using namespace std;

vector<string> splitString(const string &line) {
    vector<string> result;
    stringstream ss(line);
    string item;

    while (getline(ss, item, ',')) {
        // Trim leading and trailing whitespaces from each item
        item.erase(item.begin(), find_if(item.begin(), item.end(), [](char ch) {
            return !isspace(ch);
        }));
        item.erase(find_if(item.rbegin(), item.rend(), [](char ch) {
            return !isspace(ch);
        }).base(), item.end());

        result.push_back(item);
    }

    return result;
}

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    string ticketPriceStr; // Include the decimal point
    double ticketPrice;
};

vector<BusRoute> readBusRoutesFromFile(const string &fileName) {
    vector<BusRoute> routes;
    ifstream inFile(fileName);

    if (!inFile) {
        cerr << "Error opening file: " << fileName << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    ofstream errFile("err.txt", ios::out);

    while (getline(inFile, line)) {
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

        if (line.empty()) {
            continue;
        }

        vector<string> tokens = splitString(line);

        if (tokens.size() != 5) {
            errFile << line << endl;
            continue;
        }

        BusRoute route;
        route.startStop = tokens[0];
        route.endStop = tokens[1];
        route.dayOfWeek = tokens[2];
        route.time = tokens[3];
        route.ticketPriceStr = tokens[4];

        if (route.startStop.empty() || route.endStop.empty() || route.dayOfWeek.empty() || route.time.empty() || route.ticketPriceStr.empty() || route.time.size() != 5 || route.time[2] != ':') {
            errFile << line << endl;
            continue;
        }

        try {
            route.ticketPrice = stod(route.ticketPriceStr);
            routes.push_back(route);
        } catch (const invalid_argument &e) {
            errFile << "Invalid ticket price: " << route.ticketPriceStr << endl;
        } catch (const out_of_range &e) {
            errFile << "Ticket price out of range" << endl;
        }
    }

    return routes;
}

void printBusRoutes(const vector<string> &result) {
    cout << "result:" << endl;
    for (const auto &res : result) {
        cout << res << endl;
    }
}

int main() {
    vector<BusRoute> routes = readBusRoutesFromFile("db.csv");

    char choice;
    vector<string> result; // accumulate results

    do {
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        bool hasNewResults = false;

        switch (choice) {
        case 'a': {
            string start, end;
            cin >> start >> end;

            for (const auto &route : routes) {
                if (route.startStop == start && route.endStop == end) {
                    // Use stringstream for formatting
                    stringstream formattedResult;
                    formattedResult << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " <<
                        fixed << setprecision(2) << route.ticketPrice;
                    result.push_back(formattedResult.str());

                    hasNewResults = true;
                }
            }
            break;
        }
        case 'b': {
            string day;
            cin >> day;

            for (const auto &route : routes) {
                if (route.dayOfWeek == day) {
                    // Use stringstream for formatting
                    stringstream formattedResult;
                    formattedResult << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " <<
                        fixed << setprecision(2) << route.ticketPrice;
                    result.push_back(formattedResult.str());

                    hasNewResults = true;
                }
            }
            break;
        }
          case 'c': {
              double maxPrice;
              cin >> maxPrice;

              // Use a map to store unique routes and their positions
              map<string, bool> uniqueRoutes;

              for (size_t i = 0; i < routes.size(); ++i) {
                  const auto &route = routes[i];
                  if (route.ticketPrice <= maxPrice) {
                      // Use stringstream for formatting
                      stringstream formattedResult;
                      formattedResult << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " <<
                          fixed << setprecision(2) << route.ticketPrice;

                      // Insert the formatted route into the map if it's not already there
                      if (!uniqueRoutes[formattedResult.str()]) {
                          result.push_back(formattedResult.str());
                          uniqueRoutes[formattedResult.str()] = true;
                          hasNewResults = true;
                      }
                  }
              }

              break;
          }

        case 'd': {
            ifstream errFileIn("err.txt");
            if (errFileIn.is_open()) {
                string errLine;
                while (getline(errFileIn, errLine)) {
                    result.push_back(errLine);
                }
                errFileIn.close();
                hasNewResults = true;
            }
            break;
        }
        case 'e':
            break;
        default:
            cout << "Invalid command." << endl;
        }

        if (hasNewResults) {
            printBusRoutes(result);
            result.clear();
        }

    } while (choice != 'e');

    return 0;
}
