

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

struct List {
    string startStop;
    string endStop;
    string day;
    string time;
    double ticketPrice;
};

void parseCSVLine(const string& line, List& list) {
    istringstream ss(line);
    getline(ss, list.startStop, ',');
    getline(ss, list.endStop, ',');
    getline(ss, list.day, ',');
    getline(ss, list.time, ',');
    ss >> list.ticketPrice;
}

void printRoute(const List& list) {
    cout << list.startStop << " " << list.endStop << " " << list.day << " " << list.time << " " << fixed << setprecision(2) << list.ticketPrice << endl;
}

int main() {
    vector<List> lists;
    ifstream file("db.csv");
    ofstream errorFile("err.txt");

    if (!file.is_open()) {
        return 1;
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) {
            continue; 
        }

      List list;
        parseCSVLine(line, list);

        if (list.startStop.empty() || list.endStop.empty() || list.day.empty() || list.time.empty() || list.ticketPrice <= 0.0) {
            errorFile << line << endl;
            continue; 
        }

          lists.push_back(list);
    }

    char choice;
    do {
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start >> end;

                cout << "result:" << endl;
                for (const auto& route : lists) {
                    if (route.startStop == start && route.endStop == end) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'b': {
                string day;
                cin >> day;

                cout << "result:" << endl;
                for (const auto& route : lists) {
                    if (route.day == day) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cin >> maxPrice;
                cout << "result:" << endl;
                for (const auto& route : lists) {
                    if (route.ticketPrice <= maxPrice) {
                        printRoute(route);
                    }
                }
                break;
            }
            case 'd': {
                ifstream errFile("err.txt");
                if (errFile.is_open()) {
                    cout << "result:" << endl;
                    string errLine;
                    while (getline(errFile, errLine)) {
                        cout << errLine << endl;
                    }
                    errFile.close();
                }
                break;
            }
            case 'e':
                break;
        }

    } while (choice != 'e');

    return 0;
}
