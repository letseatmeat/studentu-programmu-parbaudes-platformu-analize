#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

void printRouteDetails();				
void printDaySchedule(); 				
void printTicketsBelowPrice(); 	
void printErrorFile();					


int main() {

	char choice;
	while(true) {
		cin >> choice;
		switch(choice) {
			case 'a': printRouteDetails(); break;
			case 'b': printDaySchedule(); break;
			case 'c': printTicketsBelowPrice(); break;
			case 'd': printErrorFile(); break;
			case 'e': return 0;
		}
	}  
} 

void printRouteDetails() {
	ifstream inFile("db.csv");
	string input1, input2, line;
	cin >> input1 >> input2;
	cout << "result:" << endl;

	if (!inFile) {
			cerr << "Error opening file!" << endl;
			return;
	}

	
	while (getline(inFile, line)) {
		vector<string> tokens;
		string token;
		line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
		if (line.empty()) {
				continue;
		}

		

		// Sadalit line vectora ar tokeniem, kuri ir atdalīti ar komu
		istringstream ss(line);
		while (getline(ss, token, ',')) {
				tokens.push_back(token);
		}

		if (tokens.size() == 5) {
				if (tokens[0].empty() || tokens[1].empty() || tokens[2].empty() || tokens[3].empty() || tokens[4].empty()) {
						continue;
				}

				if (tokens[3].length() != 5 || tokens[3][2] != ':' || tokens[4].find_first_of('.') == string::npos) {
						continue;
				}
			
				string cityFrom = tokens[0];
				string cityTo = tokens[1];
				string day = tokens[2];
				string departureTime = tokens[3];
				double price;
				
				try {
						price = stod(tokens[4]);
				} catch (const invalid_argument& e) {
						cerr << "Error: Invalid price value." << endl;
						continue;
				}

				
			if (cityFrom == input1 && cityTo == input2) {
				cout << cityFrom << " " << cityTo << " " << day << " " << departureTime << " ";
				printf("%.2f\n", price);
			}
		} 
	}

	inFile.close();
}

void printDaySchedule() {

	ifstream inFile("db.csv");
	string inputDay;
	cin >> inputDay;
	cout << "result:" << endl;

	if (!inFile) {
			cerr << "Error opening file!" << endl;
			return;
	}

	string line;
	while (getline(inFile, line)) {
		
		line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
		if (line.empty()) {
				continue;
		}

		vector<string> tokens;
		string token;
		istringstream ss(line);
		while (getline(ss, token, ',')) {
				tokens.push_back(token);
		}

		
		if (tokens.size() == 5) {
			
			if (tokens[0].empty() || tokens[1].empty() || tokens[2].empty() || tokens[3].empty() || tokens[4].empty()) {
				continue;
			}

			if (tokens[3].length() != 5 || tokens[3][2] != ':' || tokens[4].find_first_of('.') == string::npos) {
				continue;
			}


			string cityFrom = tokens[0];
			string cityTo = tokens[1];
			string day = tokens[2];
			string departureTime = tokens[3];
			double price;
			
			try {
				price = stod(tokens[4]);
			} 
			catch (const invalid_argument& e) {
				cerr << "Error: Invalid price value." << endl;
				continue;
			}

			if(day == inputDay) {
				cout << cityFrom << " " << cityTo << " " << day << " " << departureTime << " ";
				printf("%.2f\n", price);
			}
		} 
	}
	inFile.close();
}

void printTicketsBelowPrice() {
	ifstream inFile("db.csv");
	double inputPrice;
	cin >> inputPrice;
	cout << "result:" << endl;

	if (!inFile) {
			cerr << "Error opening file!" << endl;
			return;
	}

	string line;
	while (getline(inFile, line)) {
	
		line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
		if (line.empty()) {
			continue;
		}

		vector<string> tokens;
		string token;
		istringstream ss(line);
		while (getline(ss, token, ',')) {
			tokens.push_back(token);
		}

		if (tokens.size() == 5) {
			if (tokens[0].empty() || tokens[1].empty() || tokens[2].empty() || tokens[3].empty() || tokens[4].empty()) {
				continue;
			}

			if (tokens[3].length() != 5 || tokens[3][2] != ':' || tokens[4].find_first_of('.') == string::npos) {
				continue;
			}


			string cityFrom = tokens[0];
			string cityTo = tokens[1];
			string day = tokens[2];
			string departureTime = tokens[3];
			double price;
			
			try {
				price = stod(tokens[4]);
			} 
			catch (const invalid_argument& e) {
				cerr << "Error: Invalid price value." << endl;
				continue;
			}

			if (price <= inputPrice) {
				cout << cityFrom << " " << cityTo << " " << day << " " << departureTime << " ";
				printf("%.2f\n", price);
			}
		} 
	}
	inFile.close();
}

void printErrorFile() {
	set<int> errorLines;

	cout << "result:" << endl;
	ifstream inFile("db.csv");

	if (!inFile) {
			cerr << "Error opening file!" << endl;
			return;
	}

	string line;
	int count = 1;
	while (getline(inFile, line)) {
		
		line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
		
		if (line.empty()) {
				count++;
				continue;
		}

		vector<string> tokens;
		string token;

		istringstream ss(line);
		while (getline(ss, token, ',')) {
				tokens.push_back(token);
		}

		
		if (tokens.size() != 5) {
			errorLines.insert(count);
		}
		else if (tokens[3].length() != 5 || tokens[3][2] != ':' || tokens[4].find_first_of('.') == string::npos) {
			errorLines.insert(count);
	}
		count++;
	}

	inFile.clear(); 
	inFile.seekg(0, ios::beg);
	


	count = 1;
  ofstream errorFile("err.txt");
  if (errorFile.is_open()) {
    while (getline(inFile, line)) {
      if(errorLines.find(count) == errorLines.end()) {
        count++;
        continue;
      }
      line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

      errorFile << line << endl;
      cout << line << endl;
      count++;
    }
    errorFile.close();
  } 
	inFile.close();
}
