
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Autobusamarsruts {
  string Marsrutasakums;
  string Marsrutabeigas;
  string diena;
  string laiks;
  double cena;
};

string trim(const string &str) {
  size_t first = str.find_first_not_of(' ');
  if (string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

vector<string> splitString(const string &str, char delimiter) {
  vector<string> tokens;
  stringstream ss(str);
  string token;
  while (getline(ss, token, delimiter)) {
    tokens.push_back(trim(token));
  }
  return tokens;
}

bool isValiddiena(const string &diena) {
  static const vector<string> validdienas = {"Pr", "Ot", "Tr", "Ce",
                                           "Pt", "St", "Sv"};
  return find(validdienas.begin(), validdienas.end(), diena) != validdienas.end();
}

bool isValidlaiks(const string &laiks) {
  if (laiks.length() != 5) {
    return false;
  }
  if (laiks[2] != ':') {
    return false;
  }
  for (size_t i = 0; i < laiks.length(); ++i) {
    if (i != 2 && !isdigit(laiks[i])) {
      return false;
    }
  }
  int hours = stoi(laiks.substr(0, 2));
  int minutes = stoi(laiks.substr(3, 2));
  return (hours >= 0 && hours <= 23) && (minutes >= 0 && minutes <= 59);
}

bool isValidcena(const string &cena) {
  try {
    double value = stod(cena);
    return value >= 0.0;
  } catch (...) {
    return false;
  }
}

Autobusamarsruts parseAutobusamarsruts(const string &line) {
  vector<string> fields = splitString(line, ',');
  if (fields.size() == 5) {
    Autobusamarsruts route;
    route.Marsrutasakums = fields[0];
    route.Marsrutabeigas = fields[1];
    route.diena = fields[2];
    route.laiks = fields[3];
    if (isValiddiena(route.diena) && isValidlaiks(route.laiks) &&
        isValidcena(fields[4])) {
      route.cena = stod(fields[4]);
      return route;
    }
  }
  throw invalid_argument("Invalid data format");
}

vector<Autobusamarsruts> parseAutobusamarsrutss(const string &filename) {
  vector<Autobusamarsruts> routes;
  ifstream file(filename);

  if (!file.is_open()) {
    cerr << "Error opening file " << filename << endl;
    return routes;
  }

  string line;
  while (getline(file, line)) {
    try {
      Autobusamarsruts route = parseAutobusamarsruts(line);
      routes.push_back(route);
    } catch (const invalid_argument &e) {
      ofstream errFile("err.txt", ios::app);
      errFile << line << "\n";
      errFile.close();
    }
  }

  file.close();
  return routes;
}

void displayRoutes(const vector<Autobusamarsruts> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    cout << route.Marsrutasakums << " " << route.Marsrutabeigas << " " << route.diena
         << " " << route.laiks << " " << fixed << setprecision(2)
         << route.cena << endl;
  }
}

void displayRoutesByStops(const vector<Autobusamarsruts> &routes, const string &start,
                          const string &end) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.Marsrutasakums == start && route.Marsrutabeigas == end) {
      cout << route.Marsrutasakums << " " << route.Marsrutabeigas << " " << route.diena
           << " " << route.laiks << " " << fixed << setprecision(2)
           << route.cena << endl;
    }
  }
}

void displayRoutesBydiena(const vector<Autobusamarsruts> &routes, const string &diena) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.diena == diena) {
      cout << route.Marsrutasakums << " " << route.Marsrutabeigas<< " " << route.diena
           << " " << route.laiks << " " << fixed << setprecision(2)
           << route.cena << endl;
    }
  }
}

void displayRoutesBycena(const vector<Autobusamarsruts> &routes, double maxcena) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.cena <= maxcena) {
      cout << route.Marsrutasakums << " " << route.Marsrutabeigas << " " << route.diena
           << " " << route.laiks << " " << fixed << setprecision(2)
           << route.cena << endl;
    }
  }
}

bool isWhitespace(const string &str) {
  return all_of(str.begin(), str.end(),
                [](unsigned char c) { return isspace(c); });
}

void displayErrorFileContent() {
  ifstream errReadFile("err.txt");
  if (errReadFile.is_open()) {
    cout << "result:" << endl;
    string line;
    while (getline(errReadFile, line)) {
      if (!isWhitespace(line)) {
        line.erase(remove(line.begin(), line.end(), '\n'), line.end());
        line.erase(remove(line.begin(), line.end(), '\r'), line.end());
        cout << line << endl;
      }
    }
    errReadFile.close();
  } else {
    cout << "Error opening err.txt" << endl;
  }
}

int main() {

  if (FILE *file = fopen("err.txt", "r")) {
    fclose(file);
    ofstream ofs("err.txt", ios::trunc);
  }

  string filename = "db.csv";
  vector<Autobusamarsruts> routes = parseAutobusamarsrutss(filename);

  char choice;
  while (cin >> choice && choice != 'e') {
    switch (choice) {
    case 'a': {
      string start, end;
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      getline(cin, start);
      getline(cin, end);
      displayRoutesByStops(routes, start, end);
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      displayRoutesBydiena(routes, diena);
      break;
    }
    case 'c': {
      double maxcena;
      cin >> maxcena;
      displayRoutesBycena(routes, maxcena);
      break;
    }
    case 'd': {
      displayErrorFileContent();
      break;
    }
    default: {
      cout << "Invalid choice. Please enter a valid option." << endl;
      break;
    }
    }
  }

  return 0;
}