
#include <iostream>
#include <fstream>
#include<sstream>
#include<vector>
#include<cctype> 
#include<regex>
using namespace std;
void a(const vector<vector<string>>& data);
void b(const vector<vector<string>>& data);
void c(const vector<vector<string>>& data);
void d(const string& fileName);
bool isValiddata(const vector<string>& row);
void cleaned(const string& input, vector<string>& tokens);


void a (const vector<vector<string>>& data){
  string sakuma, gala;
  cin>>sakuma;
  cin>>gala;
  cout<<"result:"<<endl;
  for(const auto& row : data){
    if(row.size() >= 2 && row[0] == sakuma && row[1] == gala){
      for(const auto& element : row){
        cout << element << " ";
     }
     cout << endl; 
    } 
  }
}
void b (const vector<vector<string>>& data){
  string diena;
  cin>>diena;
  
  cout<<"result:"<<endl;
  for(const auto& row : data){
    if( row[2] == diena ){
      for(const auto& element : row){
        cout << element << " ";
     }
     cout << endl; 
    } 
  }
}
void c (const vector<vector<string>>& data){
  double cena;
  cin>>cena;

  cout<<"result:"<<endl;
  for(const auto& row : data){
    if(std::stod(row[4]) <= cena ){
      for(const auto& element : row){
        cout << element << " ";
     }
     cout << endl; 
    } 
  }
}

void d(const string& fileName){
  ifstream file(fileName);
  cout<< "result:" << endl;
 string line;
    while (getline(file, line)){
      cout << line << endl;
    }

    file.close();
}
bool isValiddata(const vector<string>& row){
  if(row.size() != 5){ //vai ir piecas pozīcijas
    return false;
  }
  if(row[2].length() != 2 || !all_of(row[2].begin(),row[2].end(), ::isalpha)){//vai ir 2 burti
    return false;
  }
  regex timeFormat("\\d{2}:\\d{2}"); //vai ir laika formats
  if(!regex_match(row[3], timeFormat )){
    return false;
  }
  regex priceFormat("\\d+\\.\\d{2}"); //cenas formats
  if(!regex_match(row[4], priceFormat)){
    return false;
  
  }
  return true;
}
void cleaned(const string& input, vector<string>& tokens){//atbrivojas no liekasm atstarpem
  stringstream ss(input);
  string token;
  while(getline(ss, token, ',')){
    string cleanToken;
    for(char c : token){
      if(!isspace(c)){
        cleanToken +=c;
        
      }
    }
    tokens.push_back(cleanToken);
    
  }
  
}

int main() {
  
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  ofstream errFile("err.txt");
  
  vector<vector<string>>data;
  
  string line;
  while (getline(inFile,line)){
    //if(line.empty()) continue;
    vector<string>row; // saglabā vārdus no rindas
    cleaned(line,row);

    if(all_of(row.begin(), row.end(), [](const string& element){
      return element.find_first_not_of(' ') == string::npos;})){
      continue; // tuksas rindas izlaiz
      }
    

    if (isValiddata(row)){
      data.push_back(row); //rinda tiek pievienota vektoram
    }else{// ja neatbilst tad ieraksta faila
      errFile<< line<< endl;
        
    }

  }
  inFile.close();
  errFile.close();
  
  

	
  char input;
  
  while (true){
    cin >> input;

    switch(input){
      case 'a':
        a(data);
        break;
      case 'b':
        b(data);
        break;
      case 'c':
        c(data);
        break;
      case 'd':
        d("err.txt");
        break;
      case 'e':
        exit(0);
      
    } 
  
  }
  
  return 0;
} 