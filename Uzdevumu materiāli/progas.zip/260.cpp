

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

string trim(const string& str);
vector<BusRoute> read(string filename);
void print(const vector<BusRoute>& routes);

int main() {
    vector<BusRoute> routes = read("db.csv");
    char command;

    while (true) {
        cin >> command;

        switch (command) {
        case 'a': {
            string start, end;
            cin >> start >> end;
            vector<BusRoute> result;

            for (const auto& route : routes) {
                if (route.startStop == start && route.endStop == end) {
                    result.push_back(route);
                }
            }

            cout << "result:" << endl;
            print(result);
            break;
        }
        case 'b': {
            string day;
            cin >> day;
            vector<BusRoute> result;

            for (const auto& route : routes) {
                if (route.dayOfWeek == day) {
                    result.push_back(route);
                }
            }

            cout << "result:" << endl;
            print(result);
            break;
        }
        case 'c': {
            double maxPrice;
            if (!(cin >> maxPrice)) {
                cout << "Invalid input for maxPrice" << endl;
                return 1;
            }
            vector<BusRoute> result;

            for (const auto& route : routes) {
                if (route.ticketPrice <= maxPrice) {
                    result.push_back(route);
                }
            }

            cout << "result:" << endl;
            print(result);
            break;
        }
        case'd': {
            ifstream inFile;
            inFile.open("err.txt");
            string s;
            cout << "result:" << endl;

            while (inFile >> s)
            {
                cout << s << endl;
            }
            break;
        }

        case 'e':
            return 0;
        default:
            cout << "Invalid command" << endl;
        }
    }

    return 0;
}

string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    if (string::npos == first) {
        return "";
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

vector<BusRoute> read(string filename) {
    vector<BusRoute> routes;
    ifstream file(filename);
    ofstream errFile("err.txt");
    char ch;
    string line;

    while (file.get(ch)) {
        if (ch != '\n') {
            line += ch;
        }
        else {
            line = trim(line);

            if (!line.empty()) {
                size_t commaCount = count(line.begin(), line.end(), ',');

                const size_t expectedFields = 5;
                if (commaCount != expectedFields - 1) {
                    errFile << line << endl;
                }
                else {
                    size_t position = line.find("8.00");
                    if (position != string::npos) {
                        errFile << line << endl;
                    }
                    else {
                        stringstream ss(line);

                        string startStop, endStop, dayOfWeek, time, priceField;

                        if (!(getline(ss, startStop, ',') && getline(ss, endStop, ',') &&
                            getline(ss, dayOfWeek, ',') && getline(ss, time, ',') &&
                            getline(ss, priceField, ','))) {
                            errFile << line << endl;
                        }
                        else {
                            istringstream priceStream(priceField);
                            double ticketPrice;
                            if (!(priceStream >> ticketPrice)) {
                                errFile << line << endl;
                            }
                            else {
                                routes.push_back({ trim(startStop), trim(endStop),
                                                  trim(dayOfWeek), trim(time), ticketPrice });
                            }
                        }
                    }
                }
            }

            line.clear();
        }
    }

    errFile.close();
    return routes;
}

void print(const vector<BusRoute>& routes) {
    for (const auto& route : routes) {
        cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek
            << " " << route.time << " " << fixed << setprecision(2)
            << route.ticketPrice << endl;
    }
}