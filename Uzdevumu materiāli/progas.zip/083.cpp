
#include <cctype>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;
void check(ifstream &inFile, vector<int> &nav_ok) {
  ofstream errfile("err.txt");
  string arr[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  string s, parbaude, parbaude2;
  int x = -1, a = 0, b, komats = 3, komats_daudz;
  bool linija_error = false;
  while (getline(inFile, s)) {

    x++;
    b = 0;
    a = 0;
    komats = 3;
    komats_daudz = 0;
    linija_error = false;
    // cout << "Processing line: " << s<< endl;
    for (int i = 0; i < s.length(); i++) { // atnem atstarpes lai vieglak
                                           // stradat
      if (s[i] != ' ') {
        parbaude += s[i];
      }
      if (s[i] == ',') {
        komats_daudz++;
        //cout << komats_daudz << " komats" << endl;
      }
    }
    if (parbaude.length() == 1) {
      // cout<<parbaude<<" error nav linija!!!!!!"<<endl;
      nav_ok.push_back(x);
    } else if (komats_daudz != 4) {
      linija_error = true;
      // cout<<"error nav komatu!!!!!!"<<endl;
    }

    s = parbaude;
    //cout << s << endl;
    parbaude.clear();
    for (int i = 0; i < s.length(); i++) {
      if (linija_error) {
        // cout<<"Error Line!!!"<<endl;
        nav_ok.push_back(x);
        errfile << s << endl;
        break;
      }
      // cout << "Processing character: " << s[i] << endl;
      if (b < 2) {
        if (s[i] == ',') { // parbauda pirmos divas pieturas
          parbaude = s.substr(a, i - a);
          // cout<<parbaude<<" parbaude pie"<<i<<endl;
          for (char c : parbaude) {
            if (isalpha(c)) { // parbauda vai tekstā ir tikai burti
              break;
            } else {
              linija_error = true;
            }
          }
          // cout<<" CIK SLIKTI IR "<<linija_error<<endl;
          b++;
          a = i + 1;
          parbaude.clear();
        }

      } else if (s[i] == ',') { // parbauda Dienas
        // parbaude.clear();
        if (komats == 3) {
          parbaude = s.substr(a, i - a);
          linija_error = true;
          // cout<<parbaude<<" pec 3komata"<<endl;
          for (int j = 0; j < sizeof(arr) / sizeof(arr[0]); j++) {
            if (parbaude == arr[j]) {
              // cout<<"Dienas MATCH "<<parbaude<<"=="<<arr[j]<<endl;
              linija_error = false;
              break;
            }
          }
          parbaude.clear();
          a = i + 1;
          komats++;
        } else if (komats == 4) { // parbauda Laiku
          parbaude = s.substr(a, i - a);
          int sk=0;
          for (char c : parbaude) {
            sk++;
            if (isdigit(c)) {
              continue;
            } else if (c == ':') {
              continue;
            } else if(sk>5) {
              linija_error = true;
              break;
            }else{
              linija_error = true;
              break;
            }
          }

          // cout<<parbaude<<" 4.komats"<<endl;
          parbaude.clear();
          komats++;
          a = i + 1;
        }

      } else if (komats == 5) { /// Parbauda cenu
        parbaude = s.substr(a, s.length() - a - 1);
        for (char c : parbaude) {
          if (isdigit(c)) {
            continue;
          } else if (c == '.') {
            continue;
          } else {
            linija_error = true;
            break;
          }
        }
        // cout<<parbaude<<"pēc 4. komats"<<endl;
        parbaude.clear();
        komats++;
      }
    }
  }
  inFile.close();
}
string tiritajs(string str){//notīra string no komatiem un atstarpēm
  str.erase(remove(str.begin(), str.end(), ' '), str.end());
  for (char &ch : str) {
    if (ch == ',') {
        ch = ' ';
    }
  }
  return str;
}

void pieturas(string sakums, string beigas, vector<int> nav_ok, ifstream &inFile) {
    string s;
    int a = 0;
    cout<<"result:"<<endl;
    while (getline(inFile, s)) {
        if (find(nav_ok.begin(), nav_ok.end(), a) == nav_ok.end()) {
            //cout << "Processing line: " << s<< endl;
            stringstream ss(s);
            string dala,prints;
            vector<string> tokens;
            prints.clear();
            while (getline(ss, dala, ',')) {
              //cout << "Processing line: " << dala<< endl;
                tokens.push_back(dala);
            }

            if (tokens.size() >= 2) { // Check if there are at least two elements
                string pirmais = tokens[0];
                string otrais = tokens[1];

                pirmais.erase(0, pirmais.find_first_not_of(" "));
                pirmais.erase(pirmais.find_last_not_of(" ") + 1);
                otrais.erase(0, otrais.find_first_not_of(" "));
                otrais.erase(otrais.find_last_not_of(" ") + 1);
                
                
                if (pirmais == sakums && otrais == beigas) {
                    prints=tiritajs(s);
                    cout<<prints<<endl;
                }
            }
        }
        a++;
    }
  inFile.close();
}
void dienas(string diena, vector<int> nav_ok, ifstream &inFile) {
  string s;
    int a = 0;
    cout<<"result:"<<endl;
    while (getline(inFile, s)) {
        if (find(nav_ok.begin(), nav_ok.end(), a) == nav_ok.end()) {
            //cout << "Processing line: " << s<< endl;
            stringstream ss(s);
            string dala,prints;
            vector<string> tokens;
            prints.clear();
            while (getline(ss, dala, ',')) {
              //cout << "Processing line: " << dala<< endl;
                tokens.push_back(dala);
            }
              string tresais=tokens[2];
              tresais.erase(0, tresais.find_first_not_of(" "));
              tresais.erase(tresais.find_last_not_of(" ")+1);
                if (tresais==diena) {
                  prints=tiritajs(s);
                  cout<<prints<<endl;
                }
            
        }
        a++;
    }
  inFile.close();
}
void cena(double cena, vector<int> nav_ok, ifstream &inFile) {
  string s;
    int a = 0;
    cout<<"result:"<<endl;
    while (getline(inFile, s)) {
        if (find(nav_ok.begin(), nav_ok.end(), a) == nav_ok.end()) {
            //cout << "Processing line: " << s<< endl;
            stringstream ss(s);
            string dala,prints;
            vector<string> tokens;
            prints.clear();
            while (getline(ss, dala, ',')) {
              //cout << "Processing line: " << dala<< endl;
                tokens.push_back(dala);
            }
              string piekt=tokens[4];
              piekt.erase(0, piekt.find_first_not_of(" "));
              piekt.erase(piekt.find_last_not_of(" ")+1);
              double num =stod(piekt);
                if (num<=cena) {
                  prints=tiritajs(s);
                  cout<<prints<<endl;
                }

        }
        a++;
    }
  inFile.close();

  
}
int main() {
  ifstream inFile,errFile;
  inFile.open("db.csv");
  vector<int> nav_ok;
  if (!inFile)
    return 0;
  check(inFile, nav_ok);
  //for (int value : nav_ok) {
    //cout << "Linijas kuras izlaist" << value + 1 << endl;
  //}
  //cout << endl;

  while (true) {
    string komanda;
    cin >> komanda;
    if (komanda == "e") {
      break;
    }
    switch (komanda[0]) {
    case 'a': {
      string sakums, beigas;
      cin >> sakums >> beigas;
      //cout << sakums << " " << beigas << endl;
      inFile.open("db.csv");
      if (!inFile)
        return 0;
      pieturas(sakums, beigas,nav_ok,inFile);
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      inFile.open("db.csv");
      if (!inFile)
          return 0;
      dienas(diena,nav_ok,inFile);
      break;
    }
    case 'c': {
      string cen;
      cin >> cen;
      double cen_num=stod(cen);
      inFile.open("db.csv");
      if (!inFile)
          return 0;
      cena(cen_num,nav_ok,inFile);
      break;
    }
    case 'd': {
      string str;
      cout<<"result:"<<endl;
      errFile.open("err.txt");
      if (!errFile)
        return 0;
      while (getline(errFile, str)) {
        cout << str << endl;
      }
      break;
    }
    }
  }
}