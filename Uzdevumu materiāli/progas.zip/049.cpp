
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Route {
    string from;
    string to;
    string day;
    string time;
    double price;
};

string clearSpaces(const string& str) {
    string result = str;
    result.erase(remove_if(result.begin(), result.end(), ::isspace), result.end());
    return result;
}

void clearErrorFile(const string& filename) {
    ofstream clearErrFile(filename, ios::trunc);
    clearErrFile.close();
}

vector<string> split(const string & line, char delimiter) {
    vector<string> tokens;
    stringstream ss(line);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

vector<Route> readDataFromFile(const string& filename) {
    vector<Route> routes;
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            if (!line.empty() && line.find_first_not_of(' ') != string::npos) {
                vector<string> tokens = split(line, ',');
                if (tokens.size() == 5) {
                    Route route;

                    route.from = clearSpaces(tokens[0]);
                    route.to = clearSpaces(tokens[1]);
                    route.day = clearSpaces(tokens[2]);
                    route.time = clearSpaces(tokens[3]);

                    try {
                        route.price = stod(clearSpaces(tokens[4]));

                        if (route.day != "Pr" && route.day != "Ot" && route.day != "Tr" && route.day != "Ce" && route.day != "Pt" && route.day != "St" && route.day != "Sv") {
                        throw invalid_argument("Invalid day");
                        }

                        if (route.time.length() != 5 || route.time[2] != ':' || !isdigit(route.time[0]) || !isdigit(route.time[1]) || !isdigit(route.time[3]) || !isdigit(route.time[4])) {
                        throw invalid_argument("Invalid time format");
                        }
                      
                    } catch (const invalid_argument& e) {
                        ofstream errFile("err.txt", ios::app);
                        errFile << clearSpaces(line) << endl;
                        errFile.close();
                        continue;
                    }

                      routes.push_back(route);
                } else {
                    ofstream errFile("err.txt", ios::app);
                    errFile << clearSpaces(line) << endl;
                    errFile.close();
                }
            }
        }
        file.close();
    } else {
        cout << "Error" << filename << endl;
    }
    return routes;
}

void displayRoutes(const vector<Route>& routes, const string& from, const string& to) {
    for (const Route& route : routes) {
        if (route.from == from && route.to == to) {
            cout << left << route.from + " " + route.to + " " + route.day + " " + route.time + " ";
            printf("%.2f", route.price);
            cout << endl;
        }
    }
}

void displayRoutesByDay(const vector<Route>& routes, const string& day) {
    for (const Route& route : routes) {
        if (route.day == day) {
            cout << left << route.from + " " + route.to + " " + route.day + " " + route.time + " ";
            printf("%.2f", route.price);
            cout << endl;
        }
    }
}

void displayRoutesByPrice(const vector<Route>& routes, double maxPrice) {
    for (const Route& route : routes) {
        if (route.price <= maxPrice) {
            cout << left << route.from + " " + route.to + " " + route.day + " " + route.time + " ";
            printf("%.2f", route.price);
            cout << endl;
        }
    }
}

void displayErrors(const string& filename) {
    ifstream errFile(filename);
    if (errFile.is_open()) {
        string line;
        while (getline(errFile, line)) {
            cout << line << endl;
        }
        errFile.close();
    }
}

int main() {
    clearErrorFile("err.txt");
    vector<Route> routes = readDataFromFile("db.csv");

    char command;
    string dummy;
    do {
        cin >> command;
        getline(cin, dummy);

        switch (command) {
            case 'a': {
                string from, to;
                getline(cin >> ws, from);
                getline(cin >> ws, to);
                cout << "result:" << endl;
                displayRoutes(routes, from, to);
                break;
            }
            case 'b': {
                string day;
                getline(cin >> ws, day);
                cout << "result:" << endl;
                displayRoutesByDay(routes, day);
                break;
            }
            case 'c': {
                double maxPrice;
                cin >> maxPrice;
                cout << "result:" << endl;
                displayRoutesByPrice(routes, maxPrice);
                break;
            }
            case 'd':
                cout << "result:" << endl;
                displayErrors("err.txt");
                break;
            case 'e':
                break;
            default:
                cout << "Error" << endl;
        }
    } while (command != 'e');

    return 0;
}
