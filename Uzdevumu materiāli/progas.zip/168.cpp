

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

class route {
public:
  string start;

  string finish;
  string day;
  string time;

  double cost;
};

string izdzesspaceunreturn(string line) {
  line.erase(remove(line.begin(), line.end(), ' '), line.end());
  line.erase(remove(line.begin(), line.end(), '\r'), line.end());
  return line;
}

bool irBurti(const string &input) {
  for (int i = 0; i < input.size(); i++) {
    if (!isalpha(input[i]))
      return false;
  }
  return true;
}
bool irLaiks(const string &input) {
  istringstream stream(input);

  string temp;
  getline(stream, temp, ':');

  try {
    if ((stoi(temp) >= 0 && stoi(temp) <= 23)) {
      getline(stream, temp, ':');
      if ((stoi(temp) >= 0 && stoi(temp) <= 59)) {
        return true;
      } else {
        return false;
      }
    } else {

      return false;
    }
  } catch (...) {
    return false;
  }
  return 0;
}

bool irCost(const string &input) {
  istringstream stream(input);
  string temp;
  getline(stream, temp, '.');
  try {
    if ((stod(temp) >= 0)) {
      getline(stream, temp, '.');
      if ((stod(temp) >= 0)) {
        return true;
      }
    }
  } catch (...) {
    return false;
  }
  return 0;
}

bool irDiena(const string &input) {
  if (input == "Pr" || input == "Ot" || input == "Tr" || input == "Ce" ||
      input == "Pt" || input == "St" || input == "Sv") {
    return true;
  } else {
    return false;
  }
}
void addtorouteorerrtxt(string line, vector<route> &routes, route route) {
  int count = std::count(line.begin(), line.end(), ',');
  int i = 0;
  if (count == 4) {

    istringstream stream(izdzesspaceunreturn(line));
    string temp;

    getline(stream, temp, ',');
    if (irBurti(temp)) {

      route.start = temp;
      i++;
    }
    getline(stream, temp, ',');
    if (irBurti(temp)) {
      route.finish = temp;
      i++;
    }
    getline(stream, temp, ',');
    if (irDiena(temp)) {
      route.day = temp;
      i++;
    }
    getline(stream, temp, ',');
    if (irLaiks(temp)) {

      route.time = temp;
      i++;
    }
    getline(stream, temp, ',');
    if (irCost(temp)) {
      route.cost = stod(temp);
      i++;
    }
    if (i == 5) {
      routes.push_back(route);
    } else {
      ofstream file;
      file.open("err.txt", ios_base::app);
      file << izdzesspaceunreturn(line) << "\n";
      file.close();
    }
  } else {
    if (!line.empty()) {
      ofstream file;
      file.open("err.txt", ios_base::app);

      file << izdzesspaceunreturn(line) << "\n";
      file.close();
    }
  }
}

void a(vector<route> routes) {
  string start, finish;

  cin >> start >> finish;
  cout << "result:"
       << "\n";
  for (auto route : routes) {
    if (route.start == start && route.finish == finish) {
      cout << route.start << " " << route.finish << " " << route.day << " "
           << route.time;
      printf(" %.2f\n", route.cost);
    }
  }
}

void b(vector<route> routes) {
  string day;

  cin >> day;
  cout << "result:"
       << "\n";
  for (auto route : routes) {
    if (route.day == day) {
      cout << route.start << " " << route.finish << " " << route.day << " "
           << route.time;
      printf(" %.2f\n", route.cost);
    }
  }
}

void c(vector<route> routes) {
  double cost;
  cin >> cost;
  cout << "result:"
       << "\n";
  for (auto route : routes) {
    if (route.cost <= cost) {
      cout << route.start << " " << route.finish << " " << route.day << " "
           << route.time;
      printf(" %.2f\n", route.cost);
    }
  }
}

void d(vector<route> routes) {
  ifstream err;

  err.open("err.txt");
  string line;
  cout << "result:"
       << "\n";
  while (getline(err, line)) {
    if (!line.empty()) {
      cout << line << "\n";
    }
  }
  err.close();
}

int main() {
  ifstream filedb("db.csv");
  ofstream fileerr("err.txt");

  vector<route> routes;
  string line, command;
  route route;

  while (getline(filedb, line)) {
    addtorouteorerrtxt(line, routes, route);
  }

  filedb.close();
  while (true) {
    cin >> command;
    if (command == "a") {
      a(routes);
    } else if (command == "b") {
      b(routes);
    } else if (command == "c") {
      c(routes);
    } else if (command == "d") {
      d(routes);
    } else if (command == "e") {
      break;
    }
  }
  return 0;
}