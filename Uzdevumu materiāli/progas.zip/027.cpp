
#include <iostream>
#include <fstream>
#include <sstream>
//Dinamiski masivi
#include <vector>
#include <iomanip>

using namespace std;

//Schedule mes turam informaciju par musu autobusiem celiem
struct Schedule {

    string Start;
    string End;
    string Week;
    string Time;
    double Price;
};

void DisplayErrFile() {
    ifstream errF("err.txt");

    if (errF.is_open()) {
        cout << "result:" << endl;
        string errL;
        while (getline(errF, errL)) {
            cout << errL << endl;
        }
        errF.close();
    }
}
//Nonem tukso vietu 
string trim(const string& str) {

    size_t first = str.find_first_not_of(" \t\r\n");
    size_t last = str.find_last_not_of(" \t\r\n");
    return (first != string::npos && last != string::npos) ? str.substr(first, (last - first + 1)) : "";
}

//Parbauda lai nebutu lieku datu
bool ValidDate(const string& date) {
    
    return (date.size() == 2 && isalpha(date[0]) && isalpha(date[1]));
}

//Ievieto informaciju Schedule ieksa, izmanto bool lai uzzinat vai ievietojums tika galam
bool BusSchedule(const string& line, Schedule& route) {

    stringstream ss(line);
    string space;

    int dCount = 0;

//Dabuj no kurienes un uz kurieni autobuss brauks
    if (getline(ss, space, ',') && !space.empty()) {
        route.Start = trim(space);
    } else {
        return false;
    }

    if (getline(ss, space, ',') && !space.empty()) {
        route.End = trim(space);
    } else {
        return false;
    }

//Dabuj datu un salidzina lai nebutu liekas dates
    if (getline(ss, space, ',') && !space.empty()) {
        route.Week = trim(space);
        if (ValidDate(route.Week)) {
            dCount++;
        }
    } else {
        return false;
    }

//Dabu laiku
    if (getline(ss, space, ',') && !space.empty()) {
        route.Time = trim(space);
    } else {
        return false;
    }

//Dabu cik maksas bilete un ja nav tadu datu tad bool bus false
    if (getline(ss, space, ',')) {
        try {
            if (!trim(space).empty()) {
                route.Price = stod(trim(space));
            } else {
                return false;
            }
        } catch (const invalid_argument& e) {
            return false;
        }
    } else {
        return false;
    }

//Iet caur un parbauda lai nebutu liekas dates
    while (ss >> space) {
        if (ValidDate(space)) {
            dCount++;
        } else {
            return false; 
        }
    }

    return dCount == 1; 
}


//Noprinte Schedule datus 
void DisplaySchedule(const vector<Schedule>& routes) {

    cout << "result:" << endl;

//Nem informaciju no Schedule un noprinte to
    for (const auto& route : routes) {

        cout << route.Start << " " << route.End << " "
             << route.Week << " " << route.Time << " "
             << fixed << setprecision(2) << route.Price << endl;
             //fixed setprecision(2) ir izmantots lai musu bilesu cena butu noprinteta ar 2 zimiem aiz komata
    }
}



int main() {
    //Musu marsruti ir ievietoti routes
    vector<Schedule> routes;

//atver musu db failu
    ifstream file("db.csv");
    

    string line;
    //Lasa csv failu un nodzes tuksos vietus, Un izmanto BusSchedule funkciju lai ievietot Schedule datus
    while (getline(file, line)) {
        if (trim(line).empty()) {

            continue;
        }

        Schedule route;
        if (!BusSchedule(line, route)) {

//Nepareizi marsruti ir novietoti err.txt
            ofstream errF("err.txt", ios::app);
            if (errF.is_open()) {

                errF << line << endl;
                errF.close();
            } 
        } else {

            routes.push_back(route);
        }
    }

    char Selection;

    do {

        cout << "";
        cin >> Selection;

        switch (Selection) {
            case 'a': {

                string start, end;
                cout << "";
                cin.ignore();
                getline(cin, start);
                cout << "";
                getline(cin, end);

                vector<Schedule> sRoutes;
//Salidzina lai musu 2 pilseti bija turi kuri ir vajadzigi mums un noprinte vinus marsrutus
                for (const auto& route : routes) {
                    if (route.Start == start && route.End == end) {

                        sRoutes.push_back(route);
                    }
                }

                DisplaySchedule(sRoutes);
                break;
            }
            case 'b': {

//Mekle kuri marsruti ir kada diena
                string day;
                cout << "";
                cin.ignore();
                getline(cin, day);

                vector<Schedule> sRoutes;

                for (const auto& route : routes) {
                    if (route.Week == day) {

                        sRoutes.push_back(route);
                    }
                }

                DisplaySchedule(sRoutes);
                break;
            }

//Mekle marsrutus kuri ir letaki par cenu kuru useris ievada            
            case 'c': {

                double PriceLimit;
                cout << "";
                cin.ignore();
                cin >> PriceLimit;

                vector<Schedule> sRoutes;

                for (const auto& route : routes) {
                    if (route.Price <= PriceLimit) {

                        sRoutes.push_back(route);
                    }
                }

                DisplaySchedule(sRoutes);
                break;
            }

//Parada musu err.txt failu            
            case 'd':{
                DisplayErrFile();
                break;
            } 

//beidz programmu                  
            case 'e':

                cout << "";
                remove("err.txt");
                break;
        }
    } while (Selection != 'e');

    return 0;
}
