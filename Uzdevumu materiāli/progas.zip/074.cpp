

#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include<set>

using namespace std;

struct route {
  string start;
  string end;
  string day;
  string time;
  double price;
};

vector<route> routes;
vector<string> errors;

void trim(string &s){
  s.erase(s.begin(), find_if(s.begin(), s.end(), [](unsigned char ch) {
  return !isspace(ch);
  })); 
  s.erase(find_if(s.rbegin(), s.rend(), [](unsigned char ch) {
    return !isspace(ch);
  }).base(), s.end());
}

void Routes() {
  ifstream file("db.csv");
  string line; 
  set<string> valid_days = {"Pr", "Ot","Tr", "Ce", "Pt", "St", "Sv"};
  while(getline(file, line)){
    trim(line);
    if(line.empty())
      continue; 
    stringstream ss(line);
    string buffer; 
    vector<string> tokens;
    while(getline(ss, buffer, ',')){
      trim(buffer);
      tokens.push_back(buffer);
    }
    if(tokens.size()!=5 || valid_days.find(tokens[2]) == valid_days.end()){
      errors.push_back(line);
      continue; 
    }
    route r;
    r.start = tokens[0];
    r.end = tokens[1];
    r.day = tokens[2];
    r.time = tokens[3];
    try{
    r.price = stod(tokens[4]);
    } catch (const invalid_argument &ia){
      errors.push_back(line);
      continue; 
    }
    
    routes.push_back(r);
  }
  file.close(); 
  }

void saveErr(){
  ofstream file("err.txt");
  for(const auto &error : errors){
    file<<error<<endl;
  }
  file.close();
}

void printRoutes(const route &r){
  cout<< r.start<<" "<<r.end<<" "<<r.day<<" "<<r.time<<" "<<fixed<<setprecision(2)<<r.price<<endl; 
}

int main() {
  Routes();
  saveErr();
  
  char command;

  while (cin >> command && command != 'e') {
    cout << "result:" << endl;

    switch (command) {
    case 'a': {
      string start, end;
      cin>>start>>end;
      for (const auto &r : routes){
        if(r.start == start && r.end == end){
          printRoutes(r); 
        }
      }
      break;
    }
    case 'b': {
      string day;
      cin>>day;
      for(const auto &r : routes){
        if(r.day == day){
          printRoutes(r);
        }
      }
      break;
    }
    case 'c': {
      double price;
      cin>>price;
      for(const auto &r: routes){
        if(r.price <= price){
          printRoutes(r);
        }
      }
      break;
    }
    case 'd': {
      ifstream file("err.txt");
      string line;
      while(getline(file, line)){
        cout<<line<<endl;
      }
      file.close();
      break; 
    }
    }
  }
}