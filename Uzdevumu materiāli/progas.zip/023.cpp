
#include <iostream>
#include <fstream>
#include <vector>
#include <bits/stdc++.h>
#include <algorithm>
#include <string>

using namespace std;

class Bus {
  public:
    string from;
    string to;
    string day;
    string time;
    string price;
};

void show (Bus b){
  cout << b.from << " " << b.to << " " << b.day << " " << b.time << " " << b.price << "\n";
}

string removeSpaces(string s) 
{ 
  s.erase(std::remove_if(s.begin(), s.end(), std::bind(std::isspace < char > ,
    std::placeholders::_1,
    std::locale::classic())),
    s.end());
    return s; 
}

bool check_day(string s){
  if (s == "Pr") return true;
  if (s == "Ot") return true;
  if (s == "Tr") return true;
  if (s == "Ce") return true;
  if (s == "Pt") return true;
  if (s == "St") return true;
  if (s == "Sv") return true;
  return false;
}

bool check_time(string s){
  if (s.length() != 5){
    return false;
  }
  if (s[2] != ':') return false;
  string s2 = s.substr(0, 2);
  string s3 = s.substr(3, 2);
  try {
    int hour = stoi(s2);
    int min = stoi(s3);
    if (min > 59 || min < 0 || hour > 23 || hour < 0) return false;
  }catch(exception e){
    return false;
  }
  return true;
}

bool check_price (string s){
  if (s[s.length()-3] != '.') return false;
  try {
    double p = stof(s);
    if (p < 0) return false;
  }catch(exception e){
    return false;
  }
 return true; 
} 


int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  ofstream outFile("err.txt");
  vector<Bus> bus_vec = {};
  
  string s; 
	while (getline(inFile,s))
	{
    vector<string> v;

    stringstream ss(s);
    if (!s.empty()){
    while (ss.good()) {
        string subs;
        getline(ss, subs, ',');
        v.push_back(subs);
    }
    if (removeSpaces(v[0]).length() != 0){
    if(v.size() != 5){
      outFile << s << "\n";
    }else{
      Bus tr;
      tr.from = removeSpaces(v[0]);
      tr.to = removeSpaces(v[1]);
      if (!check_day(removeSpaces(v[2])) || !check_time(removeSpaces(v[3])) || !check_price(removeSpaces(v[4]))){
        outFile << s << "\n";
      }else {
        tr.day = removeSpaces(v[2]);
        tr.time = removeSpaces(v[3]);
        tr.price = removeSpaces(v[4]);
        bus_vec.push_back(tr);
      }
    }
    }
  }
  }

  outFile.close();
  inFile.close();

  string command = "";

  while (command != "e"){
    cin>> command;
    if (command == "a"){
      string from, to;
      cin >> from;
      cin >> to;
      cout<< "result:"<< "\n";
      for (int i = 0; i < bus_vec.size(); i++){
        if (bus_vec[i].from == from && bus_vec[i].to == to){
          show(bus_vec[i]);
        }
      }
    }
    else if (command == "b"){
      string day;
      cin >> day;
      cout<< "result:"<< "\n";
      for (int i = 0; i < bus_vec.size(); i++){
        if (bus_vec[i].day == day){
          show(bus_vec[i]);
        }
      }
    }
    else if (command == "c"){
      double d;
      cin >> d;
      if(cin.fail()){
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout<< "incorrect input" << "\n";
      }
      else{
      if (d > 0){
      cout<< "result:"<< "\n";
      for (int i = 0; i < bus_vec.size(); i++){
        if (stof(bus_vec[i].price) < d){
          show(bus_vec[i]);
        }
      }
      }else {
        cout<< "incorrect input" << "\n";
      }
      }
    }
    else if (command == "d"){
      cout<< "result:"<< "\n";
      ifstream inFile;
      inFile.open("err.txt");

      if (!inFile) return 0;
      while (inFile >> s)
        {
          cout<< s << "\n";
        }
      
    }
    else if (command == "e"){
      break;
    } else {
      cout << "wrong command"<< "\n";
    }
  }
  remove("err.txt");
  
} 