
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

struct entry{  //Informācija par vienu ierakstu failā
  double price;
  int hours, mins;
  string source, dest, date;
};

static const vector<string> days{"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};  //Pieejamās dienas

void trimWhitespace(string &str){  //Lieko atstarpju noņemšana
  string whitespace = " \n\r\t\f\v";  //Visas iespējamās atstarpes
  str.erase(0, str.find_first_not_of(whitespace));//noņem no priekšas
  if(str.find_last_of(whitespace) != -1){  //ja atrod arī aizmugurē
    str.erase(str.find_last_of(whitespace), str.back());//noņem arī tur
  }
}

void printEntry(entry &e){  //Ieraksta pareiza izvade
  cout << e.source << " " << e.dest << " " << e.date << " " << setw(2) << setfill('0') << e.hours << ':'<< setw(2) << setfill('0') << e.mins << " " << fixed << setprecision(2) << e.price << endl;
}

entry inputOneFromFile(ifstream &inFile, ofstream &outFile){  //Viena ieraksta ievade no faila
  entry e;
  char comma;  //Šeit glabāsies nevajadzīgās rakstzīmes
  string line;
  
  getline(inFile, line);  //Dabūjam rindu no faila
  
  while(line.length() < 2){  //Kamēr tā ir praktiski tukša
    if(inFile.eof()){  //Ja ir faila beigas
      e.source = "-1";  //Iestatam, ka maršruts iet no -1
      return e;  //Atgriežam to
    }
    getline(inFile, line);  //Paņemam nākamo rindu
  }
  while(line.length() < 13 || count(line.begin(), line.end(), ',') != 4){  //Kamēr rinda ir par īsu vai tajā nav pareizs lauku skaits
    e.source = "";  //Iestatam, ka maršruta nav
    outFile << line;  //Ierakstam kļūdu failā
    return e;  //Atgriežam kļūdaino ierakstu
    getline(inFile, line);  //Paņemam nākamo rindu
  }
  
  stringstream ss(line);  //Izveidojam no rindas plūsmu

  getline(ss, e.source, ',');  //Ņemam no tās plūsmas sākumpunktu,
  trimWhitespace(e.source);  //Noņemam nevajadzīgās atstarpes
  getline(ss, e.dest, ',');  //Tāpat ar galapunktu
  trimWhitespace(e.dest);
  getline(ss, e.date, ',');  //Tāpat ar dienu
  trimWhitespace(e.date);

  if(find(days.begin(), days.end(), e.date) == days.end()){  //Ja diena nav pareizo dienu vektorā
    outFile << line;  //Ierakstam rindu kļūdu failā
    e.source = "";  //Iestatam, ka maršruta nav
    return e;
  }

  if(e.source.length()<1 || e.dest.length()<1){  //Ja nav nolasīts sākumpunkts vai galapunkts
    outFile << line;  //Ierakstam rindu kļūdu failā
    e.source = "";  //Brāķējam marsrutu
    return e;
  }

  ss >> e.hours >> comma >> e.mins >> comma;  //Ievadam laiku
  
  if(ss.fail() || e.hours > 24 || e.hours < 0 || e.mins > 59 || e.mins < 0){  //Ja laiks nav ievadīts vai nav derīgs
    outFile << line;  //Ierakstam rindu kļūdu failā
    e.source = "";  //Brāķējam marsrutu
    return e;
  }

  ss >> e.price;  //Ievadam cenu
  if(ss.fail() || e.price < 0){  //Ja cena nav ievadīta vai nav derīga JA ŠO PĀRBAUDI IELIKT KOPĀ AR LAIKU, REPLITS DOMĀ, KA KAUT KUR NAV AIZVEROŠAS IEKAVAS. KĀPĒC???
    outFile << line;  //Ierakstam rindu kļūdu failā
    e.source = "";  //Brāķējam marsrutu
    return e;
  }
  return e;  //Atgriežam derīgu maršrutu
}

void getAll(ifstream &inFile, ofstream &outFile, vector<entry>& all){  //Nolasa visus derīgos maršrutus
  entry route;
  while(route.source != "-1"){  //Kamēr nav sasniegtas faila beigas
    route = inputOneFromFile(inFile, outFile);  //Ievadam vienu maršrutu
    if(route.source.length() != 0 && route.source != "-1"){  //Ja maršuruts nav brāķēts
      all.push_back(route);  //Pievienojam to derīgo maršrutu vektoram
    }
  }
  inFile.close();  //Aizveram lasīšanas plūsmu, vairāk nevajadzēs lasīt
  outFile.close();  //Aizveram rakstīšanas plūsmu, visas kļūdas atrastas
}

void getByEndpoints(vector<entry>& all){  //Dabū maršrutus pēc sākum- un galapunkta
  string from, to;  //Meklējamie punkti

  cin >> from;  //Ievadam sākumpunktu
  while(from.length() == 0){
    cin >> from;
  }
  cin >> to;  //Ievadam galapunktu
  while(to.length() == 0){
    cin >> to;
  }

  cout << "result: " << endl;
  for(int i=0; i<all.size(); i++){  //Pa visu maršrutu vektoru
    if(all[i].source == from && all[i].dest == to){  //Meklējam derīgus maršrutus
      printEntry(all[i]);  //Izvadam tos
    }
  }
}

void getByDate(vector<entry>& all){  //Dabū maršrutus pēc dienas
  string day;  //Vajadzīgā diena
  bool valid = false;  //Vai diena ir derīga
  while(!valid){  //Ievadam dienu līdz tā ir dienu vektorā
    cin >> day;
    if(find(days.begin(), days.end(), day) != days.end()){  //Ja atrodam pareizu dienu
      valid = true;  //Izejam no cikla
    }
  }

  cout << "result: " << endl;
  for(int i=0; i<all.size(); i++){  //Meklējam maršrutus ar vajadzīģo dienu pa visu maršrutu vektoru
    if(all[i].date == day){
      printEntry(all[i]);
    }
  }
}

void getByPrice(vector<entry>& all){  //Dabū maršrutus pēc cenas
  double cost;  //Meklējamā cena
  cin >> cost;  //Ievadam cenu
  while(cin.fail() || cost < 0){
    cin >> cost;
  }

  cout << "result: " << endl;
  for(int i=0; i<all.size(); i++){  //Meklējam maršrutus ar zemāku vai vienādu cenu pa visu maršrutu vektoru
    if(all[i].price <= cost+0.001){
      printEntry(all[i]);
    }
  }
}

void printErrors(){  //Izvada kļūdu failu
  ifstream errFile;  //Kļūdu faila lasīšanas plūsma
  errFile.open("err.txt");

  if(!errFile) return;

  string line;
  cout << "result: \n";
  while(errFile >> line){  //Kamēr nav sasniegtas faila beigas
    cout << line << endl;  //Izvada rindu
  }
  errFile.close();  //Aizver kļūdu faila lasīšanas plūsmu
}

int main() {  //MAIN
  ifstream inFile;  //Faila lasīšanas plūsma
  ofstream outFile("err.txt");  //Kļūdu faila rakstīšanas plūsma
  inFile.open("db.csv");

	if (!inFile) return 0;  //Ja jebkura plūsma nav izveidota, izejam
  if (!outFile) return 0;

  vector<entry> routes;  //Derīgu maršrutu vektors
  getAll(inFile, outFile, routes);  //Ievada derīgus maršrutus vektorā

  string cmd;
  cin >> cmd;  //Ievadam pirmo komandu
  while(cmd.length() != 1){  //Lai pasargātu no vairāku komandu secīgas izpildes, ievadam stringu līdz tā garums nav 1
    cin >> cmd;
  }
  char command = cmd[0];  //Ņemam no stringa char, lai varēu darīt switch

  while(true){  //Ies, līdz neizies
    switch(command){
      case 'a':  //Komanda a - meklē maršrutus pēc galapunktiem
        getByEndpoints(routes);
        break;
      case 'b':  //Komanda b - meklē maršrutus pēc dienas
        getByDate(routes);
        break;
      case 'c':  //Komanda c - meklē maršrutus pēc cenas
        getByPrice(routes);
        break;
      case 'd':  //Komanda d - izvada kļūdu failu
        printErrors();
        break;
      case 'e':  //Komanda e - iziet no programmas
        return 0;
      default:
        break;
    }
    
    cin >> cmd;  //Turpinam ievadīt komandu kā stringu
    while(cmd.length() != 1){
      cin >> cmd;
    }
    command = cmd[0];
  }
}