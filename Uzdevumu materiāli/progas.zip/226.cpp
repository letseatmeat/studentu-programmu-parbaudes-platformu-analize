
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <regex>
#include <string>
#include <filesystem>

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

int CountOfOccurrences(const string& line) {
    int count = 0;
    stringstream ss(line);
    string attribute;
    while (getline(ss, attribute, ',')) {
        count++;
    }
    return count;
}


vector<BusRoute> readRoutesFromFile(const string& fileName) {
    vector<BusRoute> routes;
    ifstream file(fileName);

    if (!file.is_open()) {
        cerr << "error" << fileName << endl;
        exit(EXIT_FAILURE);
    }

    string line;
  
    while (getline(file, line)) {
        
        line = regex_replace(line, regex("^\\s+|\\s+$"), "");

        
        if (line.empty()) {
            continue;
        }

      
        line = regex_replace(line, regex("\\s*,\\s*"), ",");

        if (CountOfOccurrences(line) != 5) {
            ofstream errFile("err.txt", ios::app);
            errFile << "" << line << endl;
            errFile.close();
            continue;
        }


        stringstream ss(line);
        BusRoute route;

        if (getline(ss, route.startStop, ',') &&
            getline(ss, route.endStop, ',') &&
            getline(ss, route.dayOfWeek, ',') &&
            getline(ss, route.time, ',') &&
            (ss >> route.ticketPrice)) {
          
            bool isValid = true;

            
            if (route.startStop.empty() || route.endStop.empty()) {
                isValid = false;
            }

            
            if (route.dayOfWeek.size() != 2) {
                isValid = false;
            }
            
            
            if (!regex_match(route.time,  regex("\\d{2}:\\d{2}"))) {
                isValid = false;
            }

            
            if (route.ticketPrice <= 0) {
                isValid = false;
            }

            if (!isValid) {
                ofstream errFile("err.txt", ios::app);
                errFile << "" << line << endl;
                errFile.close();
            }
            routes.push_back(route);
        } else {
            ofstream errFile("err.txt", ios::app);
            errFile << "" << line << endl;
            errFile.close();
        }
    }

    file.close();
    return routes;
}

void RoutebyRoute(const vector<BusRoute>& routes, const string& startStop, const string& endStop) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.startStop == startStop && route.endStop == endStop) {
            cout << route.startStop << " " << route.endStop << " "
                 << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}


void RoutesByDay(const vector<BusRoute>& routes, const string& dayOfWeek) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.dayOfWeek == dayOfWeek) {
            cout << route.startStop << " " << route.endStop << " "
                 << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}


void TicketPrice(const vector<BusRoute>& routes, double maxPrice) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.ticketPrice <= maxPrice) {
            cout << route.startStop << " " << route.endStop << " "
                 << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}

int main() {
    ofstream clearErrFile(("err.txt"), ios::out);
    clearErrFile.close();
  
    vector<BusRoute> routes = readRoutesFromFile("db.csv");
    char choice;
    do {
        cin >> choice;

        switch (choice) {
            case 'a':
                {
                    string startStop, endStop;
                    cin >> startStop;
                    cin >> endStop;
                    RoutebyRoute(routes, startStop, endStop);
                }
                break;
            case 'b':
                {
                    string dayOfWeek;
                    cin >> dayOfWeek;
                    RoutesByDay(routes, dayOfWeek);
                }
                break;
            case 'c':
                {
                    double maxPrice;
                    cin >> maxPrice;
                    TicketPrice(routes, maxPrice);
                }
                break;
            case 'd':
                {
                    ifstream errFile("err.txt");
                    if (errFile.is_open()) {
                        cout << "result:" << endl;
                        cout << errFile.rdbuf();
                        errFile.close();
                    } else {
                        cout << "error" << endl;
                    }
                }
                break;
            case 'e':
                
                break;
            default:
                cout << "error" << endl;
        }

    } while (choice != 'e');

    return 0;
}
