
#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

string trim(string &s) {

   s.erase(remove(s.begin(), s.end(), ' '), s.end());
  
  return s;
}

void createTempFile(const string &FileName, const string &tempFileName) {
  ifstream read(FileName);
  ofstream tempFile(tempFileName);

  if (!read.is_open() || !tempFile.is_open()) {
    cout << "Error\n";
    return;
  }

  string line;
  while (getline(read, line)) {
    vector<string> row;
    stringstream s(line);

  
    while (getline(s, line, ',')) {
      line = trim(line);
      tempFile << line << ',';
    }
    tempFile << '\n';
  }

  read.close();
  tempFile.close();
}

//errorfile creaion

void createErrorFile(const string &tempFileName, const string &errorFileName) {
  ifstream read(tempFileName);
  ofstream errorFile(errorFileName);

  if (!read.is_open() || !errorFile.is_open()) {
    cout << "Error\n";
    return;
  }

  string line, word;
  while (getline(read, line)) {   
    vector<string> row;
    stringstream s(line);
    line = trim(line);
    
    while (getline(s, word, ',')) {
      row.push_back(word);
    }
    
    if (row.size() !=5 || row[2].size() != 2 ){
      errorFile << line << '\n';
    }
  }

  read.close();
  errorFile.close();
}

void read_a(const string &tempFileName) {
  ifstream read;

  string pietura_1, pietura_2;
  // cout << "Ievadi sākumpieturu: ";
  cin >> pietura_1;
  // cout << "Ievadi galamērķi: ";
  cin >> pietura_2;

  vector<string> row;
  string line, word;

  read.open(tempFileName);

  while (getline(read, line)) {
    row.clear();

    stringstream s(line);

    while (getline(s, word, ',')) {
      row.push_back(word);
    }
    if (row[0] == pietura_1){
    }
    if (row.size() == 5 && row[0] == pietura_1 && row[1] == pietura_2) {
      cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " "<< row[4] << " \n";
    }
  }
}

void read_b(const string &tempFileName){
  ifstream read;

  string diena;
  //cout << "Ievadi dienu: ";
  cin >> diena;


  vector<string> row;
  string line, word;

  read.open(tempFileName);

  while (getline(read, line)) {
    row.clear();

    stringstream s(line);

    while (getline(s, word, ',')) {
      row.push_back(word);
    }

    if (row.size() == 5 && row[2] == diena) {
      cout << row[0] << " ";
      cout << row[1] << " ";
      cout << row[2] << " ";
      cout << row[3] << " ";
      cout << row[4] << " \n";
    }
  }
}

void read_c(const string &tempFileName){
  ifstream read;

  double cena, salidzinat;
  cin >> cena;

  vector<string> row;
  string line, word;

  read.open(tempFileName);

  while (getline(read, line)) {
    row.clear();

    stringstream s(line);

    while (getline(s, word, ',')) {
      row.push_back(word);
    }

    salidzinat = stoi(row[4]); 

    if (row.size() == 5 && salidzinat <= cena) {
      cout << row[0] << " ";
      cout << row[1] << " ";
      cout << row[2] << " ";
      cout << row[3] << " ";
      cout << row[4] << " \n";
    }
  }
}

void read_d(const string &errorFileName){
  ifstream read;

  vector<string> row;
  string line, word;

  read.open(errorFileName);

  while (getline(read, line)) {
    row.clear();

    stringstream s(line);

    while (getline(s, word, ',')) {
      row.push_back(word);
    }

    if(row.size() != 1){
      for(int i = 0; i < row.size(); i++){
        if(row.size()-1 == i){
          cout << row [i] << "\n";
        }else  cout << row[i] << ",";
    }
    }
  }
}

int main() {
  ifstream inFile;
  string fileName = "db.csv";
  string tempFileName = "temp_file.txt";
  string errorFileName = "err.txt";
  createTempFile(fileName, tempFileName);
  createErrorFile(tempFileName, errorFileName);

  bool loop = true;
  while (loop) {
    char n;
    cin >> n;
    switch (n) {
    case 'a':
      cout << "result:" << endl;
      read_a(tempFileName);
      break;
    case 'b':
      cout << "result:\n";
      read_b(tempFileName);
      break;
    case 'c':
      cout << "result:\n";
      read_c(tempFileName);
      break;
    case 'd':
      cout << "result:\n";
      read_d(errorFileName);
      break;
    case 'e':
      loop = false;
      break;
    default:
      cout << "Invalid choice\n";
    }
  }
  std::remove(tempFileName.c_str());

}