
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct AutobusaMarsruts {
  string sakumaPietura;
  string galamerkis;
  string nedelasdiena;
  string laiks;
  double biļetesCena;
};
void izvaditRezultatus(const vector<AutobusaMarsruts> &maršruti) {
  cout << "result:" << endl;
  for (const auto &marsruts : maršruti) {
    cout << marsruts.sakumaPietura << " " << marsruts.galamerkis << " "
         << marsruts.nedelasdiena << " " << marsruts.laiks << " " << fixed
         << setprecision(2) << marsruts.biļetesCena << endl;
  }
}
bool irSkaitlis(const string &virkne) {
  for (char c : virkne) {
    if (!isdigit(c) && c != '.' && c != '-') {
      return false;
    }
  }
  return true;
}
string apcirpt(const string &virkne) {
  size_t pirmais = virkne.find_first_not_of(" \t");
  size_t pedejais = virkne.find_last_not_of(" \t");
  return virkne.substr(pirmais, (pedejais - pirmais + 1));
}
int main() {
  ifstream ieejasFails("db.csv");
  ofstream kludaFails("err.txt");
  if (!ieejasFails.is_open() || !kludaFails.is_open()) {

    return 1;
  }
  vector<AutobusaMarsruts> maršruti;
  string rinda;
  while (getline(ieejasFails, rinda)) {
    rinda = apcirpt(rinda);
    if (rinda.empty()) {
      continue;
    }
    vector<string> zīmes;
    stringstream ss(rinda);
    string zīme;
    while (getline(ss, zīme, ',')) {
      zīmes.push_back(apcirpt(zīme));
    }

    if (zīmes.size() != 5 || irSkaitlis(zīmes[1])) {
      if (!rinda.empty()) {
        kludaFails << rinda << endl;
      }
      continue;
    }

    AutobusaMarsruts marsruts;
    marsruts.sakumaPietura = zīmes[0];
    marsruts.galamerkis = zīmes[1];
    marsruts.nedelasdiena = zīmes[2];
    marsruts.laiks = zīmes[3];

    try {
      marsruts.biļetesCena = stod(zīmes[4]);
    } catch (const invalid_argument &e) {
      cerr << "Nederīga biļetes cena: " << zīmes[4] << endl;
      if (!rinda.empty()) {
        kludaFails << rinda << endl;
      }
      continue;
    }

    maršruti.push_back(marsruts);
  }

  ieejasFails.close();

  char izvele;
  while (true) {
    cin >> izvele;

    switch (izvele) {
    case 'a': {
      string sakums, galamerkis;

      cin >> sakums;
      cin >> galamerkis;

      vector<AutobusaMarsruts> filtrētieMaršruti;
      for (const auto &marsruts : maršruti) {
        if (marsruts.sakumaPietura == sakums &&
            marsruts.galamerkis == galamerkis) {
          filtrētieMaršruti.push_back(marsruts);
        }
      }
      izvaditRezultatus(filtrētieMaršruti);
      break;
    }
    case 'b': {
      string nedelasdiena;
      cin >> nedelasdiena;
      vector<AutobusaMarsruts> filtrētieMaršruti;
      for (const auto &marsruts : maršruti) {
        if (marsruts.nedelasdiena == nedelasdiena) {
          filtrētieMaršruti.push_back(marsruts);
        }
      }

      izvaditRezultatus(filtrētieMaršruti);
      break;
    }

    case 'c': {
      double maksimalaCena;
      cin >> maksimalaCena;
      vector<AutobusaMarsruts> filtrētieMaršruti;
      for (const auto &marsruts : maršruti) {
        if (marsruts.biļetesCena <= maksimalaCena) {
          filtrētieMaršruti.push_back(marsruts);
        }
      }
      izvaditRezultatus(filtrētieMaršruti);
      break;
    }
    case 'd': {
      ifstream kludasFails("err.txt");
      if (kludasFails) {
        cout << "result:" << endl;
        string kludasRinda;
        bool firstLine = true;
        while (getline(kludasFails, kludasRinda)) {
          bool hasNonSpace = false;
          for (char c : kludasRinda) {
            if (!isspace(c)) {
              hasNonSpace = true;
              break;
            }
          }
          if (hasNonSpace) {
            if (!firstLine) {
              cout << endl;
            }
            stringstream ss(kludasRinda);
            string zīme;
            bool firstSymbol = true;
            while (getline(ss, zīme, ',')) {
              if (!firstSymbol) {
                cout << ",";
              }
              for (char c : zīme) {
                if (!isspace(c)) {
                  cout << c;
                }
              }
              firstSymbol = false;
            }
            firstLine = false;
          }
        }
      } else {
        cout << "err.txt fails nav atrasts." << endl;
      }

      kludasFails.close();
      cout << "\n";
      break;
    }
    case 'e': {
      return 0;
    }
    default:
      cout << "Nepareiza izvēle. Mēģiniet vēlreiz." << endl;
    }
  }
  return 0;
}