

// https://cplusplus.com/doc/tutorial/classes/
// https://cplusplus.com/doc/tutorial/files/
// https://cplusplus.com/reference/sstream/stringstream/stringstream/
// https://cplusplus.com/reference/string/string/substr/
// https://cplusplus.com/reference/string/stod/
// https://cplusplus.com/reference/iomanip/setprecision/
// https://estudijas.rtu.lv/pluginfile.php/4987672/mod_resource/content/1/DIP208_L_1.pdf
// https://estudijas.rtu.lv/pluginfile.php/5257880/mod_resource/content/1/DIP208_L_5_st.pdf

#include <fstream> // Read AND write to file
#include <iomanip> // To set .00 for printing
#include <iostream>
#include <limits>  // numeric limits
#include <sstream> // sstream for splitting string
#include <string>  // Strings
#include <vector>  // Dynamic lists of BusRoute
using namespace std;

// Class
class BusRoute {

private:
  string from, to, day, time;
  double price;

public:
  BusRoute() {}

  BusRoute(string &fromArg, string &toArg, string &dayArg, string &timeArg,
           double priceArg)
      : from(fromArg), to(toArg), day(dayArg), time(timeArg), price(priceArg) {}

  void setValues(string &fromArg, string &toArg, string &dayArg,
                 string &timeArg, double priceArg) {
    from = fromArg;
    to = toArg;
    day = dayArg;
    time = timeArg;
    price = priceArg;
  }

  string getFrom() { return from; }

  string getTo() { return to; }

  string getDay() { return day; }

  double getPrice() { return price; }

  void setFrom(string &fromArg) { from = fromArg; }

  void setTo(string &toArg) { to = toArg; }

  void setDay(string &dayArg) { day = dayArg; }

  void setTime(string &timeArg) { time = timeArg; }

  void setPrice(double priceArg) { price = priceArg; }

  void print() {
    cout << from << " " << to << " " << day << " " << time
         << " "
         // Set 2 digits after point and set fixed position for point
         << setprecision(2) << fixed << price << "\n";
  }
};

/**
 * Theoretically this is not needed because we will write the incorrect line
 *  without modifications into error file but it was better to return all
 * validated lines with statuses instead of iterating over all lines and then
 * again over the corect ones.
 */
class ValidatedLine {
private:
  vector<string> line;
  bool isValid;

public:
  ValidatedLine() : line(), isValid() {}
  ValidatedLine(vector<string> lineArg, bool isValidArg)
      : line(lineArg), isValid(isValidArg) {}
  void setValues(vector<string> lineArg, bool isValidArg) {
    line = lineArg;
    isValid = isValidArg;
  }

  vector<string> getLine() { return line; }

  bool getIsValid() { return isValid; }
};

// Const vars
const string ERR_FILE_NAME = "err.txt";
const string DB_NAME = "db.csv";
// indexes for reading csv
const int INDEX_FROM = 0;
const int INDEX_TO = 1;
const int INDEX_DAY = 2;
const int INDEX_TIME = 3;
const int INDEX_PRICE = 4;
const int FIELD_COUNT = 5;

// Prototypes
bool interpretInput(char command);
void printTitleResult();
vector<BusRoute> readRoutesList(string fileName);
bool doesLineHaveCorrectFieldCount(int valuesValidatedd);
bool isValuePopulated(string value);
bool isDayFormatCorrect(string value);
bool isTimeFormatCorrect(string value);
bool isPriceFormatCorrect(string value);
BusRoute convertToRoute(vector<string> line);
void printErrorFile();
char getCharInput();
string getStringInput();
double getDoubleInput();
void printByPricesUnder(vector<BusRoute> routesList);
void printByDay(vector<BusRoute> routesList);
void printByFromAndTo(vector<BusRoute> routesList);

int main() {
  bool runScript = true;
  while (runScript == true) {
    // cout << "\nEnter command(a,b,c,d,e): "; // Comment this line to pass
    // tests
    char command = getCharInput();
    // Commands will return bool (only 'e' will return false so it ends the
    // programm)
    runScript = interpretInput(command);
  }
}

/**
 * Receives command and determines which fuctions have to be executed
 * If 'e' it will return false to end programm and others will return true
 * if valid commands except 'e' will be entered then we will read db.csv
 * and then we will execute corresponding command
 */
bool interpretInput(char command) {
  vector<BusRoute> routesList;
  if ('e' == command) // End of programm
  {
    return false;
  } else if ('a' == command || 'b' == command || 'c' == command ||
             'd' == command) { // Read content of file
    routesList = readRoutesList(DB_NAME);
  }
  switch (command) {
  case 'a':
    printByFromAndTo(routesList);
    return true;
  case 'b':
    printByDay(routesList);
    return true;
  case 'c':
    printByPricesUnder(routesList);
    return true;
  case 'd':
    printErrorFile();
    return true;
  default:
    return true;
  }
}

void printTitleResult() { cout << "result:\n"; }

// While there is an empty line at start or end then keep removing it
string trim(string value) {
  while (value.at(0) == ' ' || value.at(value.length() - 1) == ' ') {
    if (value.at(0) == ' ') { // Remove empty lines from front
      value = value.substr(1);
    }
    if (value.at(value.length() - 1) == ' ') { // Remove empty lines from back
      value = value.substr(0, value.length() - 1);
    }
  }
  return value;
}

bool doesLineHaveCorrectFieldCount(int valuesValidated) {
  if (valuesValidated == FIELD_COUNT) {
    return true;
  } else {
    return false;
  }
}

bool isValuePopulated(string value) {
  if (value.length() > 1) {
    return true;
  } else {
    return false;
  }
}

bool isDayFormatCorrect(string value) {
  if (value == "Pr" || value == "Ot" || value == "Tr" || value == "Ce" ||
      value == "Pt" || value == "St" || value == "Pv") {
    return true;
  } else {
    return false;
  }
}

/**
 * Validate timeformat
 * TODO add validation of hours and minutes
 */
bool isTimeFormatCorrect(string value) {
  if (value.length() == 5) {                   // xx:00\0
    if (value.at(value.length() - 3) == ':') { //: 00\0
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

bool isPriceFormatCorrect(string value) {
  if (value.length() > 4) { // x.00\0
    if (value.at(value.length() - 4) == '.') {
      /*
      Convert to double, if it fails then catch and return false
      This means that later if we cconvert it we will not have invalid lines
      */
      try {
        stod(value);
      } catch (const invalid_argument &e) {
        return false;
      } catch (const out_of_range &e) {
        return false;
      }
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

ValidatedLine validateLine(string line) {
  stringstream lineStream(
      line);    // Create string stream so line can be split by ","
  string value; // Create temp variable for iterating over line stram
  bool isLinevalid = true;
  // Stores all properties regardless of correct or incorrect line
  vector<string> lineValues;
  // Contains line properties and flag describing if line is valid
  ValidatedLine validatedLine;
  int index = 0; // Index of value in each iteration

  while (getline(lineStream, value, ',')) {
    value = trim(value); // Trim value string value
    /* Validate if not empty string. In the end line will be valid only
    if all validations return true, because we don't want to overwrite with true
    if there was invalid value before
    */
    bool valueIsPopulated = isValuePopulated(value);
    bool dayFormatIsCorrect;
    bool timeFormatIsCorrect;
    bool priceFormatIsCorrect;

    isLinevalid = isLinevalid && valueIsPopulated;
    switch (index) {
    case 2:
      dayFormatIsCorrect = isDayFormatCorrect(value);
      isLinevalid = isLinevalid && dayFormatIsCorrect;
      break;
    case 3:
      timeFormatIsCorrect = isTimeFormatCorrect(value);
      isLinevalid = isLinevalid && timeFormatIsCorrect;
      break;
    case 4:
      priceFormatIsCorrect = isPriceFormatCorrect(value);
      isLinevalid = isLinevalid && priceFormatIsCorrect;
      break;
    default:
      // No action
      break;
    }

    if (isLinevalid) {
      lineValues.push_back(value);
    }

    index++;
  }
  isLinevalid = isLinevalid && doesLineHaveCorrectFieldCount(index);
  validatedLine.setValues(lineValues, isLinevalid);
  return validatedLine;
}

BusRoute convertToRoute(vector<string> line) {
  BusRoute busRoute;
  for (int i = 0; i < line.size(); i++) {
    if (i == INDEX_FROM) {
      busRoute.setFrom(line[i]);
    }
    if (i == INDEX_TO) {
      busRoute.setTo(line[i]);
    }

    if (i == INDEX_DAY) {
      busRoute.setDay(line[i]);
    }

    if (i == INDEX_TIME) {
      busRoute.setTime(line[i]);
    }

    if (i == INDEX_PRICE) {
      try {
        double price = stod(line[i]);
        busRoute.setPrice(price);
      } catch (const invalid_argument &e) {
        cout << e.what() << "\n";
      } catch (const out_of_range &e) {
        cout << e.what() << "\n";
      }
    }
  }
  return busRoute;
}

/**
 * Read file content and determine valid lines
 * valid lines are converted to BusRoute obj and added to vector validRoutes
 */
vector<BusRoute> readRoutesList(string fileName) {
  vector<BusRoute> validRoutes; // Only valid routes will be collected in end

  ifstream dbFile;
  dbFile.open(fileName);
  string line; // Temp variable to represent each line in db file
  ofstream errFile(ERR_FILE_NAME);

  while (getline(dbFile, line)) {
    // Line that will be validated.
    // It contains all line data and bool to show that it is valid or not
    ValidatedLine validatedLine;
    if (line.length() > 1) // Validate only non empty lines
    {
      validatedLine = validateLine(line);
      bool lineIsValid = validatedLine.getIsValid();
      if (lineIsValid) { // If line is valid we store it as route object
        BusRoute route = convertToRoute(validatedLine.getLine());
        validRoutes.push_back(route);
      } else {
        // Write to ett.txt
        errFile << line << endl;
      }
    }
  }
  dbFile.close();
  errFile.close();
  return validRoutes;
}

void printErrorFile() {
  printTitleResult();
  ifstream errFile;
  string line;
  errFile.open(ERR_FILE_NAME);
  while (getline(errFile, line)) {
    cout << line << "\n";
  }
  errFile.close();
};

char getCharInput() {
  char input;
  cin >> input;
  if (cin.fail()) { // If invalid input try again
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
  }
  return input;
}

string getStringInput() {
  string input;
  cin >> input;
  if (cin.fail()) { // If invalid input try again
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
  }
  return input;
}

double getDoubleInput() {
  double input;
  cin >> input;
  if (cin.fail()) { // If invalid input try again
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
  }
  return input;
}

void printByPricesUnder(vector<BusRoute> routesList) {
  double priceCap = getDoubleInput();
  printTitleResult();
  for (int i = 0; i < routesList.size(); i++) {
    if (routesList[i].getPrice() <= priceCap) {
      routesList[i].print();
    }
  }
}

void printByDay(vector<BusRoute> routesList) {
  string day = getStringInput();
  printTitleResult();
  for (int i = 0; i < routesList.size(); i++) {
    if (routesList[i].getDay() == day) {
      routesList[i].print();
    }
  }
}

void printByFromAndTo(vector<BusRoute> routesList) {
  string from = getStringInput();
  string to = getStringInput();
  printTitleResult();
  for (int i = 0; i < routesList.size(); i++) {
    if (routesList[i].getFrom() == from && routesList[i].getTo() == to) {
      routesList[i].print();
    }
  }
}
