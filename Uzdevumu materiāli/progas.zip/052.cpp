
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>  
#include <algorithm> 
#include <cctype>

using namespace std;

struct Route {
    string start;
    string end;
    string day;
    string time;
    double price;
};

vector<string> split(const string &s, char delimiter) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

void printRoutes(const vector<Route>& routes, const string& start, const string& end) {
    cout << "result:" << endl;
    for (const Route& route : routes) {
        if (route.start == start && route.end == end) {
            cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }
}

void handleCommandA(vector<Route>& routes) {
    string start, end;
    cout << "Ievadiet sākuma pieturas nosaukumu: ";
    cin >> start;
    cout << "Ievadiet gala pieturas nosaukumu: ";
    cin >> end;
    printRoutes(routes, start, end);
}

void printRoutesOnDay(const vector<Route>& routes, const string& day) {
    cout << "result:" << endl;
    for (const Route& route : routes) {
        if (route.day == day) {
            cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }
}

void handleCommandB(vector<Route>& routes) {
    string day;
    cout << "Ievadiet dienas pazīmējumu (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
    cin >> day;
    printRoutesOnDay(routes, day);
}

void printRoutesUnderPrice(const vector<Route>& routes, double maxPrice) {
    cout << "result:" << endl;
    for (const Route& route : routes) {
        if (route.price <= maxPrice) {
            cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
        }
    }
}

void handleCommandC(vector<Route>& routes) {
    double maxPrice;
    cout << "Ievadiet maksimālo biļetes cenu: ";
    cin >> maxPrice;
    printRoutesUnderPrice(routes, maxPrice);
}

void handleCommandD() {
    ifstream errFile("err.txt");
    if (!errFile) {
        cout << "Nevar atvērt failu err.txt" << endl;
        return;
    }

    cout << "result:" << endl;
    string line;
    while (getline(errFile, line)) {
        cout << line << endl;
    }
}

bool containsDigit(const string &s) {
    return any_of(s.begin(), s.end(), ::isdigit);
}

  int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");
  vector<Route> routes;

  if (!inFile) {
      cout << "Nevar atvērt failu db.csv" << endl;
      return 1;
  }

  string line;
  while (getline(inFile, line)) {
      if (line.empty()) {
          continue;
      }
      vector<string> fields = split(line, ',');
      if (fields.size() != 5) {
          errFile << line << endl;
          continue;
      }
      try {
          Route route;
          route.start = trim(fields[0]);
          route.end = trim(fields[1]);
          route.day = trim(fields[2]);
          route.time = trim(fields[3]);
          if (route.start.empty() || route.end.empty() || route.day.empty() || route.time.empty()) {
              throw std::invalid_argument("Empty field");
          }
          // pārbauda vai pirmie trīs satur ciparus
          if (containsDigit(route.start) || containsDigit(route.end) || containsDigit(route.day)) {
              errFile << line << endl;
              continue; // Skip the rest of this iteration
          }
          route.price = stod(fields[4]);
          routes.push_back(route);
      } catch (const std::invalid_argument& ia) {
          // catch ja nav vienāds skaits field std::stod vai tukšs field
          errFile << line << endl;
      }
  }

 char command;
    do {
        cout << "Ievadiet komandu: ";
        cin >> command;

        switch(command) {
            case 'a':
                handleCommandA(routes);
                break;
            case 'b':
                handleCommandB(routes);
                break;
            case 'c':
                handleCommandC(routes);
                break;
            case 'd':
                handleCommandD();
                break;
        }
    } while (command != 'e');

    return 0;
}