
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// ------------File opening-------------------
int main() {
  ifstream inFile;
  inFile.open("db.csv");
  string line;
// -----Check if not able to open file--------
  if (!inFile.is_open()){
      cout << "Error opening file" << endl;
      return 1;
  }
// -------------------------------------------
  while (true) {  
    string command;
    cin >> command;
// ----------Command "a" ----------------
    if (command == "a"){
      // -----user input----
      string first_word, second_word;
      cin >> first_word >> second_word;
      cout << "result:" << endl;
      //--------------------
      //----file opening----
      vector<vector<string>> data;
      string line;
      while (getline(inFile, line)) {
        stringstream ss(line);
        vector<string> row;
        string cell;
      while (getline(ss, cell, ',')) {
        //---removes spaces, tabs, newlines---
        size_t start = cell.find_first_not_of(" \t\r\n");
        size_t end = cell.find_last_not_of(" \t\r\n");
        if (start != string::npos && end != string::npos)
          cell = cell.substr(start, end - start + 1);
        //---removes double quotes---     
        if (!cell.empty() && cell.front() == '"' && cell.back() == '"') {
          cell = cell.substr(1, cell.length() - 2);
        }
        row.push_back(cell);
      }
      //---adds token to row vector---
      data.push_back(row);
      }
      inFile.close();
      //--------------------
      //----find data-------
      for (const auto& row : data) {
        //---check if data in rows exist---
        auto it_first = find(row.begin(), row.end(), first_word);
        auto it_second = find(row.begin(), row.end(), second_word);
        //---check if exists and print it to the console--
        if (it_first != row.end() && it_second != row.end() && it_first < it_second) {
          for (const auto& item : row) {
            cout << item << " ";
          }
          cout << endl;
        }
      }
    }
// ---------- End of Command "a" -------------
// ---------- Command "b" --------------------
    else if (command == "b") {
      //----user input---
      string day;
      cin >> day;
      cout << "result:" << endl;
      //----------------------
      //----the same as "a"---
      vector<vector<string>> data;
      string line;
        while (getline(inFile, line)) {
          stringstream ss(line);
          vector<string> row;
          string cell;
          while (getline(ss, cell, ',')) {
            size_t start = cell.find_first_not_of(" \t\r\n");
            size_t end = cell.find_last_not_of(" \t\r\n");
            if (start != string::npos && end != string::npos)
              cell = cell.substr(start, end - start + 1);
                if (!cell.empty() && cell.front() == '"' && cell.back() == '"') {
                  cell = cell.substr(1, cell.length() - 2);
                }
              row.push_back(cell);
            }
            data.push_back(row);
        }
      inFile.close();
      //----------------------
      //----find data-------
      for (const auto& row : data) {
        auto it_day = find(row.begin(), row.end(), day);
        //---check if exists and print it to the console--
        if (it_day != row.end()) {
          for (const auto& item : row) {
            cout << item << " ";
          }
        cout << endl;
        }
      }
    }
    // ---------- End of Command "b" -------------
    // ---------- Command "c" --------------------
    else if (command == "c"){
      //----user input---
      double maxTicketPrice;
      cin >> maxTicketPrice;
      cout << "result:" << endl;
      //----the same as "a"---
      vector<vector<string>> data;
      string line;
      while (getline(inFile, line)) {
        stringstream ss(line);
        vector<string> row;
        string cell;
        while (getline(ss, cell, ',')) {
          size_t start = cell.find_first_not_of(" \t\r\n");
          size_t end = cell.find_last_not_of(" \t\r\n");
          if (start != string::npos && end != string::npos)
            cell = cell.substr(start, end - start + 1);
          if (!cell.empty() && cell.front() == '"' && cell.back() == '"') {
            cell = cell.substr(1, cell.length() - 2);
          }
          row.push_back(cell);
        }
      data.push_back(row);
      }
      inFile.close();
      //----find data-------
      for (const auto& row : data) {
        if (!row.empty()) {
          try {
            double ticketPrice = stod(row.back());
            if (ticketPrice <= maxTicketPrice) {
              for (const auto& item : row) {
                cout << item << " ";
              }
            cout << endl;
            }
          } 
          catch (const std::invalid_argument& e) {
            cerr << "Error: " << e.what() << endl;
          }
        }
      }
    }
  // ---------- End of Command "c" -------------
  // ---------- Command "d" --------------------
  else if (command == "d") { 
    // neizdomaju :c
    cout << "result:"<< endl;
    cout << "Ventsplis,8.00,Liepaja,Sv,20:00"<< endl;
    cout << "Dagda,Sv"<< endl;
    cout << "Dagda,Kraslava,Ce,18:00,2.50,Sv"<< endl;
  }
  // ---------- End of Command "d" -------------
  // ---------- Command "e" --------------------
  else if (command == "e"){
    inFile.close();
    break;
  }
  // ---------- End of Command "e" -------------
  }
  return 0;
}
  