#include <algorithm>
#include <fstream>
#include <iostream>
#include <regex>
#include <vector>

using namespace std;

struct route {
  string from;
  string to;
  string day;
  string time;
  string price;
};

vector<string> daysOfWeek = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

void printRoute(route r) {
  cout << r.from << ' ';
  cout << r.to << ' ';
  cout << r.day << ' ';
  cout << r.time << ' ';
  cout << r.price << endl;
}

string trim(string str) {
  return str.substr(str.find_first_not_of(" \t"),
                    str.find_last_not_of(" \t") + 1);
}

vector<string> splitString(string str, char del) {
  vector<string> out;
  int index = str.find(del);
  while (index != -1) {
    out.push_back(str.substr(0, index));
    str = str.substr(index + 1, str.size());
    index = str.find(del);
  }
  out.push_back(str);
  return out;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  ofstream outFile;
  outFile.open("err.txt");

  vector<route> routes;
  string s;

  while (getline(inFile, s)) {
    vector<string> split = splitString(s, ',');
    if (split.size() != 5 ||
        find(daysOfWeek.begin(), daysOfWeek.end(), trim(split[2])) ==
            daysOfWeek.end() ||
        !regex_match(trim(split[3]), regex("\\d{2}:\\d{2}")) ||
        !regex_match(trim(split[4]), regex("\\d*\\.\\d{2}"))) {
      if (!s.empty())
        outFile << s << endl;
    } else {
      route r;
      r.from = trim(split[0]);
      r.to = trim(split[1]);
      r.day = trim(split[2]);
      r.time = trim(split[3]);
      r.price = trim(split[4]);
      routes.push_back(r);
    }
  }
  outFile.close();
  inFile.close();

  string commandInput;
  char command;
  string from;
  string to;
  string day;
  string price;
  string output;
  while (true) {
    cin >> commandInput;
    if (commandInput.size() != 1) {
      command = ' ';
    } else {
      command = commandInput[0];
    }
    switch (command) {
    case ('a'):
      cin >> from;
      cin >> to;
      cout << "result:" << endl;
      for (route r : routes) {
        if (r.from == from && r.to == to)
          printRoute(r);
      }
      break;
    case ('b'):
      cin >> day;
      cout << "result:" << endl;
      for (route r : routes) {
        if (r.day == day)
          printRoute(r);
      }
      break;
    case ('c'):
      cin >> price;
      cout << "result:" << endl;
      for (route r : routes) {
        if (regex_match(price, regex("\\d*\\.\\d{2}")) &&
            stod(r.price) <= stod(price))
          printRoute(r);
      }
      break;
    case ('d'):
      inFile.open("err.txt");
      cout << "result:" << endl;
      while (getline(inFile, output)) {
        cout << output << endl;
      }
      inFile.close();
      break;
    case ('e'):
      return 0;
    }
  }
}