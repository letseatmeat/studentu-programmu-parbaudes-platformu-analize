
#include <iostream>
#include <fstream>
#include <iomanip> 

using namespace std;
string converBiletesCenaToStr(double cena){
  string cenaStr = "";
   stringstream ss;
    ss <<fixed << setprecision(2) << cena;
  cenaStr= ss.str();
  return cenaStr; 
}
int irLaiks(string laiks){
  string hh="",mm="",specialSymbol=":";
  try{
    hh=laiks.substr(0,2);
    mm=laiks.substr(3,2);
    stoi(hh);
    stoi(mm);
    string tempData=laiks.substr(2,1);
    if(tempData!=specialSymbol||laiks.length()!=5) return 0;
  }catch(exception e){
    return 0;
  }
  return 1;
}
string removeSpaces(string str) 
{ 
  string newString="";
   for(char c : str){
     if(c != ' ') newString=newString+c;
   }
    return newString; 
} 
string tekstsIrNepareizs(string line){
  int curPos = 0,curElementNumber=0;
  string tempData;
  string sakumaPietura="",beigumaPietura="",nedelasDiena="",laiks="";

  string dienas[7] {"Pr", "Ot", "Tr","Ce","Pt","St","Sv"};
  double biletesCena;

  while ((curPos=line.find(','))!=string::npos) {
    tempData = line.substr(0, curPos);
    tempData=removeSpaces(tempData);
    if(curElementNumber==0){
        sakumaPietura=tempData;
    }
    else if(curElementNumber==1){
        beigumaPietura=tempData;
    }
    else if(curElementNumber==2){
        nedelasDiena=tempData;
      bool isDiena=false;
        for(int i=0;i<7;i++) if(nedelasDiena==dienas[i]) isDiena=true;
        if(isDiena==false) return "";
      }
    else if(curElementNumber==3){ 
        laiks=tempData;
      if(!irLaiks(laiks)) return "";
      }
      line.erase(0, curPos + 1);
      curElementNumber++;
    if(curElementNumber==4){
        try{
          biletesCena=stod(line);
        }catch(exception e){
          return "";
        }
      curElementNumber++;
    }
  }
  if(curElementNumber==5) {
    string returnTeksts=sakumaPietura + " " + beigumaPietura + " " + nedelasDiena + " " + laiks + " " + converBiletesCenaToStr(biletesCena);
    return returnTeksts;
  }
  else {
    return "";
  }
  }
void izvaditreisuspieturas() {
  cout << "result:"<< endl;
  string pirmapietura="",otrapietura="";
  cin >> pirmapietura;
  cin >> otrapietura;

  fstream infile("db.csv", ios::in);

  string s,pirmaPieturaFromLine="",otraPieturaFromLine=""; 
  if (infile.is_open()) {
    while (getline(infile, s)) {


        pirmaPieturaFromLine="";otraPieturaFromLine="";

        string formatetsUnParbauditsTeksts=tekstsIrNepareizs(s);

        if(formatetsUnParbauditsTeksts.length()>1){
          int firstSpacePos=formatetsUnParbauditsTeksts.find(' ');

          pirmaPieturaFromLine=formatetsUnParbauditsTeksts.substr(0,firstSpacePos);
          int secondSpacePos=formatetsUnParbauditsTeksts.find(' ',firstSpacePos+1);

          otraPieturaFromLine=formatetsUnParbauditsTeksts.substr(firstSpacePos+1,secondSpacePos-firstSpacePos-1);

          if(pirmaPieturaFromLine==pirmapietura && otraPieturaFromLine==otrapietura) cout << formatetsUnParbauditsTeksts << endl;
      }

    }
      infile.close();
}
}

void izvaditreisusdiena() {
  cout << "result:"<< endl;
  string diena="";
  cin >> diena;
  fstream infile("db.csv", ios::in);
  string s,lineDiena=""; 
  if (infile.is_open()) {
    while (getline(infile, s)) {

      lineDiena="";

    string formatetsUnParbauditsTeksts=tekstsIrNepareizs(s);
    if(formatetsUnParbauditsTeksts.length()>1){
      int firstSpacePos=formatetsUnParbauditsTeksts.find(' ');
      int secondSpacePos=formatetsUnParbauditsTeksts.find(' ',firstSpacePos+1);
        lineDiena=formatetsUnParbauditsTeksts.substr(secondSpacePos+1,2);

      if(lineDiena==diena) cout << formatetsUnParbauditsTeksts << endl;
    }
  }
  infile.close();
  }
}

void izvaditreisuscena() {
  cout << "result:"<< endl;
  double cena;
  cin >> cena;
  fstream infile("db.csv", ios::in);

  string s;
  double lineCena=0; 
    if (infile.is_open()) {
      while (getline(infile, s)) {

        lineCena=0;

    string formatetsUnParbauditsTeksts=tekstsIrNepareizs(s);

    if(formatetsUnParbauditsTeksts.length()>1){
      int firstSpacePos=formatetsUnParbauditsTeksts.find(' ');
      int secondSpacePos=formatetsUnParbauditsTeksts.find(' ',firstSpacePos+1);
      int thirdSpacePos=formatetsUnParbauditsTeksts.find(' ',secondSpacePos+1);
      int fourSpacePos=formatetsUnParbauditsTeksts.find(' ',thirdSpacePos+1);
      int fivthSpacePost=formatetsUnParbauditsTeksts.find(' ',fourSpacePos+1);

      try{
          lineCena=stod(formatetsUnParbauditsTeksts.substr(fourSpacePos+1,fivthSpacePost-fourSpacePos-1));
      }catch(exception e){

      }

      if(cena>=lineCena) cout << formatetsUnParbauditsTeksts << endl;
    }
  }
  infile.close();
    }
}

void izveidotErrorsFile() {
  fstream infile("db.csv", ios::in);
  string line; 
  ofstream outFile("err.txt");
  bool firstLine=true;
  if (infile.is_open()) {
    if (outFile.is_open()) {

        while (getline(infile, line)) {
         string formatetsUnParbauditsTeksts=tekstsIrNepareizs(line);
          if(formatetsUnParbauditsTeksts==""&&line!=""&&line.length()>1){
            if(firstLine){
              outFile << line;
              firstLine=false;
            }
            else {
              outFile << endl << line;
            }
          }
        }


       outFile.close(); 
    } 
    infile.close();
  }
}
void izvaditerrors(){
  cout << "result:" << endl;
  string line;
  bool firstLine=true;
  fstream infile("err.txt", ios::in);
  if (infile.is_open()) {
    while (getline(infile, line)) {
      
        cout << line << endl;
      
       
    }
      infile.close();
  }
}
int main() {


  char command;
  bool loop = true;
  izveidotErrorsFile();
  while (loop) {
  cin >> command;
    switch (command) {
        case 'a': izvaditreisuspieturas();break;
        case 'b': izvaditreisusdiena(); break;
        case 'c': izvaditreisuscena(); break;
        case 'd': izvaditerrors(); break;
       case 'e': loop = false; break;
    }
  }
  return 0;
} 