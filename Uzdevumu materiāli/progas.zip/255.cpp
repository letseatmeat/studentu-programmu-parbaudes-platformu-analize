﻿
#include <iostream>
#include <fstream> 
#include <regex>
using namespace std;
void arrayRes(string Array[], int len) { // it is possible to make this funxtion for all arrays? int string....
	//cout << "result:";
	for (int i = 0; i < len; i++) {
		cout << Array[i];
		if (i != len - 1) { //I don't like it
			cout << " ";
		}
	};
	cout << endl;
}
string TrimSpacesBeginEnd(string parsed) {
	int firstNotSpace = parsed.find_first_not_of(' ');
	int lastNotSpace = parsed.find_last_not_of(' ');
	if (firstNotSpace > 0) return parsed.erase(0, firstNotSpace);
	if (lastNotSpace != parsed.length() - 1) return parsed.erase(lastNotSpace + 1, parsed.length() - 1);
	return parsed;
}
bool StringParserToArray(string s, string parsed[5], string delimiter = ",") {
	// if any of elements is empty, when false
	int pos = 0;
	int cnt = 0;
	while ((pos = s.find(delimiter)) != std::string::npos) {
		if (cnt > 3) return false;
		pos = s.find(delimiter);
		parsed[cnt] = TrimSpacesBeginEnd(s.substr(0, pos));
		if (parsed[cnt] == "") return false;
		//cout << endl << parsed[cnt];
		cnt++;
		s.erase(0, pos + delimiter.length());
	}
	parsed[cnt] = TrimSpacesBeginEnd(s);//how to fix it inside the loop, I got pos = -1
	return true;
}
void CopiesDeleterInFile(string FileName) {
	//It Make new file to write not the same strings 
	// after that rewrite FileName.
	string buffer;
	ifstream MyReadFile(FileName);
	vector <string> StringsInFile;
	int cnt = 0;
	while (getline(MyReadFile, buffer)) {
		StringsInFile.push_back(buffer);
		cnt++;
	}
	MyReadFile.close();

	bool flag = false;
	int FileLen = StringsInFile.size();
	ofstream NewFile("BufferTorewriteFile.csv");
	for (int i = 0; i < FileLen;i++) {
		flag = false;
		for (int a = i + 1;a < FileLen;a++) {
			if (StringsInFile[i] == StringsInFile[a]) flag = true;//copy exist
		}
		if (!flag) NewFile << StringsInFile[i] << endl;
	}
	NewFile.close();
	//buffer NewFile copy to oldFile
	ofstream RewriteFile(FileName);
	ifstream NewFile1("BufferTorewriteFile.csv");

	while (getline(NewFile1, buffer)) {
		RewriteFile << buffer << endl;
	}
	NewFile1.close();
	RewriteFile.close();
	remove("BufferTorewriteFile.csv");
}
void FileMakerWithoutGapsErrorsDublicates(string bufferName, ifstream& MyReadFile, ofstream& ErrorFile) {// Can be done better, but I already wrote all functions
	// Delete Dublicates, Gaps, and made error file for all error strings
	// Check errors in data format,amount off elements and make file with error strings
	string buffer = "";
	string ParsedString[5];
	bool flag = true;
	bool DateFlag = true;
	regex Timepattern("\\d\\d:\\d\\d");
	regex Costpattern("\\d\\d.\\d\\d");
	string allDays[7] = { "Pr", "Ot", "Tr", "Ce", "Pt", "Se", "Sv" };
	ofstream bufferFile(bufferName);
	while (getline(MyReadFile, buffer)) {
		flag = true;// if String in Correct
		if (!StringParserToArray(buffer, ParsedString) || buffer == "") {// if void 
			flag = false;

		}
		else if (!regex_match(ParsedString[3], Timepattern)) {
			flag = false;

		}
		else if (!flag)
			for (int i = 0; i < 7; ++i) {//Day Format Check
				if (ParsedString[2] == allDays[i]) {
					DateFlag = true;
					break;
				}
			}
		if (!DateFlag) flag = false;
		try {
			stof(ParsedString[4]); //Try to convert to Float
		}
		catch (...) {
			flag = false;
		}
		if (flag == false && buffer != "") {
			ErrorFile << buffer << endl;
			continue;
		}
		else if (flag) {
			for (int cnt = 0;cnt <= 4;cnt++) {
				//cout<<ParsedString[cnt];
				bufferFile << ParsedString[cnt];
				if (cnt != 4) bufferFile << ",";
			}
			bufferFile << endl;
		}

	}
	bufferFile.close();
	//check if bufferFile contains dublicates
	CopiesDeleterInFile(bufferName);

}

void RouteFinder(string ParsedString[5], string InitialStop, string LastStop) {
	if (ParsedString[0] == InitialStop && ParsedString[1] == LastStop) {
		arrayRes(ParsedString, 5);
	}
	//else arrayRes(ParsedString, 5);
}
void PriceLowerThan(string ParsedString[5], float Price) {

	if ((int)(stof(ParsedString[4]) * 100) < (int)(Price * 100)) {//I don't like it.
		arrayRes(ParsedString, 5);
	}
}
void DayFinder(string ParsedString[5], string Day) {
	if (ParsedString[2] == Day) {
		arrayRes(ParsedString, 5);
	}


}

int main() {
	// Create a text string, which is used to output the text file
	string ParsedString[5];
	string input;
	// Read from the text file
	ifstream MyReadFile("db.csv");
	ofstream ErrorFile("err.txt");
	string buffer = "";
	//
	FileMakerWithoutGapsErrorsDublicates("buffer.csv", MyReadFile, ErrorFile);
	// all done, Corredcted data located in buffer.csv
	MyReadFile.close();
	ErrorFile.close();

	while (input != "e") {
		ifstream ErrorFile1("err.txt");
		//
		ifstream MyReadFile1("buffer.csv");
		input = "";
		cin >> input;
		string InitialStop;
		string LastStop;
		string Day;
		float Price;
		string time;
		if (input == "a") {
			cin >> InitialStop;
			cin >> LastStop;
		}
		else if (input == "b") cin >> Day;
		else if (input == "c")cin >> Price;
		if (input == "a" || input == "b" || input == "c") {
			cout << "result:" << endl;// begin File reading
			while (getline(MyReadFile1, buffer)) {
				StringParserToArray(buffer, ParsedString);
				if (input == "a") RouteFinder(ParsedString, InitialStop, LastStop);
				else if (input == "b") DayFinder(ParsedString, Day);
				else if (input == "c")PriceLowerThan(ParsedString, Price);
			}
		}
		if (input == "d") {
			cout << "result:" << endl;
			while (getline(ErrorFile1, buffer)) {
				cout << buffer << endl;
			}
		}
		MyReadFile1.close();
		ErrorFile.close();
	}
	remove("buffer.csv");
}
