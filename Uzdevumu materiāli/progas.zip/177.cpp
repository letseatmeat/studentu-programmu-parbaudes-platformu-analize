

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

const int MAX_BUS_ROUTES = 1000;

struct RouteInfo {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};

// Funkcija, kas analizē teksta rindu un pārvērš to par RouteInfo struktūru
bool parseRouteInfo(const string &line, RouteInfo &route) {
  istringstream ss(line);
  string field;

  // Pārbauda, vai var izgūt visus laukus no rindas
  if (getline(ss, route.startStop, ',') && getline(ss, route.endStop, ',') &&
      getline(ss, route.dayOfWeek, ',') && getline(ss, route.time, ',') &&
      ss >> route.ticketPrice) {
    string extraText;
    getline(ss, extraText);
    // Pārbauda, vai ir kāds lieks teksts pēc cenas
    if (!extraText.empty()) {
      ofstream errorFile("err.txt", ios::app);
      errorFile.close();
      return false;
    }
    return true;
  }
  return false;
}

// Funkcija, kas izvada RouteInfo informāciju uz ekranu
void printRouteInfo(const RouteInfo &route) {
  printf("%s %s %s %s %.2f\n", route.startStop.c_str(), route.endStop.c_str(),
         route.dayOfWeek.c_str(), route.time.c_str(), route.ticketPrice);
}

// Funkcija, kas noņem tukšumus no rindas un veic citas korekcijas
void fixSpaces(string &line) {
  string result;
  for (char c : line) {
    if (!isspace(c)) {
      result += c;
    }
  }
  line = result;
  line.erase(0, line.find_first_not_of(" \t\r\n"));
  line.erase(line.find_last_not_of(" \t\r\n") + 1);
}

int main() {
  // Izdzēš esošo err.txt failu, ja tas eksistē
  remove("err.txt");

  // Atver ieejas un kļūdu failus
  ifstream inputFile("db.csv");
  ofstream errorFile("err.txt");

  // Pārbauda, vai failu atvēršana bija veiksmīga
  if (!inputFile.is_open() || !errorFile.is_open()) {
    return 1;
  }

  // Izveido masīvu maršruta datu glabāšanai
  RouteInfo busRoutes[MAX_BUS_ROUTES];
  int routeCount = 0;

  char query;
  // Bezgalīgs cikls, kamēr lietotājs neievada "e"
  while (true) {
    // Ievada lietotāja izvēli (a, b, c, d vai e)
    cin >> query;
    cin.ignore(123, '\n');

    // Iziet no cikla, ja lietotājs ievada "e"
    if (query == 'e') {
      break;
    }

    // Izmest cikla iterāciju, ja ievadīta nekorekta izvēle
    if (query != 'a' && query != 'b' && query != 'c' && query != 'd') {
      continue;
    }

    string line;
    // Ielasīt katru rindu no faila
    while (getline(inputFile, line)) {
      // Korektēt tukšumus un veikt citas korekcijas
      fixSpaces(line);

      // Ja rinda ir tukša, izlaist iterāciju
      if (line.empty()) {
        continue;
      }

      // Pārbaudīt, vai ir vēl vieta masīvā
      if (routeCount < MAX_BUS_ROUTES) {
        RouteInfo route;
        // Mēģināt izparsēt rindu un saglabāt masīvā, ja izdodas
        if (parseRouteInfo(line, route)) {
          busRoutes[routeCount++] = route;
        } else {
          // Ja nepaveicas, ierakstīt rindu kļūdu failā
          errorFile << line << endl;
        }
      } else {
        break;
      }
    }

    // Izpildīt atbilstošo darbību, atkarībā no lietotāja izvēles
    switch (query) {
    case 'a': {
      string start, end;
      // Ievadīt sākuma un gala pieturas nosaukumus
      cin >> start;
      cin >> end;
      cout << "result:" << endl;
      // Izvadīt maršrutus, kas atbilst ievadei
      for (int i = 0; i < routeCount; ++i) {
        if (busRoutes[i].startStop == start && busRoutes[i].endStop == end) {
          printRouteInfo(busRoutes[i]);
        }
      }
      break;
    }
    case 'b': {
      string day;
      // Ievadīt nedēļas dienu
      cin >> day;
      cout << "result:" << endl;
      // Izvadīt maršrutus, kas kursē konkrētajā nedēļas dienā
      for (int i = 0; i < routeCount; ++i) {
        if (busRoutes[i].dayOfWeek == day) {
          printRouteInfo(busRoutes[i]);
        }
      }
      break;
    }
    case 'c': {
      double maxPrice;
      // Ievadīt maksimālo biļetes cenu
      cin >> maxPrice;
      cout << "result:" << endl;
      // Izvadīt maršrutus, kuru biļetes cena nepārsniedz ievadīto vērtību
      for (int i = 0; i < routeCount; ++i) {
        if (busRoutes[i].ticketPrice <= maxPrice) {
          printRouteInfo(busRoutes[i]);
        }
      }
      break;
    }
    case 'd':
      cout << "result:" << endl;
      ifstream errorFile("err.txt");
      string errorLine;
      // Izvadīt kļūdu faila saturu
      while (getline(errorFile, errorLine)) {
        cout << errorLine << endl;
      }
      break;
    }

    // Atiestatīt faila nolasa pozīciju uz sākumu
    inputFile.clear();
    inputFile.seekg(0, ios::beg);
  }

  // Aizvērt failus
  inputFile.close();
  errorFile.close();

  return 0;
}