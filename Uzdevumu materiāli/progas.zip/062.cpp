

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;
struct Reisi {
    string Pietura1;
    string Pietura2;
    string Diena;
    string Laiks;
    double Cena;
};
bool komati(const string& rinda) {
    size_t komatuSkaits = count(rinda.begin(), rinda.end(), ',');

    if (komatuSkaits != 4) {
        return false;
    }

    return true;
}

vector<Reisi> readPieturas(const string& file1) {
    vector<Reisi> r2;
    ifstream file(file1);



    string rinda;
    while (getline(file, rinda)) {
        rinda.erase(remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());
        if (rinda.empty()) {
            continue;
        }
        if (!komati(rinda)) {
            ofstream newFile("err.txt", ios::app);
            newFile << rinda << endl;
            continue;
        }stringstream s(rinda);
        Reisi r;
        try {
            getline(s, r.Pietura1, ',');
            getline(s, r.Pietura2, ',');
            getline(s, r.Diena, ',');
            getline(s, r.Laiks, ',');

            string cenaStr;
            getline(s, cenaStr, ',');
            r.Cena = stod(cenaStr);
            string extra;
            if (getline(s, extra)) {
                ofstream newFile("err.txt", ios::app);

                continue;
            }

            size_t commasCount = count(rinda.begin(), rinda.end(), ',');

            if (commasCount != 4) {
                ofstream newFile("err.txt", ios::app);
                continue;
            }

            if (r.Diena != "Pr" && r.Diena != "Ot" && r.Diena != "Tr" && r.Diena != "Ce" && r.Diena != "Pt" && r.Diena != "St" && r.Diena != "Sv") {
                ofstream file("err.txt", ios::app);
                file << "" << rinda << endl;
                continue;
            }

            r2.push_back(r);
        } catch (...) {
            ofstream file("err.txt", ios::app);
            file  << rinda << endl;
            continue;
        }
    }
    file.close();
    return r2;
}
void printJaunsfails() {
    ifstream file("err.txt");
    cout << "result:" << endl;

    if (file.is_open()) {
        string rinda;
        while (getline(file, rinda)) {
            cout << rinda << endl;
        }
        file.close();
    }


}
void printPietura(const vector<Reisi>& r2, const string& pietura1, const string& pietura2) {
    cout << "result:" << endl;
    for (const auto& r : r2) {
        if (r.Pietura1 == pietura1 && r.Pietura2 == pietura2) {
            cout << r.Pietura1 << " " << r.Pietura2 << " " << r.Diena << " "<< r.Laiks << " " << fixed << setprecision(2) << r.Cena << endl;
        }
    }
}

void printDiena(const vector<Reisi>& r2, const string& dayOfWeek){
    cout << "result:" << endl;
    for (const auto& r : r2) {
        if (r.Diena == dayOfWeek) {
            cout << r.Pietura1 << " " << r.Pietura2 << " " << r.Diena << " " << r.Laiks << " " << fixed << setprecision(2) << r.Cena << endl;
        }
    }
}

void printCena(const vector<Reisi>& r2, double maxCena) {
    cout << "result:" << endl;
    for (const auto& r : r2) {
        if (r.Cena <= maxCena) {
          cout << r.Pietura1 << " " << r.Pietura2 << " " << r.Diena << " "<< r.Laiks << " " << fixed << setprecision(2) << r.Cena << endl;
        }
    }
}



int main() {
    vector<Reisi> r2 = readPieturas("db.csv");

    char ch;
    do {

        cin >> ch;

        switch (ch) {
            case 'a': {
                string pietura1, pietura2;
                cin >> pietura1;
                cin >> pietura2;
                printPietura(r2, pietura1, pietura2);
                break;
            }
            case 'b': {
                string diena;

                cin >> diena;
                printDiena(r2, diena);
                break;
            }
            case 'c': {
                double maxCena;
                cin >> maxCena;
                printCena(r2, maxCena);
                break;
            }
            case 'd':
                printJaunsfails();
                break;
            case 'e':
                break;

        }
    } while (ch != 'e');

    return 0;
}
