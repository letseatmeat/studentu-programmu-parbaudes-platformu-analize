
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

struct Route {
  string start;
  string end;
  string day;
  string time;
  double price;
};


void printRoute(const Route& route) {
    cout << route.start << " " << route.end << " "
         << route.day << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
}

void printRoutes(const vector<Route>& routes) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        printRoute(route);
    }
}


bool checkRoute(const string& line, Route& route) {
    istringstream iss(line);
    vector<string> tokens;
    string token;

    while (getline(iss, token, ',')) {
        token = token.substr(token.find_first_not_of(" \t"), token.find_last_not_of(" \t") + 1);
        tokens.push_back(token);
    }

    if (tokens.size() != 5) {
        return false;
    }

    // Pārbaudiet vai sākumā ir derīgs pilsētas nosaukums
    if (tokens[0].empty() || !isalpha(tokens[0][0])) {
        return false;
    }

    // Pārbaudiet, vai beigas ir derīgs pilsētas nosaukums
    if (tokens[1].empty() || !isalpha(tokens[1][0])) {
        return false;
    }

    // Pārbaudiet, vai diena ir derīgs divu burtu saīsinājums
    if (tokens[2].length() != 2 || !isalpha(tokens[2][0]) || !isalpha(tokens[2][1])) {
        return false;
    }

    route.start = tokens[0];
    route.end = tokens[1];

    // Pārbaudiet, vai laiks ir formātā HH:MM
    if (tokens[3].length() != 5 || tokens[3][2] != ':' || !isdigit(tokens[3][0]) || !isdigit(tokens[3][1]) ||
        !isdigit(tokens[3][3]) || !isdigit(tokens[3][4])) {
        return false;
    }

    route.day = tokens[2];

    // Mēģiniet pārvērst cenu to double
    try {
        route.time = tokens[3];
        route.price = stod(tokens[4]);

        // Pārbaudiet, vai cena nav negatīva
        if (route.price < 0) {
            return false;
        }

        return true;
    } catch (...) {
        return false;
    }
}

int main() {
  
  ifstream inFile("db.csv");
  ofstream errFile("err.txt", ios::trunc);

  if (!inFile || !errFile) {
    cout << "kļūda atverot failu." << endl;
    return 0;
  }

  vector<Route> routes;
  string line;

  while (getline(inFile, line)) {
      Route route;
      if (checkRoute(line, route)) {
          routes.push_back(route);
      } else if (!line.empty()) {
          errFile << line << endl;
      }
  }
  
    char choice;
    do {
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start;
                cin >> end;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.start == start && route.end == end) {
                        printRoute(route);
                    }
                }
                break;
            }
          
            case 'b': {
                string day;
                cin >> day;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.day == day) {
                        printRoute(route);
                    }
                }
                break;
            }
          
            case 'c': {
                double maxPrice;
                cin >> maxPrice;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.price <= maxPrice) {
                        printRoute(route);
                    }
                }
                break;
            }
          
            case 'd': {
                ifstream errorFile("err.txt");
                if (errorFile.is_open()) {
                    cout << "result:" << endl;
                    string line;
                    while (getline(errorFile, line)) {
                        cout << line << endl;
                    }
                    errorFile.close();
                } 
                break;
            }
          
            case 'e':
                break;
            default:
                cout << "Nepareiza izvēle. Mēģiniet vēlreiz.\n";
        }
    } while (choice != 'e');

    return 0;
}
