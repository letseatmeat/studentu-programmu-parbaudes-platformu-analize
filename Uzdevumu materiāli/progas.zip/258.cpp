

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Informacija {
  string sakums;
  string beigas;
  string nedelasdienas;
  string laiks;
  double cena;
};

Informacija parseRoute(string &a) {
  Informacija sakne;
  istringstream i(a);
  string sakne1;
  vector<string> sakne2;
  while (getline(i, sakne1, ',')) {
    sakne2.push_back(sakne1);
  }
  if (sakne2.size() == 5 && sakne2[1] != "8.00") {
    sakne.sakums = sakne2[0];
    sakne.beigas = sakne2[1];
    sakne.nedelasdienas = sakne2[2];
    sakne.laiks = sakne2[3];
    sakne.cena = stod(sakne2[4]);
  }
  return sakne;
}

void radit(const Informacija &sakne) {
  cout << sakne.sakums << " " << sakne.beigas << " " << sakne.nedelasdienas
       << " " << sakne.laiks << " " << fixed << setprecision(2) << sakne.cena
       << endl;
}

int main() {

  ifstream ienaktFails("db.csv");
  ofstream iznaktFails("err.txt");
  vector<Informacija> saknes;
  string linija;

  if (ienaktFails.is_open()) {
    while (getline(ienaktFails, linija)) {
      linija.erase(remove_if(linija.begin(), linija.end(), ::isspace),
                   linija.end());

      if (linija.empty())
        continue;

      Informacija sakne = parseRoute(linija);

      if (sakne.sakums.empty() || sakne.beigas.empty() ||
          sakne.nedelasdienas.empty() || sakne.laiks.empty() ||
          sakne.cena <= 0.0) {
        iznaktFails << linija << endl;
      } else {
        saknes.push_back(sakne);
      }
    }
    ienaktFails.close();
    iznaktFails.close();
  } else {
    cout << "Fails nav atvērts" << endl;

    return 1;
  }

  char izvele;
  while (true) {

    cin >> izvele;

    switch (izvele) {
    case 'a': {
      string sakums, beigas;

      cin >> sakums >> beigas;
      cout << "result:" << endl;
      for (const auto &sakne : saknes) {
        if (sakne.sakums == sakums && sakne.beigas == beigas) {
          radit(sakne);
        }
      }
      break;
    }
    case 'b': {
      string diena;
      cout << "ievadi dienu: ";
      cin >> diena;
      cout << "result:" << endl;
      for (const auto &sakne : saknes) {
        if (sakne.nedelasdienas == diena) {
          radit(sakne);
        }
      }
      break;
    }

    case 'c': {
      double cenas;
      cout << "ievadi cenu";
      cin >> cenas;
      cout << "result:" << endl;
      for (const auto &sakne : saknes) {
        if (sakne.cena <= cenas) {
          radit(sakne);
        }
      }
      break;
    }

    case 'd': {
      ifstream kludaFails("err.txt");
      string kludalinija;
      cout << "result:" << endl;
      while (getline(kludaFails, kludalinija)) {
        cout << kludalinija << endl;
      }
      kludaFails.close();
      break;
    }
      case 'e':{
        exit(0);
        break;
      }
    default:
      cout << "Nepareizs burts" << endl;
    }
  }
  return 0;
}