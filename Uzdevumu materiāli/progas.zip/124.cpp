#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <cstddef>

using namespace std;

struct Route {
    string startStop;
    string finalStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

vector<Route> readRoutes(string filename) {
    ifstream inFile(filename);
    vector<Route> routes;
    ofstream errFile("err.txt");
    string line;
    string lastErrLine;

    auto trim = [](string &str) {
        size_t start = str.find_first_not_of(' '); 
        size_t end = str.find_last_not_of(' ');
        str = str.substr(start, end - start + 1);
    };

  auto isTime = [](string &str) {
      return str.length() == 5 && isdigit(str[0]) && isdigit(str[1]) && str[2] == ':' && isdigit(str[3]) && isdigit(str[4]);
  };

    while (getline(inFile, line)) {
        stringstream ss(line);
        string startStop, finalStop, dayOfWeek, time;
        double ticketPrice;
        int fieldCount = 0;
        string field;

        while (getline(ss, field, ',')) {
            ++fieldCount;
        }

        ss.clear();
        ss.str(line);

        if (fieldCount == 5 && getline(ss, startStop, ',') && getline(ss, finalStop, ',') &&
            getline(ss, dayOfWeek, ',') && getline(ss, time, ',') &&
            ss >> ticketPrice) {
            trim(startStop);
            trim(finalStop);
            trim(dayOfWeek);
            trim(time);
            routes.push_back({startStop, finalStop, dayOfWeek, time, ticketPrice});
        } else {
            errFile << line << endl;
        }
    }

    return routes;
}

void displayRoutes(const vector<Route>& routes) {
    for (const auto& route : routes) {
        cout << route.startStop << " " << route.finalStop << " " << route.dayOfWeek << " "
             << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
    }
}

void displayErrFile() {
    ifstream errFile("err.txt");
    string line;

    while (getline(errFile, line)) {
            cout << line << endl;
    }
}

int main() {
    vector<Route> routes = readRoutes("db.csv");
    char command;

    while (cin >> command && command != 'e') {
        if (command == 'a') {
            string startStop, finalStop;
            cin >> startStop >> finalStop;
            cout << "result:" << endl;
            for (const auto& route : routes) {
                if (route.startStop == startStop && route.finalStop == finalStop) {
                    displayRoutes({route});
                }
            }
        } else if (command == 'b') {
            string dayOfWeek;
            cin >> dayOfWeek;
            cout << "result:" << endl;
            for (const auto& route : routes) {
                if (route.dayOfWeek == dayOfWeek) {
                    displayRoutes({route});
                }
            }
        } else if (command == 'c') {
            double maxPrice;
            cin >> maxPrice;
            cout << "result:" << endl;
            for (const auto& route : routes) {
                if (route.ticketPrice <= maxPrice) {
                    displayRoutes({route});
                }
            }
        } else if (command == 'd') {
            cout << "result:" << endl;
            displayErrFile();
        }
    }

    return 0;
}