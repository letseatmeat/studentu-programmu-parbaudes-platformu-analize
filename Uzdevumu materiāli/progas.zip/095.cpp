
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>



struct Route {
  std::string sakums;
  std::string beigas;
  std::string diena;
  std::string laiks;
  double cena;
};



bool Parbaude(const std::vector<std::string>& tokens) {

  if (tokens.size() != 5) {
    return false;
  }

  size_t colonPos = tokens[3].find(':');
  if (colonPos == std::string::npos) {
    return false;
  }

  try {
    std::stod(tokens[4]);
  } catch (const std::exception &) {
    return false;
  }

  return true;
}



std::string atstarpes(const std::string &str) {
  size_t first = str.find_first_not_of(' ');

  if (std::string::npos == first) {
    return str;
  }

  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}



bool tukss(const std::string &str) {
  return std::all_of(str.begin(), str.end(), ::isspace);
}



std::vector<Route> visiMarsruti(const std::string &filePath, std::ofstream &errFile) {
  std::vector<Route> marsruts;
  std::ifstream file(filePath);
  std::string line;

  while (std::getline(file, line)) {
    if (line.empty() || tukss(line))
      continue;

    std::stringstream ss(line);
    std::string item;
    std::vector<std::string> tokens;

    while (std::getline(ss, item, ',')) {
      tokens.push_back(atstarpes(item));
    }

    if (!Parbaude(tokens)) {
      errFile << line << '\n';
      continue;
    }

    try {
      Route newRoute = {tokens[0], tokens[1], tokens[2], tokens[3], std::stod(tokens[4])};
      marsruts.push_back(newRoute);
    } catch (const std::exception &e) {
      errFile << line << " Error: " << e.what() << '\n';
    }
  }

  file.close();
  return marsruts;
}



void izvadMarsrutus(const std::vector<Route> &marsruts) {

  for (const auto &route : marsruts) {
    std::cout << route.sakums << " " << route.beigas << " " << route.diena << " " << route.laiks << " " << std::fixed << std::setprecision(2) << route.cena << '\n';
  }

}



int main() {

  std::ofstream errFile("err.txt");
  std::vector<Route> marsruts = visiMarsruti("db.csv", errFile);
  errFile.close();
  char komanda;



  do {
    std::cin >> komanda;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');



    switch (komanda) {



    case 'a': {
      std::string asakums, abeigas;

      std::getline(std::cin, asakums);
      std::getline(std::cin, abeigas);
      std::cout << "result:" << std::endl;

      for (const auto &route : marsruts) {
        if (route.sakums == asakums && route.beigas == abeigas) {
          izvadMarsrutus({route});
        }
      }

      break;
    }



    case 'b': {
      std::string bdiena;

      std::getline(std::cin, bdiena);

      std::cout << "result:" << std::endl;
      for (const auto &route : marsruts) {
        if (route.diena == bdiena) {
          izvadMarsrutus({route});
        }
      }
      break;
    }



    case 'c': {
      double maxcena;

      std::cin >> maxcena;
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

      std::cout << "result:" << '\n';

      for (const auto &route : marsruts) {
        if (route.cena <= maxcena) {
          izvadMarsrutus({route});
        }
      }

      break;
    }



    case 'd': {
      std::ifstream infile("err.txt");

      if (!infile.is_open()) {
        std::cout << "Nevar atvērt err failu." << std::endl;
      } else {
        std::cout << "result:" << '\n';
        infile.seekg(0, std::ios::beg);
        std::string saturs;

        while (std::getline(infile, saturs)) {
          if (!saturs.empty() && saturs.find(",,") == std::string::npos) {
            std::cout << saturs << '\n';
          }
        }

        infile.close();
      }
      break;
    }



    case 'e': {
      break;
    }



    default: {
      std::cout << "Ievadi a, b, c, d vai e." << '\n';
      break;
    }



    }
  }

while (komanda != 'e');
return 0;

}