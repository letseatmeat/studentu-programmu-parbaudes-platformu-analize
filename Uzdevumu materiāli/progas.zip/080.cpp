
#include <iostream>
#include <fstream>
#include <regex>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

class busRouteData{
//this barely any different from using a vector, but its more convenient when
//trying to understand where we are fetching the information from
  private:
    string start;
    string end;
    string day;
    string time;
    string price;

  public:
    busRouteData(string start, string end, string day, string time, string price)
      : start(start), end(end), day(day), time(time), price(price) {}

    string getStart(){
      return start;
    }
    string getEnd(){
      return end;
    }
    string getDay(){
      return day;
    }
    string getTime(){
      return time;
    }
    string getPrice(){
      return price;
    }

    void printAllParams(){
      cout << getStart() << " " << getEnd() << " " << getDay() << " " << getTime() << " " << getPrice() << endl;
    }

};

string removeWhiteSpaces(string str){
  str.erase(remove(str.begin(), str.end(), ' '), str.end());
  return str;
}

bool hasExactlyFourCommas(string input) {
    int count = 0;
    for (char ch : input) {
        if (ch == ',') {
            count++;
        }
    }
    return count == 4;
}

bool checkDayParameter(string day){
  //first check, needs to be length of 2
  if(day.length() != 2){
    return false;
  }

  //last check, needs to be one of the pairs
  string days[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  for(int it = 0; it < 7; it++){
    if(day == days[it]){
      return true;
    }
  }

  //if check fail, false by default
  return false;
}

bool checkTimeParameter(string time){
  char doubleDot = ':';
  istringstream ss(time);
  string number;
  int activeNumber;

  getline(ss, number, doubleDot);
  activeNumber = stoi(number);
  if(activeNumber < 0 || activeNumber > 23){
    return false;
  }
  getline(ss, number, doubleDot);
  activeNumber = stoi(number);
  if(activeNumber < 0 || activeNumber > 59){
    return false;
  }
  return true;
}

bool checkPriceParameter(string price){
  //everything else failed. not even regex worked. ridiculous.
  try{
    stod(price);
  } 
  catch(invalid_argument){
    return false;
  }
  return true;
}

bool checkIfAlphabetic(string anyText){
  regex enchantingTableText2("^[A-Za-z]+$"); //TL;DR: check if there are only letters
  return regex_match(anyText, enchantingTableText2);
}

vector<string> checkIfStringIsRouteData(string activeLine){
  //we take the string and split it up
  //and then check its parts individually
  //this doesnt check if the start or end are real locations
  //cout << "checking: " << activeLine << endl;
  string start, end, day, time, price;
  istringstream ss(activeLine);

  if(!hasExactlyFourCommas(activeLine)){
    return {};
  }

  //I REGRET NOTHING !!!!!!!!
  getline(ss, start, ',');
  start = removeWhiteSpaces(start);
  if(!checkIfAlphabetic(start)){
    return {};
  }
  //cout << "parmater1: " << start << endl;
  getline(ss, end, ',');
  end = removeWhiteSpaces(end);
  if(!checkIfAlphabetic(end)){
    return {};
  }
  //cout << "parmater2: " << end << endl;
  getline(ss, day, ',');
  day = removeWhiteSpaces(day);
  if(!checkDayParameter(day)){
    return {};
  }
  //cout << "parmater3: " << day << endl;
  getline(ss, time, ',');
  time = removeWhiteSpaces(time);
  if(!checkTimeParameter(time)){
    return {};
  }
  //cout << "parmater4: " << time << endl;
  getline(ss, price, ',');
  //cout << "parmater5-1: " << price << endl;
  price = removeWhiteSpaces(price);
  //cout << "parmater5-2: " << "[" << price << "]" << endl;
  if(!checkPriceParameter(price)){
    return {};
  }
  //cout << "parmater5-3: " << price << endl;
  return {start, end, day, time, price};
}

vector<busRouteData> readFile(string fileName){
  string line;
  vector<busRouteData> listOfRoutes;
  ifstream inputFile; //reads file ?
  inputFile.open("db.csv");
  ofstream errOutputFile;
  errOutputFile.open("err.txt", std::ios::out | std::ios::trunc);
  while(getline(inputFile, line, '\n')){
    vector<string> lineData = checkIfStringIsRouteData(line);
    if(!lineData.empty()){
      listOfRoutes.push_back(busRouteData(lineData[0], lineData[1], lineData[2], lineData[3], lineData[4]));
    } else if(line.length() > 1){ //cheap solution, but this seems to be an anomaly
      errOutputFile << line << endl;
    }
  }
  inputFile.close();
  errOutputFile.close();
  return listOfRoutes;
}

void searchByDestination(string start, string end, vector<busRouteData> routes){
  cout << "result:" << endl;
  for(auto route : routes){
    if(route.getStart() == start && route.getEnd() == end){
      route.printAllParams(); 
    }
  }
}

void searchByDay(string day, vector<busRouteData> routes){
  cout << "result:" << endl;
  for(auto route : routes){
    if(route.getDay() == day){
      route.printAllParams(); 
    }
  }
}

void searchByMaxPrice(string price, vector<busRouteData> routes){
  cout << "result:" << endl;
  for(auto route : routes){
    if(stoi(route.getPrice()) <= stoi(price)){ //stoi -> string to int
      route.printAllParams(); 
    }
  }
}

void readErrorLogFile(){
  cout << "result:" << endl;
  ifstream errorLogFile;
  string line;
  errorLogFile.open("err.txt", ios::app);
  while(getline(errorLogFile, line, '\n')){
    cout << line << endl;
  }
  errorLogFile.close();
}

/*
TL;DR: what has happened so far

we define a class called busRouteData (you will never guess what this objects stores)
then a bunch of functions that are used to check if specific parameters are correct
then a big function (checkIfStringIsRouteData) that runs all of those checks on a given line
it outputs a vector of strings (start, end, day, time, price)
then readFile, which reads the file line by line and outputs bad lines to err.txt
it is run first in the main function (it returns a vector cotaining several busRouteData)
user commands are processed in the main function
after we have the vector of objects, we also have functions for doing what is requested in the actual project requirements (getting the right bus lines)
*/

int main() {
  string userInput;
  //since the database doesn't get modified during runtime, we read it once
  vector<busRouteData> activeData = readFile("db.csv");
  //apparently switch is only for vars of integer type(?), sad day today.
  while (true){
    //cout << endl << "Enter command: ";
    cin >> userInput;
    if(userInput == "a"){
      string start;
      string end;
      cin >> start >> end;
      cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      if(checkIfAlphabetic(start) && checkIfAlphabetic(end)){
        searchByDestination(start, end, activeData);
      }
    } else if (userInput == "b"){
      string day;
      while(true){
        cin >> day;
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        if(checkDayParameter(day)){
          searchByDay(day, activeData);
          break;
        }
        cout << "bad input, try again: " << endl;
      }
    } else if (userInput == "c"){
      string price;
      while(true){
        cin >> price;
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        if(checkPriceParameter(price)){
          searchByMaxPrice(price, activeData);
          break;
        }
        cout << "bad input, try again: " << endl;
      }
    } else if (userInput == "d"){
      readErrorLogFile();
    } else if (userInput == "e"){
      //e -> exit
      break;
    }
  }
} 