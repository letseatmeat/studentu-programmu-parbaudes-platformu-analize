#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

// Function to remove all spaces from a string
string removeSpaces(const string &str) {
  string result = str;
  result.erase(remove_if(result.begin(), result.end(), ::isspace),
               result.end());
  return result;
}

// Structure to represent a bus route
struct BusRoute {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};

// Function to parse a CSV line and create a BusRoute object
bool parseCSVLine(const string &line, BusRoute &route) {
  stringstream ss(line);
  string token;

  vector<string> fields;
  while (getline(ss, token, ',')) {
    fields.push_back(removeSpaces(token));
  }

  // Check if the line has the correct number of fields
  if (fields.size() != 5) {
    return false;
  }

  // Check if the first and second fields are words
  if (!all_of(fields[0].begin(), fields[0].end(), ::isalpha) ||
      !all_of(fields[1].begin(), fields[1].end(), ::isalpha)) {
    return false;
  }

  // Check if the third field is a valid weekday
  vector<string> validWeekdays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  if (find(validWeekdays.begin(), validWeekdays.end(), fields[2]) ==
      validWeekdays.end()) {
    return false;
  }

  // Check if the fourth field is a valid time (HH:MM)
  if (fields[3].size() != 5 || fields[3][2] != ':' ||
      !all_of(fields[3].begin(), fields[3].end(),
              [](char c) { return isdigit(c) || c == ':'; })) {
    return false;
  }

  route.startStop = fields[0];
  route.endStop = fields[1];
  route.dayOfWeek = fields[2];
  route.time = fields[3];

  try {
    // Attempt to convert the ticket price to a double
    route.ticketPrice = stod(fields[4]);

    // Check for additional fields beyond the expected 5
    if (ss >> token) {
      return false;
    }
  } catch (const invalid_argument &) {
    return false;
  } catch (const out_of_range &) {
    return false;
  }

  return true;
}

// Function to display the contents of the "err.txt" file
void displayErrorFile() {
  ifstream errorFile("err.txt");

  if (!errorFile.is_open()) {
    cerr << "Error opening error file." << endl;
    return;
  }

  cout << "result:\n";

  // Read and display each line from the error file
  string line;
  while (getline(errorFile, line)) {
    cout << line << "\n";
  }

  // Close the error file
  errorFile.close();
}

// Function to handle the exit condition
void exitProgram() { exit(0); }

// Function to display flights based on user input
// Function to display flights based on user input
void displayFlights(const vector<string> &lines, const string &param1,
                    const string &param2, const string &condition) {
  cout << "result:\n";

  for (const auto &line : lines) {
    BusRoute route;
    if (parseCSVLine(line, route)) {
      if ((condition == "on route" && route.startStop == param1 &&
           route.endStop == param2) ||
          (condition == "on day" && route.dayOfWeek == param1) ||
          (condition == "below price" && route.ticketPrice <= stod(param1))) {
        cout << route.startStop << " " << route.endStop << " "
             << route.dayOfWeek << " " << route.time << " ";
        cout.precision(2); // Set precision for the ticket price
        cout << fixed << route.ticketPrice << "\n";
      }
    }
  }
}

// Function to read lines from a file
vector<string> readLinesFromFile(const string &filename) {
  ifstream inputFile(filename);

  if (!inputFile.is_open()) {
    cerr << "Error opening file: " << filename << endl;
    exit(1);
  }

  vector<string> lines;
  string line;
  while (getline(inputFile, line)) {
    lines.push_back(line);
  }

  inputFile.close();
  return lines;
}

// Function to handle user input
void handleUserInput(const vector<string> &lines) {
  char userInput;

  do {
    cin >> userInput;

    switch (userInput) {
    case 'd':
    case 'D':
      displayErrorFile();
      break;

    case 'a':
    case 'A': {
      string startStop, endStop;
      cin >> startStop;
      cin >> endStop;
      displayFlights(lines, startStop, endStop, "on route");
      break;
    }

    case 'b':
    case 'B': {
      string day;
      cin >> day;
      displayFlights(lines, day, "", "on day");
      break;
    }

    case 'c':
    case 'C': {
      double maxPrice;
      cin >> maxPrice;
      displayFlights(lines, to_string(maxPrice), "", "below price");
      break;
    }

    case 'e':
    case 'E':
      exitProgram();
      break;

    default:
      cout << "Invalid input. Please try again." << endl;
    }
  } while (userInput != 'e' && userInput != 'E');
}

int main() {
  // Read the content of the input file into a vector of strings
  vector<string> lines = readLinesFromFile("cleaned_db.csv");

  // Handle user input
  handleUserInput(lines);

  return 0;
}
