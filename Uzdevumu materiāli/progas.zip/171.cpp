
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
// #include <cctype>
using namespace std;

int writeError(string error)
{
  ofstream file;
  file.open("err.txt", ios_base::app);
  file << error << endl;
  file.close();
  return 0;
}

string getData(int num, string data)
{
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    exit(0);

  string line, result;

  while (inFile)
  {
    getline(inFile, line);
    line.erase(std::remove(line.begin(), line.end(), ' '), line.end());
    if (count(line.begin(), line.end(), ',') != 4)
    {
      if (line != "\n")
        writeError(line);
      continue;
    }
    string lines[5];
    bool error = false;
    for (int position = 0; position < 5; position++)
    {
      lines[position] = line.substr(0, line.find(','));
      line.erase(0, line.find(',') + 1);
      if (position > 2)
      {
        // cout <<  (int)lines[position].at(0) << " " << lines[position].at(0)<<
        // endl;
        if (!((47 < (int)lines[position].at(0)) &&
              ((int)lines[position].at(0) < 58)))
        {
          error = true;
        }
      }
    }
    if (error)
    {
      writeError(lines[0] + "," + lines[1] + "," + lines[2] + "," +
                 lines[3] + "," + lines[4]);
      continue;
    }

    switch (num)
    {
    case 1:
    {
      string start, end;
      start = data.substr(0, data.find(','));
      end = data.substr(data.find(',') + 1, data.length());
      if (start == lines[0] && end == lines[1])
        result += lines[0] + " " + lines[1] + " " + lines[2] + " " + lines[3] +
                  " " + lines[4] + "\n";
    }
    break;
    case 3:
    {
      if (data == lines[2])
        result += lines[0] + " " + lines[1] + " " + lines[2] + " " + lines[3] +
                  " " + lines[4] + "\n";
    }
    break;
    case 5:
    {
      if (stof(data) > stof(lines[4]))
        result += lines[0] + " " + lines[1] + " " + lines[2] + " " + lines[3] +
                  " " + lines[4] + "\n";
    }
    break;
    default:
      break;
    }
  }
  return result;
}

string getErrors()
{
  ifstream inFile;
  inFile.open("err.txt");

  if (!inFile)
    return "";

  string currentString, result;

  while (inFile >> currentString)
  {
    result += currentString + "\n";
  }
  return result;
}

int main()
{
  char input;
  while (true)
  {
    cin >> input;
    cin.ignore();
    switch (input)
    {
    case 'a':
    {
      string start, end;
      cin >> start;
      cin >> end;
      cout << "result:" << endl
           << getData(1, start + "," + end);
    }
    break;
    case 'b':
    {
      string weekday;
      cin >> weekday;
      cout << "result:" << endl
           << getData(3, weekday);
    }
    break;

    case 'c':
    {
      string cost;
      cin >> cost;
      cout << "result:" << endl
           << getData(5, cost);
    }
    break;

    case 'd':
    {
      cout << "result:\n"
           << getErrors();
      ofstream file;
      file.open("err.txt");
      file << "" << endl;
      file.close();
    }
    break;

    case 'e':
      exit(0);
      break;

    default:
      break;
    }
  }
  return 0;
}