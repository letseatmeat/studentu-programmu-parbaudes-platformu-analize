#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

string trimStr(string str, char sym = ' ') {
    int trimStart = 0;
    int trimEnd = str.length();
    for (int i = 0; i < str.length(); i++) {
        if (str[i] == sym) {
            trimStart = i+1;
            continue;
        }
        break;
    }

    for (int i = str.length()-1; i > trimStart; i--) {
        if (str[i] == sym) {
            trimEnd = i;
            continue;
        }
        break;
    }
    return str.substr(trimStart, trimEnd-trimStart);
}

string printableVector(vector<string> vec, char type) {
    string output = "";
    for (string i : vec) {
        output += i;
        output += type;
    }
    return output;
}

void printableVector(vector<vector<string>> vec) {
    for (vector<string> i : vec) {
        string output = "";
        for (string j : i) {
            output += j;
            output += " ";
        }
        output = output.substr(0, output.length()-1);
        cout << output << endl;
    }
}

void writeFile(vector<string> data, string fileName) {
    ofstream ofile;
    ofile.open(fileName);
    for (string i : data) {
        ofile << i << endl;
    }
    ofile.close();
}

bool existsInArr(const string arr[], string val, int length) {
    for (int i = 0; i < length; i++) {
        if (arr[i] == val) {
            return true;
        }
    }
    return false;
}

bool checkDay(string day) {
    if (day.length() != 2) {
        return false;
    }
    const string days[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    const int arrLength = 7;

    return existsInArr(days, day, arrLength);
}

bool checkTime(string time) {
    if (time.length() != 5) {
        return false;
    }
    string temp;
    stringstream ss(time);
    vector<string> timeData;

    while (getline(ss, temp, ':')) {
        timeData.push_back(temp);
    }

    if (timeData.size() != 2) {
        return false;
    }

    try {
        int hours = stoi(timeData[0]);
        int minutes = stoi(timeData[1]);
        if (hours >= 24 || minutes >= 60) {
            return false;
        }
    }
    catch (exception msg) {
        return false;
    }

    return true;
}

bool checkPrice(string priceStr) {
    try {
        double price = stod(priceStr);
        if (price < 0) return false;
        return true;
    }
    catch (exception msg) {
        return false;
    }
}

vector<vector<string>> lineCheck(vector<string> lines) {
    vector<vector<string>> data;
    vector<string> errorData;

    for (string currLine : lines) {
        string temp;

        // I need this line otherwise replit tests no worky :((
        string line = currLine.substr(0, currLine.length()-1);
        
        stringstream ss(line);
        vector<string> lineData;
        if (line == "\n" || line == "") {
            continue;
        }

        while (getline(ss, temp, ',')) {
            temp = trimStr(temp);
            lineData.push_back(temp);
        }

        if (lineData.size() != 5) {
            errorData.push_back(line);
            continue;
        }

        if (!checkDay(lineData[2])) {
            errorData.push_back(line);
            continue;
        }

        if (!checkTime(lineData[3])) {
            errorData.push_back(line);
            continue;
        }

        if (!checkPrice(lineData[4])) {
            errorData.push_back(line);
            continue;
        }

        data.push_back(lineData);
    }
    writeFile(errorData, "err.txt");
    
    return data;
}

vector<string> readFile(string fileName) {
    ifstream inFile;
    inFile.open(fileName);
    if (!inFile) return {};

    string s;
    string line;
    vector<string> rawData;
    while (getline(inFile, line)) {
        rawData.push_back(line);
    }
    inFile.close();

    return rawData;
}
vector<vector<string>> filterByRoute(vector<vector<string>> data, string start, string destination) {
    vector<vector<string>> filteredData;

    for (vector<string> i : data) {
        string tempStart = i[0];
        string tempDestination = i[1];
        if (tempStart == start && tempDestination == destination) {
            filteredData.push_back(i);
        }
    }
    return filteredData;
}

vector<vector<string>> filterByDay(vector<vector<string>> data, string day) {
    vector<vector<string>> filteredData;

    for (vector<string> i : data) {
        string tempDay = i[2];
        if (tempDay == day) {
            filteredData.push_back(i);
        }
    }
    return filteredData;
}

vector<vector<string>> filterByPrice(vector<vector<string>> data, string priceStr) {
    double price;

    try {
        price = stod(priceStr);
    }
    catch(exception msg) {
        return {};
    }

    vector<vector<string>> filteredData;

    for (vector<string> i : data) {
        double tempPrice = stod(i[4]);
        if (price >= tempPrice) {
            filteredData.push_back(i);
        }
    }
    return filteredData;
}

int main(int argc, char const *argv[])
{
    string fileName = "db.csv";
    vector<string> rawLines = readFile(fileName);
    vector<vector<string>> data = lineCheck(rawLines);
    bool isRunning = true;
    while (isRunning) {
        string input;
        cout << ">";
        cin >> input;
        if (input.length() != 1) {
            cout << "error" << endl;
            continue;
        }
        char ch = input.c_str()[0];
        string start;
        string destination;
        string day; 
        string price;

        switch (ch) {
            case 'a':
                cin >> start;
                cin >> destination;
                cout << "result:" << endl;
                printableVector(filterByRoute(data, start, destination));
                break;
            case 'b':
                cin >> day;
                cout << "result:" << endl;
                printableVector(filterByDay(data, day));
                break;
            case 'c':
                cin >> price;
                cout << "result:" << endl;
                printableVector(filterByPrice(data, price));
                break;
            case 'd':
                cout << "result:" << endl;
                cout << printableVector(readFile("err.txt"), '\n');
                break;
            case 'e':
                isRunning = false;
                break;
            default:
                cout << "Invalid choice" << endl;
            
        }
        
    }

    return 0;
}
