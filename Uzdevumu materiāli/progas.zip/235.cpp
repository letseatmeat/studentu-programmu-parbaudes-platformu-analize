
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <iomanip>
#include <limits>


using namespace std;

string trim(const string& str){
  size_t first = str.find_first_not_of(' ');
  size_t last = str.find_last_not_of(' ');
  if(first != string::npos && last != string::npos){
    return str.substr(first, last+ 1);
  }else{
    return "";
  }
}

class Route{
  public:
    string begining, end, day, time;
    double price;
    Route(string beginning, string end, string day, string time, double price){
      this->begining = trim(beginning);
      this->end = trim(end);
      this->day = trim(day);
      this->time = trim(time);
      this->price = price;
    }
  void print(){
  cout << begining << " " << end << " " << day << " " << time << " " << fixed << setprecision(2) << price << endl;
  }
};

bool isNumber(const string& x){
  string x1=trim(x);
  try {
    stod(x1);
    return true;
  } catch (const invalid_argument& ia) {
    return false;
  } catch (const out_of_range& oor) {
    return false;
  }
}

bool isDay(const string& x){
  string x1=trim(x);
  if(x1 == "Pr" || x1 == "Ot" || x1 == "Tr" || x1 == "Ce"|| x1 == "Pt"  || x1 == "St" || x1 == "Sv"){
    return true;
  }else{
    return false;
  }
}

bool isTime(const string& x){
  string x1=trim(x);
  if(x1.length() == 5 && isNumber(x1.substr(0,2)) && isNumber(x1.substr(3,2)) && x1.substr(2,1)==":"){
    return true;
  }else{
    return false;
  }
}

void addRoute(const string& s, vector<Route>& routes,ofstream& outFile){
  if(s.find_first_not_of("\r\n\t") == string::npos) {
    return;
  }
  
  istringstream iss(s);
  string beginning, end, day, time, price_str,extra;
  double price;

  getline(iss >> ws, beginning, ',');
  getline(iss >> ws, end, ',');
  getline(iss >> ws, day, ',');
  getline(iss >> ws, time, ',');
  getline(iss >> ws, price_str, ',');
  getline(iss >> ws, extra, ',');


  
  
  
  if ((!beginning.empty()&& !isNumber(beginning)) && (!end.empty() && !isNumber(end)) && (!day.empty() && isDay(day)) && (!time.empty() && isTime(time)) && (!price_str.empty() && isNumber(price_str))&& extra.empty()) {
      price = stod(price_str);
      routes.emplace_back(beginning, end, day, time, price);
  } else{
    outFile << s << endl;
  }
}

void functionA(vector<Route>& routes){
  string beginning, end;
  cin>>beginning>>end;
  cout<<"result:"<<endl;
  for(Route& r : routes){
    if(r.begining == beginning && r.end == end){
      r.print();
    }
  }
}

void functionB(vector<Route>& routes){
  string day;
  cin>>day;
  cout<<"result:"<<endl;
  for(Route& r : routes){
    if(r.day == day){
      r.print();
    }
  }
}

void functionC(vector<Route>& routes){
  double price;;
  cin>>price;
  cout<<"result:"<<endl;
  for(Route& r : routes){
    if(r.price <=price){
      r.print();
    }
  }
}

void functionD(){
  string x;
  ifstream inErrFile;
  inErrFile.open("err.txt");
  if(!inErrFile) return;
  cout<<"result:"<<endl;
  while(inErrFile>> x){
    cout<<x<<endl;
  }
  inErrFile.close();
}

int main() {
  vector<Route> routes;
  ofstream outFile;
  outFile.open("err.txt");
  ifstream inFile;
  inFile.open("db.csv");
	if(!inFile) return 0;
  string s; 
  while(getline(inFile,s)){
    addRoute(s,routes, outFile);
  }
  string input;
  while(true){
    cin >> input;
    if(input == "a"){
      functionA(routes);
    }
    if(input == "b"){
      functionB(routes);
    }
    if(input == "c"){
      functionC(routes);
    }
    if(input == "d"){
      functionD();
    }
    if(input == "e"){
      break;
    }else{
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
  }
  inFile.close();
  outFile.close();
  routes.clear();
  return 0;
} 