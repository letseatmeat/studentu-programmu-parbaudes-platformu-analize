
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
#include <vector>

using namespace std;

string trim(const string &s) {
    // This is a function for trimming leading and trailing spaces.
    int first = s.find_first_not_of(' ');
    if (string::npos==first) {
        return "";
    }
    int last = s.find_last_not_of(' ');
    return s.substr(first, (last - first + 1));
}

bool fieldCount(const string &s) {
    // This is a function to check if the field count is valid
    // for the current line (5 fields).
    istringstream str(s);
    string field;
    int fieldCount = 0;

    while (getline(str, field, ',')) {
        fieldCount++;
    }

    return fieldCount == 5;
}

bool validPrice(const string &s) {
    // This is a function for validating the price format.
    istringstream str(s);
    string field;
    int fieldCount = 0;

    while (getline(str, field, ',')) {
        fieldCount++;
        if (fieldCount==5) {
            regex price("^\\d+\\.\\d{2}$");
            field = trim(field);
            return regex_match(field, price);
        }
    }
  return false;
}

bool validTime(const string &s) {
    istringstream str(s);
    string field;
    int fieldCount = 0;

    while (getline(str, field, ',')) {
        fieldCount++;
        field = trim(field);

        if (fieldCount==4) {
            if (field.size() != 5) {
            return false;
            }
        if (field[2]!=':') {
        return false;
      }

      string hours = field.substr(0, 2);
      string minutes = field.substr(3, 2);
      int hrs = stoi(hours);
      int min = stoi(minutes);

      if (hrs>=0&& hrs<=23&& min>=0&& min<=59) {
        return true;
      } else {
        return false;
      }
    }
  }
  return false; 
}

bool validDay(const string &s) {
    // This is a function for checking valid day format.
    istringstream str(s);
    string field;
    int fieldCount = 0;

    while (getline(str, field, ',')) {
        fieldCount++;
        field = trim(field);
        if (fieldCount==3) {
        field = trim(field);
        if (field.find("Pr")|| field.find("Ot")|| field.find("Tr")|| field.find("Ce")|| field.find("Pt")|| field.find("St")|| field.find("Sv")) {
            return true;
        } else {
            return false;
      }
    }
  }
}

bool validRoutes(const string &s) {
    // This is a function that combines all the checks.
    return fieldCount(s) && validPrice(s) && validTime(s) && validDay(s);
}

void routes(ifstream &inFile) {
    string begin, end;
    cout << "First stop: ";
    cin >> begin;
    begin = trim(begin);
    cout << "Last stop: ";
    cin >> end;
    end = trim(end);

    string s;
    int lineCount = 0;
    vector<string> result;

    while (getline(inFile, s)) {
        lineCount++;
        if (validRoutes(s)) {
            istringstream str(s);
            string field;
            vector<string> info;

            while (getline(str, field, ',')) {
                info.push_back(trim(field));
            }
            info[0] = trim(info[0]);
            info[1] = trim(info[1]);

            if (info[0]==begin&& info[1]==end) {
                result.push_back(s);
            }
        }
    }

    cout << "result:" << endl;
    for (const string &line : result) {
        istringstream str(line);
        string field;

        while (getline(str, field, ',')) {
            cout << trim(field) << " ";
        }
        cout << endl;
    }
}

void days(ifstream &inFile) {
    string day;
    cout << "Day:" << endl;
    cin >> day;

    string s;
    int lineCount = 0;
    vector<string> result;

    while (getline(inFile, s)) {
        if (validRoutes(s)) {
            istringstream str(s);
            string field;
            vector<string> info;

            while (getline(str, field, ',')) {
                info.push_back(trim(field));
            }

            if (info.size()>=3&& info[2]==trim(day)) {
                result.push_back(s);
            }
        }
    }
    cout << "result:" << endl;
    for (const string &line : result) {
        istringstream str(line);
        string field;

        while (getline(str, field, ',')) {
            cout << trim(field) << " ";
        }
        cout << endl;
    }
}

void price(ifstream &inFile) {
    string valueStr;
    cout << "Price less than:" << endl;
    cin >> valueStr;
    valueStr = trim(valueStr);
    double value = stod(valueStr);

    string s;
    int lineCount = 0;
    vector<string> result;

    while (getline(inFile, s)) {
        if (validRoutes(s)) {
            istringstream str(s);
            string field;
            vector<string> info;

            while (getline(str, field, ',')) {
                info.push_back(trim(field));
            }
            string priceStr = trim(info[4]);
            double price = stod(priceStr);

            if (price<=value) {
                result.push_back(s);
            }
        }
    }
    cout << "result:" << endl;
    for (const string &line : result) {
        istringstream str(line);
        string field;

        while (getline(str, field, ',')) {
        cout << trim(field) << " ";
        }
        cout << endl;
    }
}

void errfile(ifstream &outFile) {
    string s;
    vector<string> result;
    cout << "result:" << endl;
    while (getline(outFile, s)) {
        cout << s << endl;
    }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile.is_open()) {
    cout << "Error" << endl;
    return 1;
  }

  string s;
  int lineCount = 0;
  string fileName = "err.txt";
  ofstream newFile(fileName);
  if (newFile.is_open()) {
    while (getline(inFile, s)) {
      lineCount++;
      if (validRoutes(s)==false&& (s.find_first_not_of(" \t\n\v\f\r") != string::npos)) {
        newFile << s << endl;
      }
    }
    newFile.close();
  }

  ifstream errFile;
  errFile.open("err.txt");
  if (!errFile.is_open()) {
    cout << "Error opening file!" << endl;
    return 1;
  }

  if (!errFile.is_open()) {
    cout << "Error" << endl;
    return 1;
  }

  while (true) {
    cout << "Command: ";
    string cmd;
    cin >> cmd;

    if (cmd == "e") {
      break;
    } else if (cmd == "a") {
      inFile.clear();
      inFile.seekg(0);
      routes(inFile);
    } else if (cmd == "b") {
      inFile.clear();
      inFile.seekg(0);
      days(inFile);
    } else if (cmd == "c") {
      inFile.clear();
      inFile.seekg(0);
      price(inFile);
    } else if (cmd == "d") {
      inFile.clear();
      inFile.seekg(0);
      errfile(errFile);
    } else {
      cout << "Error" << endl;
    }
  }

  inFile.close();
  errFile.close();
  return 0;
}