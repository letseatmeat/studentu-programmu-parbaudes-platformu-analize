#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>

using namespace std;

struct AutobusuMarsruts {

  string sakumaPietura;
  string galaPietura;
  string diena;
  string laiks;
  double cena;
};

bool identiskasRindas(const vector<AutobusuMarsruts> &rindas,
                      const AutobusuMarsruts &jaunaRinda) {
  for (const auto &rinda : rindas) {
    if (rinda.sakumaPietura == jaunaRinda.sakumaPietura &&
        rinda.galaPietura == jaunaRinda.galaPietura &&
        rinda.diena == jaunaRinda.diena && rinda.laiks == jaunaRinda.laiks &&
        rinda.cena == jaunaRinda.cena) {
      return true;
    }
  }
  return false;
}

vector<AutobusuMarsruts> nolasitMarsrutus() {
  vector<AutobusuMarsruts> marsruti;
  ifstream fails("db.csv");
  if (!fails) {
    cerr << "kluda faila atversana" << endl;
    exit(EXIT_FAILURE);
  }

  string rinda;
  while (getline(fails >> ws, rinda)) {
    rinda.erase(remove_if(rinda.begin(), rinda.end(), ::isspace), rinda.end());
    if (rinda.empty()) {
      continue;
    }

    stringstream datuStraume(rinda);
    AutobusuMarsruts marsruts;
    getline(datuStraume, marsruts.sakumaPietura, ',');
    getline(datuStraume, marsruts.galaPietura, ',');
    getline(datuStraume, marsruts.diena, ',');
    getline(datuStraume, marsruts.laiks, ',');
    datuStraume >> marsruts.cena;

    if (!identiskasRindas(marsruti, marsruts)) {
      marsruti.push_back(marsruts);
    }
  }

  fails.close();
  return marsruti;
}

void izvaditReisus(const vector<AutobusuMarsruts> &marsruti) {
  string sakumaPietura;
  cin >> ws;
  getline(cin, sakumaPietura);

  string galaPietura;
  getline(cin, galaPietura);

  cout << "result:" << endl;
  for (const auto &marsruts : marsruti) {
    if (marsruts.sakumaPietura == sakumaPietura &&
        marsruts.galaPietura == galaPietura) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
           << marsruts.diena << " " << marsruts.laiks << " " << fixed
           << setprecision(2) << marsruts.cena << endl;
    }
  }
}

void ievaditDienas(const vector<AutobusuMarsruts> &marsruti) {
  string ievaditDienu;
  cin >> ievaditDienu;
  cout << "result:" << endl;
  for (const auto &marsruts : marsruti) {
    if (marsruts.diena == ievaditDienu) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
           << marsruts.diena << " " << marsruts.laiks << " " << fixed
           << setprecision(2) << marsruts.cena << endl;
    }
  }
}

void ievaditCenu(const vector<AutobusuMarsruts> &marsruti) {

  double maxCena;
  cin >> maxCena;
  cout << "result:" << endl;
  for (const auto &marsruts : marsruti) {
    if (marsruts.cena <= maxCena) {
      cout << marsruts.sakumaPietura << " " << marsruts.galaPietura << " "
           << marsruts.diena << " " << marsruts.laiks << " " << fixed
           << setprecision(2) << marsruts.cena << endl;
    }
  }
}
bool irPilseta(const string &nosaukums) {
  set<string> pilsetas = {"Riga",    "Kraslava", "Daugavpils", "Ventspils",
                          "Liepaja", "Rezekne",  "Dagda"};
  return pilsetas.count(nosaukums) > 0;
}
void errFails(const AutobusuMarsruts &jaunaRinda) {
  ofstream errFails("err.txt", ios::app);
  if (!errFails) {
    cerr << "kluda faila atversana" << endl;
    exit(EXIT_FAILURE);
  }
  if (!irPilseta(jaunaRinda.sakumaPietura) ||
      !irPilseta(jaunaRinda.galaPietura)) {
    errFails << jaunaRinda.sakumaPietura << " " << jaunaRinda.galaPietura << " "
             << jaunaRinda.diena << " " << jaunaRinda.laiks << " " << fixed
             << setprecision(2) << jaunaRinda.cena << endl;
  }
  errFails.close();
}

int main() {
  char pieprasijums;
  vector<AutobusuMarsruts> marsruti = nolasitMarsrutus();

  do {
    cin >> pieprasijums;

    switch (pieprasijums) {
    case 'a': {
      izvaditReisus(marsruti);
      break;
    }
    case 'b': {
      ievaditDienas(marsruti);
      break;
    }
    case 'c': {
      ievaditCenu(marsruti);
      break;
    }
    case 'd': {
      cout << "result:" << endl;
      for (const auto &marsruts : marsruti) {
        errFails(marsruts);
      }
      ifstream errFile("err.txt");
      if (errFile.is_open()) {
        string line;
        while (getline(errFile, line)) {
          cout << line << endl;
        }
        errFile.close();
      } else {
        cerr << "Kluda faila atversana (err.txt)" << endl;
        exit(EXIT_FAILURE);
      }
      break;
    }
    case 'e': {
      break;
    }
    default:
      cout << "Nepareiza ievade" << endl;
    }
  } while (pieprasijums != 'e');
  return 0;
}