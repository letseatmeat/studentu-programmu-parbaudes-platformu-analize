#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
#include <vector>

using namespace std;

bool checkLine(const vector<string> &flight) {

  // jabut 5 elementiem
  if (flight.size() != 5)
    return false;

  // tikai burti
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < flight[i].length(); ++j) {
      if (!isalpha(flight[i][j])) {
        return false;
      }
    }
  }

  // (Pr, Ot, Tr, Ce, Pt, St, Sv)
  if (flight[2].find("Pr" || "Ot" || "Tr" || "Ce" || "Pt" || "St" || "Sv") != string::npos){
    return false;
  }

  // formats (00:00) 24h
  const regex time("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
  if (!regex_match(flight[3], time))
    return false;

  // cena (0.00)
  const regex price("^\\d+\\.\\d{2}$");
  if (!regex_match(flight[4], price))
    return false;

  return true;
}

void findCities(const vector<vector<string>> &list_of_flights,
                const string &fromCity, const string &toCity) {
  cout << "result:"
       << "\n";
  for (const auto &flight : list_of_flights) {
    if (flight[0] == fromCity && flight[1] == toCity) {
      for (const auto &data : flight) {
        cout << data << " ";
      }
      cout << "\n";
    }
  }
}

void findDay(const vector<vector<string>> &list_of_flights, const string &day) {
  cout << "result:"
       << "\n";
  for (const auto &flight : list_of_flights) {
    if (flight[2] == day) {
      for (const auto &data : flight) {
        cout << data << " ";
      }
      cout << "\n";
    }
  }
}

void findCost(const vector<vector<string>> &list_of_flights, double &maxCost) {
  cout << "result:"
       << "\n";
  for (const auto &flight : list_of_flights) {

    double cost = stod(flight[4]);
    if (cost <= maxCost) {
      for (const auto &data : flight) {
        cout << data << " ";
      }
      cout << "\n";
    }
  }
}

void printErr() {
  cout << "result:"
       << "\n";
  ifstream i;
  i.open("err.txt");

  if (!i)
    return;

  string s;
  while (i >> s) {
    cout << s << endl;
  }
}

int main() {
  // atveram failu db.csv
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  vector<vector<string>> list_of_flights;
  vector<string> flight;

  string s;
  string data;

  ofstream errFile("err.txt");

  // lasam informaciju no ieejas faila

  while (getline(inFile, s)) {
    flight.clear();
    istringstream s_stream(s);

    while (getline(s_stream, data, ',')) {
      // izdzesam visas atstarpes
      data.erase(remove(data.begin(), data.end(), ' '), data.end());
      // pievienojam informaciju reisam
      flight.push_back(data);
    }

    // parbaudam vai rinda ir kļudaina
    if (!checkLine(flight)) {
      // vai nav tukša
      if (!flight.empty()) {
        // kļudainas rindas rakstam err.txt
        errFile << s << endl;
      }
    }
    // vai nav tukša
    else if (!flight.empty()) {
      // šie ieraksti atbilst formatam, pievienojam masīvam "list_of_flights"
      list_of_flights.push_back(flight);
    }
  }

  errFile.close();

  // usera ievades komanadas
  while (true) {
    char command;
    cin >> command;

    // a
    if (command == 'a') {
      string fromCity, toCity;
      cin >> fromCity;
      cin >> toCity;

      findCities(list_of_flights, fromCity, toCity);
    }

    // b
    else if (command == 'b') {
      string day;
      cin >> day;

      findDay(list_of_flights, day);
    }

    // c
    else if (command == 'c') {
      double maxCost;
      cin >> maxCost;

      findCost(list_of_flights, maxCost);
    }

    // d
    else if (command == 'd') {
      printErr();
    }

    // e
    else if (command == 'e') {
      break;
    }
  }

  return 0;
}
