
#include <limits>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;

struct Marsruts {
    string sakumaPietura;
    string galaPietura;
    string nedelasDiena;
    string laiks;
    double biletesCena;
};

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r\f\v");
    if (first == string::npos)
        return "";
    size_t last = str.find_last_not_of(" \t\n\r\f\v");
    return str.substr(first, (last - first + 1));
}

bool isValidPrice(const string& str) {
    stringstream ss(str);
    double test;
    return (ss >> test) && ss.eof();
}

vector<Marsruts> loadBusRoutes(const string& fileName) {
    ifstream inFile(fileName);
    vector<Marsruts> routes;
    string line;

    ofstream errFile("err.txt", ios_base::trunc);
    errFile.close();
    errFile.open("err.txt", ios_base::app);

    while (getline(inFile, line)) {
        stringstream ss(trim(line));
        Marsruts route;

        vector<string> fields;
        string field;
        while (getline(ss, field, ',')) {
            fields.push_back(trim(field));
        }

        if (fields.size() != 5 || !isValidPrice(fields[4])) {
            errFile << line << endl;
            continue;
        }

        route = {fields[0], fields[1], fields[2], fields[3], stod(fields[4])};
        routes.push_back(route);
    }
    errFile.close();
    return routes;
}

void displayRoutes(const vector<Marsruts>& routes, const string& start, const string& end) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.sakumaPietura == start && route.galaPietura == end) {
            cout << route.sakumaPietura << " " << route.galaPietura << " "
                 << route.nedelasDiena << " " << route.laiks << " "
                 << fixed << setprecision(2) << route.biletesCena << endl;
        }
    }
}

void displayRoutesByDay(const vector<Marsruts>& routes, const string& day) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.nedelasDiena == day) {
            cout << route.sakumaPietura << " " << route.galaPietura << " "
                 << route.nedelasDiena << " " << route.laiks << " "
                 << fixed << setprecision(2) << route.biletesCena << endl;
        }
    }
}

void displayRoutesBelowPrice(const vector<Marsruts>& routes, double maxPrice) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        if (route.biletesCena <= maxPrice) {
            cout << route.sakumaPietura << " " << route.galaPietura << " "
                 << route.nedelasDiena << " " << route.laiks << " "
                 << fixed << setprecision(2) << route.biletesCena << endl;
        }
    }
}

void displayErrorFile(const string& fileName) {
    ifstream errFile(fileName);
    cout << "result:" << endl;
    string line;
    while (getline(errFile, line)) {
        line = trim(line);
        if (!line.empty()) {
            cout << line << endl;
        }
    }
    errFile.close();
}

int main() {
    vector<Marsruts> routes = loadBusRoutes("db.csv");
    string start, end, day;
    double price;
    char choice;

    while (cin >> choice) {
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 'a':
                getline(cin, start);
                getline(cin, end);
                displayRoutes(routes, start, end);
                break;
            case 'b':
                getline(cin, day);
                displayRoutesByDay(routes, day);
                break;
            case 'c':
                if (!(cin >> price)) {
                    cout << "Nepareiza cena!" << endl;
                    cin.clear();
                }
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                displayRoutesBelowPrice(routes, price);
                break;
            case 'd':
                displayErrorFile("err.txt");
                break;
            case 'e':
                return 0;
            default:
                cout << "Neatpazits vaicajums. Ludzu, meginiet velreiz." << endl;
                break;
        }
    }

    return 0;
}
