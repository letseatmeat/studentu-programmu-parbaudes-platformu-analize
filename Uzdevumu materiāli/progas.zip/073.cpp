
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

struct Marsruts {  //struktūras definēšana
  string sakums;
  string beigas;
  string diena;
  string laiks;
  string cena;
}; 

Marsruts parsauksana (vector<string> marsruta_vektors) {  // funkcija, kas pārvērš vektoru ar maršruta atribūtiem uz struktūru
  Marsruts marsruts;
  marsruts.sakums = marsruta_vektors[0];
  marsruts.beigas = marsruta_vektors[1];
  marsruts.diena = marsruta_vektors[2];
  marsruts.laiks = marsruta_vektors[3];
  marsruts.cena = marsruta_vektors[4];
  return marsruts; 
}

vector<string> teksta_sadalisana(string marsruts, char simbols) {  //funkcija, kas sadala teksta rindu pēc dotā simbola
  vector<string> marsruta_vektors;
  string marsruta_dala;
  istringstream ss(marsruts);
  while (getline(ss, marsruta_dala, simbols)) {
    marsruta_vektors.push_back(marsruta_dala);
  }
  return marsruta_vektors;
}

bool marsruta_parbaude(string line) {  //funkcija, kas pārbauda, vai maršruts ir ierakstīts pareizi
  Marsruts marsruts;
  vector<string>marsruta_vektors = teksta_sadalisana(line, ',');
  
  if (marsruta_vektors.size() != 5) return false;  //pārbauda maršruta atribūtu skaitu
  
  marsruts = parsauksana(marsruta_vektors);

  if (marsruts.diena != "Pr" && marsruts.diena != "Ot" && marsruts.diena != "Tr" && marsruts.diena != "Ce" && marsruts.diena != "Pt" && marsruts.diena != "St" && marsruts.diena != "Sv") return false;   //pārbauda, vai diena ir ierakstīta pareizi
  
  if (marsruts.sakums == marsruts.beigas) return false;  //pārbauda, vai maršruta sākums un beigas nav viens un tas pats

  for (char c : marsruts.sakums) {  //pārbauda, vai visi sākuma pieturas simboli ir burti
    if (!isalpha(c)) return false;
  }
  for (char c : marsruts.beigas) {  //pārbauda, vai visi beigu pieturas simboli ir burti
    if (!isalpha(c)) return false;
  }
  vector<string> laiks = teksta_sadalisana(marsruts.laiks, ':');
  if (laiks.size() != 2) return false;  //pārbauda, vai laikam ir divi atribūti (stundas un minūtes)
  int hour = stoi(laiks[0]);
  int minute = stoi(laiks[1]);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return false;  //pārbauda, vai stundas un minūtes ir ierakstītas pareizi

  vector<string> cena = teksta_sadalisana(marsruts.cena, '.');
  if (cena.size() != 2) return false;  //pārbauda, vai cenai ir divi atribūti (eiro un centi)
  if (cena[1].length() != 2) return false;  //pārbauda, vai centi ir ierakstīti ar diviem cipariem
  int eiro = stoi(cena[0]);
  int centi = stoi(cena[1]);
  if (eiro < 0 || centi < 0 || centi > 99) return false; //pārbauda, vai eiro un centi ir ierakstīti pareizi
  
  return true;  //ja visas pārbaudes veiksmīgi izietas, tad maršruts tiek pieņemts kā pareizi ierakstīts
}

void filtret_pieturas(vector<string> marsruti) {  //funkcija, kas parāda maršrutus ar ievadītām sākuma un beigu pieturām uz ekrāna
  string ievadita_sakuma_pietura;
  string ievadita_beigu_pietura;
  cin >> ievadita_sakuma_pietura;
  cin >> ievadita_beigu_pietura;
  cout << "result:" << endl;
  for (string s : marsruti) {
    vector<string> sadalits_vektors = teksta_sadalisana(s, ',');
    Marsruts marsruts = parsauksana(sadalits_vektors);
    replace(s.begin(), s.end(), ',', ' ');  //aizvieto komatus ar atstarpi
    if (marsruts.sakums == ievadita_sakuma_pietura && marsruts.beigas == ievadita_beigu_pietura) cout << s << endl;  //pats nosacījums
  }
  return;
}

void filtret_dienas (vector<string> marsruti) {  //funkcija, kas parāda maršrutus ar ievadīto dienu uz ekrāna
  string diena;
  cin >> diena;
  cout << "result:" << endl;
  for (string s : marsruti) {
    vector<string> sadalits_vektors = teksta_sadalisana(s, ',');
    Marsruts marsruts = parsauksana(sadalits_vektors);
    replace(s.begin(), s.end(), ',', ' ');
    if (marsruts.diena == diena) cout << s << endl;
  }
}
void filtret_cenu (vector<string>marsruti) {  //funkcija, kas parāda maršrutus ar cenu, kas ir zem ievadītās cenas uz ekrāna
  string ievadita_cena;
  cin >> ievadita_cena;
  cout << "result:" << endl;
  
  vector<int>sadalita_ievadita_cena;
  string ievaditas_cenas_dala;
  istringstream ievaditais_ss (ievadita_cena);
  int parveidota_ievadita_cena;
  while (getline(ievaditais_ss, ievaditas_cenas_dala, '.')) {
    parveidota_ievadita_cena = stoi(ievaditas_cenas_dala);
    sadalita_ievadita_cena.push_back(parveidota_ievadita_cena);
  }  //ieliek ievadīto cenu (eiro un centus) vektorā kā int tipa vērības

  for (string s : marsruti) {
    vector<string> sadalits_vektors = teksta_sadalisana(s, ',');
    Marsruts marsruts = parsauksana(sadalits_vektors);
    string cena = marsruts.cena;
    vector<int>sadalita_cena;
    string cenas_dala;
    istringstream ss(cena);
    int parveidota_cena;
    while (getline(ss, cenas_dala, '.')) {
      parveidota_cena = stoi(cenas_dala);
      sadalita_cena.push_back(parveidota_cena);
    }  //izdara to pašu, tikai ar maršruta cenu
    replace(s.begin(), s.end(), ',', ' ');
    if (sadalita_cena[0] < sadalita_ievadita_cena[0]) cout << s << endl;
    else if (sadalita_cena[0] == sadalita_ievadita_cena[0] && sadalita_cena[1] < sadalita_ievadita_cena[1]) cout << s << endl;  //salīdzina abas cenas un izvada uz ekrāna maršrutu, ja tā cena ir zemāka par ievadīto
  }
  return;

}
 void kludainie_ieraksti() { //funkcija, kas ekrānā izvada err.txt faila saturu
   cout << "result:" << endl;
   ifstream errFile;
   errFile.open("err.txt");
   string s;
   while(getline(errFile, s)) {
     cout << s << endl;
   }
   return;
 }

vector<string> ierakstu_skirosana() {  //funkcija, kas šķiro db.csv faila ierakstus pēc pareizības
  vector<string> pareizi_marsruti;
  ifstream inFile;
  ofstream outFile("err.txt");  //err.txt fails tiek uztaisīts un atvērts rakstīšanai
  inFile.open("db.csv");  //db.csv fails tiek atvērts lasīšanai

  if (!inFile) return pareizi_marsruti;  //pārbauda, vai fails eksistē

  string s; 
  while (getline(inFile, s)) {  //iziet cauri visām rindām db.csv failā
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ' '|| s[i] == '\n' || s[i] == '\r') {  //pārbauda, vai dotais simbols rindā ir tāds, kuru vajag ignorēt
        s.erase(i, 1);
        i--;  //indekss tiek samazināts par 1, lai cikls pareizi turpina darboties pēc simbola izdzēšanas
      }
    }
    if (marsruta_parbaude(s)) {
      pareizi_marsruti.push_back(s);  //ja ieraksts ir pareizs, tad tas tiek pievienots pareizo ierakstu vektoram
    }
    else  {
      if (!s.empty()) {  //pārbauda, vai ieraksts nav tukšs
        outFile << s << endl;  //ieraksta nepareizos ierakstus err.txt failā
      }
    }
  }
  return pareizi_marsruti;  //funkcija atgriež vektoru, ar pareizi ievadītiem maršrutiem
}

int main() {
  vector<string> marsruti = ierakstu_skirosana();
  char izvele;
  while (izvele != 'e') {
    cin >> izvele;
    switch (izvele) {
      case 'a':
        filtret_pieturas(marsruti);
        break;
      
      case 'b':
        filtret_dienas(marsruti);
        break;
      
      case 'c':
        filtret_cenu(marsruti);
        break;
      
      case 'd':
        kludainie_ieraksti();
        break;
      
      case 'e':
        break;
      
      default:
        cout << "wrong command" << endl;
        break;
    }
  }
} 