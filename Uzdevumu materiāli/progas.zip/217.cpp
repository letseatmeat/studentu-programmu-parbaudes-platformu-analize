
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;
int main() {
  
while (true){
  string vaic;
  cin >> vaic;

ifstream inFile;
inFile.open("db.csv");

if (!inFile) return 0;

if (vaic == "a") {  //strādā, bet izvada lieku tukšu rindu
string a1, a2;
cin >> a1;
cin >> a2;
cout << "result:\n";

ifstream db("db.csv");

    for (string rinda; getline(db, rinda);) {
        if (rinda.find(a1) == 0 && rinda.find(a2) != string::npos) {
          
            rinda.erase(0, rinda.find_first_not_of(' '));
            replace(rinda.begin(), rinda.end(), ',', ' ');
            rinda.erase(unique(rinda.begin(), rinda.end(), [](char a, char b) { return a == ' ' && b == ' '; }), rinda.end());
            cout << rinda << endl;
        }
    }
    }

else if (vaic == "b"){  // dara to pašu problēmu, ko 'a'
string b;
cin >> b;
cout << "result:\n";

ifstream db("db.csv");

 string rinda;
  while (getline(db, rinda)) {
    
      rinda.erase(0, rinda.find_first_not_of(' '));
      replace(rinda.begin(), rinda.end(), ',', ' ');
      rinda.erase(unique(rinda.begin(), rinda.end(), [](char a, char b) { return a == ' ' && b == ' '; }), rinda.end());
      if (rinda.find(b) != string::npos) {
          cout << rinda << endl;
      }
  }
}
else if (vaic == "c"){  // stādā, bet izvada vienu lieku vērtību testā (kurai ir lieka papildus diena)
double c;
cin >> c;
cout << "result:\n";

ifstream db("db.csv");
string rinda;
while (getline(db, rinda)) {

      rinda.erase(0, rinda.find_first_not_of(' '));
     replace(rinda.begin(), rinda.end(), ',', ' ');
      rinda.erase(unique(rinda.begin(), rinda.end(), [](char a, char b) { return a == ' ' && b == ' '; }), rinda.end());

    istringstream cc(rinda);
    string vert;
    double dec;

    while (cc >> vert) {
        try {
            size_t poz;
              dec = stod(vert, &poz);
            if (poz == vert.length() && dec <= c) {
                cout << rinda << endl;
                break;
            }
        } catch (const invalid_argument& e) {
        }
      
    }
}
}
  else if (vaic == "d"){ //vajag vel parveidot, pagaidam tikai pagaidu risinajums
    cout << "result:\n";
    ifstream db("db.csv");
    ofstream error("err.txt");

      string rinda;
      while (getline(db, rinda)) {

          stringstream dd(rinda);
          string nav;
          int skaits = 0;
          while (getline(dd, nav, ',')) {
                skaits++;
          }

          if (skaits != 5) {
            error << rinda << "\n";
            cout << rinda << "\n";
          }
      }
    }
  else if (vaic == "e"){
    break;
  }
}
}
