#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <bits/stdc++.h>
#include <sstream>
using namespace std;

void outputCities(const vector<map<string, string>>& schedule){
  string city1, city2;
  cin >> city1 >> city2;
  cout << "result:" << endl;
  for (const auto& entry : schedule){
    float price = stof(entry.at("price"));
    if (city1 == entry.at("city1") && city2 == entry.at("city2")) {
        cout <<entry.at("city1") << " " << entry.at("city2") << " " << entry.at("weekday") << " " << entry.at("time") << " " << fixed << setprecision(2) << price << endl;
    }
  }
}
void outputWeekdays(const vector<map<string, string>>& schedule){
  string input;
  cin >> input;
  cout << "result:" << endl;
  for (const auto& entry : schedule){
    float price = stof(entry.at("price"));
    string weekday = entry.at("weekday");
    if (input == weekday){
      cout <<entry.at("city1") << " " << entry.at("city2") << " " << entry.at("weekday") << " " << entry.at("time") << " " << fixed << setprecision(2) << price << endl;
    }
  }
}
void outputTickets(const vector<map<string, string>>& schedule){
  float input;
  cin >> input;

  cout << "result:" << endl;

  for (const auto& entry : schedule){
    float price = stof(entry.at("price"));
    if (price <= input) {
        cout <<entry.at("city1") << " " << entry.at("city2") << " " << entry.at("weekday") << " " << entry.at("time") << " " << fixed << setprecision(2) << price << endl;
    }
  }
}
void outputErrors(){
  string line;
  ifstream file("ett.txt");
  cout << "result:" << endl;
  while (getline(file, line)) {
      cout << line << endl;
  }
}


int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;
  
  vector<map <string, string>> schedule;
  string line;
  ofstream errorFile("ett.txt", ios::trunc);
  while (getline(inFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line.empty()){
      continue;
    }
    stringstream ss(line);
    vector<string> elements;
    string element;
    int counter = 0;
    while (getline(ss, element, ',')) {
        elements.push_back(element);
        counter++;
    }
    if (counter != 5){
      ofstream errorFile("ett.txt",ios::app);
      errorFile << line << endl;
      continue;
    }
    try{
      map<string, string> entry;
      string city1 = elements[0];
      string city2 = elements[1];
      string weekday = elements[2];
      string time = elements[3];
      if (time.find(":") == string::npos || time.length() != 5){
        ofstream errorFile("ett.txt",ios::app);
        errorFile << line << endl;
        continue;
      }
      double checkPrice = stof(elements[4]);
      string price = to_string(checkPrice);
      entry["city1"] = city1;
      entry["city2"] = city2;
      entry["weekday"] = weekday;
      entry["time"] = time;
      entry["price"] = price;
      
      schedule.push_back(entry);
      
    } catch (int i){
      ofstream errorFile("ett.txt",ios::app);
      errorFile << line << endl;
      continue;
    }
    
  }
  inFile.close();
  
  char input;
  bool toggle = true;
  while(toggle){
    cin >> input; 
    switch(input){
      case 'a':
        outputCities(schedule);
      break;
      case 'b':
        outputWeekdays(schedule);
        break;
      case 'c':
        outputTickets(schedule);
        break;
      case 'd':
        outputErrors();
        break;
      case 'e':
        toggle = false;
        break;
      default:
        cout << "Ievadiet pareizu komandu!" << endl;
    }    
  }
}

