#include <algorithm>
#include <fstream>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <unordered_set>

using namespace std;

void a(string line, string start, string end) {
  size_t startPos = line.find(start);
  size_t endPos = line.find(end);

  if (startPos != string::npos && endPos != string::npos && startPos < endPos) {
    replace(line.begin(), line.end(), ',', ' ');
    cout << line << endl;
  }
}

void b(string line, string day) {
  if (line.find(day) != string::npos) {
    replace(line.begin(), line.end(), ',', ' ');
    cout << line << endl;
  }
}

void c(string line, string price) {
  size_t lastCommaPos = line.find_last_of(",");
  if (lastCommaPos != string::npos) {
    string lastElement = line.substr(lastCommaPos + 1);

    // Convert the last element to a double
    stringstream ss(lastElement);
    double lastElementValue;
    if (ss >> lastElementValue) {
      // Check if the last element is a number smaller than price
      if (lastElementValue < stod(price)) {
        replace(line.begin(), line.end(), ',', ' ');
        cout << line << endl;
      }
    }
  }
}

bool isNumericFormat(const string &s) {
  size_t dotPos = s.find('.');
  if (dotPos != string::npos) {
    // Check if the part before the dot is numeric
    string beforeDot = s.substr(0, dotPos);
    if (all_of(beforeDot.begin(), beforeDot.end(), ::isdigit)) {
      // Check if the part after the dot is exactly two numeric characters
      string afterDot = s.substr(dotPos + 1);
      return afterDot.size() == 2 &&
             all_of(afterDot.begin(), afterDot.end(), ::isdigit);
    }
  }
  return false;
}

bool isTimeFormat(const string &s) {
  // Check if the string represents a valid time format from 00:00 to 24:00
  if (s.size() == 5 && s[2] == ':' && isdigit(s[0]) && isdigit(s[1]) &&
      isdigit(s[3]) && isdigit(s[4])) {
    int hours = stoi(s.substr(0, 2));
    int minutes = stoi(s.substr(3, 2));
    return hours >= 0 && hours <= 24 && minutes >= 0 && minutes <= 59;
  }
  return false;
}

bool isWeekFormat(const string &s) {
  unordered_set<string> validWeekdays = {"Pr", "Ot", "Tr", "Ce",
                                         "Pt", "Se", "Sv"};
  return validWeekdays.find(s) != validWeekdays.end();
}

bool processLine(string line) {
  if (count(line.begin(), line.end(), ',') == 4) {
    istringstream ss(line);

    string element1, element2, element3, element4, element5;
    getline(ss, element1, ',');
    getline(ss, element2, ',');
    getline(ss, element3, ',');
    getline(ss, element4, ',');
    getline(ss, element5, ',');
    if (isWeekFormat(element3) && isTimeFormat(element4) &&
        isNumericFormat(element5)) {
      return true;
    } else {
      return false;
    }
  }

  return false;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;

  ifstream errFileRead;
  errFileRead.open("err.txt");
  if (!errFileRead)
    return 0;

  ofstream errFileWrite;
  errFileWrite.open("err.txt");
  if (!errFileWrite) {
    return 0;
  }

  string line;
  while (getline(inFile, line)) {
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (processLine(line)) {
      // correct line format
    } else if (!line.empty()) {
      // Write the line to the error file
      errFileWrite << line << endl;
    }
  }
  errFileWrite.close();

  char charecter;
  while (true) {
    cout << "Ievadiet a, b, c , d vai e:" << endl;
    cin >> charecter;
    cin.clear();
    switch (charecter) {

    case 'a': {
      inFile.clear();  // Clear any error flags
      inFile.seekg(0); // Set the file pointer to the beginning
      cout << "Ievadiet sākuma pieturas nosaukumu:" << endl;
      string start;
      cin >> start;
      cout << "Ievadiet beigu pieturas nosaukumu:" << endl;
      string end;
      cin >> end;
      cout << "result:" << endl;
      string line;
      while (getline(inFile, line)) {
        // Remove spaces from the line
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (processLine(line)) {
          // correct line format
          a(line, start, end);
        }
      }
    } break;

    case 'b': {
      inFile.clear();  // Clear any error flags
      inFile.seekg(0); // Set the file pointer to the beginning
      cout << "Ievadiet nedēļas dienu:" << endl;
      string day;
      cin >> day;
      cout << "result:" << endl;
      string line;
      while (getline(inFile, line)) {
        // Remove spaces from the line
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (processLine(line)) {
          // correct line format
          b(line, day);
        }
      }
    } break;
    case 'c': {
      inFile.clear();  // Clear any error flags
      inFile.seekg(0); // Set the file pointer to the beginning
      cout << "Ievadiet brauciena cenu:" << endl;
      string price;
      cin >> price;
      cout << "result:" << endl;
      string line;
      while (getline(inFile, line)) {
        // Remove spaces from the line
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
        if (processLine(line)) {
          // correct line format
          c(line, price);
        }
      }
    } break;
    case 'd': {
      errFileRead.clear();
      errFileRead.seekg(0);
      cout << "result:" << endl;
      string s;
      while (errFileRead >> s) {
        cout << s << endl;
      }
    } break;
    case 'e':
      return 0;
    default: {
      cout << "Nepareiza ievade" << endl;
    } break;
    }
  }
  // piemers
}
