#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>
#include <cctype>

using namespace std;

bool ValidCity(string city) {
  return find_if(city.begin(), city.end(), ::isdigit) == city.end();
}
int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

	if (!inFile){
    cerr << "Can't open file" << endl;
    return 1;
  }
  
  string s; 
  vector<string> valids;
	while (getline(inFile, s)){
    //remove whitespace
    s.erase(remove_if(s.begin(), s.end(), ::isspace),s.end());
    if(s.empty()){
      continue;
    }

    //split string into vector (5)
    stringstream ss(s);
    string field;
    vector<string> fields;
    while(getline(ss, field, ',')){
      fields.push_back(field);
    }
    
    if (fields.size() != 5 || !ValidCity(fields[0]) || !ValidCity(fields[1])){
      errFile << s << endl;
    }
    else{
      replace(s.begin(), s.end(), ',' , ' ');
      valids.push_back(s);
    }
  }
  
  inFile.close();
  errFile.close();  
    
  char input;
  //cout << "Input: ";
  cin >> input;

  if (input == 'a') {
    string city1, city2;
    //cout << "City1: ";
    cin >> city1;
    //cout << "City2: ";
    cin >> city2;
    cout << "result: " << endl;
    for (const auto& valid : valids) {
      stringstream ss(valid);
      string field;
      vector<string> fields;
      while (getline(ss, field, ' ')) {  
        fields.push_back(field);
      }
      
      if (fields[0] == city1 && fields[1] == city2) {
        cout << valid << endl;
      }
    }
  }

  if(input == 'b'){
    string day;
    cin >> day;
    cout << "result: " << endl;
    for (const auto& valid : valids) {
    stringstream ss(valid);
    string field;
    vector<string> fields;
    while (getline(ss, field, ' ')) { 
      fields.push_back(field);
    }
    if (day == "Pr"){
      if (fields[2] == "Pr"){
        cout << valid << endl;
      }
    }
    else if (day == "Ot"){
      if (fields[2] == "Ot"){
        cout << valid << endl;
      }
    }
      else if (day == "Tr"){
        if (fields[2] == "Tr"){
          cout << valid << endl;
        }
      }
      else if (day == "Ce"){
        if (fields[2] == "Ce"){
          cout << valid << endl;
        }
      }
      else if (day == "Pt"){
        if (fields[2] == "Pt"){
          cout << valid << endl;
        }
      }
      else if (day == "St"){
        if (fields[2] == "St"){
          cout << valid << endl;
        }
      }
      else if (day == "Sv"){
        if (fields[2] == "Sv"){
          cout << valid << endl;
        }
      }
    } 
  }

  if (input == 'c'){
    string daudz;
    cin >> daudz;
    float daudz2 = stof(daudz);
    cout << "result: " << endl;
    for (const auto& valid : valids) {
    stringstream ss(valid);
    string field;
    vector<string> fields;
    while (getline(ss, field, ' ')) {  
      fields.push_back(field);
    }

    float p = stof(fields[4]);
    if(p <= daudz2){
      cout << valid << endl;
    }
    }  
  }

    
  if (input == 'd'){
    ifstream errFile2("err.txt");
    string i;
    cout << "result: " << endl;
    while(getline(errFile2, i)){
      cout << i << endl;
    }
    errFile2.close();
  }
  
  if (input == 'e') {
    return 0;
  }
  
  return 0;
} 