
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
using namespace std;
struct BusRoute {
  string startStop;
  string endStop;
  string dayOfWeek;
  string time;
  double ticketPrice;
};
void readFile(const string &filename, vector<BusRoute> &routes, ofstream &errorFile) {
  ifstream file(filename);
  if (!file.is_open()) {
    cerr << "Error opening file: " << filename << endl;
    exit(EXIT_FAILURE);
  }
  string line;
  while (getline(file, line)) {
    if (line.empty())
      continue;
    istringstream iss(line);
    vector<string> tokens;
    string token;
    while (getline(iss, token, ',')) {
      token.erase(0, token.find_first_not_of(" "));
      token.erase(token.find_last_not_of(" ") + 1);
      tokens.push_back(token);
    }
    if (tokens.size() != 5 || tokens[0].empty() || tokens[1].empty() ||
        tokens[2].empty() || tokens[3].empty() || tokens[4].empty() ||
        tokens[3].find(':') == string::npos) {
      errorFile << line << endl;
      continue;
    }
    BusRoute route;
    route.startStop = tokens[0];
    route.endStop = tokens[1];
    route.dayOfWeek = tokens[2];
    route.time = tokens[3];
    try {
      route.ticketPrice = stod(tokens[4]);
    } catch (const invalid_argument &e) {
      continue;
    }
    routes.push_back(route);
  }
  file.close();
}
void caseA(const vector<BusRoute> &routes) {
  string startStop, endStop;
  cin.ignore();
  getline(cin, startStop);
  getline(cin, endStop);
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.startStop == startStop && route.endStop == endStop) {
      cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
    }
  }
}
void caseB(const vector<BusRoute> &routes) {
  string dayOfWeek;
  cin >> dayOfWeek;
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.dayOfWeek == dayOfWeek) {
      cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek
           << " " << route.time << " " << fixed << setprecision(2)
           << route.ticketPrice << endl;
    }
  }
}
void caseC(const vector<BusRoute> &routes) {
  double maxPrice;
  cin >> maxPrice;
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.ticketPrice <= maxPrice) {
      cout << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
    }
  }
}
void caseD(const string &filename) {
string line;
ifstream file(filename);
    if (file.is_open()) {
        cout << "result:" << endl;
        while (getline(file, line)) {
            line.erase(0, line.find_first_not_of("\r"));
            line.erase(line.find_last_not_of("\r") + 1);
            if (!line.empty()) {
                cout << line << endl;
            }
        }
        file.close();
    } else {
        cerr << "Error opening error file: " << filename << endl;
    }
}

int main() {
  vector<BusRoute> routes;
  ofstream errorFile("err.txt");
  readFile("db.csv", routes, errorFile);
  char choice;
  do {
    cin >> choice;
    switch (choice) {
    case 'a':
      caseA(routes);
      break;
    case 'b':
      caseB(routes);
      break;
    case 'c':
      caseC(routes);
      break;
    case 'd':
      caseD("err.txt");
      break;
    case 'e':
      break;
    default:
      cout << "Invalid choice. Try again." << endl;
    }
  } while (choice != 'e');
  return 0;
}