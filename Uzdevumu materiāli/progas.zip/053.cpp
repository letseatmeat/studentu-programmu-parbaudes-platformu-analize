
#include <fstream>
#include <iostream>
#include <list>

using namespace std;

void errIzvade();
int readFile();

inline string trim(std::string &str) {
  str.erase(str.find_last_not_of(' ') + 1);
  str.erase(0, str.find_first_not_of(' '));
  return str;
}

class marsuts {
public:
  string fromWhere;
  string toWhere;
  string day;
  int timeHH;
  int timeMM;
  float price;

  marsuts(string a, string b, string c, int d, int e, float f) {
    fromWhere = a;
    toWhere = b;
    day = c;
    timeHH = d;
    timeMM = e;
    price = f;
  }

  marsuts() {}
};

list<marsuts> getValue();
void printLine(marsuts s);
void noMarsuta(marsuts *marsuti, int length);
void noDienas(marsuts *marsuti, int length);
void noCenas(marsuts *marsuti, int length);

int main() {
  bool flag = true;
  string ievade;
  if (readFile() == -2)
    return 0;

  list<marsuts> saraksts = getValue();
  marsuts marsuti[saraksts.size()];
  int i = 0;
  for (marsuts s : saraksts) {
    marsuti[i].fromWhere = s.fromWhere;
    marsuti[i].toWhere = s.toWhere;
    marsuti[i].day = s.day;
    marsuti[i].timeHH = s.timeHH;
    marsuti[i].timeMM = s.timeMM;
    marsuti[i].price = s.price;
    i++;
  }
  saraksts.clear();

  while (flag) {
    // cout << "ievadiet darbību: " << endl;
    cin >> ievade;

    if (ievade == "a") {
      noMarsuta(marsuti, i);
    } else if (ievade == "b") {
      noDienas(marsuti, i);
    } else if (ievade == "c") {
      noCenas(marsuti, i);
    } else if (ievade == "d") {
      errIzvade();
    } else if (ievade == "e") {
      flag = false;
    } else {
      cout << "ievades kļūda" << endl;
    }
  }
  return 0;
}

void noMarsuta(marsuts *marsuti, int length) {
  string fromWhere, toWhere;
  cout << "ievadiet maršutu: " << endl;
  cin >> fromWhere >> toWhere;
  cout << "result:" << endl;

  for (int i = 0; i < length; i++) {
    if (marsuti[i].fromWhere == fromWhere && marsuti[i].toWhere == toWhere)
      printLine(marsuti[i]);
  }
}

void noDienas(marsuts *marsuti, int length) {
  string diena;
  cout << "ievadiet dienu: " << endl;
  cin >> diena;
  cout << "result:" << endl;

  for (int i = 0; i < length; i++) {
    if (marsuti[i].day == diena)
      printLine(marsuti[i]);
  }
}

void noCenas(marsuts *marsuti, int length) {
  string cena;
  cout << "ievadiet cenu: " << endl;
  cin >> cena;
  cout << "result:" << endl;

  float price = stof(cena);
  for (int i = 0; i < length; i++) {
    if (marsuti[i].price <= price + 0.005)
      printLine(marsuti[i]);
  }
}

// repl interesanti darbojas
void errIzvade() {
  ifstream inFile;
  inFile.open("err.txt");
  cout << "result:" << endl;
  for (string line; getline(inFile, line);) {
    string s = line;
    //printf("%s\n", &s);
    //cout << line << endl;
    
    for (char a : s) {
      printf("%c", a);
    }
    printf("\n");
  
  }
}

list<marsuts> getValue() {
  ifstream inFile;
  list<string> invalidLines;
  list<marsuts> validLines;

  inFile.open("db.csv");

  int i = 0;
  int j = 0;
  string tempString;
  marsuts tempMarsuts;
  string tempFrom;
  string tempWhere;
  string tempDay;
  int tempTimeHH;
  int tempTimeMM;
  float tempCost;
  string dienas = "Pr Ot Tr Ce Pt St Sv";
  string tempNum;
  int k;
  bool wasSeperated;
  for (string line; getline(inFile, line);) {
    i = 0;
    j = 0;
    line += ",";
    while (line[i] != '\0' && j < 6) {
      if (line[i] != ',') {
        tempString += line[i];
      } else {
        j++;
        if (j == 1) { // if from
          if (tempString.length() < 1)
            break;

          tempString = trim(tempString);

          tempFrom = tempString;
        } else if (j == 2) { // if to
          if (tempString.length() < 1)
            break;
          tempString = trim(tempString);
          tempWhere = tempString;
        } else if (j == 3) { // if day
          tempString = trim(tempString);
          if (tempString.length() != 2)
            break;

          if (dienas.find(tempString) !=
              string::npos) { // if Pr, Ot, Tr, Ce, Pt, St, Sv
            tempDay = tempString;
          } else {
            break;
          }
        } else if (j == 4) { // if time

          tempString = trim(tempString);

          if (tempString.length() != 5)
            break;
          k = 0;
          wasSeperated = false;
          tempNum.clear();
          while (tempString[k] != '\0') {
            if (tempString[k] == ':') {
              wasSeperated = true;
              tempNum.clear();
            } else {
              if (isdigit(tempString[k]) == false) {
                j = 50;
                break;
              }
              tempNum += tempString[k];
              if (tempNum.length() == 2) {
                if (!wasSeperated) {
                  if (stoi(tempNum) >= 0 && stoi(tempNum) <= 24) {
                    tempTimeHH = stoi(tempNum);
                  } else {
                    j = 50;
                    break;
                  }
                } else {
                  if (stoi(tempNum) >= 0 && stoi(tempNum) < 60) {
                    tempTimeMM = stoi(tempNum);
                  } else {
                    j = 50;
                    break;
                  }
                }
              }
              // break;
            }
            k++;
          } // while

        } else if (j == 5) { // if Cost
          tempString = trim(tempString);
          try {
            tempCost = stof(tempString);
          } catch (const exception &e) {
            j = 50;
            break;
          }
        }
        tempString.clear();
      } // if (line[i] != ',')else
      i++;
    } // while

    if (j != 5) {
      line.pop_back();
      invalidLines.push_back(line);
    } else {
      marsuts tempMarsuts(tempFrom, tempWhere, tempDay, tempTimeHH, tempTimeMM,
                          tempCost);
      validLines.push_back(tempMarsuts);
    }
  }

  ofstream outputFile;
  outputFile.open("err.txt");
  for (string s : invalidLines) {
    if (s.length() == 1) // repl interesanta paradiba
      continue;
    else
      outputFile << s << endl;
  }
  outputFile.close();

  return validLines;
}

int readFile() {
  ifstream inFile;

  inFile.open("err.txt");
  if (inFile)
    remove("err.txt");
  inFile.close();

  inFile.open("db.csv");

  if (!inFile) {
    cout << "no file" << endl;
    inFile.close();
    return -2;
  }
  inFile.close();
  return 0;
}

void printLine(marsuts s) {
  cout << s.fromWhere << " " << s.toWhere << " " << s.day << " ";
  printf("%02d:%02d %.2f\n", s.timeHH, s.timeMM, s.price);
}