

#include <iostream>
#include <fstream>
#include <regex>
#include <vector>

using namespace std;

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  ofstream errFile("err.txt");
  vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

  if (!inFile) return 0;

  string s, a;
  // Reading the file and removing all newline characters and excess spaces that appear in a line

  // Adding all the lines to a string
  while (inFile >> s) {
    regex newlines_re("\n+");

    auto result = regex_replace(s, newlines_re, " ");

    if (s[0] == ',') {
      a.append(s);
    } else {
      a.append(" ");
      a.append(s);
    }
  }

  inFile.close();

  // Removing excess spaces after commas

  for (int i = 1; i < a.length(); ++i) {
    if ((a[i - 1] == ',') && a[i] == ' ') {
      a.erase(i, 1);
    }
  }

  a.erase(0, 1);

  vector<string> records;

  string r;

  // Adding each line as a string to a vector

  for (int i = 0; i < a.length(); ++i) {
    if (a[i] == ' ') {
      records.push_back(r);
      r = "";
  } else {
      r = r + a[i];

      if (i == a.length() - 1) {
        records.push_back(r);
        r = "";
      }
    }
  }

  vector<vector<string>> correctRecords;

  for (auto record : records) {
    vector<string> trip;

    string part;

    // Separating each line into different pieces to check their validity
    // and creating a vector for each seperate line

    for (int i = 0; i < record.length(); ++i) {
      if (record[i] == ',') {
        trip.push_back(part);
        part = "";
      } else {
        part = part + record[i];

        if (i == record.length() - 1) {
          trip.push_back(part);
          part = "";
        }
      }
    }

    // If a record is incorrect, the line gets written in the err.txt file

    // Checking if a line contains exactly 5 elements

    if (trip.size() != 5) {
      errFile << record << endl;
      continue;
    }

    // Checking if the first two elements are all string values without numbers

    if (!all_of(trip[0].begin(), trip[0].end(), [](char const& c) { return isalpha(c); }) ||
      !all_of(trip[1].begin(), trip[1].end(), [](char const& c) { return isalpha(c); })) {
      errFile << record << endl;
      continue;
    }

    // Checking if the third element is one of the week days

    if (!(find(days.begin(), days.end(), trip[2]) != days.end())) {
      errFile << record << endl;
      continue;
    }

    // Using regex to check if time (4th element) is in the correct pattern

    const regex pattern("^(?:[01]?[0-9]|2[0-3]):[0-5]?[0-9]""(?::[0-5]?[0-9])?$");

    if (!regex_match(trip[3], pattern)) {
      errFile << record << endl;
      continue;
    }

    // Checking if the price (5th element) is a number with 2 decimal points

    const regex numberRegex("^[-+]?([0-9]*\\.[0-9]+|[0-9]+)$");

    if (!regex_match(trip[4], numberRegex)) {
      errFile << record << endl;
      continue;
    }

    // Adding element to the vector that contains the correct records

    correctRecords.push_back(trip);
  }

  char letter;
  double price;
  string weekDay;
  string begin, end;

  do {
    cin.clear();
    cin >> letter;

    // Using switch to check which option the user chose
    // then using a foreach cycle to run through the vector with correct records
    // and printing the ones that fit the criteria

    switch (letter) {
      case 'a':
        cout << "result: " << endl;
        cin >> begin;
        cin >> end;

        for (auto correct_record : correctRecords) {
          if (correct_record[0] == begin) {
            if (correct_record[1] == end) {
              for (auto record : correct_record) {
                cout << record << " ";
              }

              cout << endl;
            }
          }
        }
        break;

      case 'b':
        cout << "result: " << endl;
        cin >> weekDay;

        for (auto correct_record : correctRecords) {
          if (correct_record[2] == weekDay) {
            for (auto record : correct_record) {
              cout << record << " ";
            }

            cout << endl;
          }
        }
        break;

      case 'c':
        cout << "result: " << endl;
        cin >> price;

        for (auto correct_record : correctRecords) {
          if (stoi(correct_record[4]) < price) {
            for (auto record : correct_record) {
              cout << record << " ";
            }

            cout << endl;
          }
        }
        break;

      case 'd':
        cout << "result: " << endl;
        inFile.open("err.txt");
        string error;

        while (inFile >> error) {
          cout << error << endl;
        }

        inFile.close();
        break;
    }

  } while (letter != 'e');

  // Clearing memory

  errFile.close();
  records.clear();
  correctRecords.clear();

  return 0;
}
