
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

string weekDays[7] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

class Trip {
public:
  string startName;
  string destinionName;
  string day;
  string time;
  string price;

  void printTripInfo() {
    cout << startName << " " << destinionName << " " << day << " " << time
         << " " << price << endl;
  }
};

Trip parseTrip(string line) {
  vector<string> values;
  stringstream ss(line);
  string value;

  while (getline(ss, value, ',')) {
    value.erase(remove(value.begin(), value.end(), ' '), value.end());
    values.push_back(value);
  }

  Trip trip;
  trip.startName = values[0];
  trip.destinionName = values[1];
  trip.day = values[2];
  trip.time = values[3];
  trip.price = values[4];

  return trip;
}

bool isValidLine(string line) {
  vector<string> values;
  stringstream ss(line);
  string value;

  while (getline(ss, value, ',')) {
    value.erase(remove(value.begin(), value.end(), ' '), value.end());
    values.push_back(value);
  }

  if (values.size() == 5) {

    // Check start stop
    for (int i = 0; i < values[0].length(); i++) {
      if (isdigit(values[0][i])) {
        return false;
      }
    }

    // Check destinition stop
    for (int i = 0; i < values[1].length(); i++) {
      if (isdigit(values[1][i])) {
        return false;
      }
    }

    // Check week day
    bool isWeekDay = false;
    for (int i = 0; i < sizeof(weekDays) / sizeof(weekDays[0]); i++) {
      if (values[2] == weekDays[i]) {
        isWeekDay = true;
      }
    }
    if (isWeekDay == false)
      return false;

    // Check time
    stringstream ss2(values[3]);
    vector<string> time;
    string value;

    while (getline(ss2, value, ':')) {
      time.push_back(value);
    }

    if (time.size() == 2) {
      for (int j = 0; j < time.size(); j++) {
        if (time[j].length() != 2) {
          return false;
        }
        for (int i = 0; i < time[j].length(); i++) {
          if (!isdigit(time[j][i])) {
            return false;
          }
        }
      }
    } else {
      return false;
    }

    // Check price
    try {
      stod(values[4]);
    } catch (...) {
      return false;
    }

    return true;
  } else {
    return false;
  }
}

void showRouteTrips(vector<Trip> trips) {
  string startName;
  string destinitionName;

  cin >> startName;
  cin >> destinitionName;

  for (int i = 0; i < trips.size(); i++) {
    if (trips[i].startName == startName &&
        trips[i].destinionName == destinitionName) {
      trips[i].printTripInfo();
    }
  }
}

void showWeekDayTrips(vector<Trip> trips) {
  string weekDay;

  cin >> weekDay;

  for (int i = 0; i < trips.size(); i++) {
    if (trips[i].day == weekDay) {
      trips[i].printTripInfo();
    }
  }
}

void showPriceTrips(vector<Trip> trips) {
  string price;

  cin >> price;

  double userPrice = stod(price);

  for (int i = 0; i < trips.size(); i++) {
    if (stod(trips[i].price) < userPrice) {
      trips[i].printTripInfo();
    }
  }
}

void readWrongTrips() {
  ifstream inFile;
  inFile.open("err.txt");
  string line;

  if (!inFile)
    return;

  while (getline(inFile, line)) {
    cout << line << endl;
  }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  string line;
  vector<Trip> trips;
  vector<string> wrongTrips;
  int i = 0;

  while (getline(inFile, line)) {
    if (isValidLine(line)) {
      trips.push_back(parseTrip(line));
    } else {
      stringstream ss(line);
      string value;
      string trip;

      while (getline(ss, value)) {
        value.erase(remove(value.begin(), value.end(), ' '), value.end());
        trip = value;
      }
      if (trip != "") {
        wrongTrips.push_back(trip);
      }

      ofstream outFile;
      outFile.open("err.txt");
      if (!outFile)
        return 0;
      for (int i = 0; i < wrongTrips.size(); i++) {
        outFile << wrongTrips[i] << "\n";
      }
      outFile.close();
    }
  }

  string input;

  while (input != "e") {
    cin >> input;

    if (input == "a") {
      cout << "result:" << endl;
      showRouteTrips(trips);
    }
    if (input == "b") {
      cout << "result:" << endl;
      showWeekDayTrips(trips);
    }
    if (input == "c") {
      cout << "result:" << endl;
      showPriceTrips(trips);
    }
    if (input == "d") {
      cout << "result:" << endl;
      readWrongTrips();
    }
  }

  inFile.close();
}