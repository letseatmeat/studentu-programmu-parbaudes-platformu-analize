

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <set>
#include <algorithm>

using namespace std;

// Funkcija teksta pārveidei uz uppertext
string UpperCase(string text) {
  for (int i = 0; i < text.length(); i++) text[i] = toupper(text[i]);
  return text;
}

// Funkcija laika formāta atbilstības novērtēšanai
bool timeCheckFail(string time) {
  if (count(time.begin(), time.end(), ':') != 1) return true; // Jāsatur atdalītājs starp stundām un minūtēm

  // Pārbauda vai ievade ir skaitļi
  for (int i = 0; i < time.length(); i++) {
    if (!isdigit(time[i]) && time[i] != ':') {
      return true;
    }
  }

  // Pārbaude vai stundu skaits ir zem 23
  string hour = time.substr(0, time.size() - time.find(':') - 1);
  if (stoi(hour) > 23) return true;
  // Pārbaude vai minūšu skaits ir zem 60
  string minutes = time.substr(time.find(':') + 1);
  if (stoi(minutes) > 59) return true;

  return false;
}

// Funkcija cenas formāta atbilstības pārbaudei
bool priceCheckFail(string price) {
  if (count(price.begin(), price.end(), '.') > 1) return true; // Var saturēt ne vairāk kā vienu decimāldaļu atdalītāju

  // Pārbauda vai ievade ir skaitļi
  for (int i = 0; i < price.length(); i++) {
    if (!isdigit(price[i]) && price[i] != '.') {
      return true;
    }
  }
  return false;
}

// Funkcija err.txt izvadei
void printErrFile() {
  ifstream errFile;
  errFile.open("err.txt");
  string text;
  cout << "result:" << endl;
  while (getline(errFile, text)) {
    cout << text << endl;
  }
  errFile.close();
}

// Funkcija viena reisa rindiņas izvadei
void printTrip(vector<string> db) {
  for (string element : db) cout << element << " ";
  cout << endl;
}

// Funkcija, kas meklē reisus, kuru biļetes maksa nepārsniedz norādīto
void findPrice(vector<vector<string>> db, string price) {
  if (priceCheckFail(price)) { // Ja ievade neatbilst formātam, izvada kļūdu
    cout << "Incorrect price" << endl;
    return;
  }
  cout << "result:" << endl;
  for (vector<string> line : db) {
    if (stod(line[4]) <= stod(price)) printTrip(line);
  }

}

// Funkcija, kas meklē reisus pēc dienas
void findDay(vector<vector<string>> db, string day) {
  // Pārbaude vai ievade atbilst kādai dienai
  set<string> days;
  days.insert("PR");
  days.insert("OT");
  days.insert("TR");
  days.insert("CE");
  days.insert("PT");
  days.insert("ST");
  days.insert("SV");
  cout << "result:" << endl;
  if (days.find(day) == days.end()) {
    cout << "Incorrect Day" << "\n";
    return;
  }
  // Sameklē reisus, kas notiek tajā dienā
  for (vector<string> line : db) {
    if (UpperCase(line[2]) == day) printTrip(line);
  }
}

// Funkcija, kas meklē reisus pēc maršruta
void findFromTo(vector<vector<string>> db, string from, string to) {
  cout << "result:" << endl;
  for (vector<string> line : db) {
    if (UpperCase(line[0]) == from && UpperCase(line[1]) == to) printTrip(line);
  }
}

// Funkcija db.csv faila apstrādei
vector<vector<string>> processFile() {
  vector<vector<string>> dbFileData;	// Vektora, kas saturēs maršrutus, inicializācija
  set<string> days;					// Kopa, pēc kuras pārbaudīs db.csv datu dienas lauku
  days.insert("Pr");
  days.insert("Ot");
  days.insert("Tr");
  days.insert("Ce");
  days.insert("Pt");
  days.insert("St");
  days.insert("Sv");

  ifstream inFile;					// Failu inicializācija
  ofstream errorFile("err.txt");
  inFile.open("db.csv");

  if (!inFile) {						// Ja fails netiek atrasts, izvada kļūdu
    cout << "File not found" << endl;
    throw invalid_argument("File not found");
  }
  string line;
  while (getline(inFile, line))		// Lasa failu pa rindām
  {	// Rindas beigu rakstzīme (\r) ietekmē programmas darbību portālā repl
    line.erase(remove(line.begin(), line.end(), '\r'), line.end());	//Noņem \r rakstzīmi (Visual Studio izdzīvoja ar \r ¯\_(ツ)_/¯)
    if (line == "\n" || line.empty()) continue;					// Rindu izlaiž, ja tā ir tukša vai satur tikai enter
    stringstream s(line);
    vector<string> division;
    // Sadala rindu masīvā pēc komatiem
    while (s.good()) {
      string substr;
      getline(s, substr, ',');
      division.push_back(substr);
    }
    // Ja ir par daudz/par maz lauku, rinda tiek uzskatīta kā kļūdaina un izvadīta err.txt failā, pāriet uz nākamo rindu
    if (division.size() != 5) {
      errorFile << line << "\n";
      continue;
    }
    // Atstarpju noņemšana no pilsētu vārdu nosaukumu sākumiem un beigām.
    // Pastāv pilsētas, kas sastāv no vairākiem vārdiem.
    // Piemēram, Stoka pie Trentas, kas nozīmē, ka atstarpes pilsētvārdu vidū jāatstāj
    for (int i = 0; i < 2; i++) {
      int j = 0;
      int k = division[i].size();
      // Izskaita, cik daudz atstarpju ir vārda sākumā un tās noņem
      for (j; j < k; j++) {
        if (!(division[i][j] == ' ' || division[i][j] == '\t')) break;
      }
      division[i].erase(0, j);
      // Izskaita, cik daudz atstarpju ir vārda beigās un tās noņem
      k = division[i].size()-1; // Tā kā vārda izmērs var tikt mainīts, tas vēlreiz jānosaka
      for (k; k >= 0; k--) {
        if (!(division[i][k] == ' ' || division[i][k] == '\t')) break;
      }
      division[i].erase(k+1, division[i].size() - k);
    }
    // Ja viens no pilsētas vārdiem nav ievadīts, tad rinda tiek uzskatīta par kļūdainu
    if (division[0].empty() || division[1].empty()) {
      errorFile << line << "\n";
      continue;
    }

    // Noņem atstarpes no pārējiem laukiem
    for (int i = 2; i < 5; i++)
      division[i].erase(remove(division[i].begin(), division[i].end(), ' '), division[i].end());

    // Parbauda dienu pareizību
    if (days.find(division[2]) == days.end()) {
      errorFile << line << "\n";
      continue;
    }
    // Parbauda laika pareizību
    if (timeCheckFail(division[3])) {
      errorFile << line << "\n";
      continue;
    }
    // Parbauda cenas pareizību
    if (priceCheckFail(division[4])) {
      errorFile << line << "\n";
      continue;
    }
    // Ja viss pareizi, tad pievieno masīvam
    dbFileData.push_back(division);
  }
  // Aizver failus
  errorFile.close();
  inFile.close();
  return dbFileData;
}

int main() {
  vector<vector<string>> input;
  try {										// Cenšas inicializēt db.csv
    input = processFile();
  }
  catch (invalid_argument& e){
    cerr << "Error:" << e.what() << endl;	// Ja neizdodas, tad izmet kļūdu
    return 1;
  }
  string command;								
  while (true) {
    command.clear();
    cin >> command;							// Iegūst ievadīto komandu, iepriekšējo notīra
    if (command.size() != 1) {				// Ja nav viena rakstzīme, tad uzskata komandu par kļūdainu
      cout << "Incorrect command" << endl;
      continue;
    }
    switch (command[0]) {					// Atkarībā no komandas izvēlas darbību
      case 'a': {
        string from, to;
        from.clear();
        to.clear();
        cin >> from;
        cin >> to;
        findFromTo(input, UpperCase(from), UpperCase(to));
        break;
      }
      case 'b': {
        string day;
        day.clear();
        cin >> day;
        findDay(input, UpperCase(day));
        break;
      }
      case 'c': {
        string price;
        price.clear();
        cin >> price;
        findPrice(input, price);
        break;
      }
      case 'd':
        printErrFile();
        break;
      case 'e':
        return 0;
      default: // Ja komanda nepastāv, tad uzskata komandu par kļūdainu
        cout << "Incorrect command" << endl;
        break;
    }
  }
  return 0;
}