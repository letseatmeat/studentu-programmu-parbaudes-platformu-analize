#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Palīgfunkcija, kas validē cenu
bool ir_skaitlis(const string &s) {
  bool vairaki_komati = false;
  for (char c : s) {
    if (!isdigit(c)) {
      if (c == '.' && !vairaki_komati) {
        vairaki_komati = true;
      } else {
        return false;
      }
    }
  }
  return true;
}

// Palīgfunkcija, kas validē dienu
bool ir_diena(const string &s) {
  vector<string> dienas = {"Pr", "Ot", "Tr", "Ce", "Pt", "Se", "Sv"};
  return find(dienas.begin(), dienas.end(), s) != dienas.end();
}

// Palīgfunkcija, kas validē laiku
bool ir_laiks(const string &s) {
  if (s.length() != 5 || s[2] != ':') {
    return false;
  }

  string stundas = s.substr(0, 2);
  string minutes = s.substr(3, 2);

  for (char c : stundas) {
    if (!isdigit(c)) {
      return false;
    }
  }

  for (char c : minutes) {
    if (!isdigit(c)) {
      return false;
    }
  }

  int stunda = stoi(stundas);
  int minute = stoi(minutes);
  if (stunda < 0 || stunda >= 24 || minute < 0 || minute >= 60) {
    return false;
  }
  return true;
}

int main() {
  // Masīvs kurā glabāsies gala informācija ar kuru tiks strādāts dotajā
  // uzdevumā
  vector<vector<string>> dati;

  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  // Izveidots fails kurā glabāsies kļūdainā informācija
  ofstream outfile("err.txt");

  if (!outfile) {
    return 0;
  }

  string line;
  // Nolasu failu pa rindām
  while (getline(inFile, line)) {
    // Atsevišķā mainīgā glabāju oriģinālo rindu, lai to saglabāt atsevišķā
    // failā kļūdainas ievades gadījumā
    string originalLine = line;
    // Iztīru rindu no liekām atstarpēm
    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    // Izlaižu tukšas rindas
    if (line == "") {
      // outfile << originalLine;
      continue;
    }
    // Izlaižu rindas ar nepietiekamu ierakstu skaitu
    int ieraksti = count(line.begin(), line.end(), ',');
    if (ieraksti != 4) {
      outfile << originalLine;
      continue;
    }
    // mainīgais rinda tiek izmantots, lai pakāpeniski to izjaukt iegūstot tajā
    // glabāto informāciju
    string rinda = line;
    // Informācija no rindas tiek pakāpeniski salikta mainīgajos
    string sakums = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string galapunkts = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string diena = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string laiks = rinda.substr(0, rinda.find(","));
    rinda = rinda.substr(rinda.find(",") + 1);
    string cena = rinda;
    // Cenas validācija
    if (!ir_skaitlis(cena)) {
      outfile << originalLine;
      continue;
    }
    // Dienas validācija
    if (!ir_diena(diena)) {
      outfile << originalLine;
      continue;
    }
    // Laika validācija
    if (!ir_laiks(laiks)) {
      outfile << originalLine;
      continue;
    }

    // Mainīgie tiek ierakstīti masīvā kurš attiecīgi tiek pēc tam pievienots
    // gala datu masīvam
    vector<string> rindas_dati = {sakums, galapunkts, diena, laiks, cena};
    dati.push_back(rindas_dati);
  }
  inFile.close();
  outfile.close();

  string ievade = "";
  while (ievade != "e") {
    cin >> ievade;
    if (ievade == "e") {
      continue;
    }
    if (ievade == "a") {
      string sakums, galapunkts;
      cin >> sakums >> galapunkts;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (rinda[0] != sakums || rinda[1] != galapunkts) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts << " ";
        }
        cout << endl;
      }
    }
    if (ievade == "b") {
      string diena;
      cin >> diena;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (rinda[2] != diena) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts << " ";
        }
        cout << endl;
      }
    }
    if (ievade == "c") {
      double cena;
      cin >> cena;
      cout << "result:" << endl;
      for (const auto &rinda : dati) {
        if (stod(rinda[4]) >= cena) {
          continue;
        }
        for (const auto &ieraksts : rinda) {
          cout << ieraksts << " ";
        }
        cout << endl;
      }
    }
    if (ievade == "d") {
      cout << "result:" << endl;
      ifstream errFile("err.txt");

      if (!errFile) {
        return 0;
      }
      // Attiestatu faila lasīšanas vēsturi,
      // lai fails atkal tiktu lasīts no paša sākuma
      errFile.clear();
      errFile.seekg(0);

      while (errFile >> line) {
        cout << line << endl;
      }
      inFile.close();
    }
  }
}