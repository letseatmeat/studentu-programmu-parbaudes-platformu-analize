#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

bool Bezprobelov (const string str){

  int count = 0;
  istringstream potok(str);
  string clear;
  std::vector<string>clears;
 

    
  for (int i = 0; i < str.size(); i++){
    if (str[i] == ','){
      count++;
    }
  }
  while (getline(potok, clear, ',')){
    clears.push_back(clear);
   
    
  }
   
  return (count == 4 && clears[2].size() == 2 && clears[3].find(':') && clears[3].find('.'));
  
}
int main() {
  ifstream inFile;
  ofstream outFile("err.txt");
  inFile.open("db.csv");

	if (!inFile) return 0;
  string First;
  string Second;
  string s;
  char b;
  
  
    
	while (getline(inFile,  s)){
    
    
    s.erase(std::remove(s.begin(), s.end(), ' '), s.end());

    istringstream potok(s);
    string clear;
    std::vector<string>clears;

    while (getline(potok, clear, ',')){
      clears.push_back(clear);
    }
    if (Bezprobelov(s) == false && s.size() > 1){
       outFile<<s<<endl;
  }
    
  }
  outFile.close();
  inFile.close();
  while(true){
    cin >> b;
    switch(b){
      case 'a': {
        inFile.open("db.csv");
        if (!inFile) return 0;
        cin >> First;
        cin >> Second;
        cout<<"result:"<<endl;
      while (getline(inFile,  s)){
        s.erase(std::remove(s.begin(), s.end(), ' '), s.end());
        istringstream potok(s);
        string clear;
        std::vector<string>clears;

        while (getline(potok, clear, ',')){
          clears.push_back(clear);
        }
      if (Bezprobelov(s) && clears[0] == First && clears[1] == Second){
        
        for(int i = 0; i < clears.size(); i++){
          
          if (i == clears.size()-1){
            cout << clears[i];
          }
          else 
             cout << clears[i] << " ";
        }
        cout<<endl;
      }
    }
        inFile.close();
      break;
      }
      case 'b':{
        inFile.open("db.csv");
            if (!inFile) return 0;
            cin >> First;
           
            cout<<"result:"<<endl;
          while (getline(inFile,  s)){
            s.erase(std::remove(s.begin(), s.end(), ' '), s.end());
            istringstream potok(s);
            string clear;
            std::vector<string>clears;

            while (getline(potok, clear, ',')){
              clears.push_back(clear);
            }
          if (Bezprobelov(s) && clears[2] == First){

            for(int i = 0; i < clears.size(); i++){

              if (i == clears.size()-1){
                cout << clears[i];
              }
              else 
                 cout << clears[i] << " ";
            }
            cout<<endl;
          }
            
        }
            inFile.close();
          break;
          }
       case 'c':{
         inFile.open("db.csv");
             if (!inFile) return 0;
         double cost;
             cin >> cost;

             cout<<"result:"<<endl;
           while (getline(inFile,  s)){
             s.erase(std::remove(s.begin(), s.end(), ' '), s.end());
             istringstream potok(s);
             string clear;
             std::vector<string>clears;

             while (getline(potok, clear, ',')){
               clears.push_back(clear);
             }
           if (Bezprobelov(s) && stod(clears[4]) <= cost){

             for(int i = 0; i < clears.size(); i++){

               if (i == clears.size()-1){
                 cout << clears[i];
               }
               else 
                  cout << clears[i] << " ";
             }
             cout<<endl;
           }

         }
             inFile.close();
           break;
           }
      case 'd':{
        cout<<"result:"<<endl;
        inFile.open("err.txt");
        while (getline(inFile,  s)){
           cout<<s<<endl;
        }
        break;
        }
      case 'e':{
        exit(0);
        break;
        }
    }
  }
}
 