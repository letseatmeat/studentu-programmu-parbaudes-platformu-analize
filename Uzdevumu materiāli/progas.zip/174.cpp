

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>

using namespace std;

struct BusRoute {
    string startPoint;
    string endPoint;
    string day;
    string time;
    double price;
};

string trim(const string& str) {
    size_t first = str.find_first_not_of(" ");
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(" ");
    return str.substr(first, (last - first + 1));
}

vector<BusRoute> readDataFromFile(const string& filename, vector<string>& errors) {
    vector<BusRoute> routes;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "error " << filename << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;

        bool isEmpty = all_of(line.begin(), line.end(), ::isspace);
        if (isEmpty) continue;

        istringstream checkOrder(line);
        string checkStartPoint, checkEndPoint, checkDay, checkTime, checkPriceStr;
        getline(checkOrder, checkStartPoint, ',');
        getline(checkOrder, checkEndPoint, ',');
        getline(checkOrder, checkDay, ',');
        getline(checkOrder, checkTime, ',');
        getline(checkOrder, checkPriceStr, ',');
        if (checkOrder.peek() != EOF) {
            errors.push_back(line);
            continue;
        }

        istringstream iss(line);
        string startPoint, endPoint, day, time, priceStr;

        getline(iss, startPoint, ',');
        getline(iss, endPoint, ',');
        getline(iss, day, ',');
        getline(iss, time, ',');
        getline(iss, priceStr, ',');

        startPoint = trim(startPoint);
        endPoint = trim(endPoint);
        day = trim(day);
        time = trim(time);

        if (!priceStr.empty()) {
            try {
                double price = stod(priceStr);
                routes.push_back({startPoint, endPoint, day, time, price});
            } catch (const invalid_argument&) {
                errors.push_back(line);
            }
        } else {
            errors.push_back(line);
        }
    }

    file.close();
    return routes;
}

void removeExtraSpaces(string& str) {
    str.erase(unique(str.begin(), str.end(), [](char a, char b) {
        return a == ' ' && b == ' ';
    }), str.end());
}

void printRoutes(const vector<BusRoute>& routes) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        string startPoint = route.startPoint;
        string endPoint = route.endPoint;
        string day = route.day;
        string time = route.time;

        removeExtraSpaces(startPoint);
        removeExtraSpaces(endPoint);
        removeExtraSpaces(day);
        removeExtraSpaces(time);

        cout << startPoint << " " << endPoint << " " << day
             << " " << time << " " << fixed << setprecision(2) << route.price << endl;
    }
}

void writeErrorsToFile(const vector<string>& errors) {
    ofstream file("err.txt");
    if (!file.is_open()) {
        cerr << "error in err.txt" << endl;
        exit(EXIT_FAILURE);
    }

    for (const auto& error : errors) {
        file << error << endl;
    }

    file.close();
}

int main() {
    vector<string> errors;
    vector<BusRoute> routes = readDataFromFile("db.csv", errors);

    char choice;
    while (true) {
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start;
                cin >> end;

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.startPoint == start && route.endPoint == end) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }

            case 'b': {
                string day;
                cin >> day;

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.day == day) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }

            case 'c': {
                double maxPrice;
                cin >> maxPrice;

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.price <= maxPrice) {
                        filteredRoutes.push_back(route);
                    }
                }

                printRoutes(filteredRoutes);
                break;
            }

            case 'd': {
                cout << "result:" << endl;
                for (const auto& error : errors) {
                    if (!error.empty()) {
                        cout << error << endl;
                    }
                }
                break;
            }

            case 'e':
                cout << "" << endl;
                return 0;

            default:
                cout << "" << endl;
        }
    }

    return 0;
}
