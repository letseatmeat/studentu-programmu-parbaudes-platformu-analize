#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <limits>
#include <set>
#include <algorithm> 

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

bool isValidDayOfWeek(const string& dayOfWeek) {
    vector<string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    return std::find(validDays.begin(), validDays.end(), dayOfWeek) != validDays.end();
}

bool parseLine(const string& line, BusRoute& route) {
    stringstream ss(line);
    string startStop, endStop, dayOfWeek, time, ticketPrice;

    if (!(getline(ss, startStop, ',') && getline(ss, endStop, ',') &&
          getline(ss, dayOfWeek, ',') && getline(ss, time, ',') && getline(ss, ticketPrice, ',') && ss.eof())) {
        ofstream errFile("err.txt", ios::app);
        errFile << line;
        errFile.close();
        return false;
    }

    if (!isValidDayOfWeek(trim(dayOfWeek))) {
        ofstream errFile("err.txt", ios::app);
        errFile << line;
        errFile.close();
        return false;
    }

    route.startStop = trim(startStop);
    route.endStop = trim(endStop);
    route.dayOfWeek = trim(dayOfWeek);
    route.time = trim(time);

    try {
        route.ticketPrice = stod(trim(ticketPrice));
    } catch (...) {
        ofstream errFile("err.txt", ios::app);
        errFile << line;
        errFile.close();
        return false;
    }

    return true;
}

vector<BusRoute> readBusRoutes(const string& filename) {
    vector<BusRoute> routes;

    ofstream errFile("err.txt");

    vector<string> uniqueErrors;

    ifstream inFile(filename);
    if (!inFile) {
        cerr << "Error: Could not open file " << filename << endl;
        exit(EXIT_FAILURE);
    }
    string line;
    while (getline(inFile, line)) {
        if (line.empty()) {
            continue;
        }
        BusRoute route;
        if (parseLine(line, route)) {
            routes.push_back(route);
        } else {
            if (find(uniqueErrors.begin(), uniqueErrors.end(), line) == uniqueErrors.end()) {
                uniqueErrors.push_back(line);
            }
        }
    }
    for (const string& uniqueError : uniqueErrors) {
        errFile << uniqueError << endl;
    }
    errFile.close();
    inFile.close();
    return routes;
}

void displayRoutesByStops(const vector<BusRoute>& routes) {
    string startStop, endStop;
    cout << "Enter start stop: ";
    getline(cin, startStop);

    cout << "Enter end stop: ";
    getline(cin, endStop);

    cout << "result:";
    for (const auto& route : routes) {
        if (route.startStop == startStop && route.endStop == endStop) {
            cout << endl << route.startStop << " " << route.endStop << " "
                 << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice;
        }
    }
    cout << endl;
}

void displayRoutesByDay(const vector<BusRoute>& routes) {
    string day;
    cout << "";
    getline(cin, day);
    cout << "result:";
    for (const auto& route : routes) {
        if (route.dayOfWeek == day) {
            cout << endl << route.startStop << " " << route.endStop << " "
                 << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice;
        }
    }
    cout << endl;
}

void displayRoutesByMaxPrice(const vector<BusRoute>& routes) {
    double maxPrice;
    cout << "Enter maximum ticket price: ";
    cin >> maxPrice;
    cout << "result:";
    for (const auto& route : routes) {
        if (route.ticketPrice <= maxPrice) {
            cout << endl << route.startStop << " " << route.endStop << " " << route.dayOfWeek << " " << route.time << " " << fixed << setprecision(2) << route.ticketPrice;
        }
    }
    cout << endl;
}
void displayErrorFile() {
    ifstream errFile("err.txt");
    if (errFile) {
        cout << "result:" << errFile.rdbuf();
        errFile.close();
    }
}

int main() {
    vector<BusRoute> routes = readBusRoutes("db.csv");

    char choice;
    do {
        cout << "";
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  

        switch (choice) {
            case 'a':
                displayRoutesByStops(routes);
                break;
            case 'b':
                displayRoutesByDay(routes);
                break;
            case 'c':
                displayRoutesByMaxPrice(routes);
                break;
            case 'd':
                displayErrorFile();
                break;
            case 'e':
                break;
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 'e');

    return 0;
}
