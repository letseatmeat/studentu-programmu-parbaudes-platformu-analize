// Agnese Rozenberga 221RDB117 2.kurss 8.grupa
#include <iostream>
#include <iomanip>
#include <set>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm> 

using namespace std;

struct AutobusaMarshruts 
{
    string From;
    string toHere;
    string dienas;
    string laiks;
    string cena;
};


void Saisinat(string& str) 
{
    str.erase(str.begin(),  find_if(str.begin(), str.end(),  [](int ch)
      {
        return !isspace(ch);
      }));

    str.erase(find_if(str.rbegin(), str.rend(), [](int ch) 
    {
        return  !isspace(ch);
    }).base(), str.end());
}

string toLowercase(string str) 
{
    transform(str.begin(), str.end(), str.begin(), ::tolower) ;
    return  str;
}

void uzdevumsA (vector<AutobusaMarshruts>& maršruti, string From, string toHere) 
{
    cout << "result:"<< endl;
    for (const auto& maršruts: maršruti) 
    {
        string saisinsatsFrom =  maršruts.From;
        string saisinatsToHere = maršruts.toHere;

        Saisinat(saisinsatsFrom);
        Saisinat(saisinatsToHere);

        if (saisinsatsFrom == From && saisinatsToHere == toHere) 
         {
            cout << maršruts.From <<" "<< maršruts.toHere << " " << maršruts.dienas << " " << maršruts.laiks << " " << maršruts.cena << endl;
        }
    }
}


void uzdevumsB(vector<AutobusaMarshruts>& maršruti, string dienas) 
{
    cout << "result:" << endl;
    dienas =  toLowercase(dienas);
    for (const auto& maršruts : maršruti) 
    {
        string saisinatsDianas = maršruts.dienas;

        Saisinat(saisinatsDianas);

        saisinatsDianas= toLowercase(saisinatsDianas);

        if (saisinatsDianas == dienas) 
        {
            cout << maršruts.From << " " << maršruts.toHere << " " << maršruts.dienas << " " << maršruts.laiks << " " << maršruts.cena << endl;
        }
    }
}


void UzdevumsC(vector<AutobusaMarshruts>& maršruti, double moneyMoves)
{
    cout << "result:" << endl;

    set<pair<string, string>> processedRoutes;

    for (const auto& maršruts : maršruti) 
    {
        if (stod(maršruts.cena) <= moneyMoves) 
    {
            pair <string, string> route = make_pair(maršruts.From, maršruts.toHere);

            if (processedRoutes.find(route)== processedRoutes.end())
      {
                cout << maršruts.From << " " << maršruts.toHere << " " << maršruts.dienas << " " << maršruts.laiks << " " << fixed <<setprecision(2)<< stod(maršruts.cena) << endl;

                processedRoutes.insert(route);

            }
        }
    }
}

void uzdevumsD(string kludasTeksts) 
{
    cout << "Uzdevums D nestrādā"<<endl;

} 


int main() 
{
    ifstream fails("db.csv");
    vector<AutobusaMarshruts> maršruti;

    if (fails.is_open()) 
    {
        string rinda;
        while (getline(fails, rinda)) 
        {
            stringstream ss(rinda);
            AutobusaMarshruts maršruts;
            getline(ss, maršruts.From, ',');
            getline(ss, maršruts.toHere, ',');
            getline(ss, maršruts.dienas, ',');
            getline(ss, maršruts.laiks, ',');
            getline(ss, maršruts.cena, ',');


            Saisinat(maršruts.From);
            Saisinat(maršruts.toHere);
            Saisinat(maršruts.dienas);
            Saisinat(maršruts.laiks);
            Saisinat(maršruts.cena);
          
            if (!ss.fail()) 
            {
                maršruti.push_back(maršruts);
            }
        }
        fails.close();
    } else {
        cout << "error " << endl;
        return 1;
    }

    char  izvele;
    do 
    {
        cin >> izvele;

        switch (izvele) 
        {
            case 'a': 
              {
                string From, toHere;
                cin >> From;
                cin >> toHere;

                uzdevumsA(maršruti, From, toHere);
                break;
            }
            case 'b': 
              {
                string dienas;
                cin >> dienas;

                uzdevumsB(maršruti, dienas);
                break;
            }
            case 'c': 
              {
                double  moneyMoves;
                cin >> moneyMoves;

                UzdevumsC(maršruti, moneyMoves);
                break;
            }
            case 'd': 
              {
                cout << "Uzdevums D nestrādā"<<endl;
                break;
            }
            case 'e':
                break;
            default:
                cout << " " << endl;
        }

    } while (izvele != 'e');


    return 0;
}
