

#include <iostream>
#include <fstream>
//#include <istream> //??
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <cstdio>
#include <algorithm>
#include <stdexcept>
//#include <cctype> //??
//#include <cmath> //??
//#include <cstring> //??
//#include <ctype.h> //??
//#include <stdio.h> //??

using namespace std;

// struktura datiem
struct destinationInfo {
    string startLocation;
    string endLocation;
    string weekDay;
    string departTime;
    double ticketPrice;
};

// vai ir skaitlis
bool isNumber(const string& s) {
    for (char c : s) {
        if ((isdigit(c) == 0) && (c != '.')) {
            return false;
        }
    }
    return true;
}

//funckija, vai ir dots laiks
bool isTime(const string& s) {
    for (char c : s) {
        if (c == ':') return true;
    }
    return false;
}

// nonemt atstarpes
string removeSpaces(const string& s) {
    string result = s;
    result.erase(remove(result.begin(), result.end(), ' '), result.end());
    return result;
}

// vai ir nedelas diena?
string checkDay(const string& day) {
    string week[] = { "Pr","Ot","Tr","Ce","Pt","St","Sv" };
    for (const string& validDay : week) {
        if (day == validDay) {
            return validDay;
        }
    }
    return "";
}



// lasam no faila un veicam kludu apstradi
vector<destinationInfo> readDestinations(const string& filename) {
    vector<destinationInfo> destinations;
    ifstream file(filename);

    /*
    if (!file.is_open()) {
        cerr << "nevar atvert failu: " << filename << endl;
        exit(0);
    }
    */

    string line;
    while (getline(file, line)) {
        line = removeSpaces(line);
        istringstream iss(line);
        string startLocation, endLocation, weekDay, departTime, ticketPrice;

        // sadalam laukus mainigajiem
        getline(iss, startLocation, ',');
        getline(iss, endLocation, ',');
        getline(iss, weekDay, ',');
        getline(iss, departTime, ',');
        getline(iss, ticketPrice);

        // shuunu parbaude, skaits, formats

        if (startLocation.empty() || endLocation.empty() || weekDay.empty() || departTime.empty() || ticketPrice.empty() || (!isNumber(ticketPrice)) || (!isTime(departTime))) {
            //rindas ar ierakstiem raksta ieksa err faila
            if (line.size() != 0) {
                ofstream errFile("err.txt", ios::app);
                errFile << line << endl;
            }
            continue;
        }


        //ja tuksa rinda, izlaizham
        if (line.size() == 0) continue;

        // ja nav cipara formats, izlaizham
        if (!isNumber(ticketPrice)) continue;

        // saglaba mainigos
        destinationInfo route;
        route.startLocation = startLocation;
        route.endLocation = endLocation;
        route.weekDay = checkDay(weekDay); //nedelas diena?
        route.departTime = departTime;
        route.ticketPrice = stod(ticketPrice);

        // parbauda nedelas dienu vai tuksa
        if (route.weekDay.empty()) continue;

        destinations.push_back(route);
    }

    file.close();
    return destinations;
}

void printStartEndInfo(const vector<destinationInfo>& destinations, string startCity, string endCity) {
    cout << "result: " << endl;
    for (const auto& route : destinations) {
        if (route.startLocation == startCity && route.endLocation == endCity) {
            cout << route.startLocation << " ";
            cout << route.endLocation << " ";
            cout << route.weekDay << " ";
            cout << route.departTime << " ";
            cout << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}

void printDayInfo(const vector<destinationInfo>& destinations, string day) {
    cout << "result: " << endl;
    for (const auto& route : destinations) {
        if (route.weekDay == day) {
            cout << route.startLocation << " ";
            cout << route.endLocation << " ";
            cout << route.weekDay << " ";
            cout << route.departTime << " ";
            cout << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}

void printPriceInfo(const vector<destinationInfo>& destinations, double price) {
    cout << "result: " << endl;
    for (const auto& route : destinations) {
        if (route.ticketPrice < price) {
            cout << route.startLocation << " ";
            cout << route.endLocation << " ";
            cout << route.weekDay << " ";
            cout << route.departTime << " ";
            cout << fixed << setprecision(2) << route.ticketPrice << endl;
        }
    }
}

void printErrorFile(const string& filename) {
    cout << "result: " << endl;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        cout << line << endl;
    }
}

int main()
{

    // lasam un saglabajam vektora ierakstus
    vector<destinationInfo> destinations = readDestinations("db.csv");

    char userInput;
    string startCity, endCity, day;
    double price;
    while (true) {
        cin >> userInput;
        if (userInput != 'e') {
            switch (userInput) {
            case 'a':
                cin >> startCity;
                cin >> endCity;
                printStartEndInfo(destinations, startCity, endCity);
                break;
            case 'b':
                cin >> day;
                printDayInfo(destinations, day);
                break;
            case 'c':
                cin >> price;
                printPriceInfo(destinations, price);
                break;
            case 'd':
                printErrorFile("err.txt");
                break;
            }
        }
        else {
            remove("err.txt");
            break;
        }

    }

}