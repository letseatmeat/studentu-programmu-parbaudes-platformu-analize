﻿
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

bool isNumber(const string& str) {
    try {
        stod(str);
        return true;
    }
    catch (const invalid_argument& e) {
        return false;
    }
}

void printErrorFile() {
    ifstream errorFile("err.txt");
    string line;
    cout << "result:" << endl;
    while (getline(errorFile, line)) {
        cout << line << endl;
    }
    errorFile.close();
}

void printA(vector<vector<string>> csvDataCorrect) {
    string firstCity, secondCity;
    cin >> firstCity; 
    cin >> secondCity;

    cout << "result:" << endl;
    for (const vector<string>& row : csvDataCorrect) {
        if (row[0] == firstCity && row[1] == secondCity) {
            cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;
        }
    }

}

void printB(vector<vector<string>> csvDataCorrect) {
    string day;
    cin >> day;

    cout << "result:" << endl;
    for (const vector<string>& row : csvDataCorrect) {
        if (row[2] == day) {
            cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;
        }
    }

}

void printC(vector<vector<string>> csvDataCorrect) {
    double cost;
    cin >> cost;

    cout << "result:" << endl;
    for (const vector<string>& row : csvDataCorrect) {
        if (stod(row[4]) <= cost) {
            cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;
        }
    }

}

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \n\r\t");
    size_t last = str.find_last_not_of(" \n\r\t");
    if (first == string::npos || last == string::npos)
        return "";
    return str.substr(first, (last - first + 1));
}

int main() {
    char choice;
    ifstream inFile;
    ofstream errorFile("err.txt");
    inFile.open("db.csv");

    if (!inFile.is_open()) {
        cerr << "Error opening file" << endl;
        return 1;
    }

    vector<vector<string>> csvDataCorrect;

    string line;
    while (getline(inFile, line)) {

        line = trim(line); 
        if (line.empty()) continue;

        istringstream ss(line);
        string token;
        vector<string> tokens;

        while (getline(ss, token, ',')) {
            token = trim(token);
            tokens.push_back(token);
        }

        if (tokens.size() != 5 || (tokens.size() >= 3 && (isNumber(tokens[0]) || isNumber(tokens[1]) || isNumber(tokens[2])))) {
            errorFile << line << endl; 
        }
        else {
            csvDataCorrect.push_back(tokens);
        }
    }

    inFile.close();
    errorFile.close(); 


    while (true) {
        cin >> choice;

        switch (choice) {
        case 'a':
            printA(csvDataCorrect);
            break;
        case 'b':
            printB(csvDataCorrect);
            break;
        case 'c':
            printC(csvDataCorrect);
            break;
        case 'd':
            printErrorFile();
            break;
        case 'e':
            return 0;
        default:
            break;
        }
    }
    return 0;
}


