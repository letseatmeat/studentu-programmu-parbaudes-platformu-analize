#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct BusRoute {
    string startStation;
    string endStation;
    string dayOfWeek;
    string time;
    float price;
};

vector<BusRoute> routes;
vector<string> errors;

string trim(const string& str) {
    size_t start = str.find_first_not_of(" \t");
    size_t end = str.find_last_not_of(" \t");
    return (start == string::npos || end == string::npos) ? "" : str.substr(start, end - start + 1);
}

bool isValidDayOfWeek(const string& day) {
    vector<string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
    return find(validDays.begin(), validDays.end(), day) != validDays.end();
}

bool isValidTime(const string& time) {
    if (time.length() != 5 || time[2] != ':') return false;
    int hour = stoi(time.substr(0, 2));
    int minute = stoi(time.substr(3, 2));
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;
}

bool parseLine(const string& line, BusRoute& route) {
    stringstream ss(line);
    string item;
    vector<string> tokens;
    while (getline(ss, item, ',')) {
        tokens.push_back(trim(item));
    }

    if (tokens.size() != 5) return false;
    if (!isValidDayOfWeek(tokens[2]) || !isValidTime(tokens[3])) return false;

    route.startStation = tokens[0];
    route.endStation = tokens[1];
    route.dayOfWeek = tokens[2];
    route.time = tokens[3];
    try {
        route.price = stof(tokens[4]);
    } catch (const exception&) {
        return false;
    }

    return true;
}


void normalizeEndOfLine(string& line) {
    if (!line.empty() && line.back() == '\r') {
        line.pop_back(); // Remove carriage return character
    }
}

void readDatabase(const string& filename) {
    ifstream inFile(filename);
    string line;
    while (getline(inFile, line)) {
        normalizeEndOfLine(line);

        if (line.find_first_not_of(" \t") == string::npos) {
            // Skip lines that are empty or contain only whitespace
            continue;
        }

        BusRoute route;
        if (parseLine(line, route)) {
            routes.push_back(route);
        } else {
            errors.push_back(line);
        }
    }
}


void writeErrors(const string& filename) {
    ofstream outFile(filename);
    for (const auto& error : errors) {
        outFile << error << endl;
    }
}

void displayRoutes(const vector<BusRoute>& filteredRoutes) {
    cout << "result:" << endl;
    for (const auto& route : filteredRoutes) {
        cout << route.startStation << " " << route.endStation << " " 
             << route.dayOfWeek << " " << route.time << " " 
             << fixed << setprecision(2) << route.price << endl;
    }
}

int main() {
    readDatabase("db.csv");

    char query;
    do {
        cout << "Enter query (a, b, c, d, e): ";
        cin >> query;
        cout << endl;

        switch (query) {
            case 'a': {
                string start, end;
                cout << "Enter start and end stations: " << endl;
                cin >> start >> end;

                vector<BusRoute> filteredRoutes;
                copy_if(routes.begin(), routes.end(), back_inserter(filteredRoutes), 
                        [start, end](const BusRoute& r) {
                            return r.startStation == start && r.endStation == end;
                        });
                
                displayRoutes(filteredRoutes);
                break;
            }
            case 'b': {
                string day;
                cout << "Enter day of week (e.g., Pr, Ot): " << endl;
                cin >> day;

                vector<BusRoute> filteredRoutes;
                copy_if(routes.begin(), routes.end(), back_inserter(filteredRoutes), 
                        [day](const BusRoute& r) {
                            return r.dayOfWeek == day;
                        });
                
                displayRoutes(filteredRoutes);
                break;
            }
            case 'c': {
                float maxPrice;
                cout << "Enter maximum ticket price: " << endl;
                cin >> maxPrice;

                vector<BusRoute> filteredRoutes;
                copy_if(routes.begin(), routes.end(), back_inserter(filteredRoutes), 
                        [maxPrice](const BusRoute& r) {
                            return r.price <= maxPrice;
                        });
                
                displayRoutes(filteredRoutes);
                break;
            }
            case 'd': {
                cout << "result:" << endl;
                for (const auto& error : errors) {
                    cout << error << endl;
                }
                break;
            }
            case 'e': {
                break;
            }
            default:
                cout << "Invalid input, try again." << endl;
                break;
        }
    } while (query != 'e');

    writeErrors("err.txt");

    return 0;
}
