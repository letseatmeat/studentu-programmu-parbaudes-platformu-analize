﻿

#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

class Route {
public:
    Route(string firstPoint, string endPoint, string day, string time,
        string price);

    string firstPoint;
    string endPoint;
    string day;
    string time;
    string price;
};

Route::Route(string firstPoint, string endPoint, string day, string time,
    string price) {
    this->firstPoint = firstPoint;
    this->endPoint = endPoint;
    this->day = day;
    this->time = time;
    this->price = price;
}

void CheckTimeValidation(string time) {
    istringstream iss(time);
    string element;

    while (getline(iss, element, ':')) {
        stoi(element);
    }
}

void RemoveSpaces(string& str) {
    string result;
    for (char ch : str) {
        if (!isspace(ch)) {
            result += ch;
        }
    }
    str = result;
}

void GetRoutes(map<int, Route>& RoutesMap, vector<string>& dump,
    ifstream& fildeData) {

    string line;
    int index = 0;
    while (getline(fildeData, line)) {
        RemoveSpaces(line);

        if (line.empty() || !line.size())
            continue;

        vector<string> elements;
        istringstream iss(line);
        string element;

        while (getline(iss, element, ',')) {
            elements.push_back(element);
        }

        try {
            CheckTimeValidation(elements.at(3));

            if (elements.size() > 5)
                throw invalid_argument(" ");

            float price = stof(elements.at(4));

            Route route(elements.at(0), elements.at(1), elements.at(2),
                elements.at(3), elements.at(4));

            RoutesMap.insert({ index, route });
            index++;
        }
        catch (exception& e) {
            dump.push_back(line + "\n");
            continue;
        }

        elements.clear();
    }
}

void PrintResult(Route& route) {
    cout << route.firstPoint << " " << route.endPoint << " " << route.day << " "
        << route.time << " " << route.price << endl;
}

void GetRouteByDestination(map<int, Route>& RoutesMap, string firstPoint,
    string secondPoint) {
    for (auto itr = RoutesMap.begin(); itr != RoutesMap.end(); itr++)
        if (itr->second.firstPoint == firstPoint) {
            Route route = itr->second;

            if (route.endPoint == secondPoint)
                PrintResult(route);
        }
}

void GetRouteByDay(map<int, Route>& RoutesMap, string day) {
    for (auto i : RoutesMap) {
        Route route = i.second;

        if (route.day == day)
            PrintResult(route);
    }
}

void GetRouteByPrice(map<int, Route>& RoutesMap, float price) {
    for (auto i : RoutesMap) {
        Route route = i.second;

        if (stof(route.price) <= price)
            PrintResult(route);
    }
}

void PrintDumpFile(vector<string>& dumpData) {
    ofstream outputFile("err.txt", ios::trunc);

    if (outputFile.is_open()) {
        for (int i = 0; i < dumpData.size(); i++) {
            cout << dumpData[i];
            outputFile << dumpData[i];
        }
        outputFile.close();
    }
}

int main() {

    // open file
    ifstream inFile;
    inFile.open("db.csv");

    // create dump file
    vector<string> DumpData;

    // get routes
    map<int, Route> RoutesMap;

    GetRoutes(RoutesMap, DumpData, inFile);

    inFile.close();

    // main application functional
    string user_input;
    while (true) {
        cin >> user_input;

        if (user_input == "a") {
            string firstPoint;
            string secondPoint;

            cin >> firstPoint;
            cin >> secondPoint;

            cout << "result:" << endl;
            GetRouteByDestination(RoutesMap, firstPoint, secondPoint);
        }

        if (user_input == "b") {
            string day;

            cin >> day;

            cout << "result:" << endl;
            GetRouteByDay(RoutesMap, day);
        }

        if (user_input == "c") {
            float price;

            cin >> price;

            cout << "result:" << endl;
            GetRouteByPrice(RoutesMap, price);
        }

        if (user_input == "d") {
            cout << "result:" << endl;
            PrintDumpFile(DumpData);
        }

        if (user_input == "e")
            break;
    }

    return 0;
}