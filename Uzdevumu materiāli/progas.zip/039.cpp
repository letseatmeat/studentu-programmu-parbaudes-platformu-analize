#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>

using namespace std;

string removeSpaces(string s) {
  int i = s.size() - 1;
  while (i >= 0) {
    if (s.at(i) == 0x20 || s.at(i) == 0x0D || s.at(i) == 0x0A) {
      s.erase(i, 1);
    }
    i--;
  }
  return s;
}

bool testLine(vector<string> v) {
  // test day
  if (v[2] != "Pr" && v[2] != "Ot" && v[2] != "Tr" && v[2] != "Ce" &&
      v[2] != "Pt" && v[2] != "St" && v[2] != "Sv") {
    // cout << "day" << endl;
    return false;
  }
  // test time
  regex toMatchTime("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$");
  if (!regex_match(v[3].begin(), v[3].end(), toMatchTime)) {
    cout << "time" << endl;
    return false;
  }

  // test price
  regex toMatchPrice("^((?!(0))[0-9]{1,}).[0-9][0-9]$");
  if (!regex_match(v[4].begin(), v[4].end(), toMatchPrice)) {
    cout << "Price" << endl;
    return false;
  }

  return true;
}

vector<string> splitStringByComma(string s) {
  vector<string> result;
  stringstream ss(s);
  string substr;

  while (getline(ss, substr, ',')) {
    result.push_back(substr);
  }

  return result;
}

void readErrors() {
  ifstream inFile;
  inFile.open("err.txt");
  string s;
  if (!inFile) {
    cout << "no err" << endl;
    return;
  }
  while (!inFile.eof()) {
    inFile>>s;
    cout << s;
    cout << endl;
  }
  inFile.close();
}

void findRouteByPoints(vector<vector<string>> v) {
  string dep, arr;
  cin >> dep >> arr;
  for (vector<string> line : v) {
    if (line[0] == dep && line[1] == arr) {
      cout << line[0] << " " << line[1] << " " << line[2] << " " << line[3]
           << " " << line[4] << " " << endl;
    }
  }
}

void findRouteByDay(vector<vector<string>> v) {
  string day;
  cin >> day;
  for (vector<string> line : v) {
    if (line[2] == day) {
      cout << line[0] << " " << line[1] << " " << line[2] << " " << line[3]
           << " " << line[4] << " " << endl;
    }
  }
}

void findRouteByPrice(vector<vector<string>> v) {
  float price;
  cin >> price;
  for (vector<string> line : v) {
    if (stof(line[4]) <= price) {
      cout << line[0] << " " << line[1] << " " << line[2] << " " << line[3]
           << " " << line[4] << " " << endl;
    }
  }
}
int main() {
  ifstream inFile;
  ofstream outFile;
  vector<vector<string>> v;
  inFile.open("db.csv");
  outFile.open("err.txt");
  if (!inFile)
    return 0;

  string s;
  string s2;
  int line = 0;
  while (getline(inFile, s)) {
    s2 = s;
    s = removeSpaces(s);
    if (s.size() == 0) {
      continue;
    }

    vector<string> tempV = splitStringByComma(s);
    if (tempV.size() != 5) {
      // cout << "ERROR size " << tempV.size() << endl;

      outFile << s2;
      continue;
    }
    if (!testLine(tempV)) {
      // cout << "ERROR test " << endl;
      outFile << s2;
      continue;
    }
    v.push_back(tempV);
  }

  inFile.close();

  outFile.close();


  char mode;
  do {
    cin >> mode;
    cout << "result:" << endl;
    switch (mode) {
    case 'a':
      findRouteByPoints(v);
      break;
    case 'b':
      findRouteByDay(v);
      break;
    case 'c':
      findRouteByPrice(v);
      break;
    case 'd':
      readErrors();
      break;
    case 'e':
      break;
    }
  } while (mode != 'e');
  outFile.close();
}
