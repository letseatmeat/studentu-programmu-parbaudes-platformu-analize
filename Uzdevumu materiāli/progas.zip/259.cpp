

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <regex>

using namespace std;

static regex wordRegex = regex("([a-zA-Z]+)");
static string dbFilename = "db.csv";
static string errFilename = "err.txt";

string trim(const string& str) {
    string result = str;
    result.erase(remove_if(result.begin(), result.end(), ::isspace), result.end());
    return result;
}

struct BusRoute {
    string startStop;
    string endStop;
    string weekday;
    string time;
    string ticketPriceStr;
    double ticketPrice;

    void trimRoute() {
        this->startStop = trim(this->startStop);
        this->endStop = trim(this->endStop);
        this->weekday = trim(this->weekday);
        this->time = trim(this->time);
        this->ticketPriceStr = trim(this->ticketPriceStr);
    }
};

void printRoute(const BusRoute& route) {
    cout    << route.startStop << " " << route.endStop << " "
            << route.weekday << " " << route.time << " " << fixed << setprecision(2)
            << route.ticketPrice << endl;
}

vector<BusRoute> readRoutesFromFile() {
    vector<BusRoute> routes;
    ifstream file(dbFilename);
    ofstream errFile(errFilename, ios::out);

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << dbFilename << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) {
        istringstream iss(trim(line));
        BusRoute route;
        string endOfRow;

        if (getline(iss, route.startStop, ',')      && route.startStop.size() != 0      && regex_match(route.startStop, wordRegex)  &&
            getline(iss, route.endStop, ',')        && route.endStop.size() != 0        && regex_match(route.endStop, wordRegex)    &&
            getline(iss, route.weekday, ',')        && route.weekday.size() != 0        && regex_match(route.weekday, wordRegex)    &&
            getline(iss, route.time, ',')           && route.time.size() != 0           &&
            getline(iss, route.ticketPriceStr, ',') && route.ticketPriceStr.size() != 0 && 
            !getline(iss, endOfRow) ) {

            route.trimRoute();
            route.ticketPrice = stod(route.ticketPriceStr);
            routes.push_back(route);
            continue;
        } else {
            if (line == "\r") {
                continue;
            }
            errFile << line << endl;
        }
    }

    return routes;
}

int main() {
    char choice;
    vector<BusRoute> routes = readRoutesFromFile();

    do {
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start >> end;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.startStop == start && route.endStop == end) {
                        printRoute(route);
                    }
                }
                break;
            }

            case 'b': {
                string day;
                cin >> day;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.weekday == day) {
                        printRoute(route);
                    }
                }
                break;
            }

            case 'c': {
                double maxPrice;
                cin >> maxPrice;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.ticketPrice <= maxPrice) {
                        printRoute(route);
                    }
                }
                break;
            }

            case 'd': {
                ifstream errFile(errFilename);
                if (errFile.is_open()) {
                    string line;
                    cout << "result:" << endl;
                    while (getline(errFile, line)) {
                        cout << line << endl;
                    }
                } else {
                    cerr << "Error: Could not open file " + errFilename << endl;
                }
                break;
            }

            case 'e':
                break;

            default:
                cerr << "Nepareiza izvēle. Lūdzu, izvēlieties atkal." << endl;
        }

    } while (choice != 'e');

    return 0;
}
