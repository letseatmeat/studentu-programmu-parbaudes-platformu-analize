
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

struct Route {
  std::string startStop;
  std::string endStop;
  std::string dayOfWeek;
  std::string time;
  double price;
};

bool isValidRoute(const std::vector<std::string>& tokens) {

  if (tokens.size() != 5) {
    return false;
  }

  size_t colonPos = tokens[3].find(':');
  if (colonPos == std::string::npos) {
    return false;
  }

  try {
    std::stod(tokens[4]);
  } catch (const std::exception &) {
    return false;
  }

  return true;
}

std::string trim(const std::string &str) {
  size_t first = str.find_first_not_of(' ');
  if (std::string::npos == first) {
    return str;
  }
  size_t last = str.find_last_not_of(' ');
  return str.substr(first, (last - first + 1));
}

bool isWhitespace(const std::string &str) {
  return std::all_of(str.begin(), str.end(), ::isspace);
}


std::vector<Route> loadRoutes(const std::string &filePath,
                              std::ofstream &errFile) {
  std::vector<Route> routes;
  std::ifstream file(filePath);

  std::string line;
  while (std::getline(file, line)) {
    if (line.empty() || isWhitespace(line))
      continue;

    std::stringstream ss(line);
    std::string item;
    std::vector<std::string> tokens;

    while (std::getline(ss, item, ',')) {
      tokens.push_back(trim(item));
    }

    if (!isValidRoute(tokens)) {
      errFile << line << '\n';
      continue;
    }

    try {
      Route newRoute = {tokens[0], tokens[1], tokens[2], tokens[3],
                        std::stod(tokens[4])};

      routes.push_back(newRoute);
    } catch (const std::exception &e) {
      errFile << line << " Error: " << e.what() << '\n';
    }
  }

  file.close();
  return routes;
}

void displayRoutes(const std::vector<Route> &routes) {
  for (const auto &route : routes) {
    std::cout << route.startStop << " " << route.endStop << " "
              << route.dayOfWeek << " " << route.time << " " << std::fixed
              << std::setprecision(2) << route.price << '\n';
  }
}

int main() {
  std::ofstream errFile("err.txt");
  std::vector<Route> routes = loadRoutes("db.csv", errFile);

  errFile.close();
  char command;
  do {

    std::cin >> command;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    switch (command) {
    case 'a': {
      std::string start, end;

      std::getline(std::cin, start);

      std::getline(std::cin, end);

      std::cout << "result:" << std::endl;
      for (const auto &route : routes) {
        if (route.startStop == start && route.endStop == end) {
          displayRoutes({route});
        }
      }
      break;
    }
    case 'b': {
      std::string day;

      std::getline(std::cin, day);

      std::cout << "result:" << std::endl;
      for (const auto &route : routes) {
        if (route.dayOfWeek == day) {
          displayRoutes({route});
        }
      }
      break;
    }
    case 'c': {
      double maxPrice;

      std::cin >> maxPrice;
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

      std::cout << "result:" << '\n';
      for (const auto &route : routes) {
        if (route.price <= maxPrice) {
          displayRoutes({route});
        }
      }
      break;
    }
    case 'd': {
      std::ifstream infile("err.txt");
      if (!infile.is_open()) {
        std::cout << "Failed to open error file." << std::endl;
      } else {
        std::cout << "result:" << '\n';
        infile.seekg(0, std::ios::beg);

        std::string content;
        while (std::getline(infile, content)) {
          if (!content.empty() && content.find(",,") == std::string::npos) {
            std::cout << content << '\n';
          }
        }
        infile.close();
      }
      break;
    }
    case 'e': {

      break;
    }
    default: {
      std::cout << "Invalid command. Please enter a, b, c, d, or e." << '\n';
      break;
    }
    }
  } while (command != 'e');

  return 0;
}