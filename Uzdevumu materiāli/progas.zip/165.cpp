
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

int parseInt(string str) {
  for (int i = 0; i < str.size(); i++) {
    if (int(str[i]) < 48 || int(str[i]) > 57) {
      return 0;
    }
  }
  return stoi(str);
}

double parseDouble(string str) {
  if (str.find(".") == std::string::npos) {
    return 0;
  }
  if(str.substr(str.find(".") + 1, str.size()).size() < 2){
    return 0;
  }
  if(parseInt(str.substr(0, str.find("."))) == 0){
    return 0;
  }
  if(parseInt(str.substr(str.find(".") + 1, str.size())) == 0 && str.substr(str.find(".") + 1, str.size()) != "00"){
    return 0;
  }
  return stod(str);
}

bool parseStage(string str, int stage) {
  switch (stage) {
    
  case 0:
    if (str != "" && !parseStage(str, 2) && !parseStage(str, 3) &&
        !parseStage(str, 4)) {
      return true;
    }
    break;
    
  case 1:
    if (str != "" && !parseStage(str, 2) && !parseStage(str, 3) &&
        !parseStage(str, 4)) {
      return true;
    }
    break;
    
  case 2:
    if (str == "Pr" || str == "Ot" || str == "Tr" || str == "Ce" ||
        str == "Pt" || str == "St" || str == "Sv") {
      return true;
    }
    break;
    
  case 3:
    if (str.size() == 5 && str.find(":") != std::string::npos) {
      int hrs = parseInt(str.substr(0, str.find(":")));
      int min = parseInt(str.substr(str.find(":") + 1, 4));
      if (hrs >= 0 && hrs < 24 && min >= 0 && min < 60) {
        return true;
      }
    }
    break;
    
  case 4:
    if (str.find(".") != std::string::npos) {
      if (parseDouble(str) != 0) {
        return true;
      }
    }
    break;
    
  }
  return false;
}

int output(vector<string> vect){
  if(vect.size() == 5){
    cout << vect[0] << " " << vect[1] << " " << vect[2] << " " << vect[3] << " " << vect[4] << endl;
  }
  return 0;
}

int main() {
  ifstream inFile("db.csv");
  int row = 0;
  if (!inFile)
    return 0;
  string s, errs = "", buffer = "";
  int stage = 0;
  vector<vector<string>> bus;
  int x = 0;
  while (getline(inFile, s)) {
    if(s.size() > 0){
      bus.push_back(vector<string>());
      for(int i = 0; i < s.size(); i++){
        if(s[i] != ' '){
          if(s[i] == ',' || i == s.size() - 1){
            if(i == s.size()-1){
              buffer += s[i];
            }
            if(parseStage(buffer, stage)){
              bus[x].push_back(buffer);
              if(stage == 4){
                if(s.size()-1 > i){
                  errs += s + '\n';
                  buffer = "";
                  bus.pop_back();
                  stage = 0;
                  break;
                }
                x++;
                stage = 0;
              }else{
                stage++;
              }
            }else{
              errs += s + '\n';
              buffer = "";
              bus.pop_back();
              stage = 0;
              break;
            }
            buffer = "";
          }else{
            buffer += s[i];
          }
        }
      }
    }
  }
  inFile.close();
  ofstream err("err.txt");
  err << errs;
  err.close();

  
  bool running = true;
  char cmd;
  while(running){
    cin >> cmd;
    switch(cmd){
      case 'a': {
        string start, dest;
        cin >> start >> dest;
        cout << "result:" << endl;
        for(int i = 0; i < bus.size(); i++){
          if(bus[i][0] == start && bus[i][1] == dest){
            output(bus[i]);
          }
        }
        break;
      }
      case 'b': {
        string weekday;
        cin >> weekday;
        cout << "result:" << endl;
        for(int i = 0; i < bus.size(); i++){
          if(bus[i][2] == weekday){
            output(bus[i]);
          }
        }
        break;
      }
      case 'c': {
        string cost;
        cin >> cost;
        cout << "result:" << endl;
        for(int i = 0; i < bus.size(); i++){
          if(parseDouble(cost) >= parseDouble(bus[i][4])){
            output(bus[i]);
          }
        }
        break;
      }
      case 'd': {
        cout << "result:" << endl;
        cout << errs;
        break;
      }
      case 'e': {
        running = false;
        break;
      }
    }
  }
}