#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct AutobusaMar {
    string sakPietura;
    string beigPietura;
    string diena;
    string laiks;
    double cena;
};

string trim(string str) {
    size_t first = str.find_first_not_of(" \t\n");
    size_t last = str.find_last_not_of(" \t\n");
    return str.substr(first, (last - first + 1));
}

bool parseLine(const string& line, AutobusaMar& marsruts) {
    if (line.empty()) {
        return false;
    }
  
  istringstream iss(line);
  vector<string> dataAut;

  string dataAut2;
  while (getline(iss, dataAut2, ',')) {
      dataAut.push_back(trim(dataAut2));
  }

  if (dataAut.size() == 5) {
      marsruts.sakPietura = dataAut[0];
      marsruts.beigPietura = dataAut[1];
      marsruts.diena = trim(dataAut[2]);
      marsruts.laiks = trim(dataAut[3]);

      try {
          marsruts.cena = stod(dataAut[4]);
      } catch (const invalid_argument& e) {
          return false; 
      }

      static const vector<string> dienas = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
      if (find(dienas.begin(), dienas.end(), marsruts.diena) == dienas.end()) {
          return false; 
      }

      return true;
  } else {
      return false; 
  }
}


void printRoute(const AutobusaMar& marsruts) {
    cout << marsruts.sakPietura << " " << marsruts.beigPietura << " " << marsruts.diena << " "
         << marsruts.laiks << " " << fixed << setprecision(2) << marsruts.cena << endl;
}

int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");

    if (!inFile) {
        return 1;
    }

    vector<AutobusaMar> marsruti;
    string line;

    while (getline(inFile, line)) {
        AutobusaMar marsruts;
        if (parseLine(line, marsruts)) {
              marsruti.push_back(marsruts);
        } else {
            errFile << line << endl;
        }
    }

    char choice;
    do {
        cout << "Enter command ('a', 'b', 'c', 'd', 'e'): ";
        cin >> choice;

        switch (choice) {
            case 'a':
                {
                    string start, end;
                    cout << "Sākuma pietura: ";
                    cin >> start;
                    cout << "Gala pietura: ";
                    cin >> end;

                    cout << "result:" << endl;
                    for (const auto& marsruts : marsruti) {
                        if (marsruts.sakPietura == start && marsruts.beigPietura == end) {
                            printRoute(marsruts);
                        }
                    }
                }
                break;

            case 'b':
                {
                    string diena1;
                    cout << "Enter day of the week (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                    cin >> diena1;

                    cout << "result:" << endl;
                    for (const auto& marsruts : marsruti) {
                        if (marsruts.diena == diena1) {
                            printRoute(marsruts);
                        }
                    }
                }
                break;

            case 'c':
                {
                    double maxCena;
                    cout << "Enter maximum ticket price: ";
                    cin >> maxCena;

                    cout << "result:" << endl;
                    for (const auto& marsruts : marsruti) {
                        if (marsruts.cena <= maxCena) {
                            printRoute(marsruts);
                        }
                    }
                }
                break;

            case 'd':
                {
                    cout << "result:" << endl;
                    ifstream errFileRead("err.txt");
                    string errLine;
                    while (getline(errFileRead, errLine)) {
                        cout << errLine << endl;
                    }
                }
                break;

            case 'e':
                cout << "Exiting program." << endl;
                break;

            default:
                cout << "Invalid command. Try again." << endl;
        }
    } while (choice != 'e');

    return 0;
}
