
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm> //priekš atstarpju dzešanas

using namespace std;

struct marsruts {
  string marsruta_sakums;
  string marsruta_beigas;
  string diena;
  string laiks;
  string cena;
};

void izdzestatstarpes(string& str) { //funkcija kas izdzēš atstarpes
  str.erase(remove_if(str.begin(),str.end(), ::isspace),str.end());
}

marsruts parsemarsruts(const string& line) {
  marsruts route;
  stringstream ss(line);
  getline(ss, route.marsruta_sakums, ',');
  izdzestatstarpes(route.marsruta_sakums);
  getline(ss, route.marsruta_beigas, ',');
  izdzestatstarpes(route.marsruta_beigas);
  getline(ss, route.diena, ',');
  izdzestatstarpes(route.diena);
  getline(ss, route.laiks, ',');
  izdzestatstarpes(route.laiks);
  getline(ss, route.cena);
  izdzestatstarpes(route.cena);
  //ss >> route.cena;
  return route;
};

int main() {
  ifstream inFile("db.csv");
  ofstream errorFile("err.txt");
  vector<marsruts> routes;
  
	if (!inFile) {
    cerr << endl;
    return 1;
  }
  
  string line; 
	while (getline(inFile,line)) { //skipo tukšās līnijas nolasot failu
    if (line.empty()) {
      continue;
    }
    try {                                   //
      marsruts route = parsemarsruts(line);
      if (route.marsruta_sakums.empty() || route.marsruta_beigas.empty() || route.diena.empty() || route.laiks.empty() || route.cena.empty()) {
        errorFile << line << endl;
      } else if (any_of(route.cena.begin(),route.cena.end(), ::isalpha) || any_of(route.laiks.begin(),route.laiks.end(), ::isalpha)) {
          errorFile << line << endl;
      } else {
        routes.push_back(route);
      }
      
    } catch (const std::invalid_argument& e) {
      errorFile << line << endl;
    } catch (const std::out_of_range& e) {
      errorFile << line << endl;
      }
    }
  
	char izveles;
  do {
    cin >> izveles;
    cin.ignore(); //notīra buferi pirms jaunās ievades
    switch (izveles) {
      case 'a': {
        
        cout << "result:" << endl;
        string sakums,beigas;
        getline(cin,sakums);
        getline(cin,beigas);

        for (const auto& route : routes) {
          if (route.marsruta_sakums == sakums && route.marsruta_beigas == beigas) {
            cout << route.marsruta_sakums << " " << route.marsruta_beigas << " " <<route.diena << " " << route.laiks << " " << route.cena << endl;
          }
        } break;
      }
      case 'b': {
        string dien;
        cin >> dien;
        cout << "result:" << endl;
        for (const auto& route :routes) {
          if (route.diena == dien) {
            cout << route.marsruta_sakums << " " << route.marsruta_beigas << " " <<route.diena << " " << route.laiks << " " << route.cena << endl;
          }
        } break;
      }
      case 'c': {
        double maxcena;
        if (cin >> maxcena) {
          cout << "result:" << endl;
          for (const auto& route : routes) {
            try{
              double cenadouble = stod(route.cena); //pārvērš no string uz double
              if (cenadouble <= maxcena) {
                cout << route.marsruta_sakums << " " << route.marsruta_beigas << " " <<route.diena << " " << route.laiks << " " << route.cena << endl;
              }
            } catch (const std::invalid_argument& e) {
              cerr << endl;
            }
          }
        } break;
      }
      case 'd': {
        ifstream errorFile("err.txt");
        ofstream testfile("test.txt");
        cout << "result:" << endl;
        if (errorFile && testfile) {
          string linijas;
          while (getline(errorFile, linijas)) {
            //izdzēš tukšās līnijas no err.txt
            if (!linijas.empty() && any_of(linijas.begin(),linijas.end(), ::isalnum)) { 
              testfile << linijas << endl;
            }
          }
          errorFile.close();
        remove("err.txt");
        rename("test.txt", "err.txt");
        ifstream err("err.txt");
          string linija;
          while (getline(err,linija)) {
            cout << linija << endl;
          }
        }

        break;
      } 
      case 'e': {
        cout << endl;
        break;
      }
      default:
        cout << endl;
    }
  } while (izveles != 'e');
  return 0;
} 