#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

struct BusRoute {
    string startStop;
    string finalStop;
    string dayOfWeek;
    string time;
    double ticketPrice;
};

string trim(const string& str) {
    size_t first = str.find_first_not_of(" \t");
    size_t last = str.find_last_not_of(" \t");
    return str.substr(first, (last - first + 1));
}

void readRoutesFromFile(const string& fileName, vector<BusRoute>& routes, ofstream& errFile) {
    ifstream file(fileName);
    string line;

    while (getline(file, line)) {
        if (line.empty()) continue;

        line = trim(line);

        stringstream ss(line);
        BusRoute route;

        if (getline(ss, route.startStop, ',') &&
            getline(ss, route.finalStop, ',') &&
            getline(ss, route.dayOfWeek, ',') &&
            getline(ss, route.time, ',') &&
            (ss >> route.ticketPrice)) {

            routes.push_back(route);
        } else {
            errFile << "Error parsing line: " << line << endl;
        }
    }
}

void displayRoutes(const vector<BusRoute>& routes) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        cout << route.startStop << " " << route.finalStop << " "
             << route.dayOfWeek << " " << route.time << " "
             << fixed << setprecision(2) << route.ticketPrice << endl;
    }
}

void displayErrorFile(const string& errFileName) {
    ifstream errFile(errFileName);
    string line;

    cout << "result:" << endl;
    while (getline(errFile, line)) {
        cout << line << endl;
    }
}

int main() {
    const string fileName = "db.csv";
    const string errFileName = "err.txt";

    ofstream errFile(errFileName, ios::app);
    vector<BusRoute> routes;

    readRoutesFromFile(fileName, routes, errFile);

    char choice;
    while (true) {
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cin.ignore();
                getline(cin, start);
                getline(cin, end);

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.startStop == start && route.finalStop == end) {
                        filteredRoutes.push_back(route);
                    }
                }
                displayRoutes(filteredRoutes);
                break;
            }

            case 'b': {
                string day;
                cin.ignore();
                getline(cin, day);

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.dayOfWeek == day) {
                        filteredRoutes.push_back(route);
                    }
                }
                displayRoutes(filteredRoutes);
                break;
            }

            case 'c': {
                double maxPrice;
                cin >> maxPrice;

                vector<BusRoute> filteredRoutes;
                for (const auto& route : routes) {
                    if (route.ticketPrice <= maxPrice) {
                        filteredRoutes.push_back(route);
                    }
                }
                displayRoutes(filteredRoutes);
                break;
            }

            case 'd':
                displayErrorFile(errFileName);
                break;

            case 'e':
                return 0;

            default:
                cout << "Invalid command. Try again." << endl;
                break;
        }
    }

    return 0;
}
