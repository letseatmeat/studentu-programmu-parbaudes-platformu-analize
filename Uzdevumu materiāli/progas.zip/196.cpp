

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <iterator>
#include <list>
#include <sstream>
#include <vector>
#include <iomanip>
#include <unordered_set>

namespace StringUtilities {
    std::unordered_set<char> empty_chars;

    static void initialize_empty_chars() {
        empty_chars = std::unordered_set<char>();

        empty_chars.insert(' ');
        empty_chars.insert('\n');
        empty_chars.insert('\t');
        empty_chars.insert((char)13);
    }

    static std::vector<std::string> split_string(const std::string& input, const char delim) {
        std::vector<std::string> output;
        std::istringstream stream(input);
        std::string split;

        while (std::getline(stream, split, delim)) {
            output.push_back(split);
        }

        return output;
    }

    static int last_of(const std::string& input) {
        bool found = false;

        for (int i = input.size() - 1; i >= 0; i--) {
            if (empty_chars.find(input[i]) != empty_chars.end()) {
                found = true;
                continue;
            }
            else {
                if (!found) break;
                return i + 1;
            }
        }

        return -1;
    }

    static void trim_string(std::string& input) {
        std::vector<char> output = std::vector<char>();

        bool start = true;

        int endIndex = last_of(input);
        if (endIndex < 0 || empty_chars.find(input[input.size() - 1]) == empty_chars.end()) endIndex = input.size();

        for (int i = 0; i < endIndex; i++) {
            char c = input[i];
            if ((empty_chars.find(c) != empty_chars.end()) && start) continue;

            output.push_back(c);
            start = false;
        }

        input = std::string(output.begin(), output.end());
    }

    static bool try_parse_int32(const std::string& input, int& output) {
        int i = 0;

        bool negative = false;
        if (input[0] == '-') {
            negative = true;
            i++;
        }

        int result = 0;
        int pow = 1;

        for (; i < input.size(); i++) {
            if (!isdigit(input[i])) return false;

            result *= pow;
            result += input[i] - '0';
            pow *= 10;
        }

        if (negative) result *= -1;
        output = result;

        return true;
    }

    static bool try_parse_double(const std::string& input, double& output) {
        int i = 0;

        bool negative = false;
        if (input[0] == '-') {
            negative = true;
            i++;
        }

        double result = 0;
        int pow = 1;
        bool pastDecimalPoint = false;

        for (; i < input.size(); i++) {
            if (!isdigit(input[i])) {
                if (input[i] == '.') {
                    if (pastDecimalPoint) return false;
                    pastDecimalPoint = true;
                    pow = 10;
                    continue;
                }

                return false;
            }

            char digit = input[i] - '0';
            if (pastDecimalPoint) {
                result += (double)digit / pow;
            }
            else {
                result *= pow;
                result += digit;
            }

            pow *= 10;
        }

        if (negative) result = -result;
        output = result;

        return true;
    }

    static std::string add_padding(std::string value, int zeros) {
        return std::string(zeros - std::min(zeros, (int)value.size()), '0') + value;
    }
}

struct Time {
public:
    int hour;
    int minute;

    Time() {
        hour = -1;
        minute = -1;
    }
    Time(int hour, int minute) {
        this->hour = hour;
        this->minute = minute;
    }

    static bool try_parse(const std::string& input, Time& output) {
        int hour = 0;
        int minute = 0;

        std::vector<std::string> split = StringUtilities::split_string(input, ':');
        if (split.size() != 2) return false;

        if (!StringUtilities::try_parse_int32(split[0], hour)) return false;
        if (!StringUtilities::try_parse_int32(split[1], minute)) return false;

        output = Time(hour, minute);
        return true;
    }

    void print_to_console() {
        std::cout << StringUtilities::add_padding(std::to_string(hour), 2) << ":" << StringUtilities::add_padding(std::to_string(minute), 2);
    }
};

class WeekDay {
public:
    int week_day;

    WeekDay() {
        week_day = -1;
    }
    WeekDay(int week_day) {
        this->week_day = week_day;
    }

    static bool try_parse(const std::string& input, WeekDay& output) {
        int week_day;

        if (input.compare("Pr") == 0) week_day = 1;
        else if (input.compare("Ot") == 0) week_day = 2;
        else if (input.compare("Tr") == 0) week_day = 3;
        else if (input.compare("Ce") == 0) week_day = 4;
        else if (input.compare("Pt") == 0) week_day = 5;
        else if (input.compare("Se") == 0) week_day = 6;
        else if (input.compare("Sv") == 0) week_day = 7;
        else return false;

        output = WeekDay(week_day);
        return true;
    }

    void print_to_console() {
        std::string output;

        switch (week_day) {
        case 1:
            output = "Pr";
            break;
        case 2:
            output = "Ot";
            break;
        case 3:
            output = "Tr";
            break;
        case 4:
            output = "Ce";
            break;
        case 5:
            output = "Pt";
            break;
        case 6:
            output = "Se";
            break;
        case 7:
            output = "Sv";
            break;
        default:
            break;
        }

        std::cout << output;
    }
};

class Route {
public:
    std::string departue;
    std::string destination;
    WeekDay week_day;
    Time time;
    double ticket_cost;

    bool try_parse(const std::string& line) {
        std::vector<std::string> split = StringUtilities::split_string(line, ',');
        if (split.size() != 5) return false;

        for (int i = 0; i < split.size(); i++) {
            StringUtilities::trim_string(split[i]);

            if (split[i].empty()) return false;
        }

        departue = split[0];
        destination = split[1];

        if (!WeekDay::try_parse(split[2], week_day)) return false;
        if (!Time::try_parse(split[3], time)) return false;
        if (!StringUtilities::try_parse_double(split[4], ticket_cost)) return false;

        return true;
    }

    void print_to_console() {
        std::cout << departue << " " << destination << " ";
        week_day.print_to_console();
        std::cout << " ";
        time.print_to_console();

        std::stringstream stringStream;
        stringStream << std::fixed << std::setprecision(2) << ticket_cost;
        std::string outputTicket = stringStream.str();

        std::cout << " " << outputTicket;
    }
};

class DataBase {
public:
    std::vector<Route> routes;

    DataBase() {
        routes = std::vector<Route>();
    }

    bool try_parse(char* filePath, std::vector<std::string>& errorLines) {
        std::ifstream infile(filePath);

        std::string line;
        while (std::getline(infile, line))
        {
            Route route = Route();
            bool parsed = route.try_parse(line);

            if (parsed) {
                routes.push_back(route);
            }
            else {
                errorLines.push_back(line);
            }
        }

        return true;
    }

    DataBase find_routes(const std::string& departue, const std::string& destination) {
        DataBase output = DataBase();

        for (int i = 0; i < routes.size(); i++) {
            Route route = routes[i];

            if (route.departue.compare(departue) == 0 && route.destination.compare(destination) == 0) {
                output.routes.push_back(route);
            }
        }

        return output;
    }


    DataBase find_routes_by_date(const WeekDay& weekDay) {
        DataBase output = DataBase();

        for (int i = 0; i < routes.size(); i++) {
            Route route = routes[i];

            if (route.week_day.week_day == weekDay.week_day) {
                output.routes.push_back(route);
            }
        }

        return output;
    }

    DataBase find_routes_by_cost(const double cost) {
        DataBase output = DataBase();

        for (int i = 0; i < routes.size(); i++) {
            Route route = routes[i];

            if (route.ticket_cost <= cost) {
                output.routes.push_back(route);
            }
        }

        return output;
    }

    void print_to_console() {
        for (int i = 0; i < routes.size(); i++) {
            routes[i].print_to_console();

            if (i < routes.size() - 1) std::cout << "\n";
        }
    }
};

namespace Application {
    void output_error_lines(std::vector<std::string>& errorLines);
    bool execute_command(const std::string& command);
    void find_routes();
    void find_routes_by_date();
    void find_routes_by_cost();
    void print_error_file();

    const std::string EXIT_COMMAND_SIGNATURE = "e";
    const std::string ROUTE_FINDER_COMMAND_SIGNATURE = "a";
    const std::string ROUTE_FINDER_BY_DATE_COMMAND_SIGNATURE = "b";
    const std::string ROUTE_FINDER_BY_COST_COMMAND_SIGNATURE = "c";
    const std::string PRINT_ERROR_FILE_COMMAND_SIGNATURE = "d";

    DataBase dataBase;

    void start() {
        StringUtilities::initialize_empty_chars();

        char* path = (char*)"db.csv";

        std::vector<std::string> errorLines = std::vector<std::string>();

        dataBase = DataBase();
        bool parsed = dataBase.try_parse(path, errorLines);

        output_error_lines(errorLines);

        std::string command;

        do {
            std::cin >> command;
        } while (execute_command(command));
    }

    void output_error_lines(std::vector<std::string>& errorLines) {
        std::ofstream myfile("err.txt");

        int count = 0;
        if (myfile.is_open())
        {
            for (int i = 0; i < errorLines.size(); i++) {
                StringUtilities::trim_string(errorLines[i]);

                if (errorLines[i].empty()) continue;

                myfile << errorLines[i];
                if (i < errorLines.size() - 1) myfile << "\n";
            }

            myfile.close();
        }
    }

    bool execute_command(const std::string& command) {
        if (command.compare(EXIT_COMMAND_SIGNATURE) == 0) return false;

        if (command.compare(ROUTE_FINDER_COMMAND_SIGNATURE) == 0) {
            find_routes();
        }
        else if (command.compare(ROUTE_FINDER_BY_DATE_COMMAND_SIGNATURE) == 0) {
            find_routes_by_date();
        }
        else if (command.compare(ROUTE_FINDER_BY_COST_COMMAND_SIGNATURE) == 0) {
            find_routes_by_cost();
        }
        else if (command.compare(PRINT_ERROR_FILE_COMMAND_SIGNATURE) == 0) {
            print_error_file();
        }

        return true;
    }

    void find_routes() {
        std::string departue;
        std::cin >> departue;

        std::string destination;
        std::cin >> destination;

        std::cout << "result:\n";
        dataBase.find_routes(departue, destination).print_to_console();
        std::cout << "\n";
    }

    void find_routes_by_date() {
        std::string day;
        std::cin >> day;

        WeekDay weekDay;
        if (!WeekDay::try_parse(day, weekDay)) return;

        std::cout << "result:\n";
        dataBase.find_routes_by_date(weekDay).print_to_console();
        std::cout << "\n";
    }

    void find_routes_by_cost() {
        std::string costAsString;
        std::cin >> costAsString;

        double cost;
        if (!StringUtilities::try_parse_double(costAsString, cost)) return;

        std::cout << "result:\n";
        dataBase.find_routes_by_cost(cost).print_to_console();
        std::cout << "\n";
    }

    void print_error_file() {
        std::ifstream infile("err.txt");

        std::cout << "result:\n";

        std::string line;
        while (std::getline(infile, line))
        {
            std::cout << line << "\n";
        }
    }
}

int main()
{
    Application::start();
}