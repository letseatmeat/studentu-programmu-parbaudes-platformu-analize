
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <string>
#include <vector>

using namespace std;
// Struktura, kas satur informāciju par marsrutu
struct Route {
  string start;
  string end;
  string day;
  string time;
  double price;
};

// Funkcija, kas pārbauda, vai ievadītais laiks ir atbisltoss
bool isTime(const string &time) {
  regex timeRegex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$");
  return regex_match(time, timeRegex);
}

// Funkcija, kas pārbauda, vai ievadīta cena ir atbilstoša
bool isPrice(const string &price) {
  regex priceRegex("^\\d+(\\.\\d{1,2})?$");
  return regex_match(price, priceRegex);
}

// Funkcija, kas pārbauda, vai ievadīta diena pieder nedelai
bool isDay(const string &day) {
  static const vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return find(days.begin(), days.end(), day) != days.end();
}

// Funkcija, kas izvada marsrutu
void printRoute(const Route &route) {
  cout << route.start << " " << route.end << " " << route.day << " "
       << route.time << " " << fixed << setprecision(2) << route.price << endl;
}

Route parseRoute(const string &line) {
  Route route;

  regex pattern("(\\s*,\\s*)");
  vector<string> tokens(
      sregex_token_iterator(line.begin(), line.end(), pattern, -1), {});

  // Parbauda, vai rinda nav tuksa
  if (tokens.empty()) {
    route.price = -1.0; // Rinda turpmak tiek izlaista
    return route;
  }

  // Parbauda, vai rinda ir atbilstoss lauku skaits
  if (tokens.size() != 5) {
    route.price = 0.0; // Rinda tiek atzimeta ka kluda
    return route;
  }

  // Nonem tuksos laukus
  for (auto &token : tokens) {
    token = regex_replace(token, regex("^\\s+|\\s+$"), "");
  }

  // Pieskir strukturas route vertibas no vektora sistemas
  route.start = tokens[0];
  route.end = tokens[1];
  route.day = tokens[2];
  route.time = tokens[3];

  // Parbauda, vai nav kada kluda, kas vel nav nokerta
  if (route.start.empty() || route.end.empty() || route.day.empty() ||
      route.time.empty() || !isPrice(tokens[4])) {
    route.price = 0.0; // Atzime ka kludu
  } else {
    route.price = stod(tokens[4]);
  }

  return route;
}

// Vaicajumu apskates funkcija
void processQuery(const string &query, const vector<Route> &routes) {
  switch (query[0]) {
  // A gadijums apskata, vai ir atrasts marsruts ar noteikto sakumu un beigam
    case 'a': {
    string start, end;
    cin >> start >> end;
    cout << "result:" << endl;
    for (const auto &route : routes) {
      if (route.start == start && route.end == end) {
        printRoute(route);
      }
    }
    break;
  }
    // B gadijums apskata, vai ir atrasts marsruts noteiktaja diena
  case 'b': {
    string day;
    cin >> day;
    cout << "result:" << endl;
    for (const auto &route : routes) {
      if (route.day == day) {
        printRoute(route);
      }
    }
    break;
  }
    // C gadijums apskata, vai ir atrasts marsruts noteiktaja cenu ierobezojuma
  case 'c': {
    double maxPrice;
    cin >> maxPrice;
    cout << "result:" << endl;
    for (const auto &route : routes) {
      if (route.price <= maxPrice) {
        printRoute(route);
      }
    }
    break;
  }
    // D gadijums izvada visu informaciju, kas ir atrodma err.txt faila
  case 'd': {
    ifstream errFile("err.txt");
    if (errFile.is_open()) {
      string line;
      cout << "result:" << endl;
      while (getline(errFile, line)) {
        cout << line << endl;
      }
      errFile.close();
    }
    break;
  }
  default:
    cout << "Invalid query. Please try again." << endl;
    break;
  }
}

int main() {
  // Atver lasamo (ifstream) un rakstamo (ofstream) failus
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

  if (!inFile || !errFile) {
    cerr << "Error opening files." << endl;
    return 1;
  }

  vector<Route> routes;
  string line;
  while (getline(inFile, line)) {
    Route route = parseRoute(line);

    if (line.empty()) {
      continue; // Ignore tuksas linijas
    }

    if ((route.start.empty() || route.end.empty() || route.day.empty() ||
         route.time.empty() || route.price == 0.0)) {
      errFile << line << endl; // Rindas ar trukstosiem datiem ieraksta err.txt faila
      continue;
    }

    if (!isTime(route.time) || !isDay(route.day)) {
      errFile << line
              << endl; // Rindas ar kludigiem datiem ieraksta err.txt faila
      continue;
    }

    routes.push_back(route);
  }

  errFile.close();
  inFile.close();

  string query;
  while (true) {
    cin >> query;
    if (query[0] == 'e')
      break;
    processQuery(query, routes);
  }

  return 0;
}