

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct Marsruts {
  string sakumaPietura;
  string galaPietura;
  string nedelasDiena;
  string laiks;
  string biletesCena;
};

bool parbaude(string n, string l, string b) {
  if (n != "Pr" && n != "Ot" && n != "Tr" && n != "Ce" && n != "Pt" &&
      n != "St" && n != "Sv") {
    return false;
  }

  int h = stoi(l.substr(0, 2));
  int m = stoi(l.substr(3, 2));

  if (l.length() != 5 && l[2] != ':') {
    return false;
  }

  if ((h < 0 || h > 23) || (m < 0 || m > 59)) {
    return false;
  }

  if (b.at(b.length() - 4) != '.' || stod(b) < 0) {
    return false;
  }

  return true;
}

void outputMarsruts(vector<Marsruts> &marsruts) {
  cout << "result:" << endl;
  for (auto &m : marsruts) {
    printf("%s %s %s %s %.2f\n", m.sakumaPietura.c_str(), m.galaPietura.c_str(),
           m.nedelasDiena.c_str(), m.laiks.c_str(), stod(m.biletesCena));
  }
}

void noraditsMarsruts(string &sakumaPietura, string &galaPietura,
                      vector<Marsruts> &Marsruts_a) {
  vector<Marsruts> rezultMarsruts;
  for (auto &m : Marsruts_a) {
    if (m.sakumaPietura == sakumaPietura && m.galaPietura == galaPietura) {
      rezultMarsruts.push_back(m);
    }
  }
  outputMarsruts(rezultMarsruts);
}

void noteiktaNedelasDiena(string &nedelasDiena, vector<Marsruts> &Marsruts_b) {
  vector<Marsruts> rezultMarsruts;
  for (auto &m : Marsruts_b) {
    if (m.nedelasDiena == nedelasDiena) {
      rezultMarsruts.push_back(m);
    }
  }
  outputMarsruts(rezultMarsruts);
}

void biletesMaksa(double &biletesCena, vector<Marsruts> &Marsruts_c) {
  vector<Marsruts> rezultMarsruts;
  for (auto &m : Marsruts_c) {
    if (stod(m.biletesCena) <= biletesCena) {
      rezultMarsruts.push_back(m);
    }
  }
  outputMarsruts(rezultMarsruts);
}

void outputErrorFail() {
  ifstream errFile;
  errFile.open("err.txt");

  cout << "result:" << endl;

  string line;
  while (errFile >> line) {
    cout << line << endl;
  }

  errFile.close();
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;

  ofstream errFile;
  errFile.open("err.txt");
  if (!errFile)
    return 0;

  vector<Marsruts> marsruts;
  vector<string> errors;

  string line;

  while (getline(inFile, line)) {
    if (line.length() == 1) {
      continue;
    }

    line.erase(remove(line.begin(), line.end(), ' '), line.end());

    stringstream ss(line);
    string sakumaPietura, galaPietura, nedelasDiena, laiks, biletesCena;
    getline(ss, sakumaPietura, ',');
    getline(ss, galaPietura, ',');
    getline(ss, nedelasDiena, ',');
    getline(ss, laiks, ',');
    getline(ss, biletesCena);
    if (ss.eof() && parbaude(nedelasDiena, laiks, biletesCena)) {
      marsruts.push_back(
          {sakumaPietura, galaPietura, nedelasDiena, laiks, biletesCena});
    } else {
      errors.push_back(line);
    }
  }

  for (auto e : errors) {
    errFile << e << endl;
  }

  inFile.close();
  errFile.close();

  string cmd;
  while (cmd != "e") {
    cin >> cmd;

    if (cmd == "a") {
      string sakumaPietura, galaPietura;
      cin >> sakumaPietura;
      cin >> galaPietura;
      noraditsMarsruts(sakumaPietura, galaPietura, marsruts);
    }

    else if (cmd == "b") {
      string nedelasDiena;
      cin >> nedelasDiena;
      noteiktaNedelasDiena(nedelasDiena, marsruts);
    }

    else if (cmd == "c") {
      double biletesCena;
      cin >> biletesCena;
      biletesMaksa(biletesCena, marsruts);
    }

    else if (cmd == "d") {
      outputErrorFail();
    }
  }

  return 0;
}