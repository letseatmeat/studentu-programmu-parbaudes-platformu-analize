
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <iomanip>
#include <regex>

using namespace std;

vector<string> splitLine(string inputLine);
void printResult();
bool validateDay(string dayToValidate);
double validatePrice(string priceToValidate);
bool validateTime(string timeToValidate);

// Route class that stores data about a route
class Route
{
    private:
        string start;
        string end;
        string day;
        string time;
        double price;
    public:
        // Constructor to initialize the Route object and set its properties
        Route(string start, string end, string day, string time, double price)
        {
            this->start = start;
            this->end = end;
            this->day = day;
            this->time = time;
            this->price = price;
        }

        // Public getters for the private properties of the Route object
        string getStart()
        {
            return start;
        }

        string getEnd()
        {
            return end;
        }

        string getDay()
        {
            return day;
        }

        double getPrice()
        {
            return price;
        }

        // Returns the route Object, formatted as "Start End Day Time Price"
        void returnRoute()
        {
            // Price is formatted to 2 decimal places
            cout << start << " " << end << " " << day << " " << time << " " << fixed << setprecision(2) << price << endl;
        }
};

int main() 
{
    // Open the db.csv file and check if it it exists
    ifstream inFile;
    inFile.open("db.csv");
    if (!inFile) return 0;

    // Declare a string variable to store the current line being processed
    string line;

    // A vector of Route objects that will store the validated routes from the CSV file
    vector<Route> routeList;
    // If the vector contained a lot of elements, it would be more efficient to use a different data structure, for faster lookups, but in this case it is not necessary

    // Opens err.txt in write mode (overwrites existing err.txt files every time the program is run)
    ofstream errFile("err.txt", ofstream::out);

    // Reads the file line by line and stores it in the routeList vector as a Route object after passing the required validation checks
    while (getline(inFile, line))
    {
        /*
            Loop logic overview:
            1. Ignore empty lines
            2. Remove all unnecessary spaces
            3. Split the string with commas as the delimeter
            4. Check the number of resulting fields
            5. Validate the data types
            6. Add the route to the routeList vector
            7. Move on to the next line
        */

        // Split the string by commas
        if (line.empty()) continue;

        //cout << line << endl;

        // Erases all spaces in the string
        line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());

        //cout << line << endl;


        // Call method to process the line into a vector of strings
        vector<string> processedLine = splitLine(line);

        // Checks if the field count doesn't match the required amount
        if (processedLine.size() != 5)
        {
            // Add the line to err.txt
            errFile << line << "\n";
            continue;
        }

        // Variables for readability
        string routeStart = processedLine[0];
        string routeDestination = processedLine[1];
        string dayOfWeek = processedLine[2];
        string time = processedLine[3];

        // Try to convert the price to a double using validatePrice() 
        double price;
        try
        {
            price = validatePrice(processedLine[4]);
        }
        catch (const std::exception& e)
        {
            // If the price is not a double, it gets added to err.txt and we iterate to the next line
            errFile << line << "\n";
            continue;
        }

        // Check the time and day formats, if they are incorrect, add the line to err.txt and iterate to the next line
        if (!validateDay(dayOfWeek) || !validateTime(time))
        {
            errFile << line << "\n";
            continue;
        }

        // Add the route to the vector
        routeList.push_back(Route(routeStart, routeDestination, dayOfWeek, time, price));

    }

    // Close the file streams
    inFile.close();
    errFile.close();

    // Switch-case for command input
    while (true) 
    {
        //cout << "Enter command: ";
        char command;
        cin >> command;

        switch (command) 
        {
            case 'a':
            {
                // Input start and end stations, output all matching routes
                string userStartRoute, userEndRoute;

                cin >> userStartRoute >> userEndRoute;

                printResult();
                for (int i = 0; i < routeList.size(); i++)
                {
                    if (routeList[i].getStart() == userStartRoute && routeList[i].getEnd() == userEndRoute)
                    {
                        routeList[i].returnRoute();
                    }
                }
                break;
            }
            case 'b':
            {
                string userDay;

                cin >> userDay;

                if (!validateDay(userDay))
                {
                    cout << "Invalid day" << endl;
                    break;
                }

                printResult();
                for (int i = 0; i < routeList.size(); i++)
                {
                    if (routeList[i].getDay() == userDay)
                    {
                        routeList[i].returnRoute();
                    }
                }
                break;
            }
            case 'c':
            {
                string userPrice;

                cin >> userPrice;

                double price;
                try
                {
                    price = validatePrice(userPrice);
                }
                catch (const std::exception& e)
                {
                    cout << "Invalid price" << endl;
                    break;
                }

                printResult();
                for (int i = 0; i < routeList.size(); i++)
                {
                    if (routeList[i].getPrice() <= price)
                    {
                        routeList[i].returnRoute();
                    }
                }
                break;
            }
            case 'd':
            {
                // Open the err.txt file and check if it it exists
                inFile.open("err.txt");
                if (!inFile) return 0;

                printResult();
                // Loop through the err.txt file and output each line
                while (getline(inFile, line))
                {
                    if(line.empty()) continue;

                    cout << line << endl;
                }

                inFile.close();
            }
                break;
            case 'e':
                // Exit the program
                return 0;
            default:
                /*
                // list all the routes
                for (int i = 0; i < routeList.size(); i++)
                {
                    routeList[i].returnRoute();
                }
                */
                break;
        }
    }
} 

// Split the line with commas as the delimeter and return a vector of strings
vector<string> splitLine(string inputLine)
{
    vector<string> splitLine;
    stringstream ss(inputLine);
    string temp;

    while (getline(ss, temp, ','))
    {
        splitLine.push_back(temp);
    }

    return splitLine;
}

// Output "result: " in the console
void printResult()
{
    cout << "result: " << endl;
}

// Check if the input string matches one of the defined shortforms for the day of the week
bool validateDay(string dayToValidate)
{
    // Check if the day matches one of the defined shortforms in the set
    unordered_set<string> validDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

    if(validDays.find(dayToValidate) == validDays.end())
    {
        return false;
    }

    return true;
}

// Try to convert the input string to a double using stod, throws an exception if the conversion fails
double validatePrice(string priceToValidate)
{
    double price;

    try
    {
        price = stod(priceToValidate);
    }
    catch (const std::exception& e)
    {
        throw invalid_argument("Price is not a double");
    }

    return price;
}

bool validateTime(string timeToValidate)
{
    // Use regex to check if the time matches the format hh:mm
    regex formatToValidate("([01]?[0-9]|2[0-3]):[0-5][0-9]");

    if(!regex_match(timeToValidate, formatToValidate))
    {
        return false;
    }

    return true;
}


