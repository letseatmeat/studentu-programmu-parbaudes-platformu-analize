
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct Marsruts {
  string sakPietura;
  string galaPietura;
  string diena;
  string laiks;
  string cena;
};

void marsrutsPecPieturam(
    vector<Marsruts> &routes, string &start,
    string &finish) { // parameters passed with reference = modifications in
                      // funciton affect the original values
  cout << "result:" << endl;
  for (const auto &route : routes) { // iterate caur katru maršrūtu
    if (route.sakPietura == start && route.galaPietura == finish) {
      cout << route.sakPietura << " " << route.galaPietura << " " << route.diena
           << " " << route.laiks << " " << route.cena << endl;
    }
  }
}

void marsrutsPecDienas(
    vector<Marsruts> &routes,
    string diena) { // parameters passed with reference = modifications in
                    // funciton affect the original values
  cout << "result:" << endl;

  for (const auto &route : routes) {
    if (route.diena == diena) {
      cout << route.sakPietura << " " << route.galaPietura << " " << route.diena
           << " " << route.laiks << " " << route.cena << endl;
    }
  }
}

void marsrutsPecCenas(
    vector<Marsruts> &routes,
    double maxPrice) { // parameters passed with reference = modifications in
                       // funciton affect the original values
  cout << "result:" << endl;

  for (const auto &route : routes) {
    if (stod(route.cena) <= maxPrice) {
      cout << route.sakPietura << " " << route.galaPietura << " " << route.diena
           << " " << route.laiks << " " << route.cena << endl;
    }
  }
}

bool isValid(
    string &inputLine,
    ofstream &errorFile) { // parameters passed with reference = modifications
                           // in funciton affect the original values
  if (inputLine.empty()) {
    return false; // Ignorēt tukšas līnijas
  }
  istringstream stream(inputLine);
  string start, finish, diena, laiks, biletesCena;
  // getline(istream& is, string& str, char delimiting) delimiting - simbols,
  // līdz kuram tiek dalīts teksts
  if (!(getline(stream, start, ',') && getline(stream, finish, ',') &&
        getline(stream, diena, ',') && getline(stream, laiks, ',') &&
        getline(stream, biletesCena, ',') && stream.eof())) {
    errorFile << inputLine
              << endl; // Pievieno kļudaino rindu ar vairāku/mazāku datu skaitu
    return false;      // Kļūda
    // stream.eof => end of stream, getline strāda līdz delimiting simbolam vai
    // rindas beigām
  }
  // Parbauda, vai sakPietura, galaPietura un laiks ir string tipa dati
  if (start.find_first_of("0123456789") !=
          string::npos || // nav atrasts cipars => atrodas (unsigned int)
                          // string::npos indeksā(jeb ārpus simbolu virknes)
      finish.find_first_of("0123456789") != string::npos ||
      diena.find_first_of("0123456789") != string::npos) {
    errorFile << inputLine << endl; // Ja kāds no datiem nav pareizajā datu tipā
    return false;
  }
  // Pārbaude, vai cena ir double tipa dati ar stod(string->double parsing),
  // tomēr mūsu faila nav tādu kļūdu, bet var būt cita failā
  try {
    stod(biletesCena);
  } catch (const exception &e) { // nevar nomainīt string->double, tad kļūda
    errorFile << inputLine << endl;
    return false; // Biļetes cena nav derīgs double
  }

  return true;
}

int main() {
  // vectors are not index based and can change its size during runtime
  vector<Marsruts> marsruti;
  vector<string> err;
  string readLine;
  // input stream
  ifstream inputFile("db.csv");
  // output stream
  ofstream errorFile("err.txt");

  while (getline(inputFile, readLine)) {
    if (!isValid(readLine, errorFile)) {
      continue; // Ignorēt nepareizas līnijas ar datiem
                // un pievienot err.txt failā
    }
    // Noņemt tukšumus no līnijām
    readLine.erase(remove_if(readLine.begin(), readLine.end(), ::isspace),
                   readLine.end());

    istringstream stream(readLine);
    string start, finish, diena, laiks, biletesCena;
    // getline(istream& is, string& str, char delimiting) delimiting - simbols,
    // līdz kuram tiek dalīts teksts
    if (getline(stream, start, ',') && getline(stream, finish, ',') &&
        getline(stream, diena, ',') && getline(stream, laiks, ',') &&
        getline(stream, biletesCena, ',') && stream.eof()) {
      // stream.eof => end of stream, getline strāda līdz delimiting simbolam
      // vai rindas beigām
      marsruti.push_back({start, finish, diena, laiks, biletesCena});
    }
  }

  inputFile.close();
  errorFile.close();
  // mūsu gadījumā failu var aizvērt pirms darbībam ar tā rindām, jo izmaiņas
  // vairs netiks veiktās

  char action;
  while (true) {
    cin >> action;

    switch (action) {
    case 'a': {
      // Izvadīt ekrānā visus reisus, kas kursē norādīta maršruta
      string start, end;
      cin.ignore(); // Clear the newline character from the buffer
      getline(cin, start);
      getline(cin, end);
      marsrutsPecPieturam(marsruti, start, end);
      break;
    }

    case 'b': {
      // Izvadīt ekrānā visus reisus, kas kursē noteiktā nedēļas dienā
      string day;
      cin.ignore(); // Clear the newline character from the buffer
      getline(cin, day);
      marsrutsPecDienas(marsruti, day);
      break;
    }

    case 'c': {
      // Izvadīt ekrānā visus reisus, kuru biļetes maksa nepārsniedz ievadīto
      double maxPrice;
      cin >> maxPrice;
      marsrutsPecCenas(marsruti, maxPrice);
      break;
    }

    case 'd': {
      cout << "result:" << endl;
      // Izvadīt ekrāna err.txt faila saturu
      ifstream errorFile("err.txt");
      string errorLine;
      while (getline(errorFile, errorLine)) {
        if (!errorLine.empty()) {
          cout << errorLine << endl;
        }
      }
      errorFile.close();
      break;
    }

    case 'e':
      // Exit the program
      return 0;
    }
  }

  return 0;
}
