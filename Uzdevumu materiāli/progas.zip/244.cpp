
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>

using namespace std;

class Route {
private:
  string from;
  string to;
  string day;
  string time;
  float price;

public:
  Route(string from, string to, string day, string time, float price) {
    this->from = from;
    this->to = to;
    this->day = day;
    this->time = time;
    this->price = price;
  }

  string getFrom() const { return from; }
  string getTo() const { return to; }
  string getDay() const { return day; }
  string getTime() const { return time; }
  float getPrice() const { return price; }

  void print() const {
    cout << from << " " << to << " " << day << " " << time << " "
         << setprecision(2) << fixed << price << endl;
  }
};

string ltrim(string s) {
  s.erase(0, s.find_first_not_of(" \t\n\r\f\v"));
  return s;
}

string rtrim(string s) {
  s.erase(s.find_last_not_of(" \t\n\r\f\v") + 1);
  return s;
}

string trim(string s) { return rtrim(ltrim(s)); }

int charToInt(char c) { return c - '0'; }

// dienas pārbaude
bool validateDay(string day) {
  vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};

  for (int i = 0; i < days.size(); i++) {
    if (days[i] == day)
      return true;
  }

  return false;
}

// laika pārbaude
bool validateTime(string s) {
  if (s.length() != 5)
    return false;
  if (s[2] != ':')
    return false;
  if (!isdigit(s[0]) || !isdigit(s[1]) || !isdigit(s[3]) || !isdigit(s[4]))
    return false;
  if (charToInt(s[0]) > 2 || (charToInt(s[0]) == 2 && charToInt(s[1]) > 4) ||
      charToInt(s[3]) > 5)
    return false;
  return true;
}

// cenas pārbaude
bool validatePrice(string s) {
  size_t pos;
  float num;
  try {
    num = stof(s, &pos);
    if (num > 0 && pos == s.length())
      return true;
    return false;
  } catch (...) {
    return false;
  }
}

// rezultāts meklējot pēc pieturām
void printRouteFromTo(const vector<Route> &routes) {
  string from, to;
  cin >> from;
  cin >> to;

  cout << "result:" << endl;

  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].getFrom() == trim(from) && routes[i].getTo() == trim(to)) {
      routes[i].print();
    }
  }
}

// rezultāts meklējot pēc dienas
void printRouteDay(const vector<Route> &routes) {
  string day;
  cin >> day;

  cout << "result:" << endl;

  for (int i = 0; i < routes.size(); i++) {
    if (routes[i].getDay() == trim(day)) {
      routes[i].print();
    }
  }
}

// rezultāts meklējot pēc cenas
void printRoutePrice(const vector<Route> &routes) {
  string input;
  float price;
  cin >> input;

  cout << "result:" << endl;

  if (validatePrice(input)) {
    price = stof(input);
    for (int i = 0; i < routes.size(); i++) {
      if (routes[i].getPrice() <= price) {
        routes[i].print();
      }
    }
  }
}

// kļūdainās rindas
void printError(string path) {
  string s;
  ifstream inFile;
  inFile.open(path);

  cout << "result:" << endl;

  while (inFile >> s) {
    cout << s << endl;
  }

  inFile.close();
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  string s, lineCopy;
  int position;
  vector<string> columns;
  vector<string> errorLines;
  vector<Route> routes;

  // teksta apstrāde
  while (getline(inFile, s)) {
    if (trim(s).size() == 0) {
      continue;
    }

    position = 0;
    columns.clear();
    lineCopy = s;

    // sadala rindu masīvā atdalot ar ","
    while ((position = s.find(",")) != string::npos) {
      columns.push_back(trim(s.substr(0, position)));
      s.erase(0, position + 1);
    }
    columns.push_back(trim(s));

    // pārbauda vērtības
    if (columns.size() != 5 || !validateDay(columns[2]) ||
        !validateTime(columns[3]) || !validatePrice(columns[4])) {
      errorLines.push_back(lineCopy);
      continue;
    }

    // izveido objektu un ieliek masīvā
    Route route(columns[0], columns[1], columns[2], columns[3],
                stof(columns[4]));
    routes.push_back(route);
  }

  inFile.close();

  string errPath = "err.txt";
  ofstream outFile;
  outFile.open(errPath);

  // ieraksta kļūdainās rindas failā
  for (int i = 0; i < errorLines.size(); i++) {
    outFile << errorLines[i] << endl;
  }

  outFile.close();

  string command;
  while (true) {
    cin >> command;

    if (command == "a") {
      // pieturas
      printRouteFromTo(routes);
      continue;
    } else if (command == "b") {
      // diena
      printRouteDay(routes);
      continue;
    } else if (command == "c") {
      // cena
      printRoutePrice(routes);
      continue;
    } else if (command == "d") {
      // kļūdainās rindas
      printError(errPath);
      continue;
    } else if (command == "e") {
      // iziet
      break;
    } else {
      continue;
    }
  }
}