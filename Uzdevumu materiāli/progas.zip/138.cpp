

#include <fstream>
#include <iostream>
#include <regex>
#include <vector>
using namespace std;

// function for checking if price is formated
bool checkPrice(string s) {
  try {
    stod(s);
    return true;
  } catch (...) {
    return false;
  }
}

// function for checking if time is formatted correctly
bool checkTime(string s) {
  try {
    string d = ":";
    int h = stoi(s.substr(0, s.find(d)));
    int min = stoi(s.substr(s.find(d) + 1));

    if (h < 25 && min < 60) {
      return true;
    }
    return false;
  } catch (...) {
    return false;
  }
}

// function for checking if day is formatted correctly
bool checkDay(string s) {
  string days = "PrOtTrCePtStSv";
  if ((days.find(s)) != -1) {
    return true;
  }
  return false;
}

// function for checking if stop are formatted correctly
bool checkStop(string s) {
  regex namef("(\\w+)");
  smatch m;
  if (regex_search(s, m, namef) && m.size() > 1) {
    return true;
  }
  return false;
}

// check if the row is correct and return it already split
string *checkRow(string *a, string r) {
  a = new string[5];
  string d = ",";
  int n = 0, i = 0;
  regex fr("\\s+");
  r = regex_replace(r, fr, "");

  while ((n = r.find(d)) != -1) {
    a[i] = r.substr(0, n);
    r.erase(0, n + d.length());
    i++;
  }
  if (!r.empty() && i <= 4) {
    a[i] = r;
  }

  // check if there even are 5 elements
  if (i != 4) {
    return NULL;
  }

  // check if start&end stops are correct
  if (!(checkStop(a[0]) && checkStop(a[1]))) {
    return NULL;
  }

  // check if day is correct
  if (!checkDay(a[2])) {
    return NULL;
  }

  // check if time is correct
  if (!checkTime(a[3])) {
    return NULL;
  }

  // check if price is correct
  if (!checkPrice(a[4])) {
    return NULL;
  }

  return a;
}

// function returns vector that consists of file rows
vector<string *> getFileContent(vector<string *> v) {
  string row;
  string *t;

  ifstream f("db.csv");
  ofstream e("err.txt");

  if (f) {
    while ((getline(f, row))) {
      if (row.size() > 1) {
        t = checkRow(t, row);

        if (t == NULL) {
          e << row << endl;
        } else {
          v.push_back(t);
        }
      }
    }
    e.close();
    f.close();
  }
  return v;
}

// show routes in user defined start and end points
void a(vector<string *> v) {
  cout << "result:" << endl;

  string start;
  string end;
  string *temp;

  cin >> start;
  cin >> end;

  for (auto i = v.begin(); i != v.end(); ++i) {
    temp = *i;

    if (temp[0] == start && temp[1] == end) {
      for (int j = 0; j < 5; j++) {
        cout << temp[j] + " ";
      }
      cout << endl;
    }
  }
}

// show routes in certain days
void b(vector<string *> v) {
  cout << "result:" << endl;

  string day;
  string *temp;

  cin >> day;

  for (auto i = v.begin(); i != v.end(); ++i) {
    temp = *i;

    if (temp[2] == day) {
      for (int j = 0; j < 5; j++) {
        cout << temp[j] + " ";
      }
      cout << endl;
    }
  }
}

// show routes in user budget
void c(vector<string *> v) {
  cout << "result:" << endl;
  double price;
  string *temp;

  cin >> price;

  for (auto i = v.begin(); i != v.end(); ++i) {
    temp = *i;

    if (stod(temp[4]) <= price) {
      for (int j = 0; j < 5; j++) {
        cout << temp[j] + " ";
      }
      cout << endl;
    }
  }
}

// print out err.txt content
void d() {
  cout << "result:" << endl;
  string t;
  ifstream f("err.txt");
  if (f) {
    while ((getline(f, t))) {
      cout << t << endl;
    }
    f.close();
  }
}

int main() {
  // store file content
  vector<string *> values;
  values = getFileContent(values);

  // loop for inputing commands
  string cmd;
  while (true) {
    // cout << "command: ";
    cin >> cmd;

    if (cmd == "e") {
      break;
    } else if (cmd == "a") {
      a(values);
    } else if (cmd == "b") {
      b(values);
    } else if (cmd == "c") {
      c(values);
    } else if (cmd == "d") {
      d();
    } else {
      cout << "incorrect input" << endl;
    }
  }
}
