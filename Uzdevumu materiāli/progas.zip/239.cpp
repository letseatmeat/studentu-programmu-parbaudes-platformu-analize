// valerija drozda 221rdb450
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>

using namespace std;

struct Route {
  string startStop;
  string endStop;
  string day;
  string time;
  double price;
};

struct interfaceRoute {
  string startStop;
  string endStop;
  string day;
  string time;
  string price;
  string rest;
};

vector<Route> routes;

string DaysOfWeek = "Pr,Ot,Tr,Ce,Pt,St,Sv";

void trim(string &str) {
  int i = 0;
  while (isspace(str[i]) != 0)
    i++;
  str = str.substr(i, str.length() - i);
  i = str.length() - 1;
  while (isspace(str[i]) != 0)
    i--;
  str = str.substr(0, i + 1);
}

bool isFloat(const string &str) {
  istringstream iss(str);
  float f;
  iss >> noskipws >> f;
  return iss.eof() && !iss.fail();
}

bool containsOnlyCharacters(const string &str) {
  for (char ch : str) {
    if (!isalpha(ch)) {
      return false;
    }
  }
  return true;
}

bool validRecord(interfaceRoute &route, Route &newroute) {
  trim(route.startStop);
  trim(route.endStop);
  trim(route.day);
  trim(route.time);
  trim(route.price);

  if (route.startStop.empty() || route.endStop.empty() || route.day.empty() ||
      route.time.empty() || route.price.empty())
    return false;
  if (!containsOnlyCharacters(route.startStop) ||
      !containsOnlyCharacters(route.endStop))
    return false;

  if (DaysOfWeek.find(route.day) == string::npos)
    return false;

  if (route.time.size() != 5 || !isdigit(route.time[0]) ||
      !isdigit(route.time[1]) || route.time[2] != ':' ||
      !isdigit(route.time[3]) || !isdigit(route.time[4]))
    return false;

  if (route.price.size() == 0 || !isFloat(route.price))
    return false;

  newroute.startStop = route.startStop;
  newroute.endStop = route.endStop;
  newroute.day = route.day;
  newroute.time = route.time;
  newroute.price = stod(route.price);

  return true;
}

void readRoutes() {
  ifstream inFile;
  ofstream outErr;
  inFile.open("db.csv");
  outErr.open("err.txt");

  if (!inFile)
    return;
  string s;
  while (getline(inFile, s)) {
    if (s.size() <= 1)
      continue;
    istringstream iss;
    iss.str(s);
    interfaceRoute route;
    Route newRoute;
    string token;
    bool added = false;
    if (getline(iss, route.startStop, ',') &&
        getline(iss, route.endStop, ',') && getline(iss, route.day, ',') &&
        getline(iss, route.time, ',') && getline(iss, route.price, ',') &&
        !getline(iss, route.rest) && validRecord(route, newRoute)) {
      routes.push_back(newRoute);

    } else
      outErr << s << endl;
  }
  inFile.close();
  outErr.close();
}

void printRoute(const Route &route) {
  cout << route.startStop << " " << route.endStop << " " << route.day << " "
       << route.time << " " << fixed << setprecision(2) << route.price << endl;
}

void filterAndPrintRoutesByStartAndEndStop(const string &startStop,
                                           const string &endStop) {
  cout << "result:" << endl;
  for (const Route &route : routes) {
    if (route.startStop == startStop && route.endStop == endStop) {
      printRoute(route);
    }
  }
}

void filterAndPrintRoutesByDay(const string &day) {
  cout << "result:" << endl;
  for (const Route &route : routes) {
    if (route.day == day) {
      printRoute(route);
    }
  }
}

void filterAndPrintRoutesByMaxPrice(double maxPrice) {
  cout << "result:" << endl;
  for (const Route &route : routes) {
    if (route.price <= maxPrice) {
      printRoute(route);
    }
  }
}

int main() {
  readRoutes();
  char choice;
  do {
    cin >> choice;
    switch (choice) {
    case 'a': {
      string start, end;
      cout << "Enter start stop: ";
      cin >> start;
      cout << "Enter end stop: ";
      cin >> end;
      filterAndPrintRoutesByStartAndEndStop(start, end);
      break;
    }
    case 'b': {
      string day;
      cout << "Enter day: ";
      cin >> day;
      filterAndPrintRoutesByDay(day);
      break;
    }
    case 'c': {
      double maxPrice;
      cout << "Enter max price: ";
      cin >> maxPrice;
      filterAndPrintRoutesByMaxPrice(maxPrice);
      break;
    }

    case 'd': {
      ifstream r;
      r.open("err.txt");
      if (!r) {
        break;
      }

      cout << "result:" << endl;
      string line;
      while (r >> line) {
        cout << line << endl;
      }

      r.close();
      break;
    }
    case 'e':
      break;
    }

  } while (choice != 'e');
  return 0;
}