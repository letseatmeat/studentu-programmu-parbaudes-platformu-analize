
#include <cctype>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;
void check(ifstream &inFile, vector<int> &nl) {
   string str, pb;

  string arr[] = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
   ofstream errfile("err.txt");
   bool lne = false;
  int y = -1, c = 0, d, ks = 3, kdz;

  while (getline(inFile, str)) {

    y++;
    d = 0;
    c = 0;
    ks = 3;
      kdz = 0;
      lne = false;

    for (int x = 0; x < str.length(); x++) { 

      if (str[x] != ' ') {
          pb += str[x];
      }
      if (str[x] == ',') {
          kdz++;

      }
    }
    if (pb.length() == 1) {

      nl.push_back(y);
    } else if (kdz != 4) {
        lne = true;

    }

      str = pb;

      pb.clear();
    for (int i = 0; i < str.length(); i++) {
      if (lne) {

        nl.push_back(y);
        errfile << str << endl;
        break;
      }

      if (d < 2) {
        if (str[i] == ',') { 
            pb = str.substr(c, i - c);

          for (char c : pb) {
            if (isalpha(c)) {
              break;
            } else {
                lne = true;
            }
          }

          d++;
          c = i + 1;
            pb.clear();
        }

      } else if (str[i] == ',') {
        if (ks == 3) {
          lne = true;
            pb = str.substr(c, i - c);


          for (int j = 0; j < sizeof(arr) / sizeof(arr[0]); j++) {
            if (pb == arr[j]) {

                lne = false;
              break;
            }
          }
            pb.clear();
          c = i + 1;
            ks++;
        } else if (ks == 4) { 
            pb = str.substr(c, i - c);
          int sk=0;
          for (char h : pb) {
            sk++;
            if (isdigit(h)) {
              continue;
            } else if (h == ':') {
              continue;
            } else if(sk>5) {
                lne = true;
              break;
            }else{
                lne = true;
              break;
            }
          }

        c = i + 1;

            ks++;
           pb.clear();
        }

      } else if (ks == 5) {
          pb = str.substr(c,str.length() - c - 1);
        for (char h : pb) {
          if (isdigit(h)) {
            continue;
          } else if (h == '.') {
            continue;
          } else {
              lne = true;
            break;
          }
        }
     ks++;
          pb.clear();

      }
    }
  }
  inFile.close();
}
string clnr(string s){
      s.erase(remove(s.begin(), s.end(), ' '), s.end());
  for (char &ch : s) {
    if (ch == ',') {
        ch = ' ';
    }
  }
  return s;
}

void pieturas(string sk, string bg, vector<int> nk, ifstream &inFile) {
   int x = 0;
  string str;

    cout<<"result:"<<endl;
    while (getline(inFile, str)) {
        if (find(nk.begin(), nk.end(), x) == nk.end()) {
         string bl,pr;
            pr.clear();
            stringstream dd(str);
            vector<string> tk;


            while (getline(dd, bl, ',')) {

                  tk.push_back(bl);
            }

            if (tk.size() >= 2) {
              string ot = tk[1];
                string pm = tk[0];



               ot.erase(ot.find_last_not_of(" ") + 1);

                pm.erase(0, pm.find_first_not_of(" "));
                  ot.erase(0, ot.find_first_not_of(" "));
                pm.erase(pm.find_last_not_of(" ") + 1);




                if (pm == sk && ot == bg) {
                      pr=clnr(str);
                    cout<<pr<<endl;
                }
            }
        }
        x++;
    }
      inFile.close();
}
void dien(string dn, vector<int> nk, ifstream &inFile) {
  string str;
    int x = 0;
    cout<<"result:"<<endl;
    while (getline(inFile,str)) {
        if (find(nk.begin(), nk.end(), x) == nk.end()) {
           string dl,pr;
           pr.clear();

            vector<string> tk;
           stringstream dd(str);

            while (getline(dd, dl, ',')) {

                  tk.push_back(dl);
            }
              string ext=tk[2];
          ext.erase(ext.find_last_not_of(" ")+1);
                ext.erase(0, ext.find_first_not_of(" "));

                if (ext==dn) {
                    pr=clnr(str);
                  cout<<pr<<endl;
                }

        }
        x++;
    }
  inFile.close();
}
void cena(double cn, vector<int> nk, ifstream &inFile) {
  string str;
    int x = 0;
    cout<<"result:"<<endl;
    while (getline(inFile, str)) {
        if (find(nk.begin(), nk.end(), x) == nk.end()) {
         string dl,pr;
            vector<string> tk;
            stringstream dd(str);

              pr.clear();
            while (getline(dd, dl, ',')) {

                  tk.push_back(dl);
            }
              string pk=tk[4];
          pk.erase(pk.find_last_not_of(" ")+1);
                pk.erase(0, pk.find_first_not_of(" "));

              double num =stod(pk);
                if (num<=cn) {
                    pr=clnr(str);
                  cout<<pr<<endl;
                }

        }
        x++;
    }
  inFile.close();


}
int main() {
  ifstream inFile,ef;
  inFile.open("db.csv");
  vector<int> nk;
  if (!inFile)
    return 0;
  check(inFile, nk);


  while (true) {
    string km;
    cin >> km;
    if (km == "e") {
      break;
    }
    switch (km[0]) {
    case 'a': {
      string sk, bg;
      cin >> sk >> bg;

      inFile.open("db.csv");
      if (!inFile)
        return 0;
      pieturas(sk, bg,nk,inFile);
      break;
    }

    case 'c': {
      string cn;
      cin >> cn;
      double cnm=stod(cn);
      inFile.open("db.csv");
      if (!inFile)
          return 0;
      cena(cnm,nk,inFile);
      break;
    }

      case 'b': {
        string dn;
        cin >> dn;
        inFile.open("db.csv");
        if (!inFile)
            return 0;
          dien(dn,nk,inFile);
        break;
      }
        case 'd': {
          string str;
          cout<<"result:"<<endl;
            ef.open("err.txt");
          if (!ef)
            return 0;
          while (getline(ef, str)) {
            cout << str << endl;
          }
      break;
    }
    }
  }
}