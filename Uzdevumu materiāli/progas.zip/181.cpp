

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

class Trip {
public:
  string from;
  string to;
  string day;
  string time;
  float cost;

  Trip(vector<string> v) {
    from = v[0];
    to = v[1];
    day = v[2];
    time = v[3];
    cost = stof(v[4]);
  }

  void printTrip() {
    cout << from << " " << to << " " << day << " " << time << " " << fixed
         << setprecision(2) << cost << endl;
  }
};

bool checkFields(vector<string> line) {

  string s;

  for (int i = 0; i < 3; i++) {
    s = line[i];

    for (int j = 0; j < s.length(); j++) {
      if (!isalpha(s[j])) {

        return false;
      }
    }
  }

  s = line[3];

  if (s[2] != ':') {

    return false;
  }

  s = line[4];
  int ln = s.length();

  ln = ln - 4;
  if (s[ln] != '.') {
    return false;
  }
  return true;
}

int countCommas(string s) {
  int count;
  for (int i = 0; i < s.length(); i++) {
    if (s[i] == ',') {
      count++;
    }
  }
  return count;
}

string trimspace(string s) {

  string result = "";
  size_t firstletter = s.find_first_not_of(' ');
  size_t lastletter = s.find_last_not_of(' ');

  result = s.substr(firstletter, ++lastletter);

  // cout<<result<<endl;
  return result;

  // cout<<result<<"--";
}

vector<string> splitLine(string s) {
  vector<string> result;

  stringstream strm(s);
  string word;

  while (getline(strm, word, ',')) {

    result.push_back(trimspace(word));
  }

  return result;
}

void writeToErr(vector<string> vec) {
  ofstream errFile("err.txt");

  for (string s : vec) {
    errFile << s << endl;
  }

  errFile.close();
}

void optionA(vector<Trip> tvec) {
  string frominp;
  cin >> frominp;
  string toinp;
  cin >> toinp;
  cout << "result: " << endl;

  for (Trip t : tvec) {
    if ((t.from == frominp) && (t.to == toinp)) {
      t.printTrip();
    }
  }
}

void optionD() {
  ifstream errF("err.txt");
  string s;
  cout << "result: " << endl;
  while (errF >> s) {
    cout << s << endl;
  }
}

void optionB(vector<Trip> tvec) {
  string s;
  cin >> s;
  cout << "result: " << endl;

  for (Trip t : tvec) {
    if (t.day == s) {
      t.printTrip();
    }
  }
}

void optionC(vector<Trip> tvec) {
  float f;
  cin >> f;
  cout << "result: " << endl;

  for (Trip t : tvec) {
    if (t.cost <= f) {
      t.printTrip();
    }
  }
}
int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  vector<Trip> trips;
  string line;
  vector<string> failLines;

  while (inFile) {

    getline(inFile, line);
    if (!line.empty()) {

      if (countCommas(line) == 4) {
        vector<string> splitvec = splitLine(line);

        if (checkFields(splitvec)) {

          Trip tr(splitvec);

          trips.push_back(tr);
          continue;
        }
      }

      failLines.push_back(line);
    }
  }

  writeToErr(failLines);
  char pick;
  cin >> pick;

  while (pick != 'e') {

    switch (pick) {
    case 'a':
      optionA(trips);
      break;

    case 'd':
      optionD();
      break;

    case 'b':
      optionB(trips);
      break;

    case 'c':
      optionC(trips);
      break;

    default:
      cout << "error" << endl;
      break;
    }

    cin >> pick;
  }
}