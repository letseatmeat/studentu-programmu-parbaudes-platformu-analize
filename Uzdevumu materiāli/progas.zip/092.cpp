
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <algorithm>

using namespace std;

void parbaude(ifstream& inFile, ofstream& outFile, int komandskaits, int komanda, string spietura, string gpietura, string nedelasdiena, double ievadcena){
  string line;
  vector<string> dati;
  int laukuskaits;
  bool pareizarinda = true;

  cout << "result:" << endl;

  while (getline(inFile >> ws, line)){
    
    istringstream iss(line);
    string vards;
    
    while (getline(iss, vards, ',')){
      vards.erase(remove_if(vards.begin(), vards.end(), [](unsigned char x) {
                return isspace(x);
            }), vards.end());
      dati.push_back(vards);
    }// no katras rindas vārdus saliek vektorā

    if (dati.size() == 5){
    
      string pirmaisvards = dati[0];
      for (char c : pirmaisvards){
         if (!((c >= 'a' && c<= 'z')||(c >= 'A' && c <= 'Z'))){
           pareizarinda = false;
           break;
         }
      }// pirmā vārda pārbaude

      string otraisvards = dati[1];
      for (char c : otraisvards){
         if (!((c >= 'a' && c<= 'z')||(c >= 'A' && c <= 'Z'))){
           pareizarinda = false;
           break;
         }
      }// otrā vārda pārbaude

      string tresaisvards = dati[2];
      if (!(tresaisvards=="Pr"||tresaisvards=="Ot"||tresaisvards=="Tr"||tresaisvards=="Ce"||tresaisvards=="Pt"||tresaisvards=="St"||tresaisvards=="Sv")){
        pareizarinda = false;
      }// trešā vārda pārbaude
    
      string ceturtaisvards = dati[3];
      if (ceturtaisvards[2] != ':' || !isdigit(ceturtaisvards[0]) || !isdigit(ceturtaisvards[1]) || !isdigit(ceturtaisvards[3]) || !isdigit(ceturtaisvards[4])){
        pareizarinda = false;
      }
      try {
        int stundas = stoi(ceturtaisvards.substr(0,2));
        int minutes = stoi(ceturtaisvards.substr(3,2));
        if (!(stundas>=0 && stundas<=23) || !(minutes>=0 && minutes <= 59)){
          pareizarinda = false;
        }
      } catch (const invalid_argument& e) {
        pareizarinda = false;
      }// ceturtā vārda pārbaude

      string piektaisvards = dati[4];
      int punktapozicija = piektaisvards.find(".");
      int ciparipeckomata = piektaisvards.length() - punktapozicija -1;
      if (punktapozicija == string::npos){
        pareizarinda = false;
      } else if (ciparipeckomata != 2 || !isdigit(piektaisvards[punktapozicija +1]) || !isdigit(piektaisvards[punktapozicija+2])){
        pareizarinda = false;
      }
      for (int i=0; i<punktapozicija; i++){
        if (!isdigit(piektaisvards[i])){
          pareizarinda = false;
        }
      }// piektā vārda pārbaude

      if (pareizarinda!=false && dati[0]==spietura && dati[1]==gpietura && komanda==1){
        for (const auto& data : dati){
          cout << data << " ";
        }
        cout << endl;
      }// izvada pareizās rindas (A komanda)

      if (pareizarinda!=false && dati[2]==nedelasdiena && komanda==2){
        for (const auto& data : dati){
          cout << data << " ";
        }
        cout << endl;
      }// izvada pareizās rindas (B komanda)

      if (pareizarinda!=false && komanda==3){
        double cena = stod(dati[4]);
        if (cena <= ievadcena){
          for (const auto& data : dati){
          cout << data << " ";
          }
          cout << endl;
        }
      }// izvada pareizās rindas (C komanda)
      
      if (pareizarinda==false & komandskaits==0){
        int i;
        int daudzums = dati.size();
        for (i=0; i<daudzums; i++){
          outFile << dati[i];
          if (i<daudzums-1){
            outFile << ",";
          }
        }
        outFile << endl;
      }// ieraksta err.txt failā nepareizās rindas (nepareizs formāts)

      pareizarinda = true;
      
    } else if (komandskaits==0) {
        int i;
        int daudzums = dati.size();
        for (i=0; i<daudzums; i++){
          outFile << dati[i];
          if (i<daudzums-1){
            outFile << ",";
          }
        }
        outFile << endl;
    }// ieraksta err.txt failās nepareizās rindas (nepareizs lauku skaits)
    
    dati.clear();
  }
}


void akomanda(ifstream& inFile, ofstream& outFile, int komandskaits){
  string spietura, gpietura;
  cin >> spietura;
  cin >> gpietura;

  int komanda = 1;

  parbaude(inFile, outFile, komandskaits, komanda, spietura, gpietura, "nav", 0.0);
}


void bkomanda(ifstream& inFile, ofstream& outFile, int komandskaits){
  string nedelasdiena;
  cin >> nedelasdiena;

  int komanda = 2;

  parbaude(inFile, outFile, komandskaits, komanda, "nav", "nav", nedelasdiena, 0.0);
}


void ckomanda(ifstream& inFile, ofstream& outFile, int komandskaits){
  double ievadcena;
  cin >> ievadcena;

  int komanda = 3;

  parbaude(inFile, outFile, komandskaits, komanda, "nav", "nav", "nav", ievadcena);
}


void dkomanda(ifstream& inFile, ofstream& outFile, int komandskaits){
  if (komandskaits==0){
    parbaude(inFile, outFile, komandskaits, 0, "nav", "nav", "nav", 0.0);
  }
  if (komandskaits!=0){
    cout << "result:" << endl;
  }

  ifstream errFile;
  errFile.open("err.txt");
  if (!errFile) {
    cout << "nevar atvērt failu" << endl;
  }

  string line;
  while (getline(errFile, line)){
    cout << line << endl;
  }

  errFile.close();
}


int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  ofstream outFile("err.txt");
  int komandskaits=0;

  char komanda;
  do {
    cin >> komanda;
    switch(komanda){
      case 'a':
        inFile.clear();
        inFile.seekg(0, ios::beg);
        akomanda(inFile, outFile, komandskaits);
        komandskaits++;
        break;
      case 'b':
        inFile.clear();
        inFile.seekg(0, ios::beg);
        bkomanda(inFile, outFile, komandskaits);
        komandskaits++;
        break;
      case 'c':
        inFile.clear();
        inFile.seekg(0, ios::beg);
        ckomanda(inFile, outFile, komandskaits);
        komandskaits++;
        break;
      case 'd':
        dkomanda(inFile, outFile, komandskaits);
        komandskaits++;
        break;
    }
  } while (komanda != 'e');
  
  inFile.close();
  outFile.close();
  return 0;
} 