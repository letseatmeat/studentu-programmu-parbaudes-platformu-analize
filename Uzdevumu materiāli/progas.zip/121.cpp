
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm> 
#include <cstdio>

using namespace std;

struct Route {
    string start;
    string end;
    string day;
    string time;
    double price;
};

void displayRoutes(const vector<Route>& routes) {
    cout << "result:" << endl;
    for (const auto& route : routes) {
        cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " << fixed << setprecision(2) << route.price << endl;
    }
}

const vector<string> explode(const string& s, const char& c)
{
  string buff{""};
  vector<string> v;

  for(auto n:s)
  {
    if(n != c) buff+=n; else
    if(n == c && buff != "") { v.push_back(buff); buff = ""; }
  }
  if(buff != "") v.push_back(buff);

  return v;
}

void trimRight(std::string& str) {
    size_t endpos = str.find_last_not_of(" \t\n\r");
    if (std::string::npos != endpos) {
        str = str.substr(0, endpos + 1);
    } else {
        str.clear();
    }
}

void displayErrorFile() {
    ifstream errFile("err.txt");
    if (errFile) {
        string line;
        cout << "result:" << endl;
        while (getline(errFile, line)) {
            cout << line << endl;
        }
        errFile.close();
    } else {
        cout << "Error file not found." << endl;
    }
}

void removeErrorFile() {
    const char* filename = "err.txt";

    // Check if the file exists
    if (std::remove(filename) != 0) {
        std::perror("Error removing file");
    }
}

int countSymbol(const std::string& s, const std::string& symbol) {
  int count = 0;
  for (size_t i = 0; i < s.size(); i++) {
    if (s.substr(i, symbol.size()) == symbol) {
      count++;
    }
  }

  return count;
}

int main() {
    ifstream inFile("db.csv");
    removeErrorFile();
    ofstream errFile("err.txt", ios::app);  // Open in append mode

    if (!inFile) {
        cout << "Error opening db.csv file." << endl;
        return 1;
    }

    vector<Route> routes;

    string line;
    string previousLine = "";
    while (getline(inFile, line)) {
        trimRight(line);
        if (line == ""){
            previousLine = "";
            continue;
        }

        int countStart = countSymbol(line, ",");
        if (countStart < 4){
            line = previousLine + line;
        } else {
            previousLine = "";
        }
        line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end());

        int count = countSymbol(line, ",");

        if (count < 4){
            errFile  << line << endl;
            previousLine = line;
            continue;
        } else if (count > 4){
            errFile  << line << endl;
            previousLine = "";
            continue;
        } else {
            previousLine = "";
        }

        vector<string> stringVector{explode(line, ',')};

        // cout << "LINE!!![" + line + "]!!!" << endl;
        //istringstream iss(stringVector);
        Route route;

        route.start = stringVector[0];
        route.end = stringVector[1];

        // lenght must be 2 symbols
        if (stringVector[2].size() == 2){
            route.day = stringVector[2];
        } else {
            errFile  << line << endl;
            continue;
        }
        //must contain ":"
        int countTimeSeperator = countSymbol(stringVector[3], ":");
        if (countTimeSeperator == 1){
            route.time = stringVector[3];
        } else {
            errFile  << line << endl;
            continue;
        }

        //must contain "."
        int countDoubleSeperator = countSymbol(stringVector[4], ".");
        if (countDoubleSeperator == 1){
            route.price = std::stod(stringVector[4]);
        } else {
            errFile  << line << endl;
            continue;
        }


        routes.push_back(route);
    }

    inFile.close();
    errFile.close();

    char choice;
    do {

        cin >> choice;
        switch (choice) {
            case 't': {
                cout << "All route list ";
                displayRoutes(routes);
                break; 
            }
            case 'a': {
                string start, end;
                cin >> start;
                cin >> end;

                vector<Route> selectedRoutes;
                for (const auto& route : routes) {
                    if (route.start == start && route.end == end) {
                        selectedRoutes.push_back(route);
                    }
                }
                displayRoutes(selectedRoutes);
                break;
            }

            case 'b': {
                string day;
                cout << "Enter day of the week (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                cin >> day;

                vector<Route> selectedRoutes;
                for (const auto& route : routes) {
                    if (route.day == day) {
                        selectedRoutes.push_back(route);
                    }
                }

                displayRoutes(selectedRoutes);
                break;
            }

            case 'c': {
                double maxPrice;
                cout << "Enter maximum ticket price: ";
                cin >> maxPrice;

                vector<Route> selectedRoutes;
                for (const auto& route : routes) {
                    if (route.price <= maxPrice) {
                        selectedRoutes.push_back(route);
                    }
                }

                displayRoutes(selectedRoutes);
                break;
            }

            case 'd':
                displayErrorFile();
                break;

            case 'e':
                break;

            default:
                cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != 'e');

    return 0;
}
