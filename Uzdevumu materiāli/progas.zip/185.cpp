
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;
string removeSpaces(string s) {
  s.erase(remove(s.begin(), s.end(), ' '), s.end());
  return s;
}

int pieturas(vector<string> db) {
  string sakumaPietura, galaPietura;

  cin >> sakumaPietura;
  cin >> galaPietura;
  cout << "result:"<< "\n";

  for (const string &str : db) {
    istringstream iss(str);
    string sakumaPieturaNoDb, galaPieturaNoDb;
    if (getline(iss, sakumaPieturaNoDb, ',') &&
        getline(iss, galaPieturaNoDb, ',')) {
      if (sakumaPieturaNoDb == sakumaPietura &&
          galaPieturaNoDb == galaPietura) {
        string izmainitsStr = str;
        replace(izmainitsStr.begin(), izmainitsStr.end(), ',', ' ');
        cout << izmainitsStr << "\n";
      }
    }
  }

  return 0;
}
int ned_dienas(vector<string> db) {
  string diena;
  cin >> diena;
  cout << "result:"
       << "\n";
  for (const string &str : db) {
    istringstream iss(str);
    string sakumaPieturaNoDb, galaPieturaNoDb, dienaNoDb;
    string izmainitsStr = str;
    replace(izmainitsStr.begin(), izmainitsStr.end(), ',', ' ');
    istringstream izmainitsVelreiz(izmainitsStr);
    if (izmainitsVelreiz >> sakumaPieturaNoDb >> galaPieturaNoDb >> dienaNoDb) {
      if (dienaNoDb == diena) {
        cout << izmainitsStr << "\n";
      }
    }
  }
  return 0;
}
int biletes(vector<string> db) {
  float cena;
  cin >> cena;
  cout << "result:"
       << "\n";
  for (const string &str : db) {
    istringstream iss(str);
    string sakumaPieturaNoDb, galaPieturaNoDb, dienaNoDb, laiksNoDb, cenaNoDb;
    string izmainitsStr = str;
    replace(izmainitsStr.begin(), izmainitsStr.end(), ',', ' ');
    istringstream izmainitsVelreiz(izmainitsStr);
    if (izmainitsVelreiz >> sakumaPieturaNoDb >> galaPieturaNoDb >> dienaNoDb >>
        laiksNoDb >> cenaNoDb) {
      float cenaNoDbParveidots = stof(cenaNoDb);
      if (cena >= cenaNoDbParveidots) {
        cout << izmainitsStr << "\n";
      }
    }
  }
  return 0;
}
int error() {
  cout << "result:"
       << "\n";
  ;
  ifstream inFile;
  inFile.open("err.txt");

  if (!inFile)
    return 0;

  string s;
  while (getline(inFile, s)) {
    cout << s << "\n";
  }
  return 0;
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile)
    return 0;

  string s;
  vector<string> db;
  ofstream errfile("err.txt");
  while (getline(inFile, s)) {
    int commaCount = 0;
    s = removeSpaces(s);
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ',') {
        commaCount++;
      }
      if (commaCount == 2 && s[i] == ',') {
        string diena{s[i + 1], s[i + 2]};
        // cout<<diena;
        if (diena != "Pr" && diena != "Ot" && diena != "Tr" && diena != "Ce" &&
            diena != "Pt" && diena != "St" && diena != "Sv") {
          commaCount = 5;
        }
      }
    }
    if (commaCount == 4) {
      db.push_back(s);
    } else if (commaCount != 0) {
      errfile << s << endl;
    }

    // cout << s << endl;
  }
  char choice;

  // cout<<choice;
  while (choice != 'e') {
    cin >> choice;
    switch (choice) {
    case 'a':
      pieturas(db);
      break;
    case 'b':
      ned_dienas(db);
      break;
    case 'c':
      biletes(db);
      break;
    case 'd':
      error();
      break;
    case 'e':
      break;
    default:
      break;
    }
  }

  //   for(const string& i:db){
  //     cout<< i <<"\n";
  //   }
}