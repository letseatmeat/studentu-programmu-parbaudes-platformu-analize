#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <set>
#include <string>
#include <vector>
using namespace std;

void outputErr() {
  ifstream errFile;
  errFile.open("err.txt");
  if (!errFile) return 0;
  string err;
  while (errFile >> err)
  {
  	cout << err << endl;
   }
  errFile.close();
}
void outputAllRoutesByPoints(vector<vector<string>> trips, string start, string end) {
  for(int i = 0; i < trips.size(); i++){
    if(trips[i][0]==start && trips[i][1]==end){
      for(auto data:trips[i]){
        cout << data << " ";
      }
      cout << endl;
    }
}
}
void outputWorkDayRoutes(vector<vector<string>> trips,string day) {
  for(int i = 0; i < trips.size(); i++){
    if(trips[i][2]==day){
      for(auto data:trips[i]){
        cout << data << " ";
      }
      cout << endl;
    }
  }
}
void outputRoutesPerPrice(float price, vector<vector<string>> trips) {
  for(int i = 0; i < trips.size(); i++){
    float tripPrice = stof(trips[i][4]);
    if(tripPrice<=price){
      for(auto data:trips[i]){
        cout << data << " ";
      }
      cout << endl;
    }
  }
}
bool checkTime(string time){

  if(time.length()!=5){
    return false;
  }
  if(time[2]!=':'){
    return false;
  }
  if(time[0]>'2'||time[0]<'0'){
    return false;
  }
  if(time[1]<'0'||time[1]>'9'){
    return false;
  }
  if(time[3]>'6'||time[3]<'0'){
    return false;
  }
  if(time[4]<'0'||time[4]>'9'){
    return false;
  }
  return true;
  
}
int main() {
  // const and vars
  set<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  vector<vector<string>> trips;
  // read file and prep data
  ifstream inFile;
  ofstream outFile;
  inFile.open("db.csv");
  outFile.open("err.txt");
  if (!inFile)
    return 0;
  if (!outFile)
    return 0;

  string line;
  string data;
  char query;
  // while (inFile >> s)
  // {
  // 	cout << s << endl;
  //  }
  while (getline(inFile, line)) {
    vector<string> subdata;
    bool err = false;
    data = line;
    data.erase(remove_if(data.begin(), data.end(), ::isspace), data.end());
    //cout << line << endl;
    //cout << data << endl;
    
    stringstream s(data);
    string info;
    string day;
    while (getline(s, info, ',')) {
        subdata.push_back(info);
    }
    // check if all fields filled
    if(subdata.size()!=5){
      err = true;
    }
    //check if valid time field  
    else if(!checkTime(subdata[3])){
      err = true;
    }
    //check if day in  predefined set
    else if(!days.count(subdata[2])){
       err = true;
    }
    else{
      try{
        stof(subdata[4]);
      }
      catch(...){
        err = true;
      }
    }
    
    if(err){
      outFile << line << endl;
    }
    else{
      //cout << data << endl;
      trips.push_back(subdata);
    }
  }
  inFile.close();
  outFile.close();
  // ops
  while (1) {
    cin >> query;
    switch (query) {
    case 'a': {
      string start;
      string end;
      cin >> start;
      cin >> end;
      cout << "result:" << endl;
      outputAllRoutesByPoints(trips,start,end);
      break;
    }
    case 'b': {
      string day;
      cin >> day;
      cout << "result:" << endl;
      outputWorkDayRoutes(trips,day);
      break;
    }
    case 'c': {
      float price;
      while(1){
        cin >> price;
        if (cin.good() && cin.peek() == '\n') {
          price = price;
          break;
        } else {
          cout << "incorrect input, please input again" << endl;
          cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
      }
      cout << "result:" << endl;
      outputRoutesPerPrice(price,trips);
      break;
    }
    case 'd': {
      cout << "result:" << endl;
      outputErr();
      break;
    }
    case 'e': {
      return 0;
      break;
    }
    default: {
      break;
    }
    }
  }
}