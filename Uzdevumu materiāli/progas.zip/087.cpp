

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

// Function to remove spaces from a string
void removeSpaces(string &str) {
  str.erase(remove(str.begin(), str.end(), ' '), str.end());
}

// Define a struct to represent each record
struct Record {
  string fromCity;
  string toCity;
  string day;
  string departureTime;
  double cost;
};

int main() {
  // Open the CSV file
  ifstream inputFile("db.csv");
  if (!inputFile.is_open()) {
    cerr << "Error opening the file." << endl;
    return 1;
  }

  // Create a vector to store records
  vector<Record> records;

  // Create a file for errors
  ofstream errorFile("err.txt");
  if (!errorFile.is_open()) {
    cerr << "Error creating the error file." << endl;
    return 1;
  }

  // Read the file line by line
  string line;
  while (getline(inputFile, line)) {

    // Remove spaces from the line
    removeSpaces(line);

    // Skip empty lines
    if (line.empty()) {
      continue;
    }

    istringstream iss(line);
    Record record;

    // Read each comma-separated value into the struct
    getline(iss, record.fromCity, ',');
    getline(iss, record.toCity, ',');
    getline(iss, record.day, ',');
    getline(iss, record.departureTime, ',');
    iss >> record.cost;

    // Check if the number of fields is correct
    if (iss.fail() || iss.peek() != EOF) {
      // If there was an error in the fields, write the line to the error file
      errorFile << line << endl;

    } else {
      // Add the record to the vector
      records.push_back(record);
    }
  }
  // Close the files
  inputFile.close();
  errorFile.close();

  // User interaction
  char choice;
  do {
    cin >> choice;

    ifstream errFileReader("err.txt");
    string startStop, endStop, day;
    double price;

    switch (choice) {
    case 'd':
      // Print the content of err.txt
      cout << "result: " << endl;
      if (errFileReader.is_open()) {
        string errLine;
        while (getline(errFileReader, errLine)) {
          cout << errLine << endl;
        }
        errFileReader.close();
      } else {
        cerr << "Error opening err.txt for reading." << endl;
      }
      break;

    case 'a':
      // Enter start and destination
      // cout << "Enter starting stop: ";
      cin >> startStop;
      // cout << "Enter ending stop: ";
      cin >> endStop;

      cout << "result: " << endl;
      for (const auto &record : records) {
        if (startStop == record.fromCity && endStop == record.toCity) {
          cout << record.fromCity << " " << record.toCity << " " << record.day
               << " " << record.departureTime << fixed << setprecision(2) << " "
               << record.cost << endl;
        }
      }
      break;

    case 'b':
      // Enter day
      // cout << "Enter day: ";
      cin >> day;

      cout << "result: " << endl;
      for (const auto &record : records) {
        if (day == record.day) {
          cout << record.fromCity << " " << record.toCity << " " << record.day
               << " " << record.departureTime << fixed << setprecision(2) << " "
               << record.cost << endl;
        }
      }
      break;

    case 'c':
      // Enter price
      // cout << "Enter price: ";
      cin >> price;

      cout << "result: " << endl;
      for (const auto &record : records) {
        if (price >= record.cost) {
          cout << record.fromCity << " " << record.toCity << " " << record.day
               << " " << record.departureTime << fixed << setprecision(2) << " "
               << record.cost << endl;
        }
      }
      break;

    case 'e':
      // Exit the program
      break;
    }
  } while (choice != 'e');

  return 0;
}
