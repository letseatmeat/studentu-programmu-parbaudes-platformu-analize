
#include <fstream>
#include <iomanip>
#include <limits>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct BusRoute {
  string startStop, finalStop, dayOfWeek, time;
  double ticketPrice;
};

string trim(const string &str) {
  size_t f = str.find_first_not_of(" \t\r\n");
  size_t l = str.find_last_not_of(" \t\r\n");
  return (f == string::npos || l == string::npos)
             ? ""
             : str.substr(f, (l - f + 1));
}

bool parseLine(const string &line, BusRoute &route, string &errorLine) {
  istringstream ss(trim(line));
  string start, stop, day, time;
  double price;

  vector<string> fields;
  string field;
  while (getline(ss, field, ',')) {
    fields.push_back(trim(field));
  }

  if (fields.size() != 5 || fields[3].size() != 5 ||
      fields[4].find_first_of(".") == string::npos) {
    errorLine = line; 
    return false;
  }

  start = fields[0];
  stop = fields[1];
  day = fields[2];
  time = fields[3];
  price = stod(fields[4]);
  if (start.empty() || stop.empty() || day.empty() || time.empty()) {
    errorLine = line; 
    return false;
  }

  route.startStop = start;
  route.finalStop = stop;
  route.dayOfWeek = day;
  route.time = time;
  route.ticketPrice = price;

  return true;
}

void display(const vector<BusRoute> &routes) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    cout << route.startStop << " " << route.finalStop << " " << route.dayOfWeek
         << " " << route.time << " " << fixed << setprecision(2)
         << route.ticketPrice << endl;
  }
}

void commandA(const vector<BusRoute> &allRoutes) {
  string startStop, finalStop;
  getline(cin, startStop);
  getline(cin, finalStop);

  vector<BusRoute> result;
  for (const auto &route : allRoutes) {
    if (route.startStop == startStop && route.finalStop == finalStop) {
      result.push_back(route);
    }
  }

    display(result);
}

void commandB(const vector<BusRoute> &allRoutes) {
  string day;
  getline(cin, day);

  vector<BusRoute> result;
  for (const auto &route : allRoutes) {
    if (route.dayOfWeek == day) {
      result.push_back(route);
    }
  }
    display(result);
}

void commandC(const vector<BusRoute> &allRoutes) {
  double maxPrice;
  cin >> maxPrice;
  cin.ignore();

  vector<BusRoute> result;
  for (const auto &route : allRoutes) {
    if (route.ticketPrice <= maxPrice) {
      result.push_back(route);
    }
  }

    display(result);
}

void commandD() {
  cout << "result:" << endl;
  ifstream errFile("err.txt");
  if (errFile.is_open()) {
    string line;
    while (getline(errFile, line)) {
      cout << line << endl;
    }
    errFile.close();
  } else {
    cout << "Error" << endl;
  }
}

int main() {
  vector<string> allLines;
  vector<BusRoute> allRoutes;

  ifstream inputFile("db.csv");
  ofstream errFile("err.txt", ios::app);

  if (inputFile.is_open()) {
    string line;
    while (getline(inputFile, line)) {
      allLines.push_back(line);
      if (!line.empty() && line.find_first_not_of(" \t\r\n") != string::npos) {
        BusRoute route;
        if (parseLine(line, route, line)) {
          allRoutes.push_back(route);
        } else {
            for (auto it = line.begin(); it != line.end(); ++it) {
                if (*it != '\r') {
                  errFile << *it;
                }
            }
            errFile << '\n';
        }
      }
    }
    inputFile.close();
  } else {
    cout << "Error" << endl;
    return 1;
  }

  char command;
  do {
    cin >> command;
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    switch (command) {
    case 'a':
      commandA(allRoutes);
      break;
    case 'b':
      commandB(allRoutes);
      break;
    case 'c':
      commandC(allRoutes);
      break;
    case 'd':
      commandD();
      break;
    case 'e':
      errFile.close();
      return 0;
    default:
      cout << "Invalid" << endl;
    }
  } while (true);
}