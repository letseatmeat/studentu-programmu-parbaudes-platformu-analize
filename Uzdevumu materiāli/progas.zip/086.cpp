#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct BusRoute {
    string startStop;
    string endStop;
    string weekday;
    string time;
    double ticketPrice;
};

bool isValidTimeFormat(const string& time) {
  if (time.size() != 5)
    return false;
  if (time[2] != ':')
    return false;

  int hours = stoi(time.substr(0, 2));
  int minutes = stoi(time.substr(3, 2));

  return hours >=0 && hours <= 23 && minutes >= 0 && minutes <= 59;
}

bool isValidWeekday(const string& weekday){
  vector<string> validWeekdays = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return find(validWeekdays.begin(), validWeekdays.end(), weekday) != validWeekdays.end();
}

vector<string> splitString(const string& input, char delimiter) {
  vector<string> result;
  stringstream ss(input);
  string token;
  while (getline(ss, token, delimiter)) {
    result.push_back(token);
  }
  return result;
}

bool parseBusRoute(const string& line, BusRoute& route){
  vector<string> tokens = splitString(line, ',');
  if (tokens.size() != 5)
    return false;

  route.startStop = tokens[0];
  route.endStop = tokens[1];
  route.weekday = tokens[2];
  route.time = tokens[3];

  if (!isValidTimeFormat(route.time) || !isValidWeekday(route.weekday))
    return false;
  
  try { 
    route.ticketPrice = stod(tokens[4]);
  } catch (const exception& e) {
    return false;
  }
  return true;
}
bool compareByStartStop(const BusRoute& a, const BusRoute& b) {
  return a.startStop < b.startStop;
}
bool compareByTime(const BusRoute& a, const BusRoute& b) {
  return a.time < b.time;
}
void printBusRoutes(const vector<BusRoute>& routes) {
  for (const auto& route : routes) {
  cout << route.startStop << " " << route.endStop << " " << route.weekday << " "
     << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
    }
  }
int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

  if (!inFile) {
    cerr << "Error opening file db.csv" << endl;
    return 1;
  }
  if (!errFile) {
    cerr << "Error opening file err.txt" << endl;
    return 1;
  }

  vector<BusRoute> busRoutes;

  string line;
  while (getline(inFile, line)) {
    if (line.empty() || line.find_first_not_of(" \t") == string::npos)
      continue;

    BusRoute route;
    if (parseBusRoute(line, route)){
      busRoutes.push_back(route);
    } else {
      errFile << line << endl;
  }
  
}

char choice;
  while (true) {
    cout << "Enter command (a, b, c, d, e): ";
    string input;
    getline(cin, input);

    if (input.empty() || input.size() > 1 || (input[0] != 'a' && input[0] != 'b' && input[0] != 'c' && input[0] != 'd' && input[0] != 'e')) {
      cout << "Invalid command. Please enter a, b, c, d or e." << endl;
      continue;
    }

    choice = input[0];
    
    if (choice == 'e'){
      break;
    }
    cout << "result:" << endl;

    switch (choice) {
      case 'a':
       printBusRoutes(busRoutes);
       
      break;
    case 'b':
      sort(busRoutes.begin(), busRoutes.end(), compareByStartStop); 
        printBusRoutes(busRoutes);
      
      break;
  case 'c':
  for (const auto& route : busRoutes) {
    if (route.ticketPrice < 10.00) {
       printBusRoutes({route});
    }
  }
  break;
    case 'd':
   if (!busRoutes.empty()){
     auto earliestRoute = min_element(busRoutes.begin(), busRoutes.end(), compareByTime);
     printBusRoutes({*earliestRoute});
     
   } else {
     cout << "No bus routes available." << endl;
   }
  break;
  default:
      cout << "Invalid command. Please enter a, b, c, d or e." << endl;
    }
  }
    return 0;
}