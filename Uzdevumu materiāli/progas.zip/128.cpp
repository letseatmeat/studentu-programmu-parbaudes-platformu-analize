#include <fstream>
#include <iostream>
#include <string>


using namespace std;

void a();
void b();
void c();
void d();

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  char cmd;
  ofstream error("err.txt");
  ofstream outFile("temp.txt");
  string s;
  string e;

  while (std::getline(inFile, s)) {
    int z = 0;
    if (s.length() == 0) {
      continue;
    }
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ' ') {
        for (int j = i; j < s.length(); j++) {
          s[j] = s[j + 1];
        }
        i = 0;
        s.pop_back();
      }
    }
    if (s[0] == ' ')
      s.erase(s.begin());
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ',') {
        z++;
      }
    }
    if (z != 4) {
      error << s << endl;
      continue;
    }

    string mas[5];
    int x = 0;
    int count = 0;
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == ',') {
        mas[count] = s.substr(x, i - x);
        x = i + 1;
        count++;
        if (count == 4) {
          mas[count] = s.substr(x, 5);
        }
      }
    }
    bool b = true;
    for (char str : mas[0]) {
      if (!isalpha(str)) {
        b = false;
        break;
      }
    }
    for (char str : mas[1]) {
      if (!isalpha(str)) {
        b = false;
        break;
      }
    }
    if (mas[2] != "Pr" && mas[2] != "Ot" && mas[2] != "Tr" && mas[2] != "Ce" &&
        mas[2] != "Pt") {
      b = false;
    }
    if (mas[3].length() == 5) {
      try {
        int h = stoi(mas[3].substr(0, 2));
        int m = stoi(mas[3].substr(3, 2));

        if (mas[3][2] != ':')
          b = false;
        if (h > 23 || h < 0)
          b = false;
        if (m > 59 || m < 0)
          b = false;

      } catch (const std::invalid_argument &e) {
        b = false;
      }
    }
    try {
      double d = stod(mas[4]);
      if (d < 0)
        b = false;

    } catch (const std::invalid_argument &e) {
      b = false;
    }

    if (b) {
      outFile << s << endl;
    } else {
      error << s << endl;
      continue;
    }
  }
  outFile.close();
  error.close();

  while (cmd != 'e') {

    std::cout << "";
    std::cin >> cmd;
    switch (cmd) {
    case 'a':
      a();
      break;

    case 'b':
      b();
      break;

    case 'c':
      c();
      break;

    case 'd':
      d();
      break;

    case 'e':
      remove("temp.txt");
      remove("err.txt");
      return 0;

    default:
      std::cout << "wrong command" << std::endl;
      continue;
    }
  }
}
void a() {
  ifstream inFile;
  inFile.open("temp.txt");
  string s;

  std::string start;
  cin >> start;
  std::string end;
  cin >> end;
  std::string mas[2];

  int x = 0;
  int count;
  cout << "result:" << endl;
  while (std::getline(inFile, s)) {
    count = 0;
    x = 0;
    for (int i = 0; i < s.length(); i++) {
      if (count == 2)
        break;
      if (s[i] == ',') {
        mas[count++] = s.substr(x, i - x);
        x = i + 1;
      }
    }
    if (start == mas[0] && end == mas[1]) {
      std::string z = s;
      for (int i = 0; i < z.length(); i++) {
        if (s[i] == ',') {
          z[i] = ' ';
        }
      }
      cout << z << endl;
    }
  }
}

void b() {
  ifstream inFile;
  inFile.open("temp.txt");
  string s;

  std::string dday;
  cin >> dday;

  int x = 0;
  int count;
  string day;
  cout << "result:" << endl;
  while (std::getline(inFile, s)) {
    count = 0;
    x = 0;
    for (int i = 0; i < s.length(); i++) {
      if (count == 3)
        break;
      if (s[i] == ',') {
        day = s.substr(x, i - x);
        x = i + 1;
        count++;
      }
    }
    if (dday == day) {
      std::string z = s;
      for (int i = 0; i < z.length(); i++) {
        if (s[i] == ',') {
          z[i] = ' ';
        }
      }
      cout << z << endl;
    }
  }
}
void c() {
  ifstream inFile;
  inFile.open("temp.txt");
  string s;
  double pprice;
  cin >> pprice;
  double price;

  cout << "result:" << endl;
  while (std::getline(inFile, s)) {
    for (int i = s.length() - 1; i >= 0; i--) {
      if (s[i] == ',') {
        price = stod(s.substr(i + 1, s.length() - i - 1));
        break;
      }
    }
    if (price <= pprice) {
      std::string z = s;
      for (int i = 0; i < z.length(); i++) {
        if (s[i] == ',') {
          z[i] = ' ';
        }
      }
      cout << z << endl;
    }
  }
}
void d() {
  ifstream inFile;
  inFile.open("err.txt");
  string s;
  cout << "result:" << endl;
  while (std::getline(inFile, s)) {
    cout << s << endl;
  }
}
