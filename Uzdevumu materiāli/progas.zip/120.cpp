#include <array>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <regex>
#include <string>
#include <vector>
#include <unordered_map>

class Field {
   public:
    Field(){};
    bool validate();
    std::string string();

   protected:
    std::regex pattern;
    std::string data;
};

class City : public Field {
   public:
    City(){};
    City(std::string s);
};

class WeekDay : public Field {
   public:
    WeekDay(){};
    WeekDay(std::string s);
};

class Time : public Field {
   public:
    Time(){};
    Time(std::string s);
};

class Cost : public Field {
   public:
    Cost(){};
    Cost(std::string s);
    float number();
};

class Record {
   public:
    Record(){};
    bool validate();
    std::string string();

    // Setters
    void set_src_city(std::string);
    void set_dst_city(std::string);
    void set_week_day(std::string);
    void set_time(std::string);
    void set_cost(std::string);

    // Getters
    City* get_src_city();
    City* get_dst_city();
    WeekDay* get_week_day();
    Time* get_time();
    Cost* get_cost();

   private:
    std::unordered_map<std::string, Field> fields;
};

class DB {
   public:
    std::vector<Record> records;

    DB();
    std::vector<std::string> read_err_file();
    std::vector<std::string> filter_by_week_day(std::string);
    std::vector<std::string> filter_by_src_dst(std::string, std::string);
    std::vector<std::string> filter_by_cost(float);

   private:
    std::string db_filename;
    std::string err_filename;

    void load_db(std::string);
    bool parse_record(std::string, Record *);
    void write_err_file(std::string);
};

std::string trim(std::string s) {
    const std::string whitespaces = " \t\n\r\f\v";

    size_t first_non_space = s.find_first_not_of(whitespaces);
    s.erase(0, first_non_space);

    size_t last_non_space = s.find_last_not_of(whitespaces);
    s.erase(last_non_space + 1);

    return s;
}

bool Field::validate() { return std::regex_match(this->data, this->pattern); }

std::string Field::string() { return this->data; }

City::City(std::string data) {
    this->pattern = "^[A-Z][a-zA-Z]*$";
    this->data = data;
}

WeekDay::WeekDay(std::string data) {
    this->pattern = "^Pr$|^Ot$|^Tr$|^Ce$|^Pt$|^St$|^Sv$";
    this->data = data;
}

Time::Time(std::string data) {
    this->pattern = "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$";
    this->data = data;
}

Cost::Cost(std::string data) {
    this->pattern = "^[0-9]+(\\.[0-9]{2})?$";
    this->data = data;
}

float Cost::number() { return std::stof(this->data); }

void Record::set_src_city(std::string data) { this->fields["src_city"] = City(data); }
void Record::set_dst_city(std::string data) { this->fields["dst_city"] = City(data); }
void Record::set_week_day(std::string data) { this->fields["week_day"] = WeekDay(data); }
void Record::set_time(std::string data) { this->fields["time"] = Time(data); }
void Record::set_cost(std::string data) { this->fields["cost"] = Cost(data); }

City* Record::get_src_city() { return static_cast<City*>(&this->fields["src_city"]); }
City* Record::get_dst_city() { return static_cast<City*>(&this->fields["dst_city"]); }
WeekDay* Record::get_week_day() { return static_cast<WeekDay*>(&this->fields["week_day"]); }
Time* Record::get_time() { return static_cast<Time*>(&this->fields["time"]); }
Cost* Record::get_cost() { return static_cast<Cost*>(&this->fields["cost"]); }

bool Record::validate() {
    for (auto& [_, value] : this->fields) {
        if (!value.validate()) {
            return false;
        }
    }
    return true;
}

std::string Record::string() {
    std::string str;
    std::vector<std::string> f({"src_city", "dst_city", "week_day", "time", "cost"});
    for (int i = 0; i < this->fields.size(); i++) {
        if (i == 4) {
            str += this->fields[f[i]].string();
        } else {
            str += this->fields[f[i]].string() + " ";
        }
    }
    return str;
}

DB::DB() {
    this->db_filename = "db.csv";
    this->err_filename = "err.txt";
    std::remove(this->err_filename.c_str());
    this->load_db(this->db_filename);
}

void DB::load_db(std::string filename) {
    std::ifstream infile(filename);
    for (std::string line; std::getline(infile, line);) {
        // Skip empty lines
        if (trim(line).size() == 0) {
            continue;
        }

        Record r;
        if (!this->parse_record(line, &r)) {
            this->write_err_file(line);
            continue;
        }
        this->records.push_back(r);
    }
    infile.close();
}

bool DB::parse_record(std::string s, Record* r) {
    size_t pos = 0;
    std::string token;
    std::vector<std::string> fields;

    while ((pos = s.find(",")) != std::string::npos) {
        token = s.substr(0, pos);
        fields.push_back(token);
        s.erase(0, pos + 1);
    }
    fields.push_back(s);

    if (fields.size() != 5) {
        return false;
    }

    // Remove whitespaces in each field
    for (int i = 0; i < fields.size(); i++) {
        std::string f = fields[i];
        fields[i] = trim(f);
    }

    r->set_src_city(fields[0]);
    r->set_dst_city(fields[1]);
    r->set_week_day(fields[2]);
    r->set_time(fields[3]);
    r->set_cost(fields[4]);

    return r->validate();
}

void DB::write_err_file(std::string data) {
    std::ofstream outfile(this->err_filename, std::ios::app);
    outfile << data << std::endl;
    outfile.close();
}

std::vector<std::string> DB::read_err_file() {
    std::vector<std::string> errors;
    std::ifstream infile(this->err_filename);
    for (std::string line; std::getline(infile, line);) {
        errors.push_back(line);
    }
    infile.close();
    return errors;
}

std::vector<std::string> DB::filter_by_week_day(std::string wd) {
    std::vector<std::string> filtered;
    for (auto&& r : this->records) {
        std::string r_wd = r.get_week_day()->string();
        if (r_wd == wd) {
            filtered.push_back(r.string());
        }
    }
    return filtered;
}

std::vector<std::string> DB::filter_by_src_dst(std::string src, std::string dst) {
    std::vector<std::string> filtered;
    for (auto&& r : this->records) {
        std::string r_src = r.get_src_city()->string();
        std::string r_dst = r.get_dst_city()->string();
        if (r_src == src && r_dst == dst) {
            filtered.push_back(r.string());
        }
    }
    return filtered;
}

std::vector<std::string> DB::filter_by_cost(float cost) {
    std::vector<std::string> filtered;
    for (auto&& r : this->records) {
        float r_cost = r.get_cost()->number();
        if (r_cost <= cost) {
            filtered.push_back(r.string());
        }
    }
    return filtered;
}

void print_result(std::vector<std::string> data) {
    std::cout << "result:" << std::endl;
    for (auto&& line : data) {
        std::cout << line << std::endl;
    }
}

void handle_src_dst_filter(DB *db) {
    std::string src;
    std::string dst;
    std::cin >> src;
    std::cin >> dst;
    std::vector<std::string> data = db->filter_by_src_dst(src, dst);
    print_result(data);
}

void handle_week_day_filter(DB *db) {
    std::string wd;
    std::cin >> wd;
    std::vector<std::string> data = db->filter_by_week_day(wd);
    print_result(data);
}

void handle_cost_filter(DB *db) {
    float cost;
    std::cin >> cost;
    std::vector<std::string> data = db->filter_by_cost(cost);
    print_result(data);
}

int main() {
    DB db = DB();

    while (true) {
        std::string command;
        std::cin >> command;
        switch (command.front()) {
            case 'a':
                handle_src_dst_filter(&db);
                break;
            case 'b':
                handle_week_day_filter(&db);
                break;
            case 'c':
                handle_cost_filter(&db);
                break;
            case 'd':
                print_result(db.read_err_file());
                break;
            case 'e':
                exit(0);
            default:
                std::cout << "Invalid command" << std::endl;
        }
    }
}
