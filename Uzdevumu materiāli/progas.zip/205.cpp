
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Struktura {
  string start;
  string end;
  string diena;
  string laiks;
  double cena;

  bool operator==(const Struktura &i) const {
    return start == i.start && end == i.end && diena == i.diena &&
           laiks == i.laiks && cena == i.cena;
  }
};

string del(const string &str) {
  size_t f = str.find_first_not_of(' ');
  if (string::npos == f) {
    return str;
  }
  size_t l = str.find_last_not_of(' ');
  return str.substr(f, (l - f + 1));
}

vector<string> split(const string &str, char d) {
  vector<string> tokens;
  string t;
  istringstream ts(str);
  while (getline(ts, t, d)) {
    tokens.push_back(t);
  }
  return tokens;
}

bool dienaValid(const string &diena) {
  static const vector<string> parbaude = {"Pr", "Ot", "Tr", "Ce",
                                          "Pt", "St", "Sv"};
  return find(parbaude.begin(), parbaude.end(), diena) != parbaude.end();
}

bool laiksValid(const string &laiks) {
  if (laiks.size() != 5) {
    return false;
  }

  if (!isdigit(laiks[0]) || !isdigit(laiks[1]) || laiks[2] != ':' ||
      !isdigit(laiks[3]) || !isdigit(laiks[4])) {
    return false;
  }

  int stundas = stoi(laiks.substr(0, 2));
  int minutes = stoi(laiks.substr(3, 2));

  return stundas >= 0 && stundas <= 23 && minutes >= 0 && minutes <= 59;
}

vector<Struktura> readCelsh(string filename) {
  vector<Struktura> routes;
  ifstream file(filename);
  ofstream errfile("err.txt");
  string line;
  while (getline(file, line)) {
    if (line.empty() || all_of(line.begin(), line.end(), ::isspace)) {
      continue;
    }

    vector<string> values = split(line, ',');
    if (values.size() != 5) {
      errfile << line << endl;
      continue;
    }

    Struktura r;
    try {
      r.start = del(values.at(0));
      r.end = del(values.at(1));
      r.diena = del(values.at(2));
      r.laiks = del(values.at(3));
      r.cena = stod(del(values.at(4)));

      if (!dienaValid(r.diena) || !laiksValid(r.laiks)) {
        errfile << line << endl;
        continue;
      }

      routes.push_back(r);
    } catch (const exception &e) {
      errfile << line << endl;
    }
  }
  file.close();
  errfile.close();
  return routes;
}

void printCelsh(const vector<Struktura> &routes) {
  for (const auto &r : routes) {
    cout << r.start << " " << r.end << " " << r.diena << " " << r.laiks << " "
         << fixed << setprecision(2) << r.cena << endl;
  }
}

int main() {
  vector<Struktura> routes = readCelsh("db.csv");
  char input;
  while (cin >> input && input != 'e') {
    cout << "result:" << endl;
    switch (input) {
    case 'a': {
      string start, end;
      cin >> start >> end;
      vector<Struktura> result;
      for (const auto &r : routes) {
        if (r.start == start && r.end == end) {
          result.push_back(r);
        }
      }
      printCelsh(result);
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      vector<Struktura> result;
      for (const auto &r : routes) {
        if (r.diena == diena) {
          result.push_back(r);
        }
      }
      printCelsh(result);
      break;
    }
    case 'c': {
      double max_cena;
      cin >> max_cena;
      vector<Struktura> result;
      for (const auto &r : routes) {
        if (r.cena <= max_cena) {
          if (find(result.begin(), result.end(), r) == result.end()) {
            result.push_back(r);
          }
        }
      }
      printCelsh(result);
      break;
    }
    case 'd': {
      ifstream inFile;
      inFile.open("err.txt");
      string c;
      cout << "result:" << endl;

      while (inFile >> c) {
        cout << c << endl;
      }
      break;
    }
    }
  }
  return 0;
}
