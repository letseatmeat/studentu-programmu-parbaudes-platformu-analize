

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm> 
#include <cctype> 
#include <iomanip>

//using namespace std;

// Operatoru inicializacija
struct Marshruts
{
    std::string sakumP;
    std::string galaP;
    std::string nedelD;
    std::string laiks;
    double biletC;
};

//Srtuktura, lai nodzestu tukšas rindas un liekus atstarpes simbolus
std::string trim(const std::string& str) 
{
    auto sakumP = str.begin();
    while (sakumP != str.end() && std::isspace(*sakumP)) 
    {
        sakumP++;
    }

    auto galaP = str.end();
    do 
    {
        galaP--;
    } while (std::distance(sakumP, galaP) > 0 && std::isspace(*galaP));

    return std::string(sakumP, galaP + 1); // atgriež vertibu bez atstarpem
}

// Funkcija, kas parbauda vai diena ir pareiza un atgriež true/false
bool isDayCorrect(const std::string& nedelD) 
{
    const std::vector<std::string> days = { "Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv" };
    return std::find(days.begin(), days.end(), nedelD) != days.end();
}

// Funkcija, kas parbauda vai laika korektibu
bool isTimeCorrect(const std::string& laiks) 
{
    if (laiks.length() != 5 || laiks[2] != ':') return false; // formats sastav no 5 simboliem, preteja gadijuma neder
    int hour = std::stoi(laiks.substr(0, 2));
    int minute = std::stoi(laiks.substr(3, 2));
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59; //vertibu parbaude
}


// Funkcija faila "db.csv" lasišanai, ja viss ir korekti, tad vertibas tiek pierakstiti vektorā
std::vector<Marshruts> readFile(const std::string& fileName, std::vector<std::string>& errors)
{
    std::vector<Marshruts> marshruts;
    std::ifstream file(fileName);
    std::string line;

    while (std::getline(file, line)) 
    {
        std::istringstream iss(line);
        std::vector<std::string> index;
        std::string ind;

        while (std::getline(iss, ind, ',')) 
        {
            index.push_back(trim(ind));
        }

        //Ja nav kļudas pierakstā, tad atgriež rindas informaciju
        if (index.size() == 5 && isDayCorrect(index[2]) && isTimeCorrect(index[3]))
        {
            try 
            {
                Marshruts route = { index[0], index[1], index[2], index[3], std::stod(index[4]) };
                marshruts.push_back(route);
            }
            catch (const std::exception&) 
            {
              //Ja linija nav tukša, tad pierakstam errors
              std::string trimmedLine = trim(line);
              if (!trimmedLine.empty()) 
              {
                errors.push_back(trimmedLine);
              }
            }
        }
        else 
        {
          //Ja linija nav tukša, tad pierakstam errors
          std::string trimmedLine = trim(line);
          if (!trimmedLine.empty())
            {
              errors.push_back(trimmedLine);
            }
        }
    }
    return  marshruts;
}

// Funkcija, lai failā "err.txt" ierakstit kļudainus datus
void writeErr(const std::vector<std::string>& errors) {
    // Atverot failu, ieprekšejie faili tiek nodzesti un jauna informacija tiek pierakstita
    std::ofstream errorFile("err.txt", std::ios::out | std::ios::trunc); 
    //Ja rodas kļuda atverot failu
    if (!errorFile.is_open()) 
    {
        std::cerr << "Error. Neizdevas atvert err.txt failu. " << std::endl;
        return;
    }
    //Kamer vektors ar kļudam nav tukš ierakstas vertibas
    for (const auto& error : errors) 
    {
        //Ignorejam tukšas rindas un tos failā nepierakstam
        if (!error.empty()) 
        {
            errorFile << error << '\n'; 
        }
    }
}

// Funkcija "d" komandai
void KomandaD(const std::vector<std::string>& errors) 
{
    //Palaižam funkciju, kas pieraksta kļudas failā
    writeErr(errors); 

    //Izvadam to visu ekranā
    std::cout << "result:\n";
    for (const auto& error : errors)
    {
        if (!error.empty()) 
        {
            std::cout << error << std::endl;
        }
    }
}

// Funkcija "a" komandai
void KomandaA(const std::vector<Marshruts>& marshruts) {
    std::string sakumP, galaP;
    std::cout << "Ievadiet sakuma pieturu: ";
    std::cin >> sakumP;
    std::cout << "Ievadiet gala pieturu: ";
    std::cin >> galaP;

    std::cout << "result:\n";
    for (const auto& route : marshruts) {
        if (route.sakumP == sakumP && route.galaP == galaP) {
            std::cout << route.sakumP << " " << route.galaP << " " << route.nedelD << " "
                << route.laiks << " " << std::fixed << std::setprecision(2) << route.biletC << std::endl;
        }
    }
}

// Funkcija "b" komandai
void KomandaB(const std::vector<Marshruts>& marshruts) {
    std::string nedelD;
    std::cout << "Ierakstiet nedeļas dienu (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
    std::cin >> nedelD;

    std::cout << "result:\n";
    for (const auto& route : marshruts) {
        if (route.nedelD == nedelD) {
            std::cout << route.sakumP << " " << route.galaP << " " << route.nedelD << " "
                << route.laiks << " " << std::fixed << std::setprecision(2) << route.biletC << std::endl;
        }
    }
}


// Funkcija "c" komandai
void KomandaC(const std::vector<Marshruts>& marshruts) {
    double maxCena;
    std::cout << "Ierakstiet maksimalo biļetes cenu: ";
    std::cin >> maxCena;

    std::cout << "result:\n";
    for (const auto& route : marshruts)
    {
        if (route.biletC <= maxCena) 
        {
            std::cout << route.sakumP << " " << route.galaP << " " << route.nedelD << " "
                << route.laiks << " " << std::fixed << std::setprecision(2) << route.biletC << std::endl;
        }
    }
}

int main() {
    std::vector<std::string> errors; // Vektors priekš kļudam
    std::vector<Marshruts> marshruts = readFile("db.csv", errors);


    char choice;
    while (true) 
    {
        std::cout << "Izveleties komandu (a, b, c, d, i, e): ";
        std::cin >> choice;

        switch (choice) 
        {
        case 'a': 
        {
            KomandaA(marshruts);
            break;
        }
        case 'b': 
        {
            KomandaB(marshruts);
            break;
        }
        case 'c': 
        {
            KomandaC(marshruts);
            break;
        }
        case 'd': 
        {
            KomandaD(errors);
            break;
        }
        //Informacija par autoru(pievienoju papildus komandu)
        case 'i': 
        {
            std::cout << "Alīna Krasnova 6.gr. Apl.nr:171RMC069 \n";
            break;
        }
        case 'e':
            return 0;
        default:
            std::cout << "Kļuda. Lūdzu meginiet velreiz." << std::endl;
        }
    }

    return 0;
}
 //  ifstream inFile;
 //  inFile.open("db.csv");

	// if (!inFile) return 0;
  
 //  string s; 
	// while (inFile >> s)
	// {
	// 	cout << s << endl;
 //  }
  
