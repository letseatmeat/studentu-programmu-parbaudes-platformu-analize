  #include <iostream>
  #include <fstream>
  #include <vector>
  #include <iomanip>

  using namespace std;

  struct Dati {
    string Pilseta1;
    string Pilseta2;
    string Diena;
    string Laiks;
    double Cena;
  };

  vector<string> split(const string& str, char delimiter) {
      vector<string> tokens;
      
      istringstream tokenStream(str);
      for (string token;getline(tokenStream, token, delimiter);) {
          tokens.push_back(token);
      }
      return tokens;
  }

  string trim(const string& str) {
      size_t first = str.find_first_not_of(' ');
      if (string::npos == first) {
          return str;
      }
      size_t last = str.find_last_not_of(' ');
      return str.substr(first, (last - first + 1));
  }

  int main() {
    ifstream inFile;
    inFile.open("db.csv");
    if (!inFile) return 0;

    vector<Dati> data;
    Dati temp;
    ofstream errorFile("err.txt");

    
    for (string line;getline(inFile, line);) {

      vector<string> fields = split(line, ',');
      if (fields.size() != 5 || !(istringstream(fields[4]) >> temp.Cena)|| trim(fields[2]).size() != 2) {
          errorFile << line << endl;
        
      }else {
        temp.Pilseta1 = trim(fields[0]);
        temp.Pilseta2 = trim(fields[1]);
        temp.Diena = trim(fields[2]);
        temp.Laiks = trim(fields[3]);
        data.push_back(temp);
      }
    }
    inFile.close();
    errorFile.close();
    


  for (char ch; cin >> ch && ch != 'e'; ) {

    switch (ch) {
      // Ja lietotājs ievada "a":
      case 'a': {
        string pietura1, pietura2;
        cin >> pietura1 >> pietura2;
        cout << "result:" << endl;
        for (const auto& entry : data) {
          if (entry.Pilseta1 == pietura1 && entry.Pilseta2 == pietura2) {
            cout << entry.Pilseta1 << " " << entry.Pilseta2 << " " << entry.Diena << " " << entry.Laiks << " " << fixed << setprecision(2) << entry.Cena << endl;
          }
        }
        break;
      }
      //Ja lietotājs ievada "b":
      case 'b': {
        string day;
        cin >> day;
        cout << "result:" << endl;
        for (const auto& entry : data) {
          if (entry.Diena == day) {
            cout << entry.Pilseta1 << " " << entry.Pilseta2 << " " << entry.Diena << " " << entry.Laiks << " " << fixed << setprecision(2) << entry.Cena << endl;
          }
        }
        break;
      }
      //Ja lietotājs ievada "c":
      case 'c': {
        double price;
        cin >> price;
        cout << "result:" << endl;
        for (const auto& entry : data) {
          if (entry.Cena <= price) {
            cout << entry.Pilseta1 << " " << entry.Pilseta2 << " " << entry.Diena << " " << entry.Laiks << " " << fixed << setprecision(2) << entry.Cena << endl;
          }
        }
        break;
      }
      //Ja lietotājs ievada "d":
      case 'd': {
        cout << "result:" << endl;
        ifstream errFile("err.txt");
        if (errFile.is_open()) {
          for(string line; getline(errFile, line);) {
                if (!line.empty() && line.find_first_not_of(" \t\n\r") != string::npos) {
                  cout << line << endl;
            }
          }
          errFile.close();
        }
        break;
      }
      //Ja lietotājs ievada "e":
      case 'e':
        break;
      //Ja lietotājs ievadīja nepareizo burtu:
      default:
        cout << "Unknown command." << endl;
    }
  }
}
