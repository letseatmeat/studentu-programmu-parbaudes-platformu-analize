

/* Es nezinu kāpēc man trīs testi met kļūdu, kaut arī izvade ir tāda pati kuru gaida, 
  man vienkārši vairāk nav spēku ar šo cīnīties :(    */

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

struct AutobusaMarsruts {
  string sakums;
  string beigas;
  string diena;
  string laiks;
  string cena;
};

bool parseMarsruts(const string &line, AutobusaMarsruts &marsruts) {

  stringstream ss(line);
  vector<string> fields;
  string field;
  while (getline(ss, field, ',')) {
      size_t start = field.find_first_not_of(" ");
      size_t end = field.find_last_not_of(" ");
      field = (start == string::npos || end == string::npos)
                  ? ""
                  : field.substr(start, end - start + 1);
      fields.push_back(field);
  }

  if (fields.size() != 5) {
    return false;
  }

  marsruts.sakums = fields[0];
  marsruts.beigas = fields[1];
  marsruts.diena = fields[2];

  if (fields[3].size() != 5 || fields[3][2] != ':' || !isdigit(fields[3][0]) ||
      !isdigit(fields[3][1]) || !isdigit(fields[3][3]) ||
      !isdigit(fields[3][4])) {
    return false;
  }
  marsruts.laiks = fields[3];

  try {
    marsruts.cena = fields[4];

  } catch (const invalid_argument &e) {
    return false;
  }

  return true;
}

void printMarsruts(const AutobusaMarsruts &marsruts) {
  cout << marsruts.sakums << " " << marsruts.beigas << " " << marsruts.diena << " "<< marsruts.laiks << " " << marsruts.cena << endl;
}

int main() {
  ifstream inFile("db.csv");
  ofstream errFile("err.txt");

  if (!inFile || !errFile) {
    cerr << "error" << endl;
    return 1;
  }

  string line;
  vector<AutobusaMarsruts> marsruti;

  while (getline(inFile, line)) {
      AutobusaMarsruts marsruts;
      if (parseMarsruts(line, marsruts)) {
          marsruti.push_back(marsruts);
      } else {
        if (line.empty()) {
            continue;
        }
          errFile << line << endl;
      }
  }

  while (true) {
    char choice;
    cin >> choice;
    switch (choice) {
    case 'a': {
      string sakums, gala;
      cin >> sakums;
      cin >> gala;
      cout << "result:" << endl;
      for (const auto &marsruts : marsruti) {
        if (marsruts.sakums == sakums && marsruts.beigas == gala) {
          printMarsruts(marsruts);
        }
      }
      break;
    }
    case 'b': {
      string nedelasDiena;
      cin >> nedelasDiena;
      cout << "result:" << endl;
      for (const auto &marsruts : marsruti) {
        if (marsruts.diena == nedelasDiena) {
          printMarsruts(marsruts);
        }
      }
      break;
    }
    case 'c': {
      double maxCena;
      cin >> maxCena;
      cout << "result:" << endl;
      for (const auto &marsruts : marsruti) {
        double cena = stod(marsruts.cena);
        if (cena <= maxCena) {
          printMarsruts(marsruts);
        }
      }
      break;
    }
    case 'd': {
      ifstream errFile("err.txt");
      string content;
      cout << "result:" << endl;
      while (getline(errFile, content)) {
        cout << content << endl;
      }
      errFile.close();
      break;
    }
    case 'e':
      return 0;
    default:
      cout << "error" << endl;
    }
  }
  return 0;
}