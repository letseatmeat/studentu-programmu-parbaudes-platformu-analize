
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip> 
#include <algorithm> 
using namespace std;

struct Route {
    string startStop;
    string endStop;
    string day;
    string time;
    double ticketPrice;
};
string trim(const string& s) {
    size_t start = s.find_first_not_of(" \t\n\r\f\v");
    size_t end = s.find_last_not_of(" \t\n\r\f\v");
    if (start != string::npos && end != string::npos) {
        return s.substr(start, end - start + 1);
    }
    return "";
}
vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    stringstream ss(s);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(trim(token));
    }
    return tokens;
}
bool parseRoute(const string& line, Route& route) {
  vector<string> fields = split(line, ',');

  if (fields.size() != 5) {
      return false;
  }
  route.startStop = trim(fields[0]);
  route.endStop = trim(fields[1]);
  route.day = trim(fields[2]);
  route.time = trim(fields[3]);
  try {
      size_t pos;
      route.ticketPrice = stod(fields[4], &pos);

      if (pos != fields[4].size()) {
          throw invalid_argument("");
      }
  } catch (const invalid_argument& e) {
      return false;
  }
  return true;
}
int main() {
    ifstream inFile("db.csv");
    ofstream errFile("err.txt");
  
    if (!inFile || !errFile) {
        cerr << "Error opening files." << endl;
        return 1;
    }
    vector<Route> routes;
    string line;
    while (getline(inFile, line)) {
        line = trim(line); 
        if (line.empty()) {
            continue; 
        }
        Route route;
        if (parseRoute(line, route)) {
            routes.push_back(route);
        } else {
            errFile << line << endl;
        }
    }
    char choice;
    while (true) {
        cout << "";
        cin >> choice;

        switch (choice) {
            case 'a': {
                string start, end;
                cout << "";
                cin >> start >> end;
                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.startStop == start && route.endStop == end) {
                        cout << route.startStop << " " << route.endStop << " " << route.day << " "
                             << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                    }
                }
                break;
            }
            case 'b': {
                string day;
                cout << "";
                cin >> day;
                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.day == day) {
                        cout << route.startStop << " " << route.endStop << " " << route.day << " "
                             << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cout << "";
                cin >> maxPrice;
                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.ticketPrice <= maxPrice) {
                        cout << route.startStop << " " << route.endStop << " " << route.day << " "
                             << route.time << " " << fixed << setprecision(2) << route.ticketPrice << endl;
                    }
                }
                break;
            }
            case 'd': {
                cout << "result:" << endl;
                ifstream errFileRead("err.txt");
                if (errFileRead) {
                    string errLine;
                    while (getline(errFileRead, errLine)) {
                        cout << errLine << endl;
                    }
                } else {
                    cout << "Error opening err.txt." << endl;
                }
                break;
            }
            case 'e':
                cout << "" << endl;
                return 0;
            default:
                cout << "Invalid choice." << endl;
        }
    }
    return 0;
}