#include <algorithm>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

bool checkIfNumber(string s) {
  int count = 1;
  for (int c : s) {
    if (c >= 48 && c <= 57) { // Parbauda pec ASCII vertibas

      if (s.length() == count) { // Atgriež true, ja visi simboli ir skaitļi
        return true;
      }
      count++;
    }
  }
  return false;
}

bool errValidation(int c, string sub) {
  if ((c == 1 || c == 2) && checkIfNumber(sub)) {  // Pārbauda pirmo un otro vērtību, no ieraksta. Ja skaitlis, tad false
    return false;
  } else if (c == 3 && (checkIfNumber(sub) || !(sub.length() == 2))) {  // Pārbauda trešo vērtību no ieraksta. Ja vērtība ir skaitlis vai string garums nav 2, tad false
    return false;
  } else if (c == 4 && (!(sub.at(2) == ':') || !(sub.length() == 5) ||  // Pārbauda ceturto vērtību no ieraksta. Ja simbolu virknē neietilpst ":" vai garums nav 5, tad false. Vēl arī pārbauda vai simboli ir skaitļi
                        !checkIfNumber(sub.substr(0, 2)) ||
                        !checkIfNumber(sub.substr(3, 2)))) {
    return false;
  } else if (c == 5 && (!(sub.at(sub.length() - 3) == '.') || // Pārbauda piekto vērtību. Ja simbolu virknē  "." nav pirms diviem pēdējiem cipariem, tad false, kā arī pārbauda vai simboli ir skaitļi
                        !checkIfNumber(sub.substr(0, sub.length() - 3)) || !checkIfNumber(sub.substr(sub.length() - 2, 2)))) {
    
    return false;
  }
  return true;
}

string removeSpaces(string s) {
  string newStr = "";
  for (int i = 0; i < s.length(); i++) {
    if (s[i] != ' ') {
      newStr += s[i];
    }
  }
  return newStr;
}

int main() {

  map<int, vector<string>> routes;  // Mapes atslēga ir ieraksta numurs pēc kārtas, vektorā glabā ieraksta vērtības 
  ifstream inFile;
  ifstream errFile;
  inFile.open("db.csv");
  ofstream errors("err.txt");
  string errortxt = "";

  if (!inFile)
    return 0;

  int valueInLineCount = 1; // Parāda pie kuras vērtības līnijā pašlaik esam
  string s;
  int k = 0;
  while (getline(inFile, s)) {
    s = removeSpaces(s);
    
    for (int i = 0, j = 0; i <= s.length(); i++) {
      if (s.length() == 1 || s.length() == 0) {  // Ignorējam tukšas rindas
        k--;
        break;
      }

      if (s[i] == ',' || i == s.length()) {  // Meklē komatu vai ieraksta beigas, katru vērtību izlaiž cauri validācijai, ja ir error rinda, tad pieliek to pie err.txt, 
        if (errValidation(valueInLineCount, s.substr(j, i - j)) == false) {
          errortxt = errortxt + s + "\n";
          routes[k].clear();
          k--;
          break;
        }
        
        if (valueInLineCount != 5 && i == s.length()) {
          routes[k].clear();
          k--;
          errortxt = errortxt + s + "\n";
        }

        routes[k].push_back(s.substr(j, i - j));  // Pievieno vērtību vektoram, tikai tad, ja iziet validāciju
        j = i + 1;
        valueInLineCount++;
      }
    }

    valueInLineCount = 1;
    k++;
  }
  errors << errortxt;
  errors.close();

  bool stop = false;
  char inp;
  string start, end, day;
  double price;
  
  while (stop == false) {
    cin >> inp;

    switch (inp) {

    case 'a':
      cin >> start;
      cin >> end;
      cout << "result:" << endl;
      for (int i = 0; i < routes.size(); i++) {
        if (routes[i][0] == start && routes[i][1] == end) {
          cout << routes[i][0] << " " << routes[i][1] << " " << routes[i][2]
               << " " << routes[i][3] << " " << routes[i][4] << endl;
        }
      }
      break;

    case 'b': 
      cin >> day;
      cout << "result:" << endl;
      for (int i = 0; i < routes.size(); i++) {
        if (routes[i][2] == day) {
          cout << routes[i][0] << " " << routes[i][1] << " " << routes[i][2]
               << " " << routes[i][3] << " " << routes[i][4] << endl;
        }
      }
      break;

    case 'c':
      cin >> price;
      cout << "result:" << endl;
      for (int i = 0; i < routes.size(); i++) { 
        if (stod(routes[i][4]) <= price) {
          cout << routes[i][0] << " " << routes[i][1] << " " << routes[i][2]
               << " " << routes[i][3] << " " << routes[i][4] << endl;
        }
      }
      break;

    case 'd':
      cout << "result:" << endl;
      errFile.open("err.txt");
      while (getline(errFile, s)) {
        cout << s << endl;
      }
      break;
      
    case 'e':
      stop = true;
      break;
    }
  }
}
