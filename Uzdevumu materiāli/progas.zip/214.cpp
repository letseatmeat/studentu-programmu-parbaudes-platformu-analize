#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct busaVirz {
  std::string pirmaPietura;
  std::string pedejaPietura;
  std::string nedDiena;
  std::string laiks;
  double bilesuCena;
};

bool derDiena(const std::string &day) {
  static const std::vector<std::string> derDienas = {"Pr", "Ot", "Tr", "Ce",
                                                     "Pt", "St", "Sv"};
  return std::find(derDienas.begin(), derDienas.end(), day) != derDienas.end();
}

void rinduEdit(const std::string &rinda, std::vector<busaVirz> &virzieni,
               std::ofstream &kluduFails) {
  std::istringstream ss(rinda);
  std::string sakums, beigas, diena, laiki, papildus;
  double cena;

  if (std::getline(ss, sakums, ',') && std::getline(ss, beigas, ',') &&
      std::getline(ss, diena, ',') && std::getline(ss, laiki, ',') &&
      ss >> cena) {

    sakums.erase(std::remove_if(sakums.begin(), sakums.end(), ::isspace),
                 sakums.end());
    beigas.erase(std::remove_if(beigas.begin(), beigas.end(), ::isspace),
                 beigas.end());
    diena.erase(std::remove_if(diena.begin(), diena.end(), ::isspace),
                diena.end());

    std::getline(ss, papildus);
    ss >> std::ws; // Consume any trailing whitespace after reading 'cena'
    std::getline(ss, papildus);
    papildus.erase(std::remove_if(papildus.begin(), papildus.end(), ::isspace),
                   papildus.end());

    if (papildus.empty() && derDiena(diena)) {
      virzieni.push_back({sakums, beigas, diena, laiki, cena});
    } else {
      kluduFails << rinda << std::endl;
    }
  } else {
    kluduFails << rinda << std::endl;
  }
}

void marsrutuIzvad(const std::vector<busaVirz> &marsruti) {
  std::cout << "result:" << std::endl;
  for (const auto &marsruts : marsruti) {
    std::ostringstream output;
    output << marsruts.pirmaPietura << " " << marsruts.pedejaPietura << " "
           << marsruts.nedDiena << " " << marsruts.laiks << " " << std::fixed
           << std::setprecision(2) << marsruts.bilesuCena;

    std::string outputString = output.str();
    bool spaceFlag = false;

    outputString.erase(std::remove_if(outputString.begin(), outputString.end(),
                                      [&](char c) {
                                        if (std::isspace(c)) {
                                          if (!spaceFlag) {
                                            spaceFlag = true;
                                            return false;
                                          }
                                          return true;
                                        }
                                        spaceFlag = false;
                                        return false;
                                      }),
                       outputString.end());
    std::cout << outputString << std::endl;
  }
}

int main() {
  std::ifstream marsFile("db.csv");
  std::ofstream kluduFile("err.txt");

  std::vector<busaVirz> virzien;

  if (!marsFile.is_open()) {
    std::cerr << "Error!" << std::endl;
    return 1;
  }

  std::string linija;
  while (std::getline(marsFile, linija)) {
    rinduEdit(linija, virzien, kluduFile);
  }

  marsFile.close();
  kluduFile.close();

  char izvele;
  while (true) {
    std::cin >> izvele;

    if (izvele == 'e') {
      break;
    }

    switch (izvele) {
    case 'a': {
      std::string sak, end;
      std::cin >> sak >> end;
      std::vector<busaVirz> matchingRoutes;
      for (const auto &route : virzien) {
        if (route.pirmaPietura == sak && route.pedejaPietura == end) {
          matchingRoutes.push_back(route);
        }
      }
      marsrutuIzvad(matchingRoutes);
      break;
    }
    case 'b': {
      std::string day;
      std::cin >> day;
      std::vector<busaVirz> sakritosi;
      for (const auto &route : virzien) {
        if (route.nedDiena == day) {
          sakritosi.push_back(route);
        }
      }
      marsrutuIzvad(sakritosi);
      break;
    }
    case 'c': {
      double maxCena;
      std::cin >> maxCena;
      std::vector<busaVirz> sakritosi;
      for (const auto &route : virzien) {
        if (route.bilesuCena <= maxCena) {
          sakritosi.push_back(route);
        }
      }
      marsrutuIzvad(sakritosi);
      break;
    }
    case 'd': {
      std::ifstream errFile("err.txt");
      if (!errFile.is_open()) {
        std::cerr << "Error!" << std::endl;
        return 1;
      }
      std::cout << "result:" << std::endl;
      while (std::getline(errFile, linija)) {
        linija.erase(std::remove_if(linija.begin(), linija.end(), ::isspace),
                     linija.end());
        if (!linija.empty()) {
          std::cout << linija << std::endl;
        }
      }
      errFile.close();
      break;
    }
    default:
      std::cout << "Try again!" << std::endl;
    }
  }

  return 0;
}