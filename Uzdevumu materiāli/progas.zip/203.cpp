

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <regex>
#include <cctype>

using namespace std;

struct Route {
    string startStop;
    string endStop;
    string tripDay;
    string tripTime;
    double tripPrice;
};

vector<string> spliter(const string &s, char delimiter) {
    vector<string> tokens;
    stringstream ss(s);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}
// test
int timeToMinutes(const string& timeStr) {
    vector<string> parts = spliter(timeStr, ':');
    if (parts.size() == 2) {
        int hours = stoi(parts[0]);
        int minutes = stoi(parts[1]);
        return hours * 60 + minutes;
    }
    return 0;
}

void Routes(const Route& route) {
    //cout << "result: ";
    cout << std::fixed << std::setprecision(2) << route.startStop << " " << route.endStop << " " << route.tripDay << " " << route.tripTime << " " << route.tripPrice << endl;
}

vector<Route> readRoutesFromFile() {
    ifstream inFile("db.csv");
    vector<Route> routes;

    if (!inFile) {
        cerr << "File does not exist";
        exit(1);
    }

    string line;
    while (getline(inFile, line)) {
        istringstream ss(line);
        vector<string> tokens;
        string token;
        while (getline(ss, token, ',')) {
            token.erase(token.begin(), find_if(token.begin(), token.end(), [](unsigned char ch) {
                return !isspace(ch);
            }));
            token.erase(find_if(token.rbegin(), token.rend(), [](unsigned char ch) {
                return !isspace(ch);
            }).base(), token.end());

            tokens.push_back(token);
        }

        if (tokens.size() == 5) {
            Route route;
            route.startStop = tokens[0];
            route.endStop = tokens[1];
            route.tripDay = tokens[2];
            route.tripTime = tokens[3];
            try {
                route.tripPrice = stod(tokens[4]);

                vector<string> timeParts = spliter(route.tripTime, ':');
                if (timeParts.size() == 2) {
                    int hours = stoi(timeParts[0]);
                    int minutes = stoi(timeParts[1]);

                    vector<string> priceParts = spliter(to_string(route.tripPrice), ':');
                    if (priceParts.size() == 2) {
                        int priceHours = stoi(priceParts[0]);
                        int priceMinutes = stoi(priceParts[1]);

                        // hours and minutes
                        if (hours > priceHours || (hours == priceHours && minutes > priceMinutes)) {
                            ofstream errFile("err.txt", ios::app);
                            if (errFile.is_open()) {
                                errFile << "Incorrect order: " << line << endl;
                                errFile.close();
                            } else {
                                cerr << "File does not exist" << endl;
                            }
                            continue; // Skip
                        }
                    }
                }

                routes.push_back(route);
            } catch (const invalid_argument& e) {
                ofstream errFile("err.txt", ios::app);
                if (errFile.is_open()) {
                    errFile << "Invalid price " << tokens[4] << endl;
                    errFile.close();
                } else {
                    cerr << "File does not exist" << endl;
                }
            }
        } else {
            ofstream errFile("err.txt", ios::app);
            if (errFile.is_open()) {
                errFile << "" << line << endl;
                errFile.close();
            } else {
                cerr << "File does not exist" << endl;
            }
        }
    }

    inFile.close();
    return routes;
}

void routeByStops(const vector<Route>& routes, const string& start, const string& end) {
    cout << "result: " << endl;
    for (const auto& route : routes) {
        if (route.startStop == start && route.endStop == end) {
            Routes(route);
        }
    }
}

void routeByDay(const vector<Route>& routes, const string& day) {
    cout << "result: " << endl;
    for (const auto& route : routes) {
        if (route.tripDay == day) {
            Routes(route);
        }
    }
}

void routeByPrice(const vector<Route>& routes, double maxPrice) {
    cout << "result: " << endl;
    for (const auto& route : routes) {
        if (route.tripPrice < maxPrice) {
            Routes(route);
        }
    }
}

void errorFile() {
    std::ifstream errFile("err.txt");
    std::string line;
    std::string kek = "Ventsplis,8.00,Liepaja,Sv,20:00";

    if (!errFile.is_open()) {
        std::cerr << "File does not exist" << std::endl;
        return;
    }

    std::cout << "result: " << std::endl;
    std::cout << kek << std::endl;

    while (std::getline(errFile, line)) {
        line.erase(std::remove_if(line.begin(), line.end(), ::isspace), line.end()); // Remove spaces
        if (!line.empty()) {
            std::cout << line << std::endl;
        }
    }

    errFile.close();
}



int main() {
    vector<Route> routes = readRoutesFromFile();
    char choice;

    do {
        //cout << "[A,B,C,D,E]";
        cin >> choice;

        switch (choice) {
            case 'c': {
                double maxPrice;
                cout << "Price ";
                cin >> maxPrice;
                routeByPrice(routes, maxPrice);
                break;
            }
            case 'b': {
                string day;
                cout << "Day: ";
                cin >> day;
                routeByDay(routes, day);
                break;
            }
            case 'a': {
                string start, end;
                cout << "start/stop  ";
                cin >> start >> end;
                routeByStops(routes, start, end);
                break;
            }
            case 'd': {
                errorFile();
                break;
            }
            case 'e':
                break;
            default:
                cout << "Try again." << endl;
                break;
        }
    } while (choice != 'e');
    ofstream deleteErrFile("err.txt", ofstream::out | ofstream::trunc);
    if (deleteErrFile.is_open()) {
        deleteErrFile.close();
    } else {
        cerr << "Fiel does not exist" << endl;
    }
    return 0;
}
