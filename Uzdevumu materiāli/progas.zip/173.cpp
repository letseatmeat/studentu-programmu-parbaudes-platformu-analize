

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

using namespace std;

void a() {

  string from, to;

  cin >> from;
  cin >> to;
  
  cout << "result:" << endl;

  vector<map<int, string>> data;
  
  ifstream inFile;
  inFile.open("db.csv");

  ofstream outFile;
  outFile.open("err.txt");

  if (!inFile) return;

  string s; 
  while (getline(inFile, s)) {
    
    // ignore empty lines
    if (s.length() < 2) continue;
    
    map<int, string> row;
    int fieldNum = 0;
    string field = "";
    
    for (auto ch : s) {
      if (ch == ' ') continue;
      if (ch != ',') {
        field += ch;
      } else {
        row[fieldNum] = field;
        field = "";
        fieldNum++;
      }
    }
    row[fieldNum] = field;
    field = "";

    //chech field number
    if (fieldNum != 4 ) {
      outFile << s << endl;
      continue;
    }

    //check city name
    if (!isalpha(row[0][0]) or !isalpha(row[1][0])) {
      outFile << s << endl;
      continue;
    }

    // if price is double
    try {
      double price = stod(row[4]);
    } catch (...) {
      outFile << s << endl;
      continue;
    }
    
    data.push_back(row);
  }
  for (auto row : data) {
    if (row[0] == from && row[1] == to) cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;
  }

  inFile.close();
  outFile.close();
}

void b() {

  string day;
  cin >> day;
  
  cout << "result:" << endl;

  vector<map<int, string>> data;

  ifstream inFile;
  inFile.open("db.csv");

  ofstream outFile;
  outFile.open("err.txt");

  if (!inFile) return;

  string s; 
  while (getline(inFile, s)) {

    // ignore empty lines
    if (s.length() < 2) continue;

    map<int, string> row;
    int fieldNum = 0;
    string field = "";

    for (auto ch : s) {
      if (ch == ' ') continue;
      if (ch != ',') {
        field += ch;
      } else {
        row[fieldNum] = field;
        field = "";
        fieldNum++;
      }
    }
    row[fieldNum] = field;
    field = "";

    //chech field number
    if (fieldNum != 4 ) {
      outFile << s << endl;
      continue;
    }

    //check city name
    if (!isalpha(row[0][0]) or !isalpha(row[1][0])) {
      outFile << s << endl;
      continue;
    }

    // if price is double
    try {
      double price = stod(row[4]);
    } catch (...) {
      outFile << s << endl;
      continue;
    }

    data.push_back(row);
  }
  for (auto row : data) {
    if (row[2] == day) cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;

  }

  inFile.close();
  outFile.close();
  
}

void c() {

  double prc;
  cin >> prc;
  
  cout << "result:" << endl;

  vector<map<int, string>> data;

  ifstream inFile;
  inFile.open("db.csv");

  ofstream outFile;
  outFile.open("err.txt");

  if (!inFile) return;

  string s; 
  while (getline(inFile, s)) {

    // ignore empty lines
    if (s.length() < 2) continue;

    map<int, string> row;
    int fieldNum = 0;
    string field = "";

    for (auto ch : s) {
      if (ch == ' ') continue;
      if (ch != ',') {
        field += ch;
      } else {
        row[fieldNum] = field;
        field = "";
        fieldNum++;
      }
    }
    row[fieldNum] = field;
    field = "";

    //chech field number
    if (fieldNum != 4 ) {
      outFile << s << endl;
      continue;
    }

    //check city name
    if (!isalpha(row[0][0]) or !isalpha(row[1][0])) {
      outFile << s << endl;
      continue;
    }

    // if price is double
    try {
      double price = stod(row[4]);
    } catch (...) {
      outFile << s << endl;
      continue;
    }

    data.push_back(row);
  }
  
  for (auto row : data) {
    double price = stod(row[4]);
    if (price <= prc) cout << row[0] << " " << row[1] << " " << row[2] << " " << row[3] << " " << row[4] << endl;
  }

  inFile.close();
  outFile.close();
}

void d() {
  cout << "result:" << endl;

  ifstream inFile;
  inFile.open("db.csv");

  ofstream outFile;
  outFile.open("err.txt");

  if (!inFile) return;

  string s; 
  while (getline(inFile, s)) {

    // ignore empty lines
    if (s.length() < 2) continue;

    map<int, string> row;
    int fieldNum = 0;
    string field = "";

    for (auto ch : s) {
      if (ch == ' ') continue;
      if (ch != ',') {
        field += ch;
      } else {
        row[fieldNum] = field;
        field = "";
        fieldNum++;
      }
    }
    row[fieldNum] = field;
    field = "";

    //chech field number
    if (fieldNum != 4 ) {
      outFile << s << endl;
      continue;
    }

    //check city name
    if (!isalpha(row[0][0]) or !isalpha(row[1][0])) {
      outFile << s << endl;
      continue;
    }

    // if price is double
    try {
      double price = stod(row[4]);
    } catch (...) {
      outFile << s << endl;
      continue;
    }
  }
  
  ifstream errFile;
  errFile.open("err.txt");

  if (!errFile) return;

  s = ""; 
  while (errFile >> s) {
    cout << s << endl;
  }
  
  errFile.close();
  inFile.close();
  outFile.close();
}

int main() {

  while (true) {
    int x = 1;
    
    char cmd;
    cin >> cmd;
    
    switch (cmd) {
      case 'a' : a(); break;
      case 'b' : b(); break;
      case 'c' : c(); break;
      case 'd' : d(); break;
      case 'e' : x = 0; break;
      default : break;
    }

    if (x == 0) break;
  }

} 