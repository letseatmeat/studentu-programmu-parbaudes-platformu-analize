#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>

using namespace std;

int Err(string err){
  ofstream f;
  f.open("err.txt", ios::app);
  f << err<< endl;
  f.close();
  return 0;
}

string Autobus(string cmd,string r){
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) return 0;

  string l,rez;
  int k=4;
  
  while(inFile){
    getline(inFile,l);
    l.erase(std::remove(l.begin(), l.end(), ' '), l.end());
    if(count(l.begin(), l.end(), ',')!=k){
      if(l!="\n"){
        Err(l);
      }
      continue;
    }
    int b=0;
    string arrl[5];
    for(int i=0;i<5;i++){
      arrl[i]=l.substr(0,l.find(","));
      l.erase(0,l.find(",")+1);
      if(i>=3){
        if(!(47<(int)arrl[i].at(0) && 58>(int)arrl[i].at(0))){
          b=1;
        }
      }
    }
    if(b==1){
      Err(arrl[0]+","+arrl[1]+","+arrl[2]+","+arrl[3]+","+arrl[4]);
      continue;
    }
    if(cmd=="a"){
      string s,f;
      s=r.substr(0,r.find(","));
      f=r.substr(r.find(",")+1);
      if(s==arrl[0] && f==arrl[1]){
        rez=rez+arrl[0]+" "+arrl[1]+" "+arrl[2]+" "+arrl[3]+" "+arrl[4]+"\n";
      }
    }
    if(cmd=="b"){
      if(r==arrl[2]){
        rez=rez+arrl[0]+" "+arrl[1]+" "+arrl[2]+" "+arrl[3]+" "+arrl[4]+"\n";
      }
    }
    if(cmd=="c"){
      if(stod(r)>stod(arrl[4])){
        rez=rez+arrl[0]+" "+arrl[1]+" "+arrl[2]+" "+arrl[3]+" "+arrl[4]+"\n";
      }
    }
  }
  return rez;
}

string Kludas(){
  ifstream inFile;
  inFile.open("err.txt");
  if (!inFile) {
    return "";
  }
  string l,rez;
  while(inFile >> l){
    rez=rez+l+"\n";
  }
  return rez;
}

int main() {
  string txt;
  
  cin>>txt;
  
  while(txt != "e") {
    if(txt=="a"){
      string s,f;
      cin>>s;
      cin>>f;
      cout<<"result:"<<endl<<Autobus("a",s+","+f)<<endl;
    }
    if(txt=="b"){
      string r;
      cin>>r;
      cout<<"result:"<<endl<<Autobus("b",r)<<endl;
    }
    if(txt=="c"){
      string r;
      cin>>r;
      cout<<"result:"<<endl<<Autobus("c",r)<<endl;
    }
    if(txt=="d"){
      cout<<"result:"<< endl<<Kludas();
    }


    cin>>txt;
  }
} 