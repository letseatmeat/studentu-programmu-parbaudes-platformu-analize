
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

// Funkcija sadala ievadīto stringu pa norādīto atdalītāja simbolu delim un saglabā atsevišķos stringos elems vektorā.
vector<string> &split(const string &s, char delim, vector<string> &elems) {
    stringstream in(s);
    string item;

    while (getline(in, item, delim)) {
        item.erase(
            remove(item.begin(), item.end(), ' '),
            item.end()); // Noņem atstarpes
        elems.push_back(item);
    }
    return elems;
}

// Pārbauda, vai laika formāts ir pareizs.
string timeValidation(string elem) {
    string second = elem.substr(3, 2);
    string first = elem.substr(0, 2);

    if (elem.length() == 5 && elem[2] == ':' && stoi(first) <= 23 &&
        stoi(second) <= 59) {
        return "True";
    } else {
        return "False";
    }
}

// Pārbauda, vai ievadītais elements atbilst noteiktiem laika formāta kritērijiem.
string priceValidation(string elem) {
    int check = 0;
    for (char c : elem) {
        if (isdigit(c) || c == '.') {
            check++;
        }
    }

    vector<string> parts;
    char delim = '.';
    split(elem, delim, parts);

    if (parts.size() == 2 && parts[1].length() == 2 && check > 0) {
        return "True";
    } else {
        return "False";
    }
}

// Pārbauda, vai rindiņa atbilst visiem nosacījumiem
bool validation(const vector<string> &elements) {
    if (elements.size() == 5) {
        if (elements[2] == "Pr" || elements[2] == "Ot" || elements[2] == "Tr" ||
            elements[2] == "Ce" || elements[2] == "Pt" || elements[2] == "St" ||
            elements[2] == "Sv") {
            if (timeValidation(elements[3]) == "True") {
                if (priceValidation(elements[4]) == "True") {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

// Izvadīt ekrānā visus reisus, kas kursē norādīta maršruta (lietotājs ievada sākuma pieturas un gala pieturas nosaukumus)
void vaicajumsA() {
    ofstream myFile("err.txt");
    vector<string> data;
    bool check;
    string p1, p2;  
    cin >> p1 >> p2;

    ifstream inFile;
    inFile.open("db.csv");
    string s;
    char delim = ',';
    cout << "result: \n";
    while (getline(inFile, s)) {
        split(s, delim, data);
        check = validation(data);
        if (check && data[0] == p1 && data[1] == p2) {
            for (const auto &item : data) {
                cout << item << " ";
            }

            cout << "\n";
        } else if (!check) {
            myFile << s << "\n";
        }
        data.clear();
    }
    myFile.close();
    inFile.close();
}

// Izvadīt ekrānā visus reisus, kas kursē noteiktā nedēļas dienā (lietotājs ievada dienas pazīmējums: Pr, Ot, Tr, Ce, Pt, St, Sv)
void vaicajumsB() {
    ofstream myFile("err.txt");
    vector<string> data;
    bool check;
    char delim = ',';

    string p1;
    cin >> p1;

    ifstream inFile;
    inFile.open("db.csv");
    string s;
    cout << "result: \n";
    while (getline(inFile, s)) {
        split(s, delim, data);
        check = validation(data);
        if (check && data[2] == p1) {
            for (const auto &item : data) {
                cout << item << " ";
            }

            cout << "\n";
        } else if (!check) {
            myFile << s << "\n";
        }
        data.clear();
    }
    myFile.close();
    inFile.close();
}

//Izvada ekrānā visus reisus, kuru biļetes maksa nepārsniedz ievadīto
void vaicajumsC() {
    ofstream myFile("err.txt");
    vector<string> data;
    bool check;
    char delim = ',';

    double p1;
    cin >> p1;

    ifstream inFile;
    inFile.open("db.csv");
    string s;
    cout << "result: \n";
    while (getline(inFile, s)) {
        split(s, delim, data);
        check = validation(data);
        if (check && stod(data[4]) < p1) {
            for (const auto &item : data) {
                cout << item << " ";
            }

            cout << "\n";
        } else if (!check) {
            myFile << s << "\n";
        }
        data.clear();
    }
    myFile.close();
    inFile.close();
}

//Pārtraukt programmas izpildi
void vaicajumsE() {
    cout << "\n";
    exit(0);
}

int main() {
    while (true) {
        string cmd;
        cin >> cmd;

        if (cmd == "a") {
            vaicajumsA();
        } else if (cmd == "b") {
          vaicajumsB();
        } else if (cmd == "c") {
          vaicajumsC();
        } else if (cmd == "d") {
            ifstream inFile;
            inFile.open("err.txt");
            string s;
            cout << "result: \n";

            while (getline(inFile, s)) {
                if (!s.empty() && s[0] != '\x0D') {
                    cout << s << " \n";
                }
            }
            inFile.close();
        } else if (cmd == "e") {
            vaicajumsE();
        }
    }

    return 0;
}