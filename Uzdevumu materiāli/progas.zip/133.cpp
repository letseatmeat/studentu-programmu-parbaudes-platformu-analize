

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <utility>s
#include <vector>

using namespace std;

class route {
public:
  route(string &from, string &to, string &day, string &t, double p)
      : from(std::move(from)), to(to), day(day), time(t), cost(p) {}
  void printRoute() const {
    cout << setprecision(2) << fixed;
    cout << from << " " << to << " " << day << " " << time << " " << cost
         << endl;
  }

  string from;
  string to;
  string day;
  string time;
  double cost;
};

bool checkData(const std::string &input) {
  std::regex pattern(
      "([a-zA-Z]+),([a-zA-Z]+),([a-zA-Z]{2}),(\\d{2}:\\d{2}),(\\d+\\.\\d+)");
  return std::regex_match(input, pattern);
}

void a(string from, string to, vector<route> routes) {
  cout << "result:" << endl;
  for (auto x : routes) {
    if (x.from == from and x.to == to)
      x.printRoute();
  }
}
void b(string day, vector<route> routes) {
  cout << "result:" << endl;
  for (auto x : routes) {
    if (x.day == day)
      x.printRoute();
  }
}
void c(double p, vector<route> routes) {
  cout << "result:" << endl;
  for (auto x : routes) {
    if (x.cost <= p)
      x.printRoute();
  }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;

  string s;
  vector<string> error;
  vector<route> routes;

  ofstream errorFile("error.txt");

  while (getline(inFile, s)) {
    s.erase(remove_if(s.begin(), s.end(), ::isspace), s.end());
    if (!s.empty()) {
      if (checkData(s)) {
        istringstream stream(s);
        string from, to, day, time;
        double cost;

        getline(stream, from, ',');
        getline(stream, to, ',');
        getline(stream, day, ',');
        getline(stream, time, ',');
        stream >> cost;

        routes.push_back(route(from, to, day, time, cost));
      } else if (errorFile.is_open())
        errorFile << s << endl;
    }
  }

  char input;
  
  while (input != 'e') {
    cin >> input;
    switch (input) {
    case 'a': {
      string from, to;
      cin >> from >> to;
      a(from, to, routes);
      break;
    }
    case 'b': {
      string day;
      cin >> day;
      b(day, routes);
      break;
    }
    case 'c': {
      double p;
      cin >> p;
      c(p, routes);
      break;
    }
    case 'd': {
      cout << "result:" << endl;
      ifstream inFile;
      inFile.open("error.txt");
      if (!inFile)
        return 0;
      while (getline(inFile, s)) {
        cout << s << endl;
      }
    }
    }
  }
}