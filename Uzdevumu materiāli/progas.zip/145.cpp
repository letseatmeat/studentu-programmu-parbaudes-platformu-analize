
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

class route {

  public:
    string firstStop;
    string lastStop;
    string day;
    string time;
    double price;

};


bool hasLetters(string str) {
  for (int i = 0; i < str.size(); i++) {
    if (isalpha(str[i]) || str[i] == ':') return true; 
  }
  return false;
}

int main() {


  ifstream inFile;
  inFile.open("db.csv");

  if (!inFile) return 0;

  // Saskaita rindas (arī kļūdainās);
  string line;
  int count = 0;
  while (getline (inFile, line)) {

    line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
    if (line != "") count++;

  }


  inFile.close();

  // Izveido dinamisko masīvu, kurā glabājas rindas, kuras nav tukšas un kurā nav lieku atstarpju;
  vector <string> arr;
  inFile.open("db.csv");

  if (!inFile) return 0;

  int j = 0;
  while (j < count) {
    while (getline (inFile, line)) {
      line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());
      if (line != "") {

        arr.push_back(line);
        j++;
      }
    }
  }

  inFile.close();

  // Izveido "err.txt" failu un saglabā tajā kļūdainās rindas;
  ofstream error("err.txt");
  for (int i = 0; i < count; i++) {
    string fragm = arr[i].substr(arr[i].size()-3, 2);
    if (hasLetters(fragm)) {
      error << arr[i] << endl;
      arr.erase(arr.begin() + i);
      i--;
      count--;
    }
  }
  error.close();


  // Izveido divdimensiju masīvu, kurā atsevišķi glabājas katrs vārds; 
  string arr2D[count][5];
  for (int row = 0; row < count; row++) {
    istringstream iss(arr[row]);
    string word;
    int col = 0;
    while(getline(iss, word, ',')) {
      arr2D[row][col++] = word;
    }
  }
  

  // Izveido objektu masīvu, kurā katra līnija ir cits objekts;
  route arr_obj[count];

  for (int i = 0; i < count; i++) {
    arr_obj[i].firstStop = arr2D[i][0];
    arr_obj[i].lastStop = arr2D[i][1];
    arr_obj[i].day = arr2D[i][2];
    arr_obj[i].time = arr2D[i][3];
    arr_obj[i].price = stod(arr2D[i][4]);
  }


  
// Lietotāja ievadītās komandas;
  char cmd;
  while (true) {
    cin >> cmd;
    if (cmd == 'a') {
      string start, end;
      cin >> start;
      cin >> end;
      cout << "result:" << endl;
      for (int i = 0; i < count; i++) { 
        if (arr_obj[i].firstStop == start && arr_obj[i].lastStop == end) {
          cout << arr_obj[i].firstStop << " " << arr_obj[i].lastStop << " " << arr_obj[i].day << " " << arr_obj[i].time << " " << setprecision(2) << fixed << arr_obj[i].price << endl;
        }
      }
      
    } else if (cmd == 'b') {
      string day;
      cin >> day;
      cout << "result:" << endl;
      for (int i = 0; i < count; i++) {
        if (arr_obj[i].day == day) {
          cout << arr_obj[i].firstStop << " " << arr_obj[i].lastStop << " " << arr_obj[i].day << " " << arr_obj[i].time << " " << setprecision(2) << fixed << arr_obj[i].price << endl;
        }
      }
      
    } else if (cmd == 'c') {
      double price = 0;
      cin >> price;
      cout << "result:" << endl;
      for (int i = 0; i < count; i++) {
        if (arr_obj[i].price <= price) {
          cout << arr_obj[i].firstStop << " " << arr_obj[i].lastStop << " " << arr_obj[i].day << " " << arr_obj[i].time << " " << setprecision(2) << fixed << arr_obj[i].price << endl;
        }
      }

    } else if (cmd == 'd') {
      ifstream File;
      File.open("err.txt");
      cout << "result:" << endl;
      while (getline (File, line)) {
        cout << line << endl;
      }
      File.close();

    } else if (cmd == 'e') break;
    
    else cout << "error" << endl;
  }
}
