
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>
#include <stdio.h>
#include <ctype.h>

using namespace std;

struct RouteInfo{
  string start;
  string end;
  string day;
  string time;
  string price;
};

string trim(const string& str){
  auto strStart = str.begin();
  auto strEnd = str.end();
  while (isspace(*strStart) && strStart != strEnd) {
        strStart++;
  }
  do {
        strEnd--;
  } while (isspace(*strEnd) && strStart < strEnd);
  return string(strStart, strEnd + 1);
}

bool priceFormatValidation(const string& priceString){
  try {
    stod(priceString);
    return true;
  }
  catch (const invalid_argument& e){
    return false;
  }
}

bool dayFormatValidation(const string& day){
  size_t firstNotSpace = day.find_first_not_of(" \t");
  size_t lastNotSpace = day.find_last_not_of(" \t");
  
  if (firstNotSpace == string::npos || lastNotSpace == string::npos) {
    return false;
  }
  string trimmedDay = day.substr(firstNotSpace, lastNotSpace - firstNotSpace + 1);
  
  if (trimmedDay == "Pr" || trimmedDay == "Ot" || trimmedDay == "Tr" || trimmedDay == "Ce" || trimmedDay == "Pt" || trimmedDay == "St" || trimmedDay == "Sv") {
    return true;
  }
  else {
    return false;
  }
}

bool timeFormatValidation(const string& time){
  size_t colonP = time.find(':');
  if (colonP != string::npos){
    string hoursStr = time.substr(0, colonP);
    string minutesStr = time.substr(colonP+1);

    try {
      int hours = stoi(hoursStr);
      int minutes = stoi(minutesStr);

      if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59){
        return false;
      }
    }
    catch (const invalid_argument& e) {
      return false;
    }
    return true;
  }
  return false;
}

void printRoutes(const vector<RouteInfo>& routes){
  cout << "result:" << endl;
  for(const RouteInfo& route: routes){
    cout << route.start << " " << route.end << " " << route.day << " " << route.time << " " << route.price << endl;
  }
}

int main() {
  ifstream inFile;
  inFile.open("db.csv");

	if (!inFile) return 0;

  ofstream errorFile("err.txt", ios::trunc);
  errorFile.close();
  
  string s;
  vector<RouteInfo> routes;
	while (getline(inFile, s)){
    
    if (s.size() == 1){ 
      continue;
    }
    
    int commaCount = 0;
    for (char c: s){
      if (c == ','){
        commaCount++;
      }
    }

    if (commaCount != 4) {
      ofstream errorFile("err.txt", ios::app);
      errorFile << s << endl;
      continue;
    }
    
    istringstream iss(s);
    string start, end, day, time, priceString;

    if(getline(iss, start, ',') && getline(iss, end, ',') && getline(iss, day, ',') && getline(iss, time, ',') && getline(iss, priceString, ',')) {
      
      if (timeFormatValidation(time) && priceFormatValidation(priceString) && dayFormatValidation(day)){
        RouteInfo info;
        info.start = trim(start);
        info.end = trim(end);
        info.day = trim(day);
        info.time = trim(time);
        info.price = trim(priceString);

        routes.push_back(info);
      }
      else {
        ofstream errorFile("err.txt", ios::app);
        errorFile << s << endl;
      }
    }
    else {
      ofstream errorFile("err.txt", ios::app);
      errorFile << s << endl;
    }
  }
  inFile.close();
  

  char choice;
  while (true){
    cin >> choice;
    
    if (choice == 'e'){
      errorFile.close();
      break;
    }

    switch (choice) {
      case 'a': {
        string start, end;
        cin >> start;
        cin >> end;
        vector<RouteInfo> selected;
        for(const RouteInfo& route: routes){
          if(route.start == start && route.end == end){
            selected.push_back(route);
          }
        }
        printRoutes(selected);
        break;
      }
      
      case 'b': {
        string day;
          cin >> day;
          vector<RouteInfo> selected;
          for(const RouteInfo& route: routes){
            if(route.day == day){
              selected.push_back(route);
            }
          }
        printRoutes(selected);
        break;
      }

      case 'c': {
        double price;
        cin >> price;
        vector<RouteInfo> selected;
        for(const RouteInfo& route: routes){
          if(stod(route.price) <= price){
            selected.push_back(route);
          }
        }
        printRoutes(selected);
        break;
      }

      case 'd': {
        ifstream errorFile("err.txt");
        string s;
        cout << "result:" << endl;
        while(getline(errorFile, s)){ 
          cout << s << endl;
        }
        errorFile.close();
        break;
      }

      default:
      cout << "error" << endl;
    }  
  }
  return 0;
}
