
#include <iostream>
#include <fstream>
#include <regex>
#include <vector>
#include <algorithm>

using namespace std;

bool is_alpha(const string &str) {
    return all_of(str.begin(), str.end(), [](char c) { return isalpha(c); });
}

int main() {
    ifstream ievadesFails;
    ievadesFails.open("db.csv");
    ofstream kļūduFails("err.txt");
    vector<string> dienas = {"Pr","Ot","Tr","Ce","Pt","St","Sv"};

    if (!ievadesFails) return 0;

    string rinda, apvienotaRinda;

    while (ievadesFails >> rinda) {
        regex jaunāsRindasRe("\n+");

        auto rezultāts = regex_replace(rinda, jaunāsRindasRe, " ");

        if (rinda[0] == ',') {
            apvienotaRinda.append(rinda);
        } else {
            apvienotaRinda.append(" ");
            apvienotaRinda.append(rinda);
        }
    }

    ievadesFails.close();

    for (int i = 1; i < apvienotaRinda.length(); ++i) {
        if ((apvienotaRinda[i - 1] == ',') && apvienotaRinda[i] == ' ') {
            apvienotaRinda.erase(i, 1);
        }
    }

    apvienotaRinda.erase(0, 1);

    vector<string> ieraksti;

    string rindasDaļa;

    for (int i = 0; i < apvienotaRinda.length(); ++i) {
        if (apvienotaRinda[i] == ' ') {
            ieraksti.push_back(rindasDaļa);
            rindasDaļa = "";
        } else {
            rindasDaļa = rindasDaļa + apvienotaRinda[i];

            if (i == apvienotaRinda.length() - 1) {
                ieraksti.push_back(rindasDaļa);
                rindasDaļa = "";
            }
        }
    }

    vector<vector<string>> pareizieIeraksti;

    for (auto ieraksts : ieraksti) {
        vector<string> parveidot;

        string daļa;

        for (int i = 0; i < ieraksts.length(); ++i) {
            if (ieraksts[i] == ',') {
                parveidot.push_back(daļa);
                daļa = "";
            } else {
                daļa = daļa + ieraksts[i];

                if (i == ieraksts.length() - 1) {
                    parveidot.push_back(daļa);
                    daļa = "";
                }
            }
        }

        if (parveidot.size() != 5) {
            kļūduFails << ieraksts << endl;
            continue;
        }

        if (!is_alpha(parveidot[0]) || !is_alpha(parveidot[1])) {
            kļūduFails << ieraksts << endl;
            continue;
        }

        if (!(find(dienas.begin(), dienas.end(), parveidot[2]) != dienas.end())) {
            kļūduFails << ieraksts << endl;
            continue;
        }

        const regex raksts("^(?:[01]?[0-9]|2[0-3]):[0-5]?[0-9]""(?::[0-5]?[0-9])?$");

        if (!regex_match(parveidot[3], raksts)) {
            kļūduFails << ieraksts << endl;
            continue;
        }

        const regex skaitļaRegex("^[-+]?([0-9]*\\.[0-9]+|[0-9]+)$");

        if (!regex_match(parveidot[4], skaitļaRegex)) {
            kļūduFails << ieraksts << endl;
            continue;
        }

        pareizieIeraksti.push_back(parveidot);
    }

    char burts;
    double cena;
    string nedēļasDiena, sākums, galapunkts;

    do {
        cin.clear();
        cin >> burts;

        switch (burts) {
            case 'a':
                cout << "result: " << endl;
                cin >> sākums;
                cin >> galapunkts;

                for (auto pareizais_ieraksts : pareizieIeraksti) {
                    if (pareizais_ieraksts[0] == sākums) {
                        if (pareizais_ieraksts[1] == galapunkts) {
                            for (auto ieraksts : pareizais_ieraksts) {
                                cout << ieraksts << " ";
                            }

                            cout << endl;
                        }
                    }
                }
                break;

            case 'b':
                cout << "result: " << endl;
                cin >> nedēļasDiena;

                for (auto pareizais_ieraksts : pareizieIeraksti) {
                    if (pareizais_ieraksts[2] == nedēļasDiena) {
                        for (auto ieraksts : pareizais_ieraksts) {
                            cout << ieraksts << " ";
                        }

                        cout << endl;
                    }
                }
                break;

            case 'c':
                cout << "result: " << endl;
                cin >> cena;

                for (auto pareizais_ieraksts : pareizieIeraksti) {
                    if (stod(pareizais_ieraksts[4]) < cena) {
                        for (auto ieraksts : pareizais_ieraksts) {
                            cout << ieraksts << " ";
                        }

                        cout << endl;
                    }
                }
                break;

            case 'd':
                cout << "result: " << endl;
                ievadesFails.open("err.txt");
                string kļūda;

                while (ievadesFails >> kļūda) {
                    cout << kļūda << endl;
                }

                ievadesFails.close();
                break;
        }

    } while (burts != 'e');

    kļūduFails.close();
    ieraksti.clear();
    pareizieIeraksti.clear();

    return 0;
}
