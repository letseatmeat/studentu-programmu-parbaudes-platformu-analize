#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <vector>

using namespace std;

struct Route {
  string start;
  string end;
  string day;
  string time;
  double price;

  bool operator==(const Route &other) const {
    return start == other.start && end == other.end && day == other.day &&
           time == other.time && price == other.price;
  }

  bool operator<(const Route &other) const {
    return tie(start, end, day, time, price) <
           tie(other.start, other.end, other.day, other.time, other.price);
  }
};

bool checkFormat(const string &line) {
  istringstream sstream(line);
  vector<string> count;
  string token;
  while (getline(sstream, token, ',')) {
    count.push_back(token);
  }
  return count.size() == 5;
}

string deleteSpaces(const string &str) {
  string result;
  for (char c : str) {
    if (!isspace(c)) {
      result += c;
    }
  }
  return result;
}

bool checkDay(const string &day) {
  static const vector<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  return find(days.begin(), days.end(), day) != days.end();
}

bool checkTime(const string &time) {
  if (time.size() != 5)
    return false;
  if (time[2] != ':')
    return false;
  int hours = stoi(time.substr(0, 2));
  int minutes = stoi(time.substr(3, 2));
  return hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59;
}

void readFile(const string &fileName, vector<Route> &routes,
              ofstream &errorFile) {
  ifstream inFile(fileName);
  if (!inFile.is_open()) {
    cerr << "Error opening file: " << fileName << endl;
    return;
  }

  set<Route> uniqueRoutes;
  string line;
  while (getline(inFile, line)) {
    if (line.empty())
      continue;
    line = deleteSpaces(line);

    if (!checkFormat(line)) {
      errorFile << line << endl;
      continue;
    }

    Route route;
    try {
      istringstream sstream(line);
      string start, end, day, time, price;

      getline(sstream, start, ',');
      getline(sstream, end, ',');
      getline(sstream, day, ',');
      getline(sstream, time, ',');
      getline(sstream, price, ',');

      route.start = start;
      route.end = end;
      route.day = day;
      route.time = time;
      route.price = stod(price);

      if (!checkDay(route.day) || !checkTime(route.time)) {
        errorFile << line << endl;
        continue;
      }

      if (uniqueRoutes.count(route) == 0) {
        routes.push_back(route);
        uniqueRoutes.insert(route);
      }
    } catch (const exception &e) {
      errorFile << line << endl;
    }
  }
  inFile.close();
}

void printA(const vector<Route> &routes, const string &start,
            const string &end) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.start == start && route.end == end) {
      cout << route.start << " " << route.end << " " << route.day << " "
           << route.time << " " << fixed << setprecision(2) << route.price
           << endl;
    }
  }
}

void printB(const vector<Route> &routes, const string &day) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.day == day) {
      cout << route.start << " " << route.end << " " << route.day << " "
           << route.time << " " << fixed << setprecision(2) << route.price
           << endl;
    }
  }
}

void printC(const vector<Route> &routes, double maxPrice) {
  cout << "result:" << endl;
  for (const auto &route : routes) {
    if (route.price <= maxPrice) {
      cout << route.start << " " << route.end << " " << route.day << " "
           << route.time << " " << fixed << setprecision(2) << route.price
           << endl;
    }
  }
}

void printD() {
  cout << "result:" << endl;
  ifstream errFile("err.txt");
  if (errFile) {
    string errorLine;
    while (getline(errFile, errorLine)) {
      if (!errorLine.empty()) {
        cout << errorLine << endl;
      }
    }
  }
}

int main() {
  string fileName = "db.csv";
  string errFile = "err.txt";
  vector<Route> routes;
  ofstream errorFile(errFile);
  readFile(fileName, routes, errorFile);

  char choice;
  do {
    cout << "Command: ";
    cin >> choice;
    try {
      if (!choice) {
        throw runtime_error("Input error");
      }

      switch (choice) {
      case 'a': {
        string start, end;
        cout << "Start point: ";
        cin >> start;
        cout << "End point: ";
        cin >> end;
        printA(routes, start, end);
        break;
      }
      case 'b': {
        string day;
        cout << "Day of week: ";
        cin >> day;
        printB(routes, day);
        break;
      }
      case 'c': {
        double maxPrice;
        cout << "Price: ";
        cin >> maxPrice;
        printC(routes, maxPrice);
        break;
      }
      case 'd': {
        printD();
        break;
      }
      default:
        break;
      }

    } catch (const exception &e) {
      cout << e.what() << endl;
      continue;
    }
  } while (choice != 'e');
  return 0;
}
