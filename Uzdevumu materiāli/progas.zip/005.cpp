#include <iostream>
#include <fstream>
#include <cstring>
#include <stack>
#include <bits/stdc++.h> 


using namespace std;
class Migratory{
  public:
  string nest;
  string food;
  string time;
  string time2;
  string fed;
};


string swoop(string m1){
  string course;
  char berry[m1.length()];
  strcpy(berry,m1.c_str());
  for (int i=0;i<m1.length();i++){
    if(berry[i]!=' '){
      course+=berry[i];
    }
  }
  return course;
}


int feather(string m1){
  int course=0, spoilt=0;
  char berry[m1.length()];
  strcpy(berry,m1.c_str());
  for (int i=0;i<m1.length();i++){
    if(berry[i]==','){
      course++;
    }
    if(course<3 & isdigit(berry[i])){
      spoilt++;
    }
  }
  if(spoilt==0){
    return course;
  }
  else{
    return course-1;
  }
}


Migratory hatch(string egg){
  Migratory hatchling;int straw=0; string feed;
  char berry[egg.length()];
  strcpy(berry,egg.c_str());
  for(int i=0;i<egg.length();i++){
    if(berry[i]==',' | i==egg.length()-1){
      straw+=1;
      if(straw==1){
        hatchling.nest=feed;
      }
      else if(straw==2){
        hatchling.food=feed;
      }
      else if(straw==3){
        hatchling.time=feed;
      }
      else if(straw==4){
        hatchling.time2=feed;
      }
      else{
        hatchling.fed=feed;
      }
      feed="";
    }
    else{
      feed+=berry[i];
    }
  }
  return hatchling;
}


int main() {
  ofstream fail1; ifstream fail2;
  ifstream bowl;
  stack <string> lirebird;
  stack<string> perch;
  string pear,brand="db.csv";int peach=0;

  
  bowl.open(brand);
	if (!bowl) return 0;
  fail1.open("err.txt");
  while(getline(bowl,pear)){
    if(pear.length()>1){
      pear=swoop(pear);
      if(feather(pear)==4){
        lirebird.push(pear);
      }
      else{
        fail1<<pear;
      }
    }
  }

  
  fail1.close();
  bowl.close();

  
  int swirl=lirebird.size();
  
  
  for(peach=0;peach<swirl;peach++){
    perch.push(lirebird.top());
    lirebird.pop();
  }

  
  Migratory eggs[swirl];
  for(peach=0;peach<swirl;peach++){
    pear=perch.top();
    eggs[peach]=hatch(pear);
    perch.pop();
  }

  
  bool plume=true;
  while(plume==true){
    char q1;string q2,q3;double q5=0;
    cin>>q1;

    
    switch(q1){
      
      case 'a':
        cin>>q2;
        cin>>q3;
        cout<<"result:"<<endl;
        for(peach=0;peach<swirl;peach++){
          if(q2==eggs[peach].nest & q3==eggs[peach].food){
            cout<<eggs[peach].nest<<" "<<eggs[peach].food<<" "<<eggs[peach].time<<" "<<eggs[peach].time2<<" "<<eggs[peach].fed<<endl;
          }
        }
        break;
      
      case 'b':
        cin>>q2;
        cout<<"result:"<<endl;
        for(peach=0;peach<swirl;peach++){
          if(q2==eggs[peach].time){
            cout<<eggs[peach].nest<<" "<<eggs[peach].food<<" "<<eggs[peach].time<<" "<<eggs[peach].time2<<" "<<eggs[peach].fed<<endl;
          }
        }
        break;
      
      case 'c':
        cin>>q5;
        cout<<"result:"<<endl;
        for(peach=0;peach<swirl;peach++){
          if(q5>=stod(eggs[peach].fed)){
            cout<<eggs[peach].nest<<" "<<eggs[peach].food<<" "<<eggs[peach].time<<" "<<eggs[peach].time2<<" "<<eggs[peach].fed<<endl;
          }
        }
        break;
      
      case 'd':
        cout<<"result:"<<endl;
        fail2.open("err.txt");
        if (!fail2) return 0;
        while(fail2>>q2){
          cout<<q2<<endl;
        }
        fail2.close();
        break;
      
      case 'e':
        plume=false;
        break;
      
    }
  }
} 