#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <iterator>
using namespace std;


bool isnumeric(string s) {
    bool res = false;
    try {
        int l = stoi(s);
        res = true;
    }
    catch (...) {
    }
    return res;
}

ofstream err("err.txt");
void error(string line) {
    bool x = false;
    istringstream stream(line);
    string tmp;
    vector<string> arr;
    if (line.length() != 1) {
        while (getline(stream, tmp, ',')) {
            arr.push_back(tmp);
        }
        for (int i = 0; i < arr.size(); ++i) {
            if (arr.size() != 5) {
                x = true;
            }
            else {
                if (isnumeric(arr[0]) || isnumeric(arr[1]) || isnumeric(arr[2]) || arr[i] == " ") {
                    x = true;
                }
            }
        }
        if (x) {
            err << line << endl;
        }
    }
}

int main() {
    ifstream inFile;
    inFile.open("db.csv");
    if (!inFile) return 0;

    string line;
    while (getline(inFile, line))
    {
        error(line);
    }
    inFile.close();

    string input, first, last;
    double cena;
    do {
        inFile.open("db.csv");
        cin >> input;
        if (input == "a") {
            cin >> first;
            cin >> last;
        }
        if (input == "b") {
            cin >> first;
        }
        if (input == "c") {
            cin >> cena;
        }
        if (input != "e") {
            cout << "result:" << endl;
        }
        while (getline(inFile, line))
        {
            bool x = false;
            istringstream stream(line);
            string tmp;
            vector<string> arr;
            if (line.length() != 0) {
                while (getline(stream, tmp, ',')) {
                    string k;
                    char regExp = '\n';
                    for (char c : tmp) if (c != ' ' || c == regExp) k += c;
                    tmp = k;
                    arr.push_back(tmp);
                }
                for (int i = 0; i < arr.size(); ++i) {
                    if (arr.size() != 5) {
                        x = true;
                    }
                    else {
                        if (isnumeric(arr[0]) || isnumeric(arr[1]) || isnumeric(arr[2]) || arr[i] == " ") {
                            x = true;
                        }
                    }
                }
                if (input == "d" && x) {
                    cout << line << endl;
                }
                string kop;
                for (string word : arr) {
                    kop += word + " ";
                }

                kop.pop_back();

                if (!x && input == "a" && first == arr[0] && last == arr[1]) {
                    cout << kop << endl;
                }
                if (!x && input == "b" && first == arr[2]) {
                    cout << kop << endl;
                }
                if (!x && input == "c" && cena >= stoi(arr[4])) {
                    cout << kop << endl;
                }
            }
        }inFile.close();
    } while (input != "e");
    err.close();
}