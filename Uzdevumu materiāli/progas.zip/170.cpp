
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream> 

using namespace std;

void newCorrectFile (ifstream& inFile){
  ofstream outFile("dbNew.csv");

  if(!inFile.is_open()){
    return;  
  }
  if(!outFile.is_open()){
    return;  
  }

  string line;
  vector <string> allLines;

  while (getline (inFile, line)){
    if (!line.empty() && all_of(line.begin(), line.end(), ::isspace) == false){
      for(int i=0; i< line.size();i++){
        if(line[i] == ' '){
          line.erase(i, 1);
          i--;
        } 
      }
      replace(line.begin(), line.end(), ',', ' ');
      allLines.push_back(line);
    }
  }

  for (int i=0; i<allLines.size();i++){
    int num = count(allLines[i].begin(), allLines[i].end(), ' ');
      if(num != 4){
        allLines.erase(allLines.begin()+i);
        i--;
      } else if(allLines[i].find('.') < allLines[i].find(':')){
        allLines.erase(allLines.begin() +i);
        i--;
        }
  }

  for (int i =0; i< allLines.size(); i++){
    outFile << allLines[i] << endl;
  }
  

}
void searchTripByCity (ifstream& inFile2){
  string cityDep, cityArr, line;
  cin >> cityDep;
  cin >> cityArr;

  inFile2.clear();
  inFile2.seekg(0);

  cout << "result: " << endl;

  while (getline (inFile2, line)){
    if(line.find(cityDep)!=-1 && line.find(cityArr)!=-1 && line.find(cityDep) < line.find(cityArr)){
      cout << line << endl;
    }
  }
}

void searchTripByDay (ifstream& inFile2){
  string day, line;
  cin >> day;

  inFile2.clear();
  inFile2.seekg(0);
  
  cout << "result: " << endl;
  while (getline(inFile2, line)){
    if(line.find(day) != -1){
      cout << line << endl;
    }
  }
  
}

void searchTripByPrice(ifstream& inFile2){
string line;
vector <string> allLines; 
double price;
  cin >> price;
  cout << "result: "<< endl;
  
  while(getline(inFile2, line)){
    int x = line.find_last_of(' ');

    string tripPrice = line.substr(x+1);
    double tripPriceDouble = stod(tripPrice);

    if(tripPriceDouble <= price){
      cout << line << endl;
  }
  }
}

void errorFile(){
  ifstream inFile;
  inFile.open("db.csv");
  ofstream outFile("err.txt");
  
  string line;
  vector <string> allLines;
  vector <string> checkLines;
  cout << "result: " << endl;

  while (getline (inFile, line)){
    if (!line.empty() && all_of(line.begin(), line.end(), ::isspace) == false){
      for(int i=0; i< line.size();i++){
        if(line[i] == ' '){
          line.erase(i, 1);
          i--;
        } 
      }
      allLines.push_back(line);
    }
  }

  for (int i=0; i<allLines.size();i++){
    int num = count(allLines[i].begin(), allLines[i].end(), ',');
    if(num != 4){
      checkLines.push_back(allLines[i]);
    } else if(allLines[i].find('.') < allLines[i].find(':')){
      checkLines.push_back(allLines[i]);
    }
  }

  for (int i =0; i< checkLines.size(); i++){
    outFile << checkLines[i] << endl;
  }
  }

void errorTrips(){
  ifstream errorFile;

  errorFile.open("err.txt");
  string line;

  while(getline(errorFile, line)){
    cout << line << endl;
  }
  
}


int main() {
  
  ifstream inFile;
  inFile.open("db.csv");
  
  newCorrectFile(inFile);
  errorFile();
  
  ifstream inFile2;
  inFile2.open("dbNew.csv");
  
  char command;
  
  do{
    cin >> command;

    switch(command){
      case 'a':
          searchTripByCity(inFile2);
          break;
      case 'b':
          searchTripByDay(inFile2);
          break;
      case 'c':
          searchTripByPrice(inFile2);
          break;
      case 'd':
          errorTrips();
          break;
      case 'e':
          break;
    }
  } while (command != 'e');

  inFile.close();
  inFile2.close();
  
  return 0; 
} 