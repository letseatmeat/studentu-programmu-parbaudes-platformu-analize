

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

// Definē funkciju, kas izdalīs teksta rindu pēc komatiem un izlaiž atstarpes un iepusho tās result vektorā
vector<string> splitString(const string &line) {
    vector<string> result;
    stringstream ss(line);
    string item;
    while (getline(ss, item, ',')) {
        item.erase(remove_if(item.begin(), item.end(), ::isspace), item.end());
        result.push_back(item);
    }
    return result;
}

int main() {
    ifstream inFile;
    inFile.open("db.csv");

    if (!inFile) {
        cout << "Error opening file." << endl;
        return 0;
    }

    vector<string> errors; // saglabā kļūdainās rindas
    vector<vector<string>> routes; // saglabā visus maršrutus

    string line;
    while (getline(inFile, line)) {
        // noņem tukšās rindas
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

        // Izlaižam tukšas rindas un rindas, kas pēc atstarpju izņemšanas ir tukšas
        if (line.empty()) {
            continue;
        }

        // Pārbaudam, vai rinda satur komatus un izdalām datus
        vector<string> routeData = splitString(line);

        // Pārbaudam, vai ir pietiekami daudz datu
        if (routeData.size() != 5) {
            // Kļūdainā rinda
            errors.push_back(line);
            continue;
        }

        // Pārbauda, vai dati ir pareizā secībā
        if (routeData[3] > "24:00" || routeData[4] <= "0.00") {
            errors.push_back(line);
            continue;
        }


        // Saglabājam pareizos datus
        routes.push_back(routeData);
    }

    // Izvadam kļūdas failā err.txt
    ofstream errFile("err.txt");
    for (const auto &errLine : errors) {
        errFile << errLine << endl;
    }
    errFile.close();

    // Mainīgais priekš rezultātu izvadīšanas
    vector<string> result;

    // Galvenais cikls
    char choice;
    do {
        cin >> choice;

        // Flag mainīgais, lai pārbaudītu, vai ir jauni rezultāti
        bool hasNewResults = false;

        switch (choice) {
            case 'a': {
                string start, end;
                cin >> start >> end;

                // Atrodam visus reisus starp start un end pieturām
                for (const auto &route : routes) {
                    if (route[0] == start && route[1] == end) {
                        result.push_back(route[0] + " " + route[1] + " " + route[2] + " " + route[3] + " " + route[4]);
                        hasNewResults = true;
                    }
                }
                break;
            }
            case 'b': {
                string day;
                cin >> day;

                // Atrodam visus reisus noteiktajā nedēļas dienā
                for (const auto &route : routes) {
                    if (route[2] == day) {
                        result.push_back(route[0] + " " + route[1] + " " + route[2] + " " + route[3] + " " + route[4]);
                        hasNewResults = true;
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cin >> maxPrice;

                // Atrodam visus reisus, kuru biļetes cena nepārsniedz ievadīto
                for (const auto &route : routes) {
                    double price = stod(route[4]);
                    if (price <= maxPrice) {
                        result.push_back(route[0] + " " + route[1] + " " + route[2] + " " + route[3] + " " + route[4]);
                        hasNewResults = true;
                    }
                }
                break;
            }
            case 'd': {
                // Izvadam kļūdu faila saturu
                ifstream errFileIn("err.txt");
                string errLine;
                while (getline(errFileIn, errLine)) {
                    result.push_back(errLine);
                }
                errFileIn.close();
                hasNewResults = true;
                break;
            }
            case 'e':
                // Izejam no cikla
                break;
            default:
                cout << "Invalid command." << endl;
        }

        // Izvadam rezultātu tikai tad, ja ir jauni rezultāti
        if (hasNewResults) {
            cout << "result:" << endl;
            for (const auto &res : result) {
                cout << res << endl;  
            }
            // Notīram rezultātu, lai saglabātu tikai jaunos rezultātus
            result.clear();
        }

    } while (choice != 'e');

    return 0;
}
