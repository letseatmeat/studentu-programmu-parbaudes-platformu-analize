

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <algorithm>

using namespace std;

struct BusRoute {
    string sakums;
    string gals;
    string diena;
    string laiks;
    double cena;
};

void printBusRoute(const BusRoute& route) {
    cout << route.sakums << " " << route.gals << " " << route.diena << " " << route.laiks << " " << fixed << setprecision(2) << route.cena << endl;
}

bool isValidDouble(const string& str) {
    try {
        stod(str);
        return true;
    } catch (const std::invalid_argument&) {
        return false;
    } catch (const std::out_of_range&) {
        return false;
    }
}

int main() {
    ifstream inFile("db.csv");

    if (!inFile) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    vector<BusRoute> routes;
    string line;
    while (getline(inFile, line)) {
        istringstream ss(line);
        BusRoute route;

        vector<string> tokens;
        string token;
        while (getline(ss, token, ',')) {
            size_t start = token.find_first_not_of(" \t");
            size_t end = token.find_last_not_of(" \t");

            if (start != string::npos && end != string::npos) {
                tokens.push_back(token.substr(start, end - start + 1));
            }
        }

        if (tokens.size() == 5) {
            route.sakums = tokens[0];
            route.gals = tokens[1];
            route.diena = tokens[2];

            if (isValidDouble(tokens[3])) {
                route.laiks = tokens[3];
            } else {
                ofstream errorFile("err.txt", ios::app);
                if (!line.empty()) {
                    errorFile << line << '\n';
                }
                errorFile.close();
                continue; 
            }

            route.cena = stod(tokens[4]); 
            routes.push_back(route);
        } else {
            ofstream errorFile("err.txt", ios::app);
            if (!line.empty()) {
                errorFile << line << '\n';
            }
            errorFile.close();
        }
    }

    char choice;
    while (true) {
        cout << " Choose(a, b, c, d, e): ";
        cin >> choice;

          switch (choice) {
            case 'a': {
                string start, end;
                cout << "Starting point: ";
                cin >> start;

                cout << "Final destination: ";
                cin >> end;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.sakums == start && route.gals == end) {
                        printBusRoute(route);
                    }
                }
                break;
            }

            case 'b': {
                string day;
                cout << "Enter day (Pr, Ot, Tr, Ce, Pt, St, Sv): ";
                cin >> day;

                transform(day.begin(), day.end(), day.begin(), ::toupper);

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    string routeDay = route.diena;
                    transform(routeDay.begin(), routeDay.end(), routeDay.begin(), ::toupper);

                    if (routeDay == day) {
                        printBusRoute(route);
                    }
                }
                break;
            }
            case 'c': {
                double maxPrice;
                cout << "Enter ticket price budget: ";
                cin >> maxPrice;

                cout << "result:" << endl;
                for (const auto& route : routes) {
                    if (route.cena <= maxPrice) {
                        printBusRoute(route);
                    }
                }
                break;
            }
          case 'd': {
              ifstream errorFile("err.txt");
              if (errorFile.is_open()) {
                  cout << "result:" << '\n';
                  string errorLine;
                  while (getline(errorFile, errorLine)) {
                      if (!errorLine.empty() && std::any_of(errorLine.begin(), errorLine.end(), ::isgraph)) {
                          cout << errorLine << '\n';
                      }
                  }
              } else {
                  cout << "Error opening err file." << endl;
              }
              break;
          }

            case 'e':
                cout <<  endl;
                return 0;
            default:
                cout << "Invalid choice" << endl;
        }
    }

    return 0;
}
