#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>


using namespace std;
// funkcija kas pārbauda vai vērtība ir teksts
bool tParb(const string &r){
  for(char b : r){
    if(!isalpha(b) && b != ' '){
      return false;
    }
  }
  return true;
}


// funkcija kas apstrādā failu un izveido no tā gan err.txt failu, gan vektoru, ar kuru tālāk darboties
vector<vector<string>> apstrade(){
  // atver un pārbauda datu bāzes faila eksistenci
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) exit(0);

  string rinda;
  
  // definē jaunu vektoru, kurā iekšā ir vektori, kuros iekšā ir teksta rindas
  vector<vector<string>> dati;
  ofstream errf("err.txt");
  
  
  // cikls, kas pārbauda vai datu bāzes faila rinda atbilst nosacījumiem vai nē
  while(getline(inFile, rinda)){
    // nākamajās 2 rindās katrai rindai tiek noņemti tukšie simboli to sākumos un beigās
    rinda.erase(0, rinda.find_first_not_of(" \t\r\n"));
    rinda.erase(rinda.find_last_not_of(" \t\r\n") + 1);
    // pārbauda vai rinda ir tukša, ja ir, tad izlaiž un neievieto vektorā vai err.txt failā
    if(!rinda.empty()){
      vector<string> rinda_dati;
      istringstream plusma(rinda);
      string sadale;
    // cikls, kas sadala rindu elementus pēc ',' un sakārto tos atsevišķā vektorā
      while(getline(plusma, sadale, ',')){
        // līdzīgi, kā rindas iepriekš, arī katram elementam tiek noņemti tukšie simboli to sākumos un beigās
        sadale.erase(0, sadale.find_first_not_of(" \t\r\n"));
        sadale.erase(sadale.find_last_not_of(" \t\r\n") + 1);
        // pievieno elementu vektoram
        rinda_dati.push_back(sadale);
      }
      // ja rinda satur nepieciešamo elementu skaitu un pirmie 3 locekļi ir teksta elementi, taču pārējie 2 nav, tad pievieno vektoram
      if(rinda_dati.size() == 5 && tParb(rinda_dati[0]) && tParb(rinda_dati[1]) && tParb(rinda_dati[2])){
        dati.push_back(rinda_dati);
      }
      // citādi rindu pievieno err.txt failam
      else{
        for(auto &b : rinda_dati){
          errf << b;
          if(b != rinda_dati.back()){
            errf << ",";
          }
        }
        errf << endl;
      }
     
    }
    
  }

  // aizver datu bāzes failu, jo to vairs nav nepieciešams izmantot
  inFile.close();
  // aizver err.txt failu, jo to vairs nav nepieciešams izmantot
  errf.close();
  
  return dati;

  
  }
// funkcija, kas pēc lietotāja ievadītā sākumpunkta un galamērķa, izvada visus atbilstošos maršrutus, kuri kursē norādītajos maršrutos
void aFun(vector<vector<string>> dati){
  string sakums, gals;
  
  // lietotājs ievada sākuma un gala punktus
  cin >> sakums;
  cin >> gals;
  
  cout << "result:" << endl;
  // cikls iterē cauri vektoram, kurā ir saglabāti derīgie datu bāzes dati. atlasa tos, kuri atbilst lietotāja ievadītajām vērtībām un izvada tos uz ekrāna
  for(auto a : dati){
    if(a[0] == sakums && a[1] == gals){
      for(auto b : a){
        cout << b << " ";
      }
      cout << endl;
    }
  }
      
}
// funkcija, kas pēc lietotāja ievadītas dienas, izvada visus atbilstošos maršrutus, kuri kursē tajā dienā
void bFun(vector<vector<string>> dati){
  string diena;

  cin >> diena;

  cout << "result:" << endl;
   // cikls iterē cauri vektoram, kurā ir saglabāti derīgie datu bāzes dati. atlasa tos, kuri atbilst lietotāja ievadītajām vērtībām un izvada tos uz ekrāna
  for(auto a : dati){
    if(a[2] == diena){
      for(auto b : a){
        cout << b << " ";
      }
      cout << endl;
    }

  }
}


// funkcija, kas pēc lietotāja ievadītas cenas, izvada visus atbilstošos maršrutus, kuru cena nepārsniedz ievadīto vērtību
void cFun(vector<vector<string>> dati){
  double cena;

  cin >> cena;

  cout << "result:" << endl;
  // cikls iterē cauri vektoram, kurā ir saglabāti derīgie datu bāzes dati. atlasa tos, kuri atbilst lietotāja ievadītajām vērtībām un izvada tos uz ekrāna
  for(auto a : dati){
    if(stod(a[4]) <= cena){
      for(auto b : a){
        cout << b << " ";
      }
      cout << endl;
    }
  }
}
// funkcija, kas izvada faila err.txt saturu
void dFun(){
  cout << "result:" << endl;
  
  ifstream inFile;
  inFile.open("err.txt");
  if (!inFile) exit(0);
  
  string rinda;

  while(getline(inFile, rinda)){
    cout << rinda << endl;
  }
}

// funkcija main, kas nodrošina programmas darbību
int main() {
  // tiek definēts vektors, ar kuru varēs strādāt pārējās funkcijas
  vector<vector<string>> dati = apstrade();
  char burts;
  // kamēr lietotājs neievadīs simbolu 'e', tikmēr programma turpinās darboties
  while(burts != 'e'){
    // lietotājs ievada burtu, kas izsauks funkciju, kas apstrādās datu bāzes failu
    cin >> burts;
    switch(burts){
      case 'a':
        aFun(dati);
      break;
      case 'b':
        bFun(dati);
      break;
      case 'c':
        cFun(dati);
      break;
      case 'd':
        dFun();
      break;
    }
  }
} 
