
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <regex>


using namespace std;

void printError(){
  ifstream inFile;
  string line;
  inFile.open("err.txt");
  if (!inFile) return;
  cout<<"result:"<<endl;
  while (getline(inFile, line)){
    cout<<line<<endl;
  }
  inFile.close();
}

void printPrice(vector<vector<string>> routes){
  string price;
  cout<< "Price: "<< endl;
  cin>>price;
  float pricef = stof(price);
  cout<<"result:"<<endl;
  for(int i=0;i<routes.size();i++){{
    if(stof(routes[i][4])<=pricef){
      for(int j=0;j<routes[i].size();j++){
        cout<<routes[i][j]<<" ";
      }
      cout<<endl;
      }
    }
  }
  
}

void printDay(vector<vector<string>> routes){
  string day;
  cout<< "Day: "<< endl;
  cin>>day;
  cout<<"result:"<<endl;
  for(int i=0;i<routes.size();i++){{
    if(routes[i][2]==day){
      for(int j=0;j<routes[i].size();j++){
        cout<<routes[i][j]<<" ";
      }
      cout<<endl;
      }
    }
  }
}

void printCity(vector<vector<string>> routes){
  string from;
  string to;
  cout<< "From: "<< endl;
  cin>>from;
  cout<< "To: "<< endl;
  cin>>to;
  cout<<"result:"<<endl;
  for(int i=0;i<routes.size();i++){{
    if(routes[i][0]==from && routes[i][1]==to){
      for(int j=0;j<routes[i].size();j++){
        cout<<routes[i][j]<<" ";
      }
      cout<<endl;
      }
    }
  }
}

bool isValid(vector<string> words){
  if(words.size() != 5){
    return false;
  }
  regex e1("[A-Za-z]+"); // regex pilsetām
  regex e2("(Pr|Ot|Tr|Ce|Pt|St|Sv)"); // regex dinām
  regex e3 ("([0-1][0-9]|2[0-3]):[0-5][0-9]"); // regex laikam
  regex e4("([0-9]|[1-9][0-9]|[1-9][0-9][0-9]).[0-9][0-9]"); // regex cenai
  
  if (!regex_match (words[0],e1)){
    return false;
  } 
  if (!regex_match (words[1],e1)){
    return false;
  }
  if (!regex_match (words[2],e2)){
    return false;
  }  
  if (!regex_match (words[3],e3)){
    return false;
  }  
    if (!regex_match (words[4],e4)){
      return false;
    }
  else
    return true;
}

void removeSpaces(string& str) {
    str.erase(remove_if(str.begin(), str.end(), ::isspace), str.end());
} //  nodzēš tukšumus rindā

int main() {
  ifstream inFile;
  inFile.open("db.csv");
	if (!inFile) return 0; 
  
  string line; 
  vector<vector<string>> routes;
  vector<vector<string>> errors;
  
	while (getline(inFile, line)){ 
    vector<string> words;
    
    removeSpaces(line);
    
    if (line.empty()) {
        continue;
    } // izlaiž tukšas rindas
    
    istringstream sts(line);
    string word;
    while (getline(sts, word, ',')) {
        words.push_back(word);
    } // sadala rindu vārdos, izmantojot komatu kā atdalītāju, un pievieno tos masīvam
    if (isValid(words)){
      routes.push_back(words);
    }
    else{
      errors.push_back(words); // ja rinda satur kļūdas, tad pievieno to masīvam, kurš pēc tam būs ierakstīts failā "err.txt"
    }
  }
  inFile.close();

  ofstream outFile;
  outFile.open("err.txt");
  if (!outFile) return 0;
  for(int i = 0; i < errors.size(); i++){
    for(int j = 0; j < errors[i].size(); j++){
      if(j == errors[i].size() - 1){ // ja tas ir pēdējais elements rindā
        outFile << errors[i][j];
      }
      else{
        outFile << errors[i][j] << ",";
      }
    }
    outFile << endl;
  }
  outFile.close();
  
  while(true) {
    char s;
    cin >> s;
    switch(s) {
      case 'a' :
        printCity(routes);
        break;
      case 'b':
        printDay(routes);
        break;
      case 'c':
        printPrice(routes);
      break;
      case 'd':
        printError();
      break;
      case 'e':
         return 0;
      break;
      default:
        cout<< "error"<< endl;
        return 0;
    }
  }
} 