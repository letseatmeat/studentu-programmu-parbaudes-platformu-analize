
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

struct fileInfo {
  string city;
  string city2;
  string day;
  string time;
  string cena;
};

ofstream File("ett.txt");
int main() {
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile)
    return 0;
  vector<fileInfo> info;
  string s;
  while (getline(inFile, s)) {
    string file[5];
    for (int f = 0; f < 5; f++)
      file[f] = "";
    int key = 0;
    int gar = s.size();
    for (int i = 0; i < gar; i++) {
      if (s[i] == ',') {
        key++;
      } else if (s[i] == ' ') {
      } else if (key == 0) {
        file[key] = file[key] + s[i];
      } else if (key == 1) {
        file[key] = file[key] + s[i];
      } else if (key == 2) {
        file[key] = file[key] + s[i];
      } else if (key == 3) {
        file[key] = file[key] + s[i];
      } else if (key == 4) {
        file[key] = file[key] + s[i];
      }
    }
    int garf4 = file[4].size();
    int error = 0;
    try {
      double num = stod(file[4]);
      int num2 = stoi(file[3].substr(0, 2) + file[3].substr(3, 4));
    } catch (invalid_argument ia) {
      error = 1;
    } catch (out_of_range ie) {
      error = 1;
    }
    if (key != 4 || file[2].size() != 2 || file[3].size() != 5 ||
        file[3][2] != ':' || file[4][garf4 - 3] != '.' || error == 1) {
      if (s.size() > 1) {
        File << s << endl;
      }
    } else
      info.push_back({file[0], file[1], file[2], file[3], file[4]});
  }
  File.close();

  int exit = 0;
  char choice;
  while (exit != 1) {
    cin >> choice;
    switch (choice) {
    case 'a': {
      string pilseta1, pilseta2;
      cin >> pilseta1;
      cin >> pilseta2;
      cout << "result:" << endl;
      for (const auto &k : info) {
        if (pilseta1 == k.city && pilseta2 == k.city2) {
          cout << k.city << " " << k.city2 << " " << k.day << " " << k.time
               << " " << k.cena << endl;
        }
      }
      break;
    }
    case 'b': {
      string diena;
      cin >> diena;
      cout << "result:" << endl;
      for (const auto &k : info) {
        if (diena == k.day) {
          cout << k.city << " " << k.city2 << " " << k.day << " " << k.time
               << " " << k.cena << endl;
        }
      }
      break;
    }
    case 'c': {
      double price;
      try {
        cin >> price;
        cout << "result:" << endl;
        for (const auto &k : info) {
          double cena = stod(k.cena);
          if (price >= cena) {
            cout << k.city << " " << k.city2 << " " << k.day << " " << k.time
                 << " " << k.cena << endl;
          }
        }
      } catch (invalid_argument ia) {
        cout << "invalid argument" << endl;
      }
      break;
    }
    case 'd': {
      cout << "result:" << endl;
      ifstream inFile2;
      inFile2.open("ett.txt");
      if (!inFile2)
        return 0;
      string txt;
      while (getline(inFile2, txt)) {
        cout << txt << endl;
      }
      inFile2.close();
      break;
    }
    case 'e': {
      exit = 1;
      break;
    }
    default:
      cout << "wrong command" << endl;
      break;
    }
  }
  return 0;
}