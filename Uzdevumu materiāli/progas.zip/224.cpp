#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <iomanip>
#include <algorithm>


using namespace std;

struct Marsuts {
  string startCity;
  string endCity;
  string day;
  string time;
  double price;
};

void a (vector<Marsuts> marsuti, string startCity, string endCity){
 for (const Marsuts &marsuts : marsuti){
   if(marsuts.startCity == startCity && marsuts.endCity == endCity){
     cout << marsuts.startCity << " " << marsuts.endCity << " " << marsuts.day << " " << marsuts.time << " " << fixed << setprecision(2) << marsuts.price << endl;
  }
 }
}
   void b(vector<Marsuts> marsuti,string day){
     for (const Marsuts &marsuts : marsuti){
       if (marsuts.day == day){
         cout << marsuts.startCity << " " << marsuts.endCity << " " << marsuts.day << " " << marsuts.time << " " << fixed << setprecision(2) << marsuts.price << endl;
     }
     }
   }

   void c(vector<Marsuts> marsuti,double price){
      for (const Marsuts &marsuts : marsuti){
        if (marsuts.price <= price){
          cout << marsuts.startCity << " " << marsuts.endCity << " " << marsuts.day << " " << marsuts.time << " " << fixed << setprecision(2) << marsuts.price << endl;
      }
      }
    }

    void d (){
      ifstream inFile;
      inFile.open("err.txt");

      string line;
      while (getline(inFile, line)) {
        cout << line << "\n";
      }
      inFile.close();
    }

int main() {
  vector<Marsuts> marsuti;
  set<string> days = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  ifstream inFile;
  inFile.open("db.csv");
  if (!inFile) {
    cerr << "Failed to open db.csv" << endl;
    return 1;
  }

  ofstream outFile("err.txt");
  string line;
  while (getline(inFile, line)) {
    
    if(line.empty()) continue;
    bool error = false;
    istringstream line_m(line);
    
    Marsuts marsuts;
    string field;
    vector<string> fields;
    while (getline(line_m, field, ',')) {
      string newField;
      for (char c : field) {
        if (!isspace(c)) newField += c; // izlaiz atstarpes
      }
      fields.push_back(newField);
    }
    if (fields.size() != 5) {  // parbauda vai ir 5 lauki
      error = true;
    } else {
      try {                                      //parbauda vai price ir skaitlis
        marsuts.startCity = fields[0];
        marsuts.endCity = fields[1];
        marsuts.day = fields[2];
        marsuts.time = fields[3];
        marsuts.price = stod(fields[4]);
      } catch (const invalid_argument &ia) {
        error = true;
      }
    }

    if(days.find(marsuts.day) == days.end()){  //parbauda vai diena ir pareiza formata
      error = true;
    }

    if(marsuts.time.find(":") == string::npos){  //parbauda va time satur :
      error = true;
    }
    if (error) {
      outFile << line << endl;
    } else {
      marsuti.push_back(marsuts);
    }
    line.clear();
  }

  inFile.close();
  outFile.close();

  bool active = true;
  char input;
  while(active){
    cin >> input;
    switch(input){
      case 'a':{
        string start, end;
        cin >> start >> end;
        cout << "result:\n";
        a(marsuti,start,end);
        break;}
      case 'b': {
        string day;
        cin >> day;
        cout << "result:\n";
        b(marsuti, day);
        break;}
      case 'c':{ 
        double price;
        cin >> price;
        cout << "result:\n";
        c(marsuti, price);
        break;}
      case 'd':{
        cout << "result:\n";
        d();
        break;}
      case 'e':{
        active =  false;
        break;}
      default:{
        cout << "wrong command\n";
        break;}

      }
    }

  return 0;
}

