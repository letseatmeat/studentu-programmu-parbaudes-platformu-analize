
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

bool irlaiks(string laiks) {
  int l = laiks.length();
  bool result = false;
  if (l == 5 && laiks[2] == ':' && laiks[0] >= '0' && laiks[0] <= '2' &&
      laiks[1] >= '0' && laiks[1] <= '9' && laiks[3] >= '0' &&
      laiks[3] <= '5' && laiks[4] >= '0' && laiks[4] <= '9') {
    result = true;
  }
  return result;
}
bool ircena(string cena) {
  bool result = false;
  try {
    stof(cena);
    result = true;
  } catch (...) {
  }
  return result;
}

int main() {
  bool ara = false;
  string line;
  string no, uz, diena, laiks;
  int cena;
  vector<string> dienas = {"Pr", "Ot", "Tr", "Ce", "Pt", "St", "Sv"};
  ofstream ErrFile("err.txt");
  string linerez;
  vector<string> result;
  int lol = 0;
  ifstream file("db.csv");
  if (file.is_open()) {
    while (getline(file, line)) {
      vector<string> reissrinda;
      reissrinda.push_back(line);
      vector<string> reiss_atr;
      for (auto words : reissrinda) {
        stringstream ss(words);
        string str;
        while (getline(ss, str, ',')) {
          for (int i = str.length() - 1; i >= 0; --i) {
            if (str[i] == ' ')
              str.erase(i, 1);
          }
          reiss_atr.push_back(str);
        }
      }
      if (reiss_atr.size() == 5 &&
          find(dienas.begin(), dienas.end(), reiss_atr[2]) != dienas.end() &&
          irlaiks(reiss_atr[3]) && ircena(reiss_atr[4])) {
        linerez = reiss_atr[0] + " " + reiss_atr[1] + " " + reiss_atr[2] + " " +
                  reiss_atr[3] + " " + reiss_atr[4];
        result.push_back(linerez);
      } else {
        ErrFile << line << endl;
      }
    }
    ErrFile.close();
    file.close();
  }
  char izvele;
  ifstream erfile("err.txt");

  while (ara == false) {
    cin >> izvele;
    switch (izvele) {
    case 'a': {
      string line;
      string linerez;
      vector<string> result;
      string no, uz, diena, laiks;
      int cena;
      int lol = 0;
      ifstream file("db.csv");
      string pietura1, pietura2;
      cin >> pietura1;
      cin >> pietura2;
      if (file.is_open()) {
        while (getline(file, line)) {
          vector<string> reissrinda;
          reissrinda.push_back(line);
          vector<string> reiss_atr;
          for (auto words : reissrinda) {
            stringstream ss(words);
            string str;
            while (getline(ss, str, ',')) {
              for (int i = str.length() - 1; i >= 0; --i) {
                if (str[i] == ' ')
                  str.erase(i, 1);
              }
              reiss_atr.push_back(str);
            }
          }
          if (reiss_atr.size() == 5 && reiss_atr[0] == pietura1 &&
              reiss_atr[1] == pietura2 &&
              find(dienas.begin(), dienas.end(), reiss_atr[2]) !=
                  dienas.end() &&
              irlaiks(reiss_atr[3]) && ircena(reiss_atr[4])) {
            linerez = reiss_atr[0] + " " + reiss_atr[1] + " " + reiss_atr[2] +
                      " " + reiss_atr[3] + " " + reiss_atr[4];
            if (lol == 0)
              cout << "result:"
                   << "\n";
            cout << linerez << "\n";
            lol = lol + 1;
            result.push_back(linerez);
          }
        }
        file.close();
      }
      break;
    }
    case 'b': {
      string line;
      string linerez;
      vector<string> result;
      int cena;
      int lol = 0;
      ifstream file("db.csv");
      string diena1;
      cin >> diena1;
      if (file.is_open()) {
        while (getline(file, line)) {
          vector<string> reissrinda;
          reissrinda.push_back(line);
          vector<string> reiss_atr;
          for (auto words : reissrinda) {
            stringstream ss(words);
            string str;
            while (getline(ss, str, ',')) {
              for (int i = str.length() - 1; i >= 0; --i) {
                if (str[i] == ' ')
                  str.erase(i, 1);
              }
              reiss_atr.push_back(str);
            }
          }
          if (reiss_atr.size() == 5 && reiss_atr[2] == diena1 &&
              irlaiks(reiss_atr[3]) && ircena(reiss_atr[4])) {
            linerez = reiss_atr[0] + " " + reiss_atr[1] + " " + reiss_atr[2] +
                      " " + reiss_atr[3] + " " + reiss_atr[4];
            if (lol == 0)
              cout << "result:"
                   << "\n";
            cout << linerez << "\n";
            lol = lol + 1;
            result.push_back(linerez);
          }
        }
        file.close();
      }
      break;
    }
    case 'c': {
      string line;
      string linerez;
      vector<string> result;
      int cena;
      int lol = 0;
      ifstream file("db.csv");
      float cena1;
      cin >> cena1;
      if (file.is_open()) {
        while (getline(file, line)) {
          vector<string> reissrinda;
          reissrinda.push_back(line);
          vector<string> reiss_atr;
          for (auto words : reissrinda) {
            stringstream ss(words);
            string str;
            while (getline(ss, str, ',')) {
              for (int i = str.length() - 1; i >= 0; --i) {
                if (str[i] == ' ')
                  str.erase(i, 1);
              }
              reiss_atr.push_back(str);
            }
          }
          if (reiss_atr.size() == 5 &&
              find(dienas.begin(), dienas.end(), reiss_atr[2]) !=
                  dienas.end() &&
              irlaiks(reiss_atr[3]) && ircena(reiss_atr[4]) &&
              stof(reiss_atr[4]) <= cena1) {
            linerez = reiss_atr[0] + " " + reiss_atr[1] + " " + reiss_atr[2] +
                      " " + reiss_atr[3] + " " + reiss_atr[4];
            if (lol == 0)
              cout << "result:"
                   << "\n";
            cout << linerez << endl;
            lol = lol + 1;
            result.push_back(linerez);
          }
        }
        file.close();
      }
      break;
    }
    case 'd': {
      string line;
      vector<string> rez;
      ifstream erfile("err.txt");
      if (erfile.is_open()) {
        while (getline(erfile, line)) {
          if (line == "")
            continue;
          if (find(rez.begin(), rez.end(), line) != rez.end())
            rez.push_back(line);
          // cout << line <<endl;
        }
      }
      erfile.close();
      for (int r = 0; r < rez.size(); r++)
        cout << rez[r] << endl;
      break;
    }
    case 'e': {
      ara = true;
      remove("err.txt");
      break;
    }
    }
  }
  // cout << "esmu ārā";
}