
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

void printLine(vector<string> &vec) {
  for (string s : vec)
    cout << s << " ";
  cout << endl;
}

bool checkString(string *str) {
  vector<string> weekDays = {"Pr", "Ot", "Tr", "Ce", "Pt", "Se", "Sv"};

  bool res = true;
  string temp = *(str + 2);
  for (string s : weekDays) {
    if (temp == s)
      break;
    else if (s == "Sv")
      return false;
  }

  temp = *(str + 3);

  try {
    int t1 = stoi(temp.substr(0, 2));
    int t2 = stoi(temp.substr(3, 2));
    if (t1 < 0 || t2 < 0 || t1 > 23 || t2 > 59 || temp[2] != ':')
      return false;
  } catch (...) {
    return false;
  }

  temp = *(str + 4);

  try {
    if(temp.find(".") + 3 == temp.length() && stof(temp)>0)
      return true;
    return false;
  } catch (...) {
    return false;
  }
}

void printErrorFile() {
  ifstream file;
  file.open("err.txt");
  string str;
  if (file.is_open())
    while (getline(file, str))
      cout << str << endl;
  file.close();
}

void printLowerPrices(vector<vector<string>> &vector, float price) {
  for (int i = 0; i < vector.size(); i++)
    if (stof(vector[i][4]) < price)
      printLine(vector[i]);
}

void printRoutes(vector<vector<string>> &vector, string start, string destination) {
  for (int i = 0; i < vector.size(); i++)
    if (vector[i][0] == start && vector[i][1] == destination)
      printLine(vector[i]);
}

void printDates(vector<vector<string>> &vector, string date){
  for (int i = 0; i < vector.size(); i++)
    if (vector[i][2] == date)
      printLine(vector[i]);
}

int main() {
  ifstream file;
  file.open("db.csv");

  if (!file)
    return 0;

  vector<string> lines;

  string str;
  if (file.is_open()) {
    while (getline(file, str)) {
      str.erase(remove_if(str.begin(), str.end(), ::isspace), str.end());
      if (!str.empty())
        lines.push_back(str);
    }
    file.close();
  }

  vector<vector<string>> info;
  vector<string> badInfo;

  for (string s : lines) {
    string tempArr[5];
    int i = 0;
    int i1 = 0, i2 = 0;
    string t;
    do {
      if (i == 5) {
        i++;
        break;
      }
      i2 = s.find(",", i1);
      t = s.substr(i1, i2 - i1);
      i1 = i2 + 1;
      tempArr[i] = t;
      i++;
    } while (i2 != s.npos);
    if (i != 5 || !checkString(tempArr))
      badInfo.push_back(s);
    else
      info.push_back(
          {tempArr[0], tempArr[1], tempArr[2], tempArr[3], tempArr[4]});
  }

  ofstream errFile("err.txt");
  for (string s : badInfo) {
    errFile << s << endl;
  };
  errFile.close();

  while (true) {
    string input;
    cin >> input;
    if (input == "a") {      
      string str1, str2;
      cin >> str1;
      cin >> str2;
      cout << "result:" << endl;
      printRoutes(info, str1, str2);
    } 
    else if (input == "b") {
      string date;
      cin >> date;
      cout << "result:" << endl;
      printDates(info, date);
    } 
    else if (input == "c") {
      float price;
      cin >> price;
      cout << "result:" << endl;
      printLowerPrices(info, price);
    } 
    else if (input == "d") {
      cout << "result:" << endl;
      printErrorFile();
    } 
    else if (input == "e")
      break;
  }

  return 0;
}